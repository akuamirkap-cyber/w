import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NEMO_VARIANT_IDS, SKINS, isNemoSkinId, skinToSpecies } from "../game/species";
import type { Species } from "../game/species";
import { spritePreviewFrameSingle, coinSprite } from "../game/sprites";
import type { JawState } from "../game/sprites";
import { fish3d, isSoftwareWebGL } from "../game/fish3d";
import Fish3DViewport from "./Fish3DViewport";
import type { BgStyle, GraphicsMode, OceanLightingMode, ReefMixMode, ReefRockMode, SaveData, SoundPack } from "../save";
import { UPGRADE_COSTS, MAX_UPGRADE } from "../save";
import type { Upgrades } from "../game/engine";
import { sfx } from "../game/audio";
import { TROPHIES, formatSecShort, isTrophyMet, localizeTitleReward } from "../trophies";
import {
  NEMO_VARIANT_META,
  UI_TEXT,
  getLocalizedSkinName,
  getLocalizedSkinSubtitle,
} from "../i18n";

interface Props {
  save: SaveData;
  setSave: (s: SaveData) => void;
  onPlay: (skinIdOverride?: string) => void;
  onOpenTrophies: () => void;
  loading?: boolean;
  loadPct?: number;
  paused?: boolean;
  muted?: boolean;
  onToggleMute?: () => void;
}

type ModalTab = "hub" | "theme" | "setting" | "nemo" | null;
type HubTab = "records" | "upgrades" | "skins";
type SkinFilter = "all" | "predator" | "reef" | "rare";

const UPGRADE_META: {
  id: keyof Upgrades;
  icon: string;
  en: { name: string; desc: string };
  idText: { name: string; desc: string };
}[] = [
  {
    id: "suck",
    icon: "🌀",
    en: { name: "Super Suction", desc: "Wider & stronger water suction current." },
    idText: { name: "Sedotan Super", desc: "Jangkauan & tarikan arus sedot lebih luas." },
  },
  {
    id: "speed",
    icon: "💨",
    en: { name: "Turbo Fins", desc: "Swim & maneuver much faster in the ocean." },
    idText: { name: "Sirip Turbo", desc: "Berenang & bermanuver jauh lebih lincah." },
  },
  {
    id: "size",
    icon: "🍔",
    en: { name: "Big Catch", desc: "Enter the ocean with a larger starting size." },
    idText: { name: "Ikan Bongsor", desc: "Masuk lautan dengan ukuran awal lebih besar." },
  },
];

export function coinURL() {
  return coinSprite(0).toDataURL();
}

type OpaqueBox = { minX: number; minY: number; maxX: number; maxY: number };

const TILE_CANVASES_2D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const TILE_BOX_2D: Record<string, OpaqueBox> = {};
const TILE_CANVASES_3D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const BITE_CANVASES_2D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const BITE_CANVASES_3D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const CTX_CACHE = new WeakMap<HTMLCanvasElement, CanvasRenderingContext2D>();

// Full 8-frame continuous swim cycle (matches sprites.ts TAIL_FRAMES = 8) for ultra-smooth zero-skip swimming
const SWIM_FRAMES = 8;
const BITE_CYCLE: JawState[] = [3, 6, -1, 0];

const TILE_SCALE: Record<string, number> = {
  orange: 0.78,
  nemo_panda: 0.78,
  nemo_yellow: 0.78,
  nemo_blue: 0.78,
  nemo_storm: 0.78,
  nemo_black: 0.78,
  buntal: 0.86,
  dori: 0.92,
  pierre: 0.92,
  layla: 0.94,
  andy: 0.95,
  andy_blue: 0.95,
  boris: 0.95,
  kakatua: 0.96,
  peter: 0.96,
  eddy: 0.98,
  leon: 1.02,
  idol: 1.0,
  layaran: 1.04,
  pari: 1.06,
  hiu: 1.06,
  hiu_elegan: 1.06,
  hiu_totol: 1.06,
  orca: 1.06,
  mandarin: 1.02,
  aurora: 1.04,
  narwhal: 1.06,
  seadragon: 1.06,
  axolotl: 1.02,
  tuna: 1.04,
  hammerhead: 1.04,
  butterfly: 0.96,
  snapper: 1.0,
  lumba: 1.04,
  lumba_pink: 1.04,
  snapturtle: 1.06,
  snapturtle_albino: 1.06,
  boxfish: 0.94,
  seahorse: 1.0,
  nudibranch: 1.02,
  sotong: 1.02,
  manta: 1.06,
  penyu: 1.04,
  gurita_cincin_biru: 1.02,
  hiu_paus: 1.06,
};

const PREDATOR_SKIN_IDS = new Set([
  "orca",
  "hiu",
  "hiu_elegan",
  "hiu_totol",
  "hammerhead",
  "eddy",
  "snapturtle",
  "snapturtle_albino",
  "layaran",
  "pari",
  "manta",
  "hiu_paus",
]);

function drawFishCanvas(
  cv: HTMLCanvasElement | null,
  frame: HTMLCanvasElement | undefined,
  cssW: number,
  cssH: number,
  scaleMult: number,
  maxDpr = 1.6
) {
  if (!cv || !frame) return;
  const dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
  const pw = Math.round(cssW * dpr);
  const ph = Math.round(cssH * dpr);
  if (cv.width !== pw || cv.height !== ph) {
    cv.width = pw;
    cv.height = ph;
  }
  let ctx = CTX_CACHE.get(cv);
  if (!ctx) {
    const got = cv.getContext("2d");
    if (!got) return;
    CTX_CACHE.set(cv, got);
    ctx = got;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const pad = 6;
  const fit = Math.min((cssW - pad * 2) / frame.width, (cssH - pad * 2) / frame.height) * scaleMult;
  const dw = frame.width * fit;
  const dh = frame.height * fit;

  ctx.drawImage(frame, cssW * 0.5 - dw * 0.5, cssH * 0.5 - dh * 0.5, dw, dh);
}

function computeCarouselSlotPose(d: number, trackW: number) {
  const isNarrow = trackW < 560;
  const stepX = isNarrow
    ? Math.max(134, trackW * 0.44)
    : Math.max(150, Math.min(224, trackW * 0.225));
  const fadeStart = isNarrow ? 0.48 : 2.05;
  const fadeEnd = isNarrow ? 1.28 : 2.88;
  const ad = Math.abs(d);
  const x = Math.sign(d) * stepX * (ad * 1.04 - Math.pow(Math.min(ad, 3.2), 1.42) * 0.06);
  const y = Math.pow(Math.min(ad, 3), 1.45) * 6;
  const s = Math.max(
    0.34,
    1.0 - 0.34 * Math.min(1, ad) - 0.16 * Math.max(0, Math.min(1, ad - 1)) - 0.12 * Math.max(0, ad - 2)
  );
  const op = Math.max(0, Math.min(1, 1 - (ad - fadeStart) / (fadeEnd - fadeStart)));
  return {
    transform: `translate3d(${x.toFixed(2)}px, ${y.toFixed(2)}px, 0) scale(${s.toFixed(4)})`,
    opacity: op.toFixed(3),
    zIndex: Math.round(30 - ad * 8),
    pointerEvents: (op > 0.22 ? "auto" : "none") as "auto" | "none",
  };
}

function CornerRivets() {
  return (
    <>
      <div className="pointer-events-none absolute top-2 left-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute bottom-2 left-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute bottom-2 right-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
    </>
  );
}

/* ============ WAVING TITLE & VECTOR ICONS ============ */

const TITLE_LETTERS: { ch: string; io: boolean }[] = [
  { ch: "F", io: false },
  { ch: "i", io: false },
  { ch: "s", io: false },
  { ch: "h", io: false },
  { ch: ".", io: true },
  { ch: "i", io: true },
  { ch: "o", io: true },
];

function WavingFishTitle({ sizeClass }: { sizeClass: string }) {
  return (
    <h1
      className={`font-display font-extrabold leading-none tracking-tight flex items-baseline select-none ${sizeClass}`}
      aria-label="Fish.io"
    >
      {TITLE_LETTERS.map((item, idx) => (
        <span
          key={idx}
          className={`fish-wave-letter ${item.io ? "fish-word-io" : "fish-word-gold"}`}
          style={{ animationDelay: `${idx * 0.12}s` }}
        >
          {item.ch}
        </span>
      ))}
    </h1>
  );
}

/* 2D SVG loading fish removed — loading gauge renders live 3D fish snapshots from fish3d.ts */

function GoldenCrownIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 88 64" className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="crownGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="45%" stopColor="#FFD22B" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
      </defs>
      <path
        d="M15 49 L9 21 L28 33 L44 13 L60 33 L79 21 L73 49 Z"
        fill="url(#crownGold)"
        stroke="#5C2802"
        strokeWidth="3.5"
        strokeLinejoin="round"
      />
      <rect x="14" y="47" width="60" height="9" rx="4.5" fill="#F59E0B" stroke="#5C2802" strokeWidth="3.2" />
      <circle cx="9" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="44" cy="10" r="5.5" fill="#FFF3A1" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="79" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="44" cy="36" r="3.6" fill="#EF4444" stroke="#5C2802" strokeWidth="1.8" />
      <circle cx="28" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
      <circle cx="60" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
    </svg>
  );
}

function GoldenArrowIcon({ dir }: { dir: "left" | "right" }) {
  return (
    <svg
      viewBox="0 0 64 76"
      className={`w-13 h-16 sm:w-18 sm:h-22 md:w-20 md:h-24 ${dir === "right" ? "scale-x-[-1]" : ""}`}
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`arrG-${dir}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="48%" stopColor="#FFCA1A" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>
      <path
        d="M11 38 C11 33 14 29 19 25 L43 9 C50 5 57 9 57 17 V59 C57 67 50 71 43 67 L19 51 C14 47 11 43 11 38 Z"
        fill={`url(#arrG-${dir})`}
        stroke="#FFFFFF"
        strokeWidth="5.5"
        strokeLinejoin="round"
      />
      <path
        d="M11 38 C11 33 14 29 19 25 L43 9 C50 5 57 9 57 17 V59 C57 67 50 71 43 67 L19 51 C14 47 11 43 11 38 Z"
        fill="none"
        stroke="#782C04"
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      <path
        d="M49 16 L24 33 C21 35 20 37 20 38"
        stroke="#FFFBEB"
        strokeWidth="3"
        strokeLinecap="round"
        opacity="0.7"
      />
    </svg>
  );
}

function TrophyCupIcon() {
  return (
    <svg viewBox="0 0 48 48" className="w-8 h-8 sm:w-10 sm:h-10 shrink-0 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="cupGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="50%" stopColor="#FFCA1A" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
      </defs>
      <path d="M13 12 H7 C7 20 10 24 15 24" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
      <path d="M35 12 H41 C41 20 38 24 33 24" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
      <path
        d="M13 8 H35 V20 C35 27 30 32 24 32 C18 32 13 27 13 20 Z"
        fill="url(#cupGold)"
        stroke="#5C2802"
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <rect x="21" y="31" width="6" height="7" fill="#F59E0B" stroke="#5C2802" strokeWidth="2.2" />
      <rect x="15" y="37" width="18" height="6" rx="2.5" fill="#D97706" stroke="#5C2802" strokeWidth="2.4" />
      <path d="M18 13 V21" stroke="#FFFBEB" strokeWidth="2.4" strokeLinecap="round" opacity="0.75" />
    </svg>
  );
}

function GoldStarIcon() {
  return (
    <svg viewBox="0 0 48 48" className="w-8 h-8 sm:w-10 sm:h-10 shrink-0 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="starGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="50%" stopColor="#FFD22B" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>
      <path
        d="M24 5 L29.7 16.6 L42.5 18.4 L33.2 27.4 L35.4 40.2 L24 34.1 L12.6 40.2 L14.8 27.4 L5.5 18.4 L18.3 16.6 Z"
        fill="url(#starGold)"
        stroke="#5C2802"
        strokeWidth="2.8"
        strokeLinejoin="round"
      />
      <path d="M24 10 L20.5 17.5" stroke="#FFFBEB" strokeWidth="2.2" strokeLinecap="round" opacity="0.75" />
    </svg>
  );
}

function TropicalIslandIcon({ className = "w-14 h-12 sm:w-16 sm:h-14" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 56" className={`${className} shrink-0 drop-shadow-[0_3px_5px_rgba(0,0,0,0.55)]`} fill="none" aria-hidden="true">
      <ellipse cx="32" cy="44" rx="24" ry="7" fill="#38BDF8" stroke="#083366" strokeWidth="2" opacity="0.85" />
      <path d="M12 43 C15 33 49 33 52 43 C44 47 20 47 12 43 Z" fill="#FCD34D" stroke="#78350F" strokeWidth="2.3" />
      <path d="M31 37 C29 29 30 22 33 17" stroke="#78350F" strokeWidth="5.5" strokeLinecap="round" />
      <path d="M31 37 C29 29 30 22 33 17" stroke="#D97706" strokeWidth="3.2" strokeLinecap="round" />
      <path d="M33 17 C24 10 14 14 12 22 C20 19 26 19 33 17 Z" fill="#22C55E" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C27 7 35 4 41 9 C38 13 35 15 33 17 Z" fill="#4ADE80" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C42 10 52 14 54 22 C46 19 40 19 33 17 Z" fill="#16A34A" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C23 18 18 25 21 30 C25 25 29 21 33 17 Z" fill="#15803D" stroke="#14532D" strokeWidth="1.8" strokeLinejoin="round" />
      <path d="M33 17 C43 18 48 25 45 30 C41 25 37 21 33 17 Z" fill="#22C55E" stroke="#14532D" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

/** Wooden Ship's Steering Wheel (Setir Kapal Kayu) */
function WoodenShipWheelIcon({ className = "w-14 h-14 sm:w-16 sm:h-16" }: { className?: string }) {
  const angles = [0, 45, 90, 135, 180, 225, 270, 315];
  return (
    <svg viewBox="0 0 64 64" className={`${className} shrink-0 drop-shadow-[0_3px_6px_rgba(0,0,0,0.6)]`} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="woodWheelRim" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#DDA15E" />
          <stop offset="50%" stopColor="#A96228" />
          <stop offset="100%" stopColor="#6D3812" />
        </linearGradient>
        <linearGradient id="brassHub" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF3A1" />
          <stop offset="55%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#92400E" />
        </linearGradient>
      </defs>

      {angles.map((deg) => (
        <g key={deg} transform={`rotate(${deg} 32 32)`}>
          <rect x="30" y="7" width="4" height="22" rx="1.5" fill="#9A5622" stroke="#2D1304" strokeWidth="1.8" />
          <rect x="28.6" y="3.5" width="6.8" height="8" rx="3" fill="#C97A39" stroke="#2D1304" strokeWidth="2" />
          <circle cx="32" cy="5.5" r="1.4" fill="#FDE68A" opacity="0.85" />
        </g>
      ))}

      <circle cx="32" cy="32" r="18.5" stroke="#2D1304" strokeWidth="10" />
      <circle cx="32" cy="32" r="18.5" stroke="url(#woodWheelRim)" strokeWidth="6.2" />
      <path d="M18 20 A18 18 0 0 1 44 19" stroke="#F6C88C" strokeWidth="1.6" strokeLinecap="round" opacity="0.65" />

      <circle cx="32" cy="32" r="7.2" fill="url(#brassHub)" stroke="#2D1304" strokeWidth="2.4" />
      <circle cx="32" cy="32" r="2.8" fill="#451A03" />
      <circle cx="31" cy="31" r="1" fill="#FFFBEB" opacity="0.8" />
    </svg>
  );
}

export default function Menu({
  save,
  setSave,
  onPlay,
  onOpenTrophies,
  loading = false,
  loadPct = 0,
  paused = false,
  muted = false,
  onToggleMute,
}: Props) {
  const lang = save.lang;
  const t = UI_TEXT[lang];
  const softWebGL = useMemo(() => isSoftwareWebGL(), []);

  const [modal, setModal] = useState<ModalTab>(null);
  const [hubTab, setHubTab] = useState<HubTab>("records");
  const [skinFilter, setSkinFilter] = useState<SkinFilter>("all");
  const [skinQuery, setSkinQuery] = useState("");
  const [biteTrig, setBiteTrig] = useState(0);
  const [toast, setToast] = useState<{ icon: string; msg: string } | null>(null);

  const cur = useMemo(() => SKINS.find((s) => s.id === save.skin) || SKINS[0], [save.skin]);
  const activeIdx = useMemo(() => Math.max(0, SKINS.findIndex((s) => s.id === cur.id)), [cur.id]);

  const nemoSkins = useMemo(
    () =>
      NEMO_VARIANT_IDS.map((id) => {
        const origIdx = SKINS.findIndex((s) => s.id === id);
        return { skin: SKINS[origIdx], origIdx };
      }).filter((x) => x.origIdx >= 0 && !!x.skin),
    []
  );

  const modSkinIdx = useCallback((v: number) => {
    const total = SKINS.length;
    return ((v % total) + total) % total;
  }, []);

  const saveRef = useRef(save);
  saveRef.current = save;
  const setSaveRef = useRef(setSave);
  setSaveRef.current = setSave;
  const langRef = useRef(lang);
  langRef.current = lang;

  const [carouselSettled, setCarouselSettled] = useState<boolean>(true);
  const [heroLiveReady, setHeroLiveReady] = useState(false);
  const [viewportSpecies, setViewportSpecies] = useState<Species>(() => skinToSpecies(cur, true));
  const [heroIsNemo, setHeroIsNemo] = useState<boolean>(() => isNemoSkinId(cur.id));

  const activeIdxRef = useRef(activeIdx);
  activeIdxRef.current = activeIdx;
  const virtualTargetRef = useRef<number>(activeIdx);
  const visualPosRef = useRef<number>(activeIdx);
  const carouselAnchorRef = useRef<number>(activeIdx);
  const carouselSettledRef = useRef<boolean>(true);
  const lastLabelIdxRef = useRef<number>(activeIdx);

  const carouselTrackRef = useRef<HTMLDivElement | null>(null);
  const trackWRef = useRef<number>(880);
  const slotWrapRefs = useRef<(HTMLButtonElement | null)[]>(new Array(9).fill(null));
  const slotCanvasRefs = useRef<(HTMLCanvasElement | null)[]>(new Array(9).fill(null));
  const slotVirtualRef = useRef<number[]>(new Array(9).fill(Number.NaN));
  const slotDrawnKeyRef = useRef<(string | undefined)[]>(new Array(9).fill(undefined));
  const heroAuraRef = useRef<HTMLDivElement | null>(null);
  const heroCrownRef = useRef<HTMLDivElement | null>(null);
  const heroNameRef = useRef<HTMLDivElement | null>(null);
  const settleCommitTimerRef = useRef<number | undefined>(undefined);
  const dragStateRef = useRef<{
    pointerId: number;
    startX: number;
    lastX: number;
    lastT: number;
    velSlots: number;
    startVisual: number;
    moved: boolean;
  } | null>(null);
  const suppressClickRef = useRef(false);
  const suppressClickTimerRef = useRef<number | undefined>(undefined);
  const bgBakeCursorRef = useRef<number>(0);

  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const modalRef = useRef<ModalTab>(modal);
  modalRef.current = modal;
  const hubTabRef = useRef<HubTab>(hubTab);
  hubTabRef.current = hubTab;
  const nemoIndicesRef = useRef<number[]>([]);
  nemoIndicesRef.current = nemoSkins.map((x) => x.origIdx);
  const lastNemoSkinRef = useRef<string>(isNemoSkinId(save.skin) ? save.skin : "orange");
  if (isNemoSkinId(save.skin)) {
    lastNemoSkinRef.current = save.skin;
  }
  const loadingRef = useRef(loading);
  loadingRef.current = loading;
  const softWebGLRef = useRef(softWebGL);
  softWebGLRef.current = softWebGL;

  const loadingCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastLoadingCanvasElRef = useRef<HTMLCanvasElement | null>(null);
  const loadingDrawnKeyRef = useRef<string | undefined>(undefined);

  const gridScrollRef = useRef<HTMLDivElement | null>(null);
  const tileRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const tileCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const drawnKeysRef = useRef<(string | undefined)[]>([]);
  const nemoPickerCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const nemoDrawnKeysRef = useRef<(string | undefined)[]>([]);

  const softBiteUntilRef = useRef(0);
  const toastTimerRef = useRef<number | undefined>(undefined);
  const isScrollingRef = useRef(false);
  const scrollIdleTimerRef = useRef<number | undefined>(undefined);
  const scrollTopRef = useRef(0);
  const scrollerHRef = useRef(440);
  const tileBoundsRef = useRef<{ top: number; bottom: number }[]>([]);
  const lastDrawStepRef = useRef(-1);

  const unlockedTrophyCount = useMemo(
    () => TROPHIES.filter((tItem) => !!save.unlockedTrophies[tItem.id] || isTrophyMet(tItem, save)).length,
    [
      save.unlockedTrophies,
      save.best,
      save.rank1Count,
      save.peakLevelCount,
      save.bestPeakTimeSec,
      save.bestCombo,
      save.bestDepth,
      save.totalRuns,
    ]
  );

  const coin = useMemo(() => coinURL(), []);
  // All fish showcased in the menu & loading screen always use 3D models
  const heroIs3D = !!(cur.is3D || cur.supports3D);
  const targetSkinForViewport = SKINS[modSkinIdx(virtualTargetRef.current)] || cur;
  const viewportMatchesTarget = viewportSpecies.id === `skin-${targetSkinForViewport.id}`;
  const showLiveHero3D = !loading && !softWebGL && heroIs3D && !paused && modal === null && carouselSettled && viewportMatchesTarget;

  const handleHeroFirstRender = useCallback(() => {
    setHeroLiveReady(true);
  }, []);

  const applyCarouselVisuals = useCallback(
    (vPos: number) => {
      const anchor = Math.round(vPos);
      carouselAnchorRef.current = anchor;
      const trackW = trackWRef.current || 880;
      const total = SKINS.length;

      for (let off = -4; off <= 4; off++) {
        const vIdx = anchor + off;
        const si = ((vIdx % 9) + 9) % 9;
        const el = slotWrapRefs.current[si];
        if (!el) continue;

        if (slotVirtualRef.current[si] !== vIdx) {
          slotVirtualRef.current[si] = vIdx;
          slotDrawnKeyRef.current[si] = undefined;
          const idx = ((vIdx % total) + total) % total;
          const s = SKINS[idx];
          if (s) {
            const sName = getLocalizedSkinName(s.id, s.name, langRef.current);
            el.setAttribute("aria-label", sName);
            const cv = slotCanvasRefs.current[si];
            const cached = TILE_CANVASES_3D[s.id]?.[0];
            if (cv && cached) {
              slotDrawnKeyRef.current[si] = `${s.id}|1|0`;
              drawFishCanvas(cv, cached, 260, 172, (TILE_SCALE[s.id] ?? 1) * 1.04, 1.25);
            }
          }
        }

        const pose = computeCarouselSlotPose(vIdx - vPos, trackW);
        el.style.transform = pose.transform;
        el.style.opacity = pose.opacity;
        el.style.zIndex = String(pose.zIndex);
        el.style.pointerEvents = pose.pointerEvents;
      }

      const distNearest = Math.abs(vPos - anchor);
      const focus = Math.max(0, 1 - distNearest * 1.75);
      if (heroAuraRef.current) {
        heroAuraRef.current.style.opacity = (0.35 + 0.65 * focus).toFixed(3);
      }
      if (heroCrownRef.current) {
        heroCrownRef.current.style.opacity = (0.38 + 0.62 * focus).toFixed(3);
        heroCrownRef.current.style.transform = `translate3d(0, ${((1 - focus) * 9).toFixed(2)}px, 0) scale(${(
          0.84 +
          0.16 * focus
        ).toFixed(3)})`;
      }

      const centerIdx = ((anchor % total) + total) % total;
      if (centerIdx !== lastLabelIdxRef.current) {
        lastLabelIdxRef.current = centerIdx;
        const centerSkin = SKINS[centerIdx];
        if (centerSkin && heroNameRef.current) {
          heroNameRef.current.textContent = getLocalizedSkinName(centerSkin.id, centerSkin.name, langRef.current);
        }
      }
    },
    []
  );

  useEffect(() => {
    lastLabelIdxRef.current = -1;
  }, [lang]);

  // Measure carousel track width with ResizeObserver (zero forced reflow inside rAF/pointermove)
  useEffect(() => {
    if (loading) return;
    const trackEl = carouselTrackRef.current;
    if (!trackEl) return;
    trackWRef.current = trackEl.clientWidth || 880;
    applyCarouselVisuals(visualPosRef.current);
    const ro =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver((entries) => {
            const w = entries[0]?.contentRect?.width || trackEl.clientWidth;
            if (w > 0) {
              trackWRef.current = w;
              applyCarouselVisuals(visualPosRef.current);
            }
          })
        : null;
    ro?.observe(trackEl);
    return () => ro?.disconnect();
  }, [loading, applyCarouselVisuals]);

  // Debounced commit on settle: zero React re-renders or WebGL rig swaps during rapid clicks/swipes
  useEffect(() => {
    clearTimeout(settleCommitTimerRef.current);
    if (!carouselSettled) {
      setHeroLiveReady(false);
      return;
    }
    settleCommitTimerRef.current = window.setTimeout(() => {
      const idx = modSkinIdx(virtualTargetRef.current);
      const targetSkin = SKINS[idx];
      if (!targetSkin) return;
      if (isNemoSkinId(targetSkin.id)) lastNemoSkinRef.current = targetSkin.id;
      setHeroIsNemo(isNemoSkinId(targetSkin.id));
      if (targetSkin.id !== saveRef.current.skin) {
        setSaveRef.current({ ...saveRef.current, skin: targetSkin.id });
      }
      setViewportSpecies((prev) => (prev.id === `skin-${targetSkin.id}` ? prev : skinToSpecies(targetSkin, true)));
    }, 65);
    return () => clearTimeout(settleCommitTimerRef.current);
  }, [carouselSettled, modSkinIdx]);

  const commitTargetSkinNow = useCallback(() => {
    const idx = modSkinIdx(virtualTargetRef.current);
    const targetSkin = SKINS[idx];
    if (!targetSkin) return;
    if (isNemoSkinId(targetSkin.id)) lastNemoSkinRef.current = targetSkin.id;
    setHeroIsNemo(isNemoSkinId(targetSkin.id));
    if (targetSkin.id !== saveRef.current.skin) {
      setSaveRef.current({ ...saveRef.current, skin: targetSkin.id });
    }
  }, [modSkinIdx]);

  const localizedEquippedTitle = useMemo(
    () => localizeTitleReward(save.equippedTitle, lang),
    [save.equippedTitle, lang]
  );

  const showToastMsg = useCallback((icon: string, msg: string) => {
    setToast({ icon, msg });
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 2000);
  }, []);

  const triggerTestBite = useCallback(() => {
    sfx.init();
    if (sfx.pack === "wav") {
      void sfx.whenReady(["bite1", "bite2", "eat"]).then(() => {
        if (sfx.pack === "wav") sfx.gulp(1.0, true, 0);
      });
    } else {
      sfx.gulp(1.0, true, 0);
    }
    const activeSkin = SKINS[modSkinIdx(virtualTargetRef.current)];
    const usesLive3D =
      !loadingRef.current &&
      !softWebGLRef.current &&
      carouselSettledRef.current &&
      !!(activeSkin?.is3D || activeSkin?.supports3D);
    if (!usesLive3D) {
      softBiteUntilRef.current = performance.now() + 820;
    } else {
      setBiteTrig((c) => c + 1);
    }
  }, [modSkinIdx]);

  const glideToSkinIndex = useCallback(
    (targetRealIdx: number) => {
      const total = SKINS.length;
      const curReal = modSkinIdx(virtualTargetRef.current);
      let delta = targetRealIdx - curReal;
      if (delta > total / 2) delta -= total;
      if (delta < -total / 2) delta += total;
      if (delta !== 0) {
        virtualTargetRef.current += delta;
        if (carouselSettledRef.current) {
          carouselSettledRef.current = false;
          setCarouselSettled(false);
        }
      }
      const nextSkin = SKINS[targetRealIdx];
      if (!nextSkin) return;
      if (isNemoSkinId(nextSkin.id)) lastNemoSkinRef.current = nextSkin.id;
      if (modalRef.current !== null) {
        setHeroIsNemo(isNemoSkinId(nextSkin.id));
        if (nextSkin.id !== saveRef.current.skin) {
          setSaveRef.current({ ...saveRef.current, skin: nextSkin.id });
        }
      }
    },
    [modSkinIdx]
  );

  const stepCarousel = useCallback((delta: number) => {
    if (delta === 0) return;
    virtualTargetRef.current += delta;
    if (carouselSettledRef.current) {
      carouselSettledRef.current = false;
      setCarouselSettled(false);
    }
  }, []);

  const selectSkin = useCallback(
    (skinId: string, openNemoIfAlreadySelected = true) => {
      if (isNemoSkinId(skinId)) {
        lastNemoSkinRef.current = skinId;
        if (save.skin === skinId) {
          if (openNemoIfAlreadySelected) setModal("nemo");
          else triggerTestBite();
        } else {
          const idx = SKINS.findIndex((s) => s.id === skinId);
          if (idx >= 0) glideToSkinIndex(idx);
        }
        return;
      }
      if (save.skin === skinId) {
        triggerTestBite();
        return;
      }
      const idx = SKINS.findIndex((s) => s.id === skinId);
      if (idx >= 0) glideToSkinIndex(idx);
    },
    [glideToSkinIndex, save.skin, triggerTestBite]
  );

  const pickNemoVariant = useCallback(
    (skinId: string) => {
      lastNemoSkinRef.current = skinId;
      if (save.skin === skinId) {
        triggerTestBite();
      } else {
        const idx = SKINS.findIndex((s) => s.id === skinId);
        if (idx >= 0) glideToSkinIndex(idx);
        const chosen = SKINS.find((s) => s.id === skinId);
        if (chosen) {
          showToastMsg("🐠", `${t.nemoActiveToast} ${getLocalizedSkinName(chosen.id, chosen.name, lang)}!`);
        }
      }
    },
    [glideToSkinIndex, lang, save.skin, showToastMsg, t.nemoActiveToast, triggerTestBite]
  );

  const pickRandomSkin = useCallback(() => {
    const total = SKINS.length;
    if (total <= 1) return;
    let nextIdx = activeIdx;
    while (nextIdx === activeIdx) {
      nextIdx = Math.floor(Math.random() * total);
    }
    const chosen = SKINS[nextIdx];
    if (isNemoSkinId(chosen.id)) lastNemoSkinRef.current = chosen.id;
    setSkinFilter("all");
    setSkinQuery("");
    glideToSkinIndex(nextIdx);
    showToastMsg("🎲", `${t.randomFishToast} ${getLocalizedSkinName(chosen.id, chosen.name, lang)}!`);
    requestAnimationFrame(() => {
      tileRefs.current[nextIdx]?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }, [activeIdx, glideToSkinIndex, lang, showToastMsg, t.randomFishToast]);

  const buyUp = (id: keyof Upgrades) => {
    const lv = save.upgrades[id];
    if (lv >= MAX_UPGRADE) return;
    const cost = UPGRADE_COSTS[lv];
    if (save.coins < cost) {
      showToastMsg("⚠️", t.notEnoughCoins);
      return;
    }
    setSave({ ...save, coins: save.coins - cost, upgrades: { ...save.upgrades, [id]: lv + 1 } });
    const upg = UPGRADE_META.find((u) => u.id === id);
    const upgName = upg ? (lang === "id" ? upg.idText.name : upg.en.name) : "Upgrade";
    showToastMsg("⚡", `${upgName} ${t.upgradedTo} ${lv + 1}!`);
  };

  const filteredSkins = useMemo(() => {
    const q = skinQuery.trim().toLowerCase();
    const activeNemoId = isNemoSkinId(cur.id) ? cur.id : lastNemoSkinRef.current;
    return SKINS.map((skin, origIdx) => ({ skin, origIdx })).filter(({ skin }) => {
      if (!q && isNemoSkinId(skin.id) && skin.id !== activeNemoId) return false;
      if (skinFilter === "predator" && !PREDATOR_SKIN_IDS.has(skin.id)) return false;
      if (skinFilter === "rare" && !skin.rare) return false;
      if (skinFilter === "reef" && (skin.rare || PREDATOR_SKIN_IDS.has(skin.id))) return false;
      if (q) {
        const locName = getLocalizedSkinName(skin.id, skin.name, lang).toLowerCase();
        const locSub = getLocalizedSkinSubtitle(skin.id, skin.subtitle, lang).toLowerCase();
        if (!locName.includes(q) && !locSub.includes(q) && !skin.name.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [cur.id, lang, skinFilter, skinQuery]);

  const measureTileBounds = useCallback(() => {
    const scroller = gridScrollRef.current;
    if (!scroller) return;
    scrollTopRef.current = scroller.scrollTop;
    scrollerHRef.current = scroller.clientHeight || 440;
    const bounds: ({ top: number; bottom: number } | undefined)[] = new Array(SKINS.length);
    for (let i = 0; i < SKINS.length; i++) {
      const btn = tileRefs.current[i];
      if (btn && btn.isConnected) {
        const top = btn.offsetTop;
        bounds[i] = { top, bottom: top + btn.offsetHeight };
      }
    }
    tileBoundsRef.current = bounds as { top: number; bottom: number }[];
    lastDrawStepRef.current = -1;
  }, []);

  useEffect(() => {
    if (modal !== "hub" || hubTab !== "skins") return;
    const scroller = gridScrollRef.current;
    if (!scroller) return;
    measureTileBounds();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measureTileBounds) : null;
    ro?.observe(scroller);
    drawnKeysRef.current = [];
    return () => ro?.disconnect();
  }, [modal, hubTab, skinFilter, skinQuery, measureTileBounds]);

  useEffect(() => {
    lastDrawStepRef.current = -1;
    loadingDrawnKeyRef.current = undefined;
    nemoDrawnKeysRef.current = [];
  }, [save.mode3D, skinFilter, skinQuery, modal, hubTab, loading]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (paused || loading) return;
      if (e.key === "Escape" && modal) {
        e.preventDefault();
        setModal(null);
        return;
      }
      if (!modal) {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          stepCarousel(-1);
        } else if (e.key === "ArrowRight") {
          e.preventDefault();
          stepCarousel(1);
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [loading, modal, paused, stepCarousel]);

  // Smooth 60 FPS continuous sliding carousel + 8-frame fluid swim baking loop
  useEffect(() => {
    let alive = true;
    let raf = 0;
    let prevNow = performance.now();

    const buildOne2DFrame = (s: (typeof SKINS)[number], fi: number) => {
      let arr = TILE_CANVASES_2D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(SWIM_FRAMES);
        TILE_CANVASES_2D[s.id] = arr;
      }
      if (arr[fi]) return false;
      const box = TILE_BOX_2D[s.id];
      const res = spritePreviewFrameSingle(skinToSpecies(s, false), 160, 0, fi, box);
      if (!TILE_BOX_2D[s.id]) TILE_BOX_2D[s.id] = res.box;
      arr[fi] = res.canvas;
      return true;
    };

    const buildOne3DFrame = (s: (typeof SKINS)[number], fi: number) => {
      let arr = TILE_CANVASES_3D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(SWIM_FRAMES);
        TILE_CANVASES_3D[s.id] = arr;
      }
      if (arr[fi]) return false;
      const ph = (fi / SWIM_FRAMES) * Math.PI * 2;
      arr[fi] = fish3d.renderSnapshot(
        skinToSpecies(s, true),
        {
          jaw: 0,
          chompPhase: 0,
          chompDur: 0.13,
          chompBitFired: false,
          biteLunge: 0,
          tailPh: ph,
          wag2: ph,
          bend: Math.sin(ph) * 0.085,
          turnFlip: 1,
          tilt: Math.sin(ph) * 0.045,
          gulpT: 0,
          gulpK: 0,
          sq: 0,
          expr: "normal",
          puff: false,
          sucking: false,
          swimSpeed: 0.72,
          inspectYaw: -0.22,
          inspectPitch: 0.05,
        },
        220,
        140
      );
      return true;
    };

    const buildBite2DFrame = (s: (typeof SKINS)[number], bi: number) => {
      let arr = BITE_CANVASES_2D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(BITE_CYCLE.length);
        BITE_CANVASES_2D[s.id] = arr;
      }
      if (arr[bi]) return;
      const box = TILE_BOX_2D[s.id];
      const res = spritePreviewFrameSingle(skinToSpecies(s, false), 160, BITE_CYCLE[bi], bi, box);
      if (!TILE_BOX_2D[s.id]) TILE_BOX_2D[s.id] = res.box;
      arr[bi] = res.canvas;
    };

    const buildBite3DFrame = (s: (typeof SKINS)[number], bi: number) => {
      let arr = BITE_CANVASES_3D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(BITE_CYCLE.length);
        BITE_CANVASES_3D[s.id] = arr;
      }
      if (arr[bi]) return;
      const j = BITE_CYCLE[bi];
      const ph = (bi / BITE_CYCLE.length) * Math.PI * 2;
      arr[bi] = fish3d.renderSnapshot(
        skinToSpecies(s, true),
        {
          jaw: j > 0 ? j / 6 : j < 0 ? -0.18 : 0,
          chompPhase: j === -1 ? 0.08 : 0,
          chompDur: 0.13,
          chompBitFired: j === -1,
          biteLunge: j === -1 ? 1.6 : j >= 5 ? -0.5 : 0,
          tailPh: ph * 2,
          wag2: ph * 2,
          bend: Math.sin(ph) * 0.06,
          turnFlip: 1,
          tilt: Math.sin(ph) * 0.04,
          gulpT: j === -1 ? 0.65 : 0,
          gulpK: 0.65,
          sq: j === -1 ? 0.14 : 0,
          expr: j === -1 ? "happy" : "normal",
          puff: j === -1,
          sucking: false,
          swimSpeed: 0.65,
          inspectYaw: -0.22,
          inspectPitch: 0.05,
        },
        220,
        140
      );
    };

    const tick = (now: number) => {
      if (!alive) return;
      const dt = Math.min(0.032, Math.max(0.001, (now - prevNow) / 1000));
      prevNow = now;

      if (document.hidden || pausedRef.current) {
        raf = requestAnimationFrame(tick);
        return;
      }

      const activeModal = modalRef.current;
      const curHubTab = hubTabRef.current;
      const activeIndex = activeIdxRef.current;
      const isLoading = loadingRef.current;
      const totalSkins = SKINS.length;
      const wrapIdx = (v: number) => ((v % totalSkins) + totalSkins) % totalSkins;

      // 1. Advance continuous carousel spring physics & GPU transforms at locked 60+ FPS with ZERO React re-renders
      let isSliding = false;
      if (!isLoading) {
        const dragging = dragStateRef.current !== null;
        if (!dragging) {
          const diff = virtualTargetRef.current - visualPosRef.current;
          if (Math.abs(diff) > 0.0005) {
            const k = 1 - Math.exp(-15.5 * dt);
            visualPosRef.current += diff * k;
            if (Math.abs(virtualTargetRef.current - visualPosRef.current) < 0.0015) {
              visualPosRef.current = virtualTargetRef.current;
            }
          }
          const isSettled = Math.abs(virtualTargetRef.current - visualPosRef.current) <= 0.015;
          if (isSettled !== carouselSettledRef.current) {
            carouselSettledRef.current = isSettled;
            setCarouselSettled(isSettled);
          }
        }
        isSliding = dragging || !carouselSettledRef.current;
        applyCarouselVisuals(visualPosRef.current);
      }

      if (isScrollingRef.current) {
        raf = requestAnimationFrame(tick);
        return;
      }

      const visibleIndices: number[] = [];
      if (!isLoading && activeModal === "hub" && curHubTab === "skins") {
        const viewTop = scrollTopRef.current - 150;
        const viewBottom = scrollTopRef.current + scrollerHRef.current + 150;
        const bounds = tileBoundsRef.current;
        for (let i = 0; i < totalSkins; i++) {
          const b = bounds[i];
          if (!b) continue;
          if (b.bottom >= viewTop && b.top <= viewBottom) {
            visibleIndices.push(i);
          }
        }
      }

      const ringAnchor = isLoading ? activeIndex : carouselAnchorRef.current;
      const ringOrder = [0, -1, 1, -2, 2, -3, 3, -4, 4].map((off) => wrapIdx(ringAnchor + off));
      const pickerOpen = !isLoading && activeModal === "nemo";

      let bakedAny = false;

      // Pass 1: Frame 0 for instant 3D appearance. During active slide, ONLY bake a visible slot if completely missing.
      const pass1Order = isLoading
        ? ringOrder
        : isSliding
          ? ringOrder
          : (() => {
              const bgIdx = bgBakeCursorRef.current % totalSkins;
              bgBakeCursorRef.current = (bgIdx + 1) % totalSkins;
              return Array.from(
                new Set([
                  activeIndex,
                  ...ringOrder,
                  ...(pickerOpen ? nemoIndicesRef.current : []),
                  ...visibleIndices,
                  bgIdx,
                ])
              );
            })();

      for (const idx of pass1Order) {
        const s = SKINS[idx];
        if (!s) continue;
        const want3D = !!(s.is3D || s.supports3D);
        if (want3D) {
          if (!TILE_CANVASES_3D[s.id]?.[0]) {
            buildOne3DFrame(s, 0);
            bakedAny = true;
            break;
          }
        } else if (!s.is3D && !TILE_CANVASES_2D[s.id]?.[0]) {
          buildOne2DFrame(s, 0);
          bakedAny = true;
          break;
        }
      }

      // Pass 2: Smooth remaining 7 tail-swim 3D frames ONLY when carousel is settled (prevents WebGL readback stalls mid-slide)
      if (!bakedAny && !isSliding) {
        outer: for (const idx of pass1Order) {
          const s = SKINS[idx];
          if (!s) continue;
          const want3D = !!(s.is3D || s.supports3D);
          if (want3D) {
            const arr = TILE_CANVASES_3D[s.id];
            for (let fi = 1; fi < SWIM_FRAMES; fi++) {
              if (!arr || !arr[fi]) {
                buildOne3DFrame(s, fi);
                bakedAny = true;
                break outer;
              }
            }
          } else if (!s.is3D) {
            const arr = TILE_CANVASES_2D[s.id];
            for (let fi = 1; fi < SWIM_FRAMES; fi++) {
              if (!arr || !arr[fi]) {
                buildOne2DFrame(s, fi);
                bakedAny = true;
                break outer;
              }
            }
          }
        }
      }

      // ~18 FPS tail-swim step when settled
      const baseStep = Math.floor(now / 55);
      const isBiting = now < softBiteUntilRef.current;
      const shouldDraw = bakedAny || isBiting || (!isSliding && baseStep !== lastDrawStepRef.current);

      if (shouldDraw && isLoading) {
        lastDrawStepRef.current = baseStep;
        const loadSkin = SKINS[activeIndex] || SKINS[0];
        const lcv = loadingCanvasRef.current;
        if (lcv !== lastLoadingCanvasElRef.current) {
          lastLoadingCanvasElRef.current = lcv;
          loadingDrawnKeyRef.current = undefined;
        }
        const swimFrames = TILE_CANVASES_3D[loadSkin.id];
        if (lcv && swimFrames) {
          const fIdx = baseStep % swimFrames.length;
          let frame = swimFrames[fIdx];
          let actualIdx = fIdx;
          if (!frame) {
            for (let off = 1; off < swimFrames.length; off++) {
              const prev = (fIdx - off + swimFrames.length) % swimFrames.length;
              if (swimFrames[prev]) {
                frame = swimFrames[prev];
                actualIdx = prev;
                break;
              }
            }
          }
          const lKey = `load3d|${loadSkin.id}|${actualIdx}`;
          if (frame && loadingDrawnKeyRef.current !== lKey) {
            loadingDrawnKeyRef.current = lKey;
            drawFishCanvas(lcv, frame, 128, 80, (TILE_SCALE[loadSkin.id] ?? 1) * 1.06, 1.8);
          }
        }
      } else if (!isLoading) {
        if (!isSliding) lastDrawStepRef.current = baseStep;

        // Draw recycled carousel slots: during slide ONLY draw uninitialized slots; when settled animate 8-frame swimming
        const curAnchor = carouselAnchorRef.current;
        for (let off = -4; off <= 4; off++) {
          const vIdx = curAnchor + off;
          const si = ((vIdx % 9) + 9) % 9;
          const cv = slotCanvasRefs.current[si];
          if (!cv) continue;

          if (isSliding && slotDrawnKeyRef.current[si] !== undefined) continue;
          if (!isSliding && !shouldDraw && slotDrawnKeyRef.current[si] !== undefined) continue;

          const idx = wrapIdx(vIdx);
          const s = SKINS[idx];
          if (!s) continue;

          const use3DTile = !!(s.is3D || s.supports3D);
          if (isBiting && vIdx === virtualTargetRef.current) {
            const bi = Math.floor(now / 85) % BITE_CYCLE.length;
            if (use3DTile) buildBite3DFrame(s, bi);
            else if (!s.is3D) buildBite2DFrame(s, bi);
          }

          const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
          const swimFrames = has3D ? TILE_CANVASES_3D[s.id] : s.is3D ? undefined : TILE_CANVASES_2D[s.id];
          if (!swimFrames) continue;

          let frame: HTMLCanvasElement | undefined;
          let drawKey = "";
          if (isBiting && vIdx === virtualTargetRef.current) {
            const biteFrames = has3D ? BITE_CANVASES_3D[s.id] : BITE_CANVASES_2D[s.id];
            const bi = Math.floor(now / 85) % BITE_CYCLE.length;
            frame = biteFrames?.[bi] || swimFrames[0];
            drawKey = `bite|${s.id}|${has3D ? 1 : 0}|${bi}`;
          } else {
            const fIdx = isSliding ? 0 : (baseStep + Math.abs(vIdx) * 2) % swimFrames.length;
            frame = swimFrames[fIdx];
            let actualIdx = fIdx;
            if (!frame) {
              for (let k = 1; k < swimFrames.length; k++) {
                const prev = (fIdx - k + swimFrames.length) % swimFrames.length;
                if (swimFrames[prev]) {
                  frame = swimFrames[prev];
                  actualIdx = prev;
                  break;
                }
              }
            }
            drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
          }

          if (frame && slotDrawnKeyRef.current[si] !== drawKey) {
            slotDrawnKeyRef.current[si] = drawKey;
            drawFishCanvas(cv, frame, 260, 172, (TILE_SCALE[s.id] ?? 1) * (has3D ? 1.04 : 1.06), 1.25);
          }
        }

        // All Fish Grid inside Hub modal — always 3D
        if (shouldDraw && activeModal === "hub" && curHubTab === "skins") {
          for (const idx of visibleIndices) {
            const s = SKINS[idx];
            const cv = tileCanvasRefs.current[idx];
            if (!cv) continue;
            const use3DTile = !!(s.is3D || s.supports3D);
            const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
            const frames = has3D ? TILE_CANVASES_3D[s.id] : s.is3D ? undefined : TILE_CANVASES_2D[s.id];
            if (!frames) continue;

            const fIdx = (baseStep + idx) % frames.length;
            const frame = frames[fIdx] || frames[0];
            if (!frame) continue;

            const actualIdx = frame === frames[0] && !frames[fIdx] ? 0 : fIdx;
            const drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
            if (drawnKeysRef.current[idx] !== drawKey) {
              drawnKeysRef.current[idx] = drawKey;
              drawFishCanvas(cv, frame, 132, 74, (TILE_SCALE[s.id] ?? 1) * (has3D ? 0.96 : 1), 1.45);
            }
          }
        }

        // Nemo Skin Picker modal — always 3D
        if (shouldDraw && pickerOpen) {
          const nIndices = nemoIndicesRef.current;
          for (let ni = 0; ni < nIndices.length; ni++) {
            const idx = nIndices[ni];
            const s = SKINS[idx];
            const cv = nemoPickerCanvasRefs.current[ni];
            if (!s || !cv) continue;
            const use3DTile = !!(s.is3D || s.supports3D);
            const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
            const frames = has3D ? TILE_CANVASES_3D[s.id] : TILE_CANVASES_2D[s.id];
            if (!frames) continue;

            const fIdx = (baseStep + ni) % frames.length;
            const frame = frames[fIdx] || frames[0];
            if (!frame) continue;

            const actualIdx = frame === frames[0] && !frames[fIdx] ? 0 : fIdx;
            const drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
            if (nemoDrawnKeysRef.current[ni] !== drawKey) {
              nemoDrawnKeysRef.current[ni] = drawKey;
              drawFishCanvas(cv, frame, 156, 88, (TILE_SCALE[s.id] ?? 1) * (has3D ? 1.0 : 1.02), 1.5);
            }
          }
        }
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      clearTimeout(toastTimerRef.current);
      clearTimeout(scrollIdleTimerRef.current);
      clearTimeout(suppressClickTimerRef.current);
      clearTimeout(settleCommitTimerRef.current);
    };
  }, [applyCarouselVisuals]);

  const handleGridScroll = () => {
    const scroller = gridScrollRef.current;
    if (scroller) scrollTopRef.current = scroller.scrollTop;
    isScrollingRef.current = true;
    clearTimeout(scrollIdleTimerRef.current);
    scrollIdleTimerRef.current = window.setTimeout(() => {
      isScrollingRef.current = false;
      lastDrawStepRef.current = -1;
    }, 100);
  };

  const loadingPct = Math.max(0, Math.min(100, Math.round(loadPct * 100)));
  const loadingStageText =
    loadPct < 0.22
      ? t.loadingStages[0]
      : loadPct < 0.49
        ? t.loadingStages[1]
        : loadPct < 0.88
          ? t.loadingStages[2]
          : loadPct < 0.99
            ? t.loadingStages[3]
            : t.loadingStages[4];

  const centerFishName = getLocalizedSkinName(cur.id, cur.name, lang);

  // ================= DEDICATED FULL-SCREEN LOADING OVERLAY (HIDES GAME & MENU UNTIL READY) =================
  if (loading) {
    return (
      <div
        className="fixed inset-0 z-50 flex flex-col items-center justify-center px-5 overflow-hidden select-none"
        style={{
          background: "linear-gradient(180deg, #169ae8 0%, #095ab2 48%, #04245e 100%)",
        }}
        role="status"
        aria-live="polite"
      >
        <div className="sun-rays opacity-75">
          <div className="ray" />
          <div className="ray" />
          <div className="ray" />
          <div className="ray" />
        </div>

        {/* Floating decorative ocean bubbles */}
        <span className="float-bubble-a pointer-events-none absolute left-[14%] bottom-[24%] w-4 h-4 rounded-full border-2 border-cyan-100/70 bg-cyan-200/20" aria-hidden="true" />
        <span className="float-bubble-b pointer-events-none absolute right-[16%] bottom-[32%] w-3 h-3 rounded-full border-2 border-cyan-100/65 bg-cyan-200/20" aria-hidden="true" />
        <span className="float-bubble-c pointer-events-none absolute left-[24%] top-[26%] w-2.5 h-2.5 rounded-full border border-cyan-100/70 bg-cyan-200/25" aria-hidden="true" />

        <div className="relative z-10 flex flex-col items-center w-full max-w-[580px] gap-10">
          <WavingFishTitle sizeClass="text-[66px] sm:text-[88px] md:text-[106px]" />

          {/* Loading Bar + 3D Swimming Fish Asset Moving Right as Gauge Fills */}
          <div className="relative w-full pt-14 sm:pt-16">
            {/* Live 3D game fish swimming rightwards at the leading edge of the progress fill */}
            <div
              className="fish-swim-glide pointer-events-none absolute top-0 z-20 -translate-x-1/2 transition-all duration-150 ease-out flex items-center"
              style={{ left: `${Math.min(95, Math.max(5, loadingPct))}%` }}
            >
              <span className="w-2.5 h-2.5 rounded-full border border-cyan-100/80 bg-cyan-200/35 -mr-2 mb-3 animate-pulse" aria-hidden="true" />
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-100/75 -mr-1 mt-3" aria-hidden="true" />
              <canvas
                ref={loadingCanvasRef}
                aria-label={centerFishName}
                className="w-[112px] h-[70px] sm:w-[132px] sm:h-[82px] block drop-shadow-[0_6px_14px_rgba(2,18,48,0.72)]"
              />
            </div>

            {/* Gauge Track */}
            <div className="relative w-full h-8 sm:h-10 rounded-full border-[3.5px] border-[#042352] bg-[#04183b]/90 p-1 shadow-[inset_0_4px_10px_rgba(0,0,0,0.65),0_10px_24px_rgba(2,14,38,0.6)]">
              <div
                className="h-full rounded-full transition-all duration-150 ease-out relative overflow-hidden"
                style={{
                  width: `${Math.max(4, loadingPct)}%`,
                  background: "linear-gradient(90deg, #06b6d4 0%, #38bdf8 52%, #fde047 100%)",
                  boxShadow: "inset 0 2px 0 rgba(255,255,255,0.65)",
                }}
              />
            </div>

            <div className="mt-3 flex items-center justify-between px-2 text-sm sm:text-base font-extrabold text-cyan-100 text-outline tracking-wider uppercase">
              <span>{loadingStageText}</span>
              <span className="tabular-nums text-yellow-300">{loadingPct}%</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between items-center px-3 py-3 sm:py-5 overflow-hidden select-none pointer-events-none">
      {/* ================= TOP-CENTER: BIG WAVING Fish.io TITLE (NO WATER SPLASH BACKDROP) ================= */}
      <header className="relative z-20 flex flex-col items-center pt-1 sm:pt-2 shrink-0 pointer-events-auto">
        <WavingFishTitle sizeClass="text-[clamp(62px,8.2vw,118px)]" />

        {localizedEquippedTitle && (
          <div className="mt-1 px-3.5 py-0.5 rounded-full bg-[#062658]/80 border border-yellow-300/75 text-xs font-extrabold text-yellow-200 shadow-md">
            👑 {t.equippedTitle}: « {localizedEquippedTitle} »
          </div>
        )}
      </header>

      {/* ================= CENTER: SMOOTH 60 FPS CONTINUOUS SLIDING 3D CAROUSEL + CROWN + NAME + PLAY ================= */}
      <main className="relative z-20 flex-1 w-full max-w-[1260px] flex flex-col items-center justify-center min-h-0 pointer-events-auto">
        <div
          className="relative w-full flex items-center justify-center gap-1 sm:gap-2 md:gap-4 touch-pan-y"
          onPointerDown={(e) => {
            const target = e.target as HTMLElement | null;
            if (target?.closest(".arcade-arrow-btn")) return;
            // Allow interactive 3D orbit directly on the settled hero 3D canvas; drag anywhere else to smoothly scrub carousel
            if (carouselSettled && showLiveHero3D && target?.closest(".hero-live-3d-orbit")) return;
            dragStateRef.current = {
              pointerId: e.pointerId,
              startX: e.clientX,
              lastX: e.clientX,
              lastT: performance.now(),
              velSlots: 0,
              startVisual: visualPosRef.current,
              moved: false,
            };
          }}
          onPointerMove={(e) => {
            const ds = dragStateRef.current;
            if (!ds || ds.pointerId !== e.pointerId) return;
            const dxTotal = e.clientX - ds.startX;
            if (!ds.moved && Math.abs(dxTotal) < 8) return;
            if (!ds.moved) {
              ds.moved = true;
              try {
                e.currentTarget.setPointerCapture?.(e.pointerId);
              } catch {
                // ignore if pointer is no longer active
              }
              if (carouselSettledRef.current) {
                carouselSettledRef.current = false;
                setCarouselSettled(false);
              }
            }
            const trackW = trackWRef.current || 880;
            const stepX = trackW < 560 ? Math.max(134, trackW * 0.44) : Math.max(150, Math.min(224, trackW * 0.225));
            const nextVisual = ds.startVisual - dxTotal / stepX;
            const now = performance.now();
            const dtSec = Math.max(0.008, (now - ds.lastT) / 1000);
            const stepDx = e.clientX - ds.lastX;
            ds.velSlots = -(stepDx / stepX) / dtSec;
            ds.lastX = e.clientX;
            ds.lastT = now;
            visualPosRef.current = nextVisual;
            virtualTargetRef.current = Math.round(nextVisual);
            applyCarouselVisuals(nextVisual);
          }}
          onPointerUp={(e) => {
            const ds = dragStateRef.current;
            if (!ds || ds.pointerId !== e.pointerId) return;
            dragStateRef.current = null;
            if (ds.moved) {
              try {
                if (e.currentTarget.hasPointerCapture?.(e.pointerId)) {
                  e.currentTarget.releasePointerCapture?.(e.pointerId);
                }
              } catch {
                // ignore
              }
              suppressClickRef.current = true;
              clearTimeout(suppressClickTimerRef.current);
              suppressClickTimerRef.current = window.setTimeout(() => {
                suppressClickRef.current = false;
              }, 80);
              const momentum = Math.max(-1.6, Math.min(1.6, ds.velSlots * 0.14));
              virtualTargetRef.current = Math.round(visualPosRef.current + momentum);
            }
          }}
          onPointerCancel={(e) => {
            const ds = dragStateRef.current;
            if (!ds || ds.pointerId !== e.pointerId) return;
            dragStateRef.current = null;
            virtualTargetRef.current = Math.round(visualPosRef.current);
          }}
        >
          {/* Left Golden Arrow */}
          <button
            type="button"
            onClick={() => stepCarousel(-1)}
            aria-label="Previous fish"
            className="arcade-arrow-btn shrink-0 p-1 z-40"
          >
            <GoldenArrowIcon dir="left" />
          </button>

          {/* Fixed 9-Slot Hardware-Accelerated Virtual Track (Zero DOM unmount/remount while sliding) */}
          <div
            ref={carouselTrackRef}
            className="relative flex-1 max-w-[1060px] h-[220px] sm:h-[275px] md:h-[305px] flex items-center justify-center overflow-visible"
          >
            {/* Big Golden Radial Spotlight Glow anchored at center */}
            <div
              ref={heroAuraRef}
              className="hero-golden-aura pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[270px] h-[270px] sm:w-[360px] sm:h-[360px] md:w-[420px] md:h-[420px] rounded-full transition-none"
              aria-hidden="true"
            />

            {/* Golden Crown perched gracefully above center slot */}
            <div
              ref={heroCrownRef}
              className="pointer-events-none absolute top-1 sm:top-2 left-1/2 -translate-x-1/2 z-30"
              aria-hidden="true"
            >
              <GoldenCrownIcon className="w-16 h-12 sm:w-20 sm:h-15 md:w-24 md:h-18 drop-shadow-[0_5px_8px_rgba(0,0,0,0.55)]" />
            </div>

            {/* 9 Fixed Physical Slots recycled seamlessly around carouselAnchorRef */}
            {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((si) => {
              const vPos = visualPosRef.current;
              const anchor = Math.round(vPos);
              let initVIdx = anchor;
              for (let off = -4; off <= 4; off++) {
                const candidate = anchor + off;
                if (((candidate % 9) + 9) % 9 === si) {
                  initVIdx = candidate;
                  break;
                }
              }
              const idx = modSkinIdx(initVIdx);
              const s = SKINS[idx];
              const sName = getLocalizedSkinName(s.id, s.name, lang);
              const isFocusedLive =
                showLiveHero3D && heroLiveReady && initVIdx === virtualTargetRef.current;

              return (
                <button
                  key={si}
                  type="button"
                  ref={(el) => {
                    slotWrapRefs.current[si] = el;
                  }}
                  onClick={() => {
                    if (suppressClickRef.current || dragStateRef.current?.moved) return;
                    const clickedVIdx = slotVirtualRef.current[si];
                    const delta = clickedVIdx - virtualTargetRef.current;
                    if (delta !== 0) {
                      stepCarousel(delta);
                    } else if (!showLiveHero3D) {
                      triggerTestBite();
                    }
                  }}
                  aria-label={sName}
                  style={{ willChange: "transform, opacity" }}
                  className="absolute top-1/2 left-1/2 -ml-[145px] -mt-[96px] w-[290px] h-[192px] flex items-center justify-center cursor-pointer origin-center bg-transparent border-none p-0"
                >
                  <div
                    className={`w-full h-full flex items-center justify-center ${
                      isFocusedLive ? "opacity-0" : "opacity-100"
                    }`}
                  >
                    <canvas
                      ref={(el) => {
                        slotCanvasRefs.current[si] = el;
                      }}
                      className="w-[290px] h-[192px] block pointer-events-none"
                    />
                  </div>
                </button>
              );
            })}

            {/* Persistent Live 3D Hero Viewport (never destroyed during carousel navigation; swaps rig cleanly when settled) */}
            {!softWebGL && heroIs3D && (
              <div
                className={`hero-live-3d-orbit absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-30 w-[260px] h-[180px] sm:w-[320px] sm:h-[220px] md:w-[350px] md:h-[236px] flex items-center justify-center ${
                  showLiveHero3D && heroLiveReady
                    ? "opacity-100 pointer-events-auto cursor-pointer"
                    : "opacity-0 pointer-events-none"
                }`}
                title={t.testBite}
              >
                <Fish3DViewport
                  species={viewportSpecies}
                  onBiteCount={biteTrig}
                  paused={paused || modal !== null || !carouselSettled || !viewportMatchesTarget}
                  interactive={true}
                  bulkScale={save.bulkPref}
                  onFirstRender={handleHeroFirstRender}
                />
              </div>
            )}
          </div>

          {/* Right Golden Arrow */}
          <button
            type="button"
            onClick={() => stepCarousel(1)}
            aria-label="Next fish"
            className="arcade-arrow-btn shrink-0 p-1 z-40"
          >
            <GoldenArrowIcon dir="right" />
          </button>
        </div>

        {/* Center Fish Name + Quick Browser / Nemo Variant Buttons */}
        <div className="relative z-20 flex flex-col items-center -mt-2 sm:-mt-1 mb-3 sm:mb-4">
          <div
            ref={heroNameRef}
            className="font-display text-[32px] sm:text-[40px] md:text-[46px] font-extrabold text-white text-outline leading-none tracking-wide"
          >
            {centerFishName}
          </div>
          <div className="mt-1.5 flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => {
                commitTargetSkinNow();
                setHubTab("skins");
                setModal("hub");
              }}
              className="px-3.5 py-1 rounded-full bg-[#06316e]/80 hover:bg-[#094391] border border-cyan-300/60 text-xs font-extrabold text-cyan-100 cursor-pointer shadow transition-colors"
            >
              🐠 {t.allFish} ({SKINS.length})
            </button>
            {heroIsNemo && (
              <button
                type="button"
                onClick={() => {
                  commitTargetSkinNow();
                  setModal("nemo");
                }}
                className="px-3.5 py-1 rounded-full bg-orange-600/90 hover:bg-orange-500 border border-amber-200/75 text-xs font-extrabold text-white cursor-pointer shadow transition-colors"
              >
                🎨 {t.nemoVariants}
              </button>
            )}
          </div>
        </div>

        {/* Big Golden-Orange Glossy PLAY Button (NO WATER SPLASH BACKDROP) */}
        <div className="relative z-20 flex items-center justify-center">
          <button
            type="button"
            onClick={() => onPlay(SKINS[modSkinIdx(virtualTargetRef.current)]?.id || cur.id)}
            className="ocean-play-orange relative z-10 overflow-hidden min-w-[290px] sm:min-w-[380px] md:min-w-[440px] px-10 sm:px-14 py-3 sm:py-4 flex items-center justify-center gap-4"
          >
            <span className="relative font-display text-[36px] sm:text-[48px] md:text-[54px] font-extrabold tracking-wide text-white text-outline leading-none">
              {t.play}
            </span>
            <svg viewBox="0 0 36 40" className="relative w-9 h-10 sm:w-11 sm:h-12 shrink-0 drop-shadow-[0_2px_2px_rgba(92,31,2,0.7)]" fill="none" aria-hidden="true">
              <path
                d="M6 7 C6 3.5 10 1.5 13 3.4 L31 15.6 C33.8 17.5 33.8 22.5 31 24.4 L13 36.6 C10 38.5 6 36.5 6 33 Z"
                fill="#FFE44D"
                stroke="#5C1F02"
                strokeWidth="3.2"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      </main>

      {/* ================= BOTTOM BAR: CENTER (Leaderboard + Trophies) & RIGHT (Theme + Setting, NO BLUE PANEL) ================= */}
      <footer className="relative z-20 w-full max-w-[1280px] flex items-end justify-center pb-1 sm:pb-2 pointer-events-none">
        {/* Bottom-Center: Leaderboard & Trophies */}
        <div className="pointer-events-auto flex items-center justify-center gap-4 sm:gap-6 flex-wrap">
          <button
            type="button"
            onClick={() => {
              setHubTab("records");
              setModal("hub");
            }}
            className="ocean-pill-blue min-w-[195px] sm:min-w-[245px] md:min-w-[270px] px-6 py-2.5 sm:py-3.5 flex items-center justify-center gap-3"
          >
            <TrophyCupIcon />
            <span className="font-display text-[20px] sm:text-[24px] md:text-[26px] font-extrabold text-white text-outline tracking-wide">
              {t.leaderboard}
            </span>
          </button>

          <button
            type="button"
            onClick={onOpenTrophies}
            className="ocean-pill-blue min-w-[190px] sm:min-w-[235px] md:min-w-[260px] px-6 py-2.5 sm:py-3.5 flex items-center justify-center gap-3"
          >
            <GoldStarIcon />
            <span className="font-display text-[20px] sm:text-[24px] md:text-[26px] font-extrabold text-white text-outline tracking-wide">
              {t.trophies}
            </span>
          </button>
        </div>

        {/* Bottom-Right Stacked: Theme & Setting — 1.8x Enlarged Floating Icons + Crisp Labels (NO BLUE PANEL) */}
        <div className="pointer-events-auto fixed bottom-3 right-3 sm:bottom-5 sm:right-5 flex flex-col gap-1.5 sm:gap-2 items-start z-30">
          <button
            type="button"
            onClick={() => setModal("theme")}
            className="theme-float-btn flex items-center gap-3 px-2 py-0.5"
          >
            <div className="w-[94px] sm:w-[116px] flex items-center justify-center shrink-0">
              <TropicalIslandIcon className="w-[94px] h-[82px] sm:w-[116px] sm:h-[101px]" />
            </div>
            <span className="font-display text-[22px] sm:text-[28px] font-extrabold text-white text-outline tracking-wide">
              {t.theme}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setModal("setting")}
            className="theme-float-btn flex items-center gap-3 px-2 py-0.5"
          >
            <div className="w-[94px] sm:w-[116px] flex items-center justify-center shrink-0">
              <WoodenShipWheelIcon className="w-[94px] h-[94px] sm:w-[116px] sm:h-[116px]" />
            </div>
            <span className="font-display text-[22px] sm:text-[28px] font-extrabold text-white text-outline tracking-wide">
              {t.setting}
            </span>
          </button>
        </div>
      </footer>

      {/* ================= MODAL 1: OCEAN HUB (LEADERBOARD / UPGRADES / ALL FISH) ================= */}
      {modal === "hub" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.leaderboard}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[920px] h-[86vh] max-h-[680px] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-amber-200/20 shrink-0">
              <nav className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => setHubTab("records")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "records" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>🏆</span>
                  <span>{t.leaderboard}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHubTab("upgrades")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "upgrades" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>⚡</span>
                  <span>{t.upgrades}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHubTab("skins")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "skins" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>🐠</span>
                  <span>
                    {t.allFish} ({SKINS.length})
                  </span>
                </button>
              </nav>

              <div className="flex items-center gap-2 ml-auto">
                <div className="ff-carved-slot px-3 h-[34px] flex items-center gap-1.5 shrink-0">
                  <img src={coin} className="w-4 h-4 shrink-0" alt="" />
                  <span className="font-extrabold text-[14px] text-yellow-300 tabular-nums">
                    {save.coins.toLocaleString("en-US")}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setModal(null)}
                  className="ui-btn px-3 py-1.5 text-[12px] text-amber-100"
                  style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
                >
                  ✕ {t.close}
                </button>
              </div>
            </header>

            {hubTab === "records" && (
              <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-3">
                <div className="artistic-inset p-3.5 flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h2 className="text-[18px] font-extrabold text-amber-100 text-outline">{t.recordsTitle}</h2>
                    <div className="text-[12px] font-semibold text-cyan-200/90 mt-0.5">
                      {save.name.trim() || t.defaultPlayerName} · {centerFishName}
                      {localizedEquippedTitle ? ` · «${localizedEquippedTitle}»` : ""}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setModal(null);
                      onOpenTrophies();
                    }}
                    className="ui-btn px-3.5 py-1.5 text-[12px] text-white"
                    style={{ background: "linear-gradient(180deg, #0ea5e9 0%, #0369a1 100%)" }}
                  >
                    🏅 {t.trophies} ({unlockedTrophyCount}/{TROPHIES.length})
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { icon: "🏆", label: t.bestScore, val: save.best.toLocaleString("en-US"), col: "text-yellow-300" },
                    { icon: "👑", label: t.rank1Wins, val: `${save.rank1Count}×`, col: "text-amber-200" },
                    {
                      icon: "⏱️",
                      label: t.fastestPeak,
                      val: save.bestPeakTimeSec !== null ? formatSecShort(save.bestPeakTimeSec, lang) : t.notYet,
                      col: "text-cyan-200",
                    },
                    { icon: "🔥", label: t.bestCombo, val: `x${save.bestCombo}`, col: "text-orange-300" },
                    { icon: "🌊", label: t.deepestDive, val: `${save.bestDepth.toLocaleString("en-US")} m`, col: "text-sky-200" },
                    { icon: "🎮", label: t.totalRuns, val: `${save.totalRuns}`, col: "text-emerald-200" },
                  ].map((st) => (
                    <div key={st.label} className="artistic-inset p-3 flex flex-col gap-1">
                      <div className="text-[11px] font-bold text-amber-200/75 flex items-center gap-1.5">
                        <span>{st.icon}</span>
                        <span>{st.label}</span>
                      </div>
                      <div className={`text-[20px] sm:text-[22px] font-extrabold tabular-nums ${st.col}`}>
                        {st.val}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="artistic-inset p-3.5 flex items-center justify-between gap-3 flex-wrap mt-auto">
                  <div className="text-[12px] font-bold text-amber-100/90">{t.controlsHint}</div>
                  <button
                    type="button"
                    onClick={() => {
                      setModal(null);
                      onPlay(cur.id);
                    }}
                    className="ui-btn px-4 py-1.5 text-[13px] text-white"
                    style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
                  >
                    ▶ {t.playNow}
                  </button>
                </div>
              </div>
            )}

            {hubTab === "upgrades" && (
              <div className="relative z-10 flex-1 min-h-0 flex flex-col gap-2.5 overflow-y-auto wood-scroll pr-1">
                <div className="artistic-inset px-3.5 py-2.5 shrink-0">
                  <div className="text-[15px] font-extrabold text-amber-100">{t.workshopTitle}</div>
                  <div className="text-[11.5px] font-medium text-amber-200/80">{t.workshopDesc}</div>
                </div>

                <div className="flex flex-col gap-2.5">
                  {UPGRADE_META.map((u) => {
                    const lv = save.upgrades[u.id];
                    const max = lv >= MAX_UPGRADE;
                    const cost = max ? 0 : UPGRADE_COSTS[lv];
                    const canBuy = !max && save.coins >= cost;
                    const pct = Math.round((lv / MAX_UPGRADE) * 100);
                    const uCopy = lang === "id" ? u.idText : u.en;
                    return (
                      <div key={u.id} className="artistic-inset p-3.5 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="ff-carved-slot w-12 h-12 flex items-center justify-center text-2xl shrink-0">
                            {u.icon}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-[15px] font-extrabold text-white">{uCopy.name}</span>
                              <span className="px-2 py-0.5 rounded-md bg-cyan-950/90 border border-cyan-400/40 text-[11px] font-extrabold text-cyan-200 tabular-nums">
                                Lv {lv}/{MAX_UPGRADE}
                              </span>
                            </div>
                            <p className="text-[11.5px] text-amber-100/80 mt-0.5">{uCopy.desc}</p>
                            <div className="ff-bar-slot h-3 mt-2 overflow-hidden relative">
                              <div className="ff-yellow-fill h-full transition-all duration-200" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => buyUp(u.id)}
                          disabled={!canBuy}
                          className="ui-btn px-3.5 py-2 min-w-[106px] text-[12.5px] text-white shrink-0 flex items-center justify-center gap-1.5 disabled:opacity-45 disabled:cursor-not-allowed tabular-nums"
                          style={{
                            background: max
                              ? "linear-gradient(180deg, #10b981 0%, #047857 100%)"
                              : canBuy
                                ? "linear-gradient(180deg, #ffb422 0%, #d97706 100%)"
                                : "#3f240f",
                          }}
                        >
                          {max ? (
                            <span>✓ {t.maxed}</span>
                          ) : (
                            <>
                              <img src={coin} className="w-4 h-4 shrink-0" alt="" />
                              <span className="text-[#231004] font-black">{cost}</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {hubTab === "skins" && (
              <div className="relative z-10 flex-1 min-h-0 flex flex-col gap-2">
                <div className="flex flex-wrap items-center justify-between gap-2 shrink-0">
                  <div className="ff-carved-slot p-0.5 flex items-center gap-0.5 overflow-x-auto">
                    {(
                      [
                        { id: "all", label: `${t.filterAll} (${SKINS.length})` },
                        { id: "predator", label: `🦈 ${t.filterPredator}` },
                        { id: "reef", label: `🐠 ${t.filterReef}` },
                        { id: "rare", label: `★ ${t.filterRare}` },
                      ] as { id: SkinFilter; label: string }[]
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setSkinFilter(tab.id)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          skinFilter === tab.id
                            ? "bg-amber-400 text-[#231004] shadow-sm"
                            : "text-amber-100/80 hover:text-white hover:bg-white/5"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 ml-auto">
                    <button
                      type="button"
                      onClick={pickRandomSkin}
                      className="ui-btn px-2.5 py-1 text-[11px] text-white"
                      style={{ background: "linear-gradient(180deg, #3292bc 0%, #1a587a 100%)" }}
                    >
                      🎲 {t.randomFish}
                    </button>
                    <div className="ff-carved-slot px-2.5 py-1 flex items-center gap-1.5 w-[170px] sm:w-[200px]">
                      <span className="text-[11px] text-amber-200/75" aria-hidden="true">
                        🔍
                      </span>
                      <input
                        type="text"
                        value={skinQuery}
                        onChange={(e) => setSkinQuery(e.target.value)}
                        placeholder={t.searchFishPlaceholder}
                        className="bg-transparent border-none outline-none text-[11.5px] font-bold text-amber-50 placeholder-amber-200/45 w-full"
                      />
                      {skinQuery && (
                        <button
                          type="button"
                          onClick={() => setSkinQuery("")}
                          className="text-[10px] font-extrabold text-amber-200/80 hover:text-white cursor-pointer px-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div ref={gridScrollRef} onScroll={handleGridScroll} className="flex-1 min-h-0 overflow-y-auto wood-scroll pr-1.5 pb-1">
                  {filteredSkins.length === 0 ? (
                    <div className="artistic-inset p-6 text-center flex flex-col items-center justify-center gap-2 my-4">
                      <div className="text-2xl">🐚</div>
                      <div className="text-sm font-extrabold text-amber-100">{t.noFishFound}</div>
                      <button
                        type="button"
                        onClick={() => {
                          setSkinFilter("all");
                          setSkinQuery("");
                        }}
                        className="ui-btn px-3 py-1 text-xs text-white"
                        style={{ background: "linear-gradient(180deg, #06b6d4 0%, #0369a1 100%)" }}
                      >
                        {t.showAllFish}
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                      {filteredSkins.map(({ skin: s, origIdx: idx }) => {
                        const isActive = s.id === cur.id;
                        const sName = getLocalizedSkinName(s.id, s.name, lang);
                        const sSub = getLocalizedSkinSubtitle(s.id, s.subtitle, lang);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            ref={(el) => {
                              tileRefs.current[idx] = el;
                            }}
                            onClick={() => selectSkin(s.id, true)}
                            className={`${
                              isActive
                                ? "wood-fish-tile-active"
                                : s.rare
                                  ? "wood-fish-tile wood-fish-tile-rare"
                                  : "wood-fish-tile"
                            } p-2 flex flex-col justify-between gap-1.5 text-center`}
                          >
                            <div
                              className={`${
                                s.rare ? "etalase-lagoon-window etalase-lagoon-window-rare" : "etalase-lagoon-window"
                              } relative w-full h-[78px] overflow-hidden flex items-center justify-center`}
                            >
                              {s.rare ? (
                                <span className="badge-langka absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider text-white">
                                  ★ {t.rareBadge}
                                </span>
                              ) : isNemoSkinId(s.id) ? (
                                <span className="absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider text-white bg-gradient-to-b from-orange-400 to-orange-600 border border-amber-200/50 shadow-sm">
                                  🎨 {t.nemoVariants}
                                </span>
                              ) : null}
                              {(s.supports3D || s.is3D) && (
                                <span className="absolute top-1 right-1 z-10 px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-cyan-400 text-[#052038]">
                                  {s.is3D ? "3D ONLY" : "3D"}
                                </span>
                              )}
                              <canvas
                                ref={(el) => {
                                  tileCanvasRefs.current[idx] = el;
                                }}
                                aria-label={sName}
                                className="w-[132px] h-[74px] object-contain block pointer-events-none"
                              />
                            </div>

                            <div className="px-0.5">
                              <div className={`text-[13.5px] font-extrabold leading-tight truncate ${isActive ? "text-[#2b1405]" : "text-amber-50"}`}>
                                {sName}
                              </div>
                              <div className={`text-[10.5px] font-bold truncate mt-0.5 ${isActive ? "text-[#5c2c0a]" : "text-cyan-200/90"}`}>
                                {sSub}
                              </div>
                            </div>

                            <div
                              className={`h-[24px] rounded-lg flex items-center justify-center text-[10.5px] font-extrabold tracking-wide ${
                                isActive
                                  ? "bg-[#241105] text-yellow-300 border border-[#613412]"
                                  : "bg-black/40 text-amber-300 border border-amber-200/15"
                              }`}
                            >
                              {isActive ? `✓ ${t.active}` : t.select}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL 2: THEME & OCEAN VISUALS ================= */}
      {modal === "theme" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.themeModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[680px] max-h-[88vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div className="flex items-center gap-2.5">
                <TropicalIslandIcon className="w-10 h-9" />
                <div>
                  <h2 className="text-[19px] sm:text-[22px] font-extrabold text-amber-100 text-outline">
                    {t.themeModalTitle}
                  </h2>
                  <p className="text-[11.5px] font-semibold text-cyan-200/90 mt-0.5">{t.themeModalDesc}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => setSave({ ...save, laut: !save.laut })}
                className={`w-full rounded-xl border p-3 flex items-center justify-between gap-3 cursor-pointer text-left transition-all ${
                  save.laut
                    ? "bg-[#06364e]/90 border-teal-300/80 shadow-[0_0_16px_rgba(45,212,191,0.28)]"
                    : "bg-[#241206]/85 border-[#a67342]/60"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-xl">🌊</span>
                  <div>
                    <div className="text-[13px] font-extrabold text-teal-100">{t.ocean3DMode}</div>
                    <div className="text-[11px] text-cyan-100/80">{t.ocean3DDesc}</div>
                  </div>
                </div>
                <span
                  className={`shrink-0 px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                    save.laut ? "bg-teal-300 text-[#042a36]" : "bg-amber-400 text-[#231004]"
                  }`}
                >
                  {save.laut ? t.on : t.off}
                </span>
              </button>

              <div className="artistic-inset p-3 flex flex-col gap-2">
                <div className="text-[12px] font-extrabold text-amber-200">🎨 {t.backdropLabel}</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(
                    [
                      { id: "game1", en: "🌊 Ocean Classic", idLabel: "🌊 Laut Biru (G1)" },
                      { id: "reef_g1", en: "☀️ Reef + G1 Water", idLabel: "☀️ Reef + Air G1" },
                      { id: "game2", en: "🌴 Tropical Reef", idLabel: "🌴 Reef (G2)" },
                      { id: "shipwreck", en: "⚓ Shipwreck", idLabel: "⚓ Kapal Karam" },
                      { id: "kelp", en: "🌿 Kelp Forest", idLabel: "🌿 Hutan Kelp" },
                      { id: "temple", en: "🏛️ Coral Temple", idLabel: "🏛️ Kuil Karang" },
                      { id: "lagoon", en: "✨ Crystal Lagoon", idLabel: "✨ Laguna Gua" },
                    ] as { id: BgStyle; en: string; idLabel: string }[]
                  ).map((opt) => {
                    const active = save.bgStyle === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, bgStyle: opt.id })}
                        className={`px-2.5 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                          active ? "bg-teal-300 text-[#042a36] shadow-sm" : "bg-black/35 text-amber-100/85 hover:bg-black/55"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🪸 {t.reefModeLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "game1", en: "🪨 Original G1", idLabel: "🪨 Asli G1" },
                        { id: "game2", en: "🪸 100% G2 Reef", idLabel: "🪸 100% G2" },
                        { id: "mix", en: "🌺 Mix G1+G2", idLabel: "🌺 Mix G1+G2" },
                      ] as { id: ReefMixMode; en: string; idLabel: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, laut: true, reefMix: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.reefMix === opt.id ? "bg-teal-300 text-[#042a36]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    ))}
                  </div>
                </div>

                {save.reefMix !== "game1" && (
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🪨 {t.rockStyleLabel}</span>
                    <div className="flex items-center gap-1">
                      {(
                        [
                          { id: "g1", en: "🪨 G1 Boulders", idLabel: "🪨 G1 Asli" },
                          { id: "g2", en: "⛰️ G2 Cliffs", idLabel: "⛰️ G2 Tebing" },
                        ] as { id: ReefRockMode; en: string; idLabel: string }[]
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setSave({ ...save, laut: true, rockStyle: opt.id })}
                          className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                            save.rockStyle === opt.id ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                          }`}
                        >
                          {lang === "id" ? opt.idLabel : opt.en}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🏔️ {t.reefDepthLabel}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, reef3D: true })}
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                        save.reef3D ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      3D
                    </button>
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, reef3D: false })}
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                        !save.reef3D ? "bg-amber-400 text-[#231004]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      2D
                    </button>
                  </div>
                </div>
              </div>

              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">💡 {t.oceanLightLabel}</span>
                  <div className="flex items-center gap-1">
                    {(
                      [
                        { id: "after", en: "✨ Enhanced (Soft)", idLabel: "✨ After (Halus)" },
                        { id: "before", en: "🌑 Classic", idLabel: "🌑 Before (Awal)" },
                      ] as { id: OceanLightingMode; en: string; idLabel: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, oceanLighting: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.oceanLighting === opt.id ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🖥️ {t.graphicsLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "hd_boost", label: `🚀 ${t.hud.gfxBoost}` },
                        { id: "super_hd", label: `💎 ${t.hud.gfxSuper}` },
                        { id: "ultra_fps", label: `⚡ ${t.hud.gfxUltra}` },
                      ] as { id: GraphicsMode; label: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, graphicsMode: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.graphicsMode === opt.id ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <footer className="relative z-10 flex items-center justify-end gap-2 pt-1 border-t border-amber-200/15 shrink-0">
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-4 py-1.5 text-[12.5px] text-white"
                style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
              >
                {t.saveAndClose}
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: SETTINGS ================= */}
      {modal === "setting" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.settingsModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[640px] max-h-[88vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div className="flex items-center gap-2.5">
                <WoodenShipWheelIcon className="w-10 h-10" />
                <div>
                  <h2 className="text-[19px] sm:text-[22px] font-extrabold text-amber-100 text-outline">
                    {t.settingsModalTitle}
                  </h2>
                  <p className="text-[11.5px] font-semibold text-cyan-200/90">{t.settingsModalDesc}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-2.5">
              <div className="artistic-inset p-3 flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[12.5px] font-extrabold text-amber-200">🌐 {t.languageLabel}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSave({ ...save, lang: "en" })}
                    className={`px-3 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                      save.lang === "en" ? "bg-cyan-300 text-[#052038] shadow-sm" : "bg-black/40 text-amber-100/80 hover:text-white"
                    }`}
                  >
                    🇺🇸 {t.langEn}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSave({ ...save, lang: "id" })}
                    className={`px-3 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                      save.lang === "id" ? "bg-amber-300 text-[#231004] shadow-sm" : "bg-black/40 text-amber-100/80 hover:text-white"
                    }`}
                  >
                    🇮🇩 {t.langId}
                  </button>
                </div>
              </div>

              <div className="artistic-inset p-3 flex flex-col gap-1.5">
                <label className="text-[12px] font-extrabold text-amber-200">🏷️ {t.playerNameLabel}</label>
                <div className="ff-carved-slot px-3 py-2 flex items-center gap-2 focus-within:border-amber-300/70">
                  <input
                    type="text"
                    value={save.name}
                    maxLength={14}
                    onChange={(e) => setSave({ ...save, name: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        setModal(null);
                        onPlay(cur.id);
                      }
                    }}
                    placeholder={t.playerNamePlaceholder}
                    className="bg-transparent border-none outline-none text-amber-50 font-extrabold text-[14px] w-full placeholder-amber-200/45"
                  />
                </div>
              </div>

              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🐠 {t.fishRenderLabel}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, mode3D: false })}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        !save.mode3D ? "bg-amber-400 text-[#231004]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      {t.fish2D}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, mode3D: true })}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        save.mode3D ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      {t.fish3D}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🔊 {t.soundPackLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "wav", label: `🎵 ${t.soundWav}` },
                        { id: "classic", label: `🎹 ${t.soundClassic}` },
                      ] as { id: SoundPack; label: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          sfx.init();
                          sfx.setPack(opt.id);
                          setSave({ ...save, soundPack: opt.id });
                          if (opt.id === "wav") {
                            void sfx.whenReady(["bite1", "bite2", "eat"]).then(() => {
                              if (sfx.pack === "wav") sfx.gulp(1.0, true, 0);
                            });
                          } else {
                            window.setTimeout(() => sfx.gulp(1.0, true, 0), 40);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.soundPack === opt.id
                            ? opt.id === "wav"
                              ? "bg-emerald-300 text-[#042e29]"
                              : "bg-amber-400 text-[#231004]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {onToggleMute && (
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🔈 {t.muteLabel}</span>
                    <button
                      type="button"
                      onClick={onToggleMute}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        !muted ? "bg-emerald-300 text-[#042e29]" : "bg-rose-400 text-rose-950"
                      }`}
                    >
                      {muted ? `🔇 ${t.soundMuted}` : `🔊 ${t.soundOn}`}
                    </button>
                  </div>
                )}
              </div>

              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">⚡ {t.swimSpeedLabel}</span>
                  <div className="flex items-center gap-1">
                    {[0.8, 1.0, 1.3, 1.6].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setSave({ ...save, speedPref: val })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer tabular-nums ${
                          Math.abs(save.speedPref - val) < 0.05
                            ? "bg-amber-400 text-[#231004]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {val.toFixed(1)}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🔍 {t.cameraZoomLabel}</span>
                    <div className="flex items-center gap-1">
                      {[
                        { val: 1.0, label: t.zoomNormal },
                        { val: 1.34, label: t.zoomMid },
                        { val: 1.75, label: t.zoomClose },
                      ].map((opt) => {
                        const active =
                          opt.val === 1.0
                            ? save.cameraZoom < 1.18
                            : opt.val === 1.34
                              ? save.cameraZoom >= 1.18 && save.cameraZoom < 1.55
                              : save.cameraZoom >= 1.55;
                        return (
                          <button
                            key={opt.val}
                            type="button"
                            onClick={() => setSave({ ...save, cameraZoom: opt.val })}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                              active ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10.5px] font-bold text-amber-200/75">{t.far}</span>
                    <input
                      type="range"
                      min={1.0}
                      max={1.85}
                      step={0.05}
                      value={save.cameraZoom}
                      onChange={(e) => setSave({ ...save, cameraZoom: Number(e.target.value) })}
                      className="flex-1 h-1.5 accent-amber-300 cursor-pointer"
                    />
                    <span className="text-[11px] font-extrabold text-amber-100 tabular-nums w-10 text-right">
                      {save.cameraZoom.toFixed(2)}×
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🍽️ {t.bulkLabel}</span>
                  <div className="flex items-center gap-1">
                    {[1.0, 1.7, 2.0].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => {
                          setSave({ ...save, bulkPref: val });
                          triggerTestBite();
                        }}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer tabular-nums ${
                          Math.abs(save.bulkPref - val) < 0.05
                            ? "bg-cyan-300 text-[#052038]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {val.toFixed(1)}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <footer className="relative z-10 flex items-center justify-between gap-2 pt-1 border-t border-amber-200/15 shrink-0 flex-wrap">
              <span className="text-[11px] font-bold text-amber-100/80">{t.controlsHint}</span>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-4 py-1.5 text-[12.5px] text-white ml-auto"
                style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
              >
                {t.saveAndClose}
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* ================= MODAL 4: NEMO 5-MORPH SKIN PICKER ================= */}
      {modal === "nemo" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.nemoModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[780px] max-h-[90vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div className="min-w-0">
                <h2 className="text-[18px] sm:text-[21px] font-extrabold text-amber-100 text-outline flex items-center gap-2">
                  <span aria-hidden="true">🐠</span>
                  <span>
                    {t.nemoModalTitle} ({nemoSkins.length})
                  </span>
                </h2>
                <p className="text-[11.5px] font-semibold text-cyan-200/90 mt-0.5">{t.nemoModalDesc}</p>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 grid grid-cols-2 sm:grid-cols-3 gap-2.5 overflow-y-auto wood-scroll pr-1">
              {nemoSkins.map(({ skin: s }, ni) => {
                const isActive = s.id === cur.id;
                const sName = getLocalizedSkinName(s.id, s.name, lang);
                const meta = NEMO_VARIANT_META[s.id]?.[lang] || {
                  badge: "NEMO",
                  desc: getLocalizedSkinSubtitle(s.id, s.subtitle, lang),
                };
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => pickNemoVariant(s.id)}
                    className={`${isActive ? "wood-fish-tile-active" : "wood-fish-tile"} p-2.5 flex flex-col justify-between gap-1.5 text-center`}
                  >
                    <div className="etalase-lagoon-window relative w-full h-[92px] overflow-hidden flex items-center justify-center">
                      <span className="absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider bg-slate-950/75 text-amber-200 border border-amber-300/35">
                        {meta.badge}
                      </span>
                      {s.supports3D && (
                        <span className="absolute top-1 right-1 z-10 px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-cyan-400 text-[#052038]">
                          3D
                        </span>
                      )}
                      <canvas
                        ref={(el) => {
                          nemoPickerCanvasRefs.current[ni] = el;
                        }}
                        aria-label={sName}
                        className="w-[156px] h-[88px] object-contain block pointer-events-none"
                      />
                    </div>

                    <div className="px-0.5">
                      <div className={`text-[14px] font-extrabold leading-tight truncate ${isActive ? "text-[#2b1405]" : "text-amber-50"}`}>
                        {sName}
                      </div>
                      <div className={`text-[10.5px] font-bold truncate mt-0.5 ${isActive ? "text-[#5c2c0a]" : "text-cyan-200/90"}`}>
                        {meta.desc}
                      </div>
                    </div>

                    <div
                      className={`h-[26px] rounded-lg flex items-center justify-center text-[11px] font-extrabold tracking-wide ${
                        isActive
                          ? "bg-[#241105] text-yellow-300 border border-[#613412]"
                          : "bg-black/40 text-amber-300 border border-amber-200/15"
                      }`}
                    >
                      {isActive ? `✓ ${t.active}` : t.chooseSkin}
                    </div>
                  </button>
                );
              })}
            </div>

            <footer className="relative z-10 flex items-center justify-between gap-2 pt-1 border-t border-amber-200/15 shrink-0">
              <div className="text-[11.5px] font-bold text-amber-100/90 truncate">
                {t.nowActive} <span className="text-yellow-300 font-extrabold">{centerFishName}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setModal(null)}
                  className="ui-btn px-3.5 py-1.5 text-[12px] text-amber-100"
                  style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
                >
                  {t.saveAndClose}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setModal(null);
                    onPlay(cur.id);
                  }}
                  className="ui-btn px-4 py-1.5 text-[12.5px] text-white"
                  style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
                >
                  ▶ {t.playNow}
                </button>
              </div>
            </footer>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="artistic-wood-board px-4 py-2 flex items-center gap-2 text-xs sm:text-sm font-extrabold text-amber-50 shadow-2xl">
            <span aria-hidden="true">{toast.icon}</span>
            <span>{toast.msg}</span>
          </div>
        </div>
      )}
    </div>
  );
}
