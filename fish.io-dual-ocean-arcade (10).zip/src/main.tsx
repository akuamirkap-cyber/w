import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./games/submarine/index.css";

createRoot(document.getElementById("root")!).render(<App />);
