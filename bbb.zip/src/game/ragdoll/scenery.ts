// The backdrop from the reference: a glowing vertical gradient with layered silhouettes - big bonsai-like
// trees with cloud canopies, and grassy hills along the bottom. It is painted once per size/theme into
// three bitmaps (sky + far trees, near trees, hills) that the game slides against each other for parallax
// and fills with living things in between: light shafts, fireflies, mist, falling leaves, birds.

export interface Theme {
  name: string; top: string; mid: string; bot: string;
  tree: string; hill: string; plat: string; platTop: string; glow: string;
  /** rim light on the stickmen, firefly colour, light-shaft colour, foreground grass */
  rim: string; fly: string; ray: string; fg: string;
  /** sun or moon: x,y as fractions, radius factor, colour; night skies also get stars */
  disc: [number, number, number, string]; stars: boolean;
}

export const THEMES: Theme[] = [
  { name: 'Hutan Toska', top: '#0a4767', mid: '#0f8097', bot: '#37ebf1', tree: '#052f48', hill: '#075f74', plat: '#0a3b48', platTop: '#11596a', glow: 'rgba(150,255,250,0.28)', rim: '#1c5566', fly: '#eaff9a', ray: '190,255,250', fg: '#04303d', disc: [0.72, 0.2, 0.09, '#c9fffb'], stars: false },
  { name: 'Senja Ungu', top: '#2a1a5e', mid: '#7440a6', bot: '#f6a3c6', tree: '#170b3d', hill: '#4a2278', plat: '#27144c', platTop: '#40236e', glow: 'rgba(255,200,225,0.3)', rim: '#4b3478', fly: '#ffd9f2', ray: '255,200,235', fg: '#1d0d3f', disc: [0.3, 0.26, 0.1, '#ffd6ec'], stars: true },
  { name: 'Lembah Jingga', top: '#7a2a1c', mid: '#d9652b', bot: '#ffd870', tree: '#47130c', hill: '#8a3516', plat: '#4a1810', platTop: '#70281a', glow: 'rgba(255,240,170,0.35)', rim: '#7a3a22', fly: '#fff0a8', ray: '255,225,150', fg: '#3a0f09', disc: [0.62, 0.42, 0.13, '#fff3b8'], stars: false },
  { name: 'Malam Biru', top: '#050b28', mid: '#14306e', bot: '#4897dc', tree: '#02051a', hill: '#0b2a62', plat: '#071235', platTop: '#12265a', glow: 'rgba(170,215,255,0.25)', rim: '#23407e', fly: '#d8f6ff', ray: '170,210,255', fg: '#020820', disc: [0.76, 0.18, 0.075, '#eef6ff'], stars: true },
  { name: 'Rawa Zamrud', top: '#0a3a2b', mid: '#1c8a5c', bot: '#bdf47e', tree: '#05241a', hill: '#136043', plat: '#0a3324', platTop: '#145038', glow: 'rgba(230,255,170,0.3)', rim: '#1f5a40', fly: '#f4ff9a', ray: '225,255,170', fg: '#04211a', disc: [0.28, 0.22, 0.09, '#eaffc0'], stars: false },
];

type C2 = CanvasRenderingContext2D;
export interface CanvasLike { width: number; height: number; getContext(t: '2d'): unknown }
export type MakeCanvas = (w: number, h: number) => CanvasLike;
/** three parallax bitmaps, each `pad` px wider than the screen on both sides */
export interface Scene { sky: CanvasLike; near: CanvasLike; hills: CanvasLike; pad: number }

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function clump(ctx: C2, rnd: () => number, cx: number, cy: number, rw: number, rh: number) {
  ctx.beginPath();
  const n = 10;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const px = cx + Math.cos(a) * rw * (0.6 + rnd() * 0.3);
    const py = cy + Math.sin(a) * rh * (0.45 + rnd() * 0.3);
    const r = rh * (0.42 + rnd() * 0.33);
    ctx.moveTo(px + r, py); ctx.arc(px, py, r, 0, Math.PI * 2);
  }
  ctx.moveTo(cx + rw * 0.75, cy); ctx.ellipse(cx, cy, rw * 0.75, rh * 0.7, 0, 0, Math.PI * 2);
  ctx.fill();
}

function tree(ctx: C2, rnd: () => number, x: number, baseY: number, height: number, lean: number) {
  const clumps: [number, number, number][] = [];
  const grow = (x0: number, y0: number, ang: number, L: number, wd: number, depth: number) => {
    const bend = (rnd() - 0.5) * 0.7;
    const ex = x0 + Math.cos(ang) * L; const ey = y0 + Math.sin(ang) * L;
    ctx.lineWidth = wd;
    ctx.beginPath(); ctx.moveTo(x0, y0);
    ctx.quadraticCurveTo(x0 + Math.cos(ang + bend) * L * 0.55, y0 + Math.sin(ang + bend) * L * 0.55, ex, ey);
    ctx.stroke();
    if (depth >= 3) { clumps.push([ex, ey, L]); return; }
    const n = depth === 0 ? 3 : 2;
    for (let i = 0; i < n; i++) {
      const spread = (i / (n - 1) - 0.5) * (1.5 + rnd() * 0.5);
      // branches reach sideways rather than straight up, like the flat-topped trees in the reference
      const a = ang + spread + (rnd() - 0.5) * 0.3;
      const flat = a + (Math.cos(a) >= 0 ? 1 : -1) * 0.28 * (depth + 1) * (Math.sin(a) < -0.5 ? 1 : 0.3);
      grow(ex, ey, flat, L * (0.62 + rnd() * 0.18), Math.max(wd * 0.58, 2), depth + 1);
    }
    if (depth >= 2) clumps.push([ex, ey, L * 0.85]);
  };
  ctx.lineCap = 'round';
  // flared foot of the trunk
  ctx.beginPath();
  ctx.moveTo(x - height * 0.075, baseY + 4); ctx.quadraticCurveTo(x - height * 0.03, baseY - height * 0.04, x - height * 0.025, baseY - height * 0.1);
  ctx.lineTo(x + height * 0.025, baseY - height * 0.1); ctx.quadraticCurveTo(x + height * 0.03, baseY - height * 0.04, x + height * 0.075, baseY + 4);
  ctx.closePath(); ctx.fill();
  grow(x, baseY, -Math.PI / 2 + lean, height * 0.4, height * 0.058, 0);
  for (const [cx, cy, L] of clumps) clump(ctx, rnd, cx, cy, L * 1.25, L * 0.55);
}

function hills(ctx: C2, rnd: () => number, w: number, h: number, y0: number, amp: number, u: number) {
  const ph = rnd() * 10; const f1 = (1.2 + rnd()) / w * Math.PI * 2; const f2 = (2.6 + rnd() * 2) / w * Math.PI * 2;
  const top = (x: number) => y0 - Math.sin(x * f1 + ph) * amp - Math.sin(x * f2 + ph * 2.3) * amp * 0.45 - Math.abs(Math.sin(x * f2 * 0.37 + ph)) * amp * 0.5;
  ctx.beginPath(); ctx.moveTo(0, h);
  for (let x = 0; x <= w + 8; x += 8) ctx.lineTo(x, top(x));
  ctx.lineTo(w, h); ctx.closePath(); ctx.fill();
  // grass tufts and little ferns along the ridge
  for (let x = rnd() * 40 * u; x < w; x += (26 + rnd() * 90) * u) {
    const y = top(x) + 2;
    const n = 3 + Math.floor(rnd() * 4);
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + (i / (n - 1) - 0.5) * 1.5 + (rnd() - 0.5) * 0.2;
      const L = (9 + rnd() * 16) * u;
      ctx.beginPath();
      ctx.moveTo(x - 2.4 * u, y); ctx.quadraticCurveTo(x + Math.cos(a) * L * 0.5, y + Math.sin(a) * L * 0.7, x + Math.cos(a) * L, y + Math.sin(a) * L);
      ctx.quadraticCurveTo(x + Math.cos(a) * L * 0.4, y + Math.sin(a) * L * 0.5, x + 2.4 * u, y);
      ctx.closePath(); ctx.fill();
    }
    if (rnd() < 0.22) {
      // a curled sprout with a bud
      const L = (26 + rnd() * 22) * u; const dir = rnd() < 0.5 ? -1 : 1;
      ctx.lineWidth = 2.2 * u; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x, y - L, x + dir * L * 0.45, y - L * 0.9); ctx.stroke();
      ctx.beginPath(); ctx.arc(x + dir * L * 0.45, y - L * 0.82, 4.5 * u, 0, Math.PI * 2); ctx.fill();
    }
  }
}

/** paint the backdrop layers (w,h = screen size in device px) */
export function paintScene(w: number, h: number, th: Theme, seed: number, make: MakeCanvas): Scene {
  const rnd = rng(seed * 7919 + 13);
  const u = Math.max(0.5, Math.min(w, h * 1.5) / 1100);
  const pad = Math.round(46 * u);
  const W = w + pad * 2;
  const sky = make(W, h); const near = make(W, h); const hill = make(W, h);
  const cs = sky.getContext('2d') as C2; const cn = near.getContext('2d') as C2; const ch = hill.getContext('2d') as C2;

  // every silhouette layer is drawn opaque on its own bitmap, then laid down with one even alpha
  const layer = (into: C2, alpha: number, color: string, draw: (c: C2) => void) => {
    const cv = make(W, h);
    const c = cv.getContext('2d') as C2;
    c.fillStyle = color; c.strokeStyle = color;
    draw(c);
    into.globalAlpha = alpha;
    into.drawImage(cv as unknown as CanvasImageSource, 0, 0);
    into.globalAlpha = 1;
  };

  // --- sky: gradient, stars, sun/moon, ground glow, far trees
  const g = cs.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, th.top); g.addColorStop(0.5, th.mid); g.addColorStop(1, th.bot);
  cs.fillStyle = g; cs.fillRect(0, 0, W, h);
  if (th.stars) {
    cs.fillStyle = '#ffffff';
    for (let i = 0; i < 130; i++) {
      const y = rnd() * h * 0.6;
      cs.globalAlpha = (0.15 + rnd() * 0.6) * (1 - y / (h * 0.62));
      cs.beginPath(); cs.arc(rnd() * W, y, (0.5 + rnd() * 1.1) * u, 0, Math.PI * 2); cs.fill();
    }
    cs.globalAlpha = 1;
  }
  const [dx, dy, dr, dc] = th.disc;
  const cx = pad + dx * w; const cy = dy * h; const R = dr * Math.min(w, h * 1.4);
  const halo = cs.createRadialGradient(cx, cy, R * 0.5, cx, cy, R * 4.2);
  halo.addColorStop(0, th.glow); halo.addColorStop(1, 'rgba(255,255,255,0)');
  cs.fillStyle = halo; cs.fillRect(0, 0, W, h);
  cs.globalAlpha = 0.5; cs.fillStyle = dc;
  cs.beginPath(); cs.arc(cx, cy, R, 0, Math.PI * 2); cs.fill();
  cs.globalAlpha = 0.35;
  cs.beginPath(); cs.arc(cx, cy, R * 0.8, 0, Math.PI * 2); cs.fill();
  cs.globalAlpha = 1;
  const glow = cs.createRadialGradient(W * 0.5, h * 1.02, 0, W * 0.5, h * 1.02, Math.max(w, h) * 0.75);
  glow.addColorStop(0, th.glow); glow.addColorStop(1, 'rgba(255,255,255,0)');
  cs.fillStyle = glow; cs.fillRect(0, 0, W, h);
  const baseY = h * 0.93;
  const count = Math.max(2, Math.round(w / (430 * u)));
  layer(cs, 0.2, th.tree, (c) => {
    for (let i = 0; i < count + 1; i++) tree(c, rnd, ((i + 0.15 + rnd() * 0.5) / (count + 1)) * W, baseY - h * 0.08, h * (0.62 + rnd() * 0.2), (rnd() - 0.5) * 0.3);
  });
  // faint horizontal scan texture, as in the screenshot
  cs.fillStyle = 'rgba(255,255,255,0.018)';
  for (let y = 0; y < h; y += Math.max(3, Math.round(4 * u))) cs.fillRect(0, y, W, 1);

  // --- near trees + the canopy hanging in from the top
  layer(cn, 0.34, th.tree, (c) => {
    for (let i = 0; i < count; i++) tree(c, rnd, ((i + 0.25 + rnd() * 0.5) / count) * W, baseY, h * (0.8 + rnd() * 0.22), (rnd() - 0.5) * 0.36);
    for (let i = 0; i < count + 1; i++) clump(c, rnd, ((i + rnd() * 0.8) / (count + 1)) * W, h * (0.02 + rnd() * 0.07), (150 + rnd() * 120) * u, (55 + rnd() * 30) * u);
  });

  // --- hills, plus the corner vignette
  layer(ch, 0.42, th.hill, (c) => hills(c, rnd, W, h, h * 0.88, h * 0.035, u));
  layer(ch, 0.6, th.hill, (c) => hills(c, rnd, W, h, h * 0.955, h * 0.028, u));
  const vg = ch.createRadialGradient(W * 0.5, h * 0.55, Math.min(w, h) * 0.45, W * 0.5, h * 0.55, Math.max(w, h) * 0.85);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,10,25,0.4)');
  ch.fillStyle = vg; ch.fillRect(0, 0, W, h);
  return { sky, near, hills: hill, pad };
}

/** a soft round glow sprite (white core fading out), tinted by the caller's colour */
export function glowSprite(make: MakeCanvas, color: string, size = 64): CanvasLike {
  const cv = make(size, size);
  const c = cv.getContext('2d') as C2;
  const g = c.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.18, color); g.addColorStop(1, 'rgba(255,255,255,0)');
  c.globalAlpha = 1; c.fillStyle = g; c.fillRect(0, 0, size, size);
  // the second stop carries the colour; fade it out toward the edge
  c.globalCompositeOperation = 'destination-in';
  const a = c.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  a.addColorStop(0, 'rgba(0,0,0,1)'); a.addColorStop(0.25, 'rgba(0,0,0,0.55)'); a.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = a; c.fillRect(0, 0, size, size);
  c.globalCompositeOperation = 'source-over';
  return cv;
}
