SWORD OF THE SEA — build siap main
==================================

ISI
---
index.html  → game lengkap dalam SATU file (semua JS/CSS/asset sudah inline).
              Tidak butuh internet, tidak butuh install apa pun.

CARA MAIN
---------
CARA TERMUDAH (offline):
  Double-click index.html — langsung kebuka di Chrome / Edge / Firefox modern.

KALAU BLOKIR (beberapa browser galak soal file://):
  1. Buka terminal / command prompt di folder ini
  2. Jalankan salah satu:
        npx serve .
     atau
        python -m http.server 8000
  3. Buka http://localhost:8000 (atau alamat yang muncul)

HOSTING ONLINE (gratis):
  Upload index.html ke itch.io (HTML game), Netlify Drop, Vercel,
  atau GitHub Pages — langsung bisa dishare sebagai link.

KONTROL
-------
  A / D atau ← / →   = belok (carving)
  SPACE / klik       = lompat · tahan sambil di udara = flip
  WASD trik + grab   = freestyle di udara
  1 / 2 / 3          = mode kamera (Klasik / Sekiro / Sword of the Sea)
  ⚙️ Settings        → tab "Dunia" = ganti world map (Gurun / Ngarai / Kuil)
                       tab "Kamera", "Kabut", "Warna", dll = tuning feel

Build: 30 Sep 2026 · seed dunia 1337
