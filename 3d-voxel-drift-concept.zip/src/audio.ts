export class Sfx {
  ctx: AudioContext | null = null;
  master!: GainNode;
  engGain!: GainNode; engFilter!: BiquadFilterNode; eng1!: OscillatorNode; eng2!: OscillatorNode;
  scrGain!: GainNode; scrFilter!: BiquadFilterNode;
  noiseBuf!: AudioBuffer;
  lastRumble = 0;

  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = (this.ctx = new AC());
    this.master = ctx.createGain(); this.master.gain.value = 0.55;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp).connect(ctx.destination);

    this.noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

    // engine
    this.eng1 = ctx.createOscillator(); this.eng1.type = 'sawtooth';
    this.eng2 = ctx.createOscillator(); this.eng2.type = 'square';
    this.engFilter = ctx.createBiquadFilter(); this.engFilter.type = 'lowpass'; this.engFilter.frequency.value = 500;
    this.engGain = ctx.createGain(); this.engGain.gain.value = 0;
    this.eng1.connect(this.engFilter); this.eng2.connect(this.engFilter);
    this.engFilter.connect(this.engGain).connect(this.master);
    this.eng1.start(); this.eng2.start();

    // tire screech
    const n = ctx.createBufferSource(); n.buffer = this.noiseBuf; n.loop = true;
    this.scrFilter = ctx.createBiquadFilter(); this.scrFilter.type = 'bandpass'; this.scrFilter.frequency.value = 2200; this.scrFilter.Q.value = 6;
    this.scrGain = ctx.createGain(); this.scrGain.gain.value = 0;
    n.connect(this.scrFilter).connect(this.scrGain).connect(this.master);
    n.start();
  }

  update(playing: boolean, speed: number, drifting: boolean) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const f = 45 + speed * 3.2 + (drifting ? 25 : 0);
    this.eng1.frequency.setTargetAtTime(f, t, 0.08);
    this.eng2.frequency.setTargetAtTime(f * 0.5 + 1.5, t, 0.08);
    this.engFilter.frequency.setTargetAtTime(drifting ? 1100 : 650, t, 0.1);
    this.engGain.gain.setTargetAtTime(playing ? 0.07 : 0, t, 0.15);
    this.scrGain.gain.setTargetAtTime(playing && drifting ? 0.09 : 0, t, drifting ? 0.03 : 0.08);
    this.scrFilter.frequency.setTargetAtTime(1900 + Math.sin(t * 40) * 300, t, 0.02);
  }

  tone(freq: number, dur: number, type: OscillatorType = 'square', vol = 0.15, slideTo?: number, delay = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  noise(dur: number, freq: number, vol: number, type: BiquadFilterType = 'lowpass', delay = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t, Math.random()); s.stop(t + dur);
  }

  attach() { this.tone(320, 0.09, 'triangle', 0.18, 160); this.noise(0.08, 3000, 0.08, 'highpass'); }
  release() { this.tone(500, 0.12, 'sine', 0.12, 900); }
  perfect(combo: number) {
    const base = 523 * Math.pow(2, Math.min(combo - 1, 12) / 12);
    [1, 1.26, 1.5, 2].forEach((m, i) => this.tone(base * m, 0.22, 'triangle', 0.16, undefined, i * 0.06));
    this.tone(base * 4, 0.4, 'sine', 0.06, undefined, 0.24);
  }
  nice() { this.tone(660, 0.12, 'triangle', 0.12); this.tone(880, 0.15, 'triangle', 0.1, undefined, 0.07); }
  tick() { this.tone(1200, 0.04, 'sine', 0.05); }
  crash() {
    this.noise(0.6, 900, 0.5);
    this.tone(300, 0.7, 'sawtooth', 0.15, 40);
    this.tone(120, 0.5, 'square', 0.1, 30, 0.1);
  }
  rumble() {
    if (!this.ctx || this.ctx.currentTime - this.lastRumble < 0.25) return;
    this.lastRumble = this.ctx.currentTime;
    this.noise(0.35, 220, 0.12);
  }
  thud(strength = 8) {
    if (!this.ctx) return;
    this.noise(0.25, 170, Math.min(0.5, 0.15 + strength * 0.03));
    this.tone(95, 0.28, 'sine', 0.28, 35);
  }
  nos(big = false) {
    this.noise(0.55, 5200, 0.13, 'highpass');
    this.tone(170, 0.5, 'sawtooth', 0.07, 950);
    if (big) this.tone(85, 0.6, 'square', 0.07, 480, 0.05);
  }
  whoosh() {
    this.noise(0.5, 2500, 0.12, 'bandpass');
    this.tone(200, 0.45, 'sine', 0.1, 700);
  }
  land() {
    this.thud(10);
    this.noise(0.3, 500, 0.2);
  }
  coin(n = 0) {
    const k = (n % 8) / 2;
    this.tone(987 * Math.pow(2, k / 12), 0.08, 'square', 0.07);
    this.tone(1318 * Math.pow(2, k / 12), 0.22, 'square', 0.07, undefined, 0.07);
  }
  fanfare() {
    [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, 0.18, 'square', 0.1, undefined, i * 0.12));
    this.tone(1318, 0.5, 'triangle', 0.12, undefined, 0.75);
  }
  start() { [392, 523, 784].forEach((f, i) => this.tone(f, 0.15, 'square', 0.1, undefined, i * 0.08)); }
}

// ============ MUSIK ADAPTIF (tangga nada pentatonik, full synth) ============
export type MusicStyle = 'off' | 'ceria' | 'ngebut';

const MAJ_PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24];
const MIN_PENTA = [0, 3, 5, 7, 10, 12, 15, 17, 19, 22, 24];
// melodi 32-step, -1 = istirahat
const CERIA_LEAD = [2,-1,3,-1,4,3,2,-1, 2,-1,3,-1,4,-1,5,-1, 5,-1,4,-1,3,-1,2,-1, 3,2,1,2,0,-1,0,-1];
const NGEBUT_LEAD = [4,4,-1,3,2,-1,2,3, 4,4,-1,5,4,3,2,1, 0,-1,0,1,2,-1,2,3, 4,3,2,1,0,-1,-1,-1];
const CERIA_ROOTS = [0, 7, 9, 5];    // C - G - Am - F (bagian bass, riang)
const NGEBUT_ROOTS = [0, 0, -4, -2]; // A - A - F - G (ngebut!)

export class Music {
  ctx: AudioContext | null = null;
  level!: GainNode;
  leadBus!: GainNode;
  noiseBuf: AudioBuffer | null = null;
  style: MusicStyle = 'ceria';
  step = 0;
  nextT = 0;
  lastLevel = -1;

  begin(ctx: AudioContext, master: GainNode, noise: AudioBuffer) {
    if (this.ctx) return;
    this.ctx = ctx;
    this.noiseBuf = noise;
    this.level = ctx.createGain(); this.level.gain.value = 0;
    this.level.connect(master);
    this.leadBus = ctx.createGain();
    const dry = ctx.createGain(); dry.gain.value = 0.8;
    this.leadBus.connect(dry).connect(this.level);
    // echo biar melodi berasa pro
    const dly = ctx.createDelay(1); dly.delayTime.value = 0.27;
    const fb = ctx.createGain(); fb.gain.value = 0.32;
    const wet = ctx.createGain(); wet.gain.value = 0.35;
    this.leadBus.connect(dly); dly.connect(fb).connect(dly); dly.connect(wet).connect(this.level);
  }
  setStyle(s: MusicStyle) { this.style = s; this.step = 0; }

  private toneAt(t: number, freq: number, dur: number, type: OscillatorType, vol: number, dest?: AudioNode, slideTo?: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(Math.max(20, freq), t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(dest || this.level);
    o.start(t); o.stop(t + dur + 0.05);
  }
  private noiseAt(t: number, dur: number, freq: number, vol: number, type: BiquadFilterType) {
    const ctx = this.ctx!;
    const s = ctx.createBufferSource(); s.buffer = this.noiseBuf!;
    s.playbackRate.value = 0.9 + Math.random() * 0.2;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq;
    if (type === 'bandpass') f.Q.value = 1.2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.level);
    s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.02);
  }

  update(_dt: number, run: boolean, intensity: number, drift: boolean, combo: number) {
    if (!this.ctx) return;
    const target = run && this.style !== 'off' ? 0.5 * intensity : 0;
    if (target !== this.lastLevel) {
      this.level.gain.setTargetAtTime(target, this.ctx.currentTime, 0.25);
      this.lastLevel = target;
    }
    if (!run || this.style === 'off') return;
    const ngebut = this.style === 'ngebut';
    const stepDur = 60 / (ngebut ? 150 : 132) / 4;
    const ct = this.ctx.currentTime;
    if (this.nextT < ct - 0.25) this.nextT = ct + 0.06;
    let guard = 0;
    while (this.nextT < ct + 0.18 && guard++ < 12) {
      this.playStep(this.step, this.nextT, ngebut, drift, combo);
      this.nextT += stepDur;
      this.step = (this.step + 1) % 32;
    }
  }

  private playStep(s: number, t: number, ngebut: boolean, drift: boolean, combo: number) {
    const bar = Math.floor(s / 8) % 4;
    if (!ngebut) {
      if (s % 4 === 0) this.toneAt(t, 150, 0.12, 'sine', 0.5, undefined, 42);
      if (s % 2 === 0) this.noiseAt(t, 0.035, 7500, 0.05, 'highpass');
      if (s % 2 === 0) {
        const f = 130.81 * Math.pow(2, CERIA_ROOTS[bar] / 12);
        this.toneAt(t, f, 0.2, 'triangle', 0.17, undefined, f * 0.995);
      }
      const deg = CERIA_LEAD[s];
      if (deg >= 0) {
        const up = combo >= 3 ? 12 : 0;
        const f = 261.63 * Math.pow(2, (MAJ_PENTA[deg] + up) / 12);
        this.toneAt(t, f, 0.24, 'triangle', 0.11, this.leadBus);
        if (combo >= 4) {
          const f2 = 261.63 * Math.pow(2, (MAJ_PENTA[Math.min(deg + 2, MAJ_PENTA.length - 1)] + up) / 12);
          this.toneAt(t + 0.02, f2, 0.2, 'sine', 0.05, this.leadBus);
        }
      }
      if (drift && s % 2 === 1) {
        const f = 523.25 * Math.pow(2, MAJ_PENTA[(s * 3) % 8] / 12);
        this.toneAt(t, f, 0.12, 'sine', 0.045, this.leadBus);
      }
    } else {
      if (s % 4 === 0) this.toneAt(t, 160, 0.11, 'sine', 0.55, undefined, 40);
      if (s % 8 === 4) { this.noiseAt(t, 0.12, 1900, 0.16, 'bandpass'); this.toneAt(t, 195, 0.09, 'triangle', 0.1); }
      this.noiseAt(t, s % 2 ? 0.025 : 0.04, 8000, s % 2 ? 0.03 : 0.055, 'highpass');
      if (s % 2 === 0) {
        const off = NGEBUT_ROOTS[bar] + (s % 8 === 6 ? 12 : 0);
        const f = 110 * Math.pow(2, off / 12);
        this.toneAt(t, f, 0.16, 'sawtooth', 0.08, undefined, f);
      }
      const deg = NGEBUT_LEAD[s];
      if (deg >= 0) {
        const up = combo >= 3 ? 12 : 0;
        const f = 220 * Math.pow(2, (MIN_PENTA[deg] + up) / 12);
        this.toneAt(t, f, 0.14, 'square', 0.05, this.leadBus);
        this.toneAt(t, f / 2, 0.14, 'triangle', 0.06, this.leadBus);
      }
    }
  }
}
