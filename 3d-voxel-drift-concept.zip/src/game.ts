import * as THREE from 'three';
import { Sfx, Music, type MusicStyle } from './audio';

const W = 4.4;
const TAU = Math.PI * 2;
const CHUNK = 1.25; // thin neat slices — satisfying collapse

export type SkinName = 'asphalt' | 'candy';
export type CamMode = 0 | 1 | 2;
export type FxName = 'V1' | 'V2';
export type RoadBuild = 'instant' | 'wave';
export type Mode = 'drift' | 'spidey' | 'free';
export type BotMode = 'off' | 'ghost' | 'solid';
export type NosColor = 'blue' | 'purple' | 'green';
export const NOS: Record<NosColor, { outer: number; mid: number; css: string }> = {
  blue: { outer: 0x2f9dff, mid: 0x9fdcff, css: '63,169,255' },
  purple: { outer: 0xa44dff, mid: 0xe3b8ff, css: '180,92,255' },
  green: { outer: 0x22ee8b, mid: 0xc2ffe2, css: '61,255,158' },
};
export type EdgeName = 'hidden' | 'flat' | 'rail';
export type CarName = 'taxi' | 'panda' | 'damkar' | 'tank' | 'vw' | 'viper';
export const CAM_NAMES = ['KLASIK', 'FOLLOW', 'DRONE'] as const;
export const CARS: { id: CarName; icon: string; label: string }[] = [
  { id: 'viper', icon: '🐍', label: 'VIPER' },
  { id: 'taxi', icon: '🚕', label: 'TAXI' },
  { id: 'panda', icon: '🐼', label: 'PANDA 86' },
  { id: 'damkar', icon: '🚒', label: 'DAMKAR' },
  { id: 'tank', icon: '🪖', label: 'TANK' },
  { id: 'vw', icon: '🪲', label: 'VW' },
];

type Seg = {
  type: 's' | 'a' | 'r';
  jmp?: number;
  launch?: number;
  bld?: THREE.Group;
  y0: number; y1: number; len: number; d0: number;
  sx: number; sz: number; h: number;
  cx: number; cz: number; R: number; a0: number; s: number; sweep: number;
  poleTop?: THREE.Mesh;
};

type Chunk = { g: THREE.Group; d: number; falling: boolean; vy: number; t: number; spin: THREE.Vector3; geo?: THREE.BufferGeometry; by: number; spawned: boolean; spawnT: number; spawnDelay: number };

export type Callbacks = {
  onScore: (score: number, combo: number) => void;
  onPopup: (text: string, color: string) => void;
  onGameOver: (score: number) => void;
  onRaceEnd?: (win: boolean, score: number) => void;
  onRace?: (pp: number, bp: number, remain: number) => void;
  onHint?: (h: string) => void;
  onBoost?: (on: boolean) => void;
};

const wrap = (a: number) => {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
};
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const backOut = (x: number) => { const c = 1.70158; const u = x - 1; return 1 + (c + 1) * u * u * u + c * u * u; };

function sample(sg: Seg, t: number) {
  if (sg.type === 'r') {
    return {
      x: sg.sx + Math.sin(sg.h) * sg.len * t,
      z: sg.sz + Math.cos(sg.h) * sg.len * t,
      y: sg.y0 + (sg.y1 - sg.y0) * t * t,
      h: sg.h,
    };
  }
  if (sg.type === 's') {
    return { x: sg.sx + Math.sin(sg.h) * sg.len * t, z: sg.sz + Math.cos(sg.h) * sg.len * t, y: sg.y0 + (sg.y1 - sg.y0) * t, h: sg.h };
  }
  const a = sg.a0 + sg.s * sg.sweep * t;
  const e = t * t * (3 - 2 * t);
  return { x: sg.cx + sg.R * Math.cos(a), z: sg.cz + sg.R * Math.sin(a), y: sg.y0 + (sg.y1 - sg.y0) * e, h: Math.PI / 2 - (a + sg.s * Math.PI / 2) };
}

function project(sg: Seg, x: number, z: number) {
  if (sg.type === 's' || sg.type === 'r') {
    const dx = x - sg.sx, dz = z - sg.sz;
    const along = dx * Math.sin(sg.h) + dz * Math.cos(sg.h);
    const lat = dx * Math.cos(sg.h) - dz * Math.sin(sg.h);
    if (along < -0.4 || along > sg.len + 0.4) return { t: 0, lat: Infinity, slat: 0 };
    return { t: Math.min(1, Math.max(0, along / sg.len)), lat: Math.abs(lat), slat: lat };
  }
  const a = Math.atan2(z - sg.cz, x - sg.cx);
  let d = (((sg.s * (a - sg.a0)) % TAU) + TAU) % TAU;
  if (d > sg.sweep) {
    if (d > TAU - 0.08) d = 0;
    else if (d < sg.sweep + 0.08) d = sg.sweep;
    else return { t: 0, lat: Infinity, slat: 0 };
  }
  const l = Math.hypot(x - sg.cx, z - sg.cz) - sg.R;
  return { t: d / sg.sweep, lat: Math.abs(l), slat: l };
}

type Skin = {
  fog: number; sky: [string, string, string];
  road: number; roadSide: number; roadBottom: number;
  line: number; dust: number[];
};

const SKINS: Record<SkinName, Skin> = {
  asphalt: {
    fog: 0xc9b8ff, sky: ['#8f7bff', '#c9b8ff', '#efe6ff'],
    road: 0x40404e, roadSide: 0x9aa0c2, roadBottom: 0x666a85,
    line: 0xf5f5f5, dust: [0x9aa0b8, 0xffffff, 0xe0606e],
  },
  candy: {
    fog: 0xcfe8ff, sky: ['#5fc8ff', '#bfe6ff', '#ffd3ec'],
    road: 0xfdf8ff, roadSide: 0xc4b3f2, roadBottom: 0x9d8ae0,
    line: 0xffd6e6, dust: [0xd9ccff, 0xffffff, 0xff8fb0],
  },
};

// soft edge palette (shared by both skins)
const EDGE = {
  flatA: new THREE.Color(0xe0606e), flatB: new THREE.Color(0xf6f1e7),
  flatSideA: new THREE.Color(0xb84a58), flatSideB: new THREE.Color(0xcfc8b8),
  rail: new THREE.Color(0xbf5570), railSide: new THREE.Color(0x9e4259),
};

export class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  cb: Callbacks;
  sfx = new Sfx();
  music = new Music();
  musicStyle: MusicStyle = 'ceria';
  skin: SkinName = 'asphalt';
  fx: FxName = 'V2';
  roadBuild: RoadBuild = 'instant';
  mode: Mode = 'drift';
  nos: NosColor = 'blue';
  nosN = 0;
  nosKey = false;
  nosToggleMode = false; nosToggleOn = false; nosMul = 1; comboKey = false;
  boostFxOn = false;
  effV = 13;
  slope = 0;
  airborne = false; airVy = 0; airT = 0; airLaunchY = 0; lastJumpN = -99;
  freeDir = 0; freeSlide = 0; freeSX = 0; freeSZ = 0; driftAcc = 0;
  bot: BotMode = 'off';
  botDist = 0; botV = 13; botOff = 0; bumpX = 0; bumpZ = 0; bumpCD = 0; botH = 0; botPush = 0; bumpSlow = 0;
  finishD = 1100; raceAcc = 0;
  coins: { m: THREE.Mesh; d: number; chunk: Chunk; got: boolean }[] = [];
  botCar!: THREE.Group; botMats: THREE.Material[] = [];
  coinStreak = 0; coinT = 0;
  coinGeo = new THREE.BoxGeometry(0.45, 0.55, 0.14);
  coinMat = new THREE.MeshBasicMaterial({ color: 0xffc93c });
  checkerTex!: THREE.CanvasTexture;
  fovKick = 0;
  settled = false;
  overSent = false;
  edge: EdgeName = 'hidden';
  carName: CarName = 'viper';
  pal = { road: new THREE.Color(), roadSide: new THREE.Color(), roadBottom: new THREE.Color(), line: new THREE.Color() };
  segs: Seg[] = [];
  chunks: Chunk[] = [];
  base = 0; cur = 0; dist = 0;
  gen = { x: 0, z: 0, h: 0, y: 0, d: 0 };
  car!: THREE.Group; carBody!: THREE.Group;
  carBodies: Partial<Record<CarName, THREE.Group>> = {};
  pos = new THREE.Vector3(); h = 0; v = 13;
  vis = { yaw: 0, yawV: 0, roll: 0, sq: 1, sqV: 0, pitch: 0, pitchV: 0 };
  attached: Seg | null = null; attachErr = 0;
  orbit = { r: 0, a: 0, s: 1 };
  holding = false;
  state: 'idle' | 'play' | 'crash' | 'done' = 'idle';
  crashT = 0; crashVel = new THREE.Vector3();
  score = 0; combo = 0; shake = 0;
  camMode: CamMode = 0;
  lastHint = '';
  ropeSegs: THREE.Mesh[] = [];
  ropeT = 0; ropeWob = 0; ropeSlack = 0;
  ropeB = new THREE.Vector3();
  ropeTmpA = new THREE.Vector3(); ropeTmpE = new THREE.Vector3();
  ropeTmp1 = new THREE.Vector3(); ropeTmp2 = new THREE.Vector3(); ropeTmp3 = new THREE.Vector3();
  flame!: THREE.Group;
  flameMeshes: THREE.Mesh[] = [];
  flameOuter!: THREE.MeshBasicMaterial;
  flameMid!: THREE.MeshBasicMaterial;
  flameGlow!: THREE.MeshBasicMaterial;
  light: THREE.DirectionalLight;
  parts: { m: THREE.Mesh; v: THREE.Vector3; life: number; max: number; grow: number; grav: boolean }[] = [];
  partIdx = 0;
  skids: { m: THREE.Mesh; life: number }[] = [];
  skidIdx = 0;
  boxGeo = new THREE.BoxGeometry(1, 1, 1);
  roadMat = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
  poleMat = new THREE.MeshLambertMaterial({ color: 0xf2f2f5 });
  ringMat = new THREE.MeshLambertMaterial({ color: 0xe0606e });
  signPoleMat = new THREE.MeshLambertMaterial({ color: 0x4a4a5a });
  signBoardMat = new THREE.MeshLambertMaterial({ color: 0x23232e });
  signArrowMat = new THREE.MeshLambertMaterial({ color: 0xffd23f, emissive: 0x553f00 });
  coneMat = new THREE.MeshLambertMaterial({ color: 0xff7a1a });
  coneStripeMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
  camPos = new THREE.Vector3();
  raf = 0; last = performance.now();
  clouds: THREE.Group[] = [];

  constructor(el: HTMLElement, cb: Callbacks) {
    this.cb = cb;
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    el.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 400);
    this.applySkin(this.skin, true);

    this.scene.add(new THREE.HemisphereLight(0xffffff, 0xb9a8ff, 1.7));
    this.light = new THREE.DirectionalLight(0xfff4e8, 1.5);
    this.light.castShadow = true;
    this.light.shadow.mapSize.set(1024, 1024);
    const sc = this.light.shadow.camera;
    sc.left = -22; sc.right = 22; sc.top = 22; sc.bottom = -22; sc.far = 90;
    this.scene.add(this.light, this.light.target);

    const ropeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    for (let i = 0; i < 12; i++) {
      const rm = new THREE.Mesh(this.boxGeo, ropeMat);
      rm.visible = false;
      this.scene.add(rm);
      this.ropeSegs.push(rm);
    }
    this.ropeB.set(0, 0, 0);

    for (let i = 0; i < 140; i++) {
      const m = new THREE.Mesh(this.boxGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, depthWrite: false }));
      m.visible = false; this.scene.add(m);
      this.parts.push({ m, v: new THREE.Vector3(), life: 0, max: 1, grow: 1, grav: false });
    }
    const skidGeo = new THREE.PlaneGeometry(0.3, 0.55); skidGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 260; i++) {
      const m = new THREE.Mesh(skidGeo, new THREE.MeshBasicMaterial({ color: 0x23232e, transparent: true, opacity: 0, depthWrite: false }));
      m.visible = false; this.scene.add(m);
      this.skids.push({ m, life: 0 });
    }
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0x333344 });
    for (let i = 0; i < 36; i++) {
      const g = new THREE.Group();
      for (let k = 0; k < 4; k++) {
        const b = new THREE.Mesh(this.boxGeo, cloudMat);
        b.scale.set(rand(2, 5), rand(1.5, 3), rand(2, 5));
        b.position.set(rand(-3, 3), rand(-0.5, 0.5), rand(-3, 3));
        g.add(b);
      }
      g.position.set(rand(-70, 70), rand(-40, -15), rand(-20, 140));
      this.scene.add(g); this.clouds.push(g);
    }

    this.buildCars();
    this.buildSpidey();
    this.buildBot();
    const ccv = document.createElement('canvas'); ccv.width = 64; ccv.height = 16;
    const ccx = ccv.getContext('2d')!;
    for (let yy = 0; yy < 2; yy++) for (let xx = 0; xx < 8; xx++) { ccx.fillStyle = (xx + yy) % 2 ? '#111116' : '#f5f5f5'; ccx.fillRect(xx * 8, yy * 8, 8, 8); }
    this.checkerTex = new THREE.CanvasTexture(ccv); this.checkerTex.colorSpace = THREE.SRGBColorSpace;
    this.buildFlame();
    this.bldMats = [0x8f93c9, 0x7d84c2, 0xa5a8d8, 0x6f76b8].map((c) => new THREE.MeshLambertMaterial({ color: c }));
    const streetGeo = new THREE.PlaneGeometry(500, 500); streetGeo.rotateX(-Math.PI / 2);
    this.street = new THREE.Mesh(streetGeo, new THREE.MeshLambertMaterial({ color: 0x35314a }));
    this.street.visible = false;
    this.scene.add(this.street);
    this.reset();
    window.addEventListener('resize', this.resize);
    this.resize();
    this.loop();
  }

  applySkin(name: SkinName, first = false) {
    this.skin = name;
    const S = SKINS[name];
    this.pal.road.set(S.road); this.pal.roadSide.set(S.roadSide); this.pal.roadBottom.set(S.roadBottom);
    this.pal.line.set(S.line);
    const cv = document.createElement('canvas'); cv.width = 2; cv.height = 256;
    const cx = cv.getContext('2d')!;
    const gr = cx.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, S.sky[0]); gr.addColorStop(0.55, S.sky[1]); gr.addColorStop(1, S.sky[2]);
    cx.fillStyle = gr; cx.fillRect(0, 0, 2, 256);
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const old = this.scene.background as THREE.Texture | null;
    this.scene.background = tex;
    if (old && (old as THREE.Texture).isTexture && !first) (old as THREE.Texture).dispose();
    this.scene.fog = new THREE.Fog(S.fog, 50, 135);
  }

  setSkin(name: SkinName) {
    if (name === this.skin) return;
    this.applySkin(name);
    if (this.state !== 'play') this.reset();
  }
  setEdge(e: EdgeName) {
    if (e === this.edge) return;
    this.edge = e;
    if (this.state !== 'play') this.reset();
  }
  setCar(name: CarName) {
    this.carName = name;
    if (this.mode === 'spidey') return;
    for (const k of Object.keys(this.carBodies) as CarName[]) {
      const b = this.carBodies[k]!;
      b.visible = k === name;
    }
    this.carBody = this.carBodies[name]!;
    this.carBody.rotation.set(0, 0, 0);
  }
  applyMode() {
    const sp = this.mode === 'spidey';
    for (const k of Object.keys(this.carBodies) as CarName[]) this.carBodies[k]!.visible = !sp && k === this.carName;
    this.spideyRoot.visible = sp;
    this.carBody = sp ? this.spideyBody : this.carBodies[this.carName]!;
    this.carBody.rotation.set(0, 0, 0);
    this.street.visible = false;
  }
  setCam(m: CamMode) { this.camMode = m; }
  setMode(m: Mode) { if (m === this.mode) return; this.mode = m; this.botCar.visible = this.raceOn(); if (this.state !== 'play') this.reset(); }
  setBot(b: BotMode) {
    this.bot = b;
    this.botCar.visible = b !== 'off' && this.mode !== 'spidey';
    const ghost = b === 'ghost';
    for (const mt of this.botMats) {
      mt.transparent = ghost;
      (mt as THREE.MeshLambertMaterial).opacity = ghost ? 0.55 : 1;
      mt.depthWrite = !ghost;
      mt.needsUpdate = true;
    }
  }
  raceOn() { return this.bot !== 'off' && this.mode !== 'spidey'; }
  setFx(f: FxName) { const was = this.fx; this.fx = f; if (was !== f && this.state !== 'play') this.reset(); }
  setRoadBuild(b: RoadBuild) { if (b === this.roadBuild) return; this.roadBuild = b; if (this.state !== 'play') this.reset(); }
  setNos(c: NosColor) {
    this.nos = c;
    if (this.flameOuter) {
      this.flameOuter.color.set(NOS[c].outer);
      this.flameMid.color.set(NOS[c].mid);
      this.flameGlow.color.set(NOS[c].outer);
    }
  }
  setNosMode(toggle: boolean) { this.nosToggleMode = toggle; this.nosToggleOn = false; }
  setBoostFx(on: boolean) { if (on !== this.boostFxOn) { this.boostFxOn = on; this.cb.onBoost?.(on); } }
  nosActive() { return this.nosN > 0 || this.nosKey || this.nosToggleOn || this.comboKey; }
  nosDown() {
    if (this.nosToggleMode) {
      this.nosToggleOn = !this.nosToggleOn;
      if (this.nosToggleOn && this.state === 'play') this.sfx.nos(true);
    } else {
      this.nosN++;
      if (this.state === 'play') this.sfx.nos(true);
    }
  }
  nosUp() { if (!this.nosToggleMode) this.nosN = Math.max(0, this.nosN - 1); }
  nosKeyDown() { if (!this.nosKey) { this.nosKey = true; if (this.state === 'play') this.sfx.nos(true); } }
  nosKeyUp() { this.nosKey = false; }
  comboDown() { if (!this.comboKey) { this.comboKey = true; if (this.state === 'play') this.sfx.nos(true); } }
  comboUp() { this.comboKey = false; }
  hideRope() { for (const m of this.ropeSegs) m.visible = false; }
  ropeAY() { return this.mode === 'spidey' ? 1.3 : 0.8; }
  renderRope(A: THREE.Vector3, E: THREE.Vector3, time: number) {
    const N = this.ropeSegs.length;
    const dir = this.ropeTmp1.copy(E).sub(A);
    const L = Math.max(0.001, dir.length());
    const side = this.ropeTmp2.set(-dir.z, 0, dir.x);
    if (side.lengthSq() < 1e-6) side.set(1, 0, 0); else side.normalize();
    const sagAmt = (0.04 + this.ropeSlack) * L * 0.1;
    const wob = this.ropeWob * Math.min(1.4, 2 + L * 0.05);
    const th = (0.07 + this.ropeSlack * 0.06) * (this.mode === 'spidey' ? 0.55 : 1);
    let px = 0, py = 0, pz = 0;
    for (let i = 0; i <= N; i++) {
      const tt = i / N;
      const env = Math.sin(Math.PI * tt);
      const wx = A.x + (E.x - A.x) * tt + side.x * wob * env * Math.sin(time * 26 - tt * 7);
      const wy = A.y + (E.y - A.y) * tt - sagAmt * env + wob * 0.3 * env * Math.cos(time * 31 - tt * 5);
      const wz = A.z + (E.z - A.z) * tt + side.z * wob * env * Math.sin(time * 26 - tt * 7);
      if (i > 0) {
        const m = this.ropeSegs[i - 1];
        m.visible = true;
        m.position.set((px + wx) / 2, (py + wy) / 2, (pz + wz) / 2);
        this.ropeTmp3.set(wx, wy, wz);
        m.lookAt(this.ropeTmp3);
        m.scale.set(th, th, Math.hypot(wx - px, wy - py, wz - pz) * 1.2 + 0.02);
      }
      px = wx; py = wy; pz = wz;
    }
  }
  buildFlame() {
    const flame = new THREE.Group();
    this.flameOuter = new THREE.MeshBasicMaterial({ color: NOS[this.nos].outer, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false });
    this.flameMid = new THREE.MeshBasicMaterial({ color: NOS[this.nos].mid, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false });
    const core = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false });
    const f1 = new THREE.Mesh(this.boxGeo, this.flameOuter); f1.scale.set(0.44, 0.44, 0.92); f1.position.set(0, 0.35, -1.32);
    const f2 = new THREE.Mesh(this.boxGeo, this.flameMid); f2.scale.set(0.27, 0.27, 0.72); f2.position.set(0, 0.35, -1.24);
    const f3 = new THREE.Mesh(this.boxGeo, core); f3.scale.set(0.14, 0.14, 0.5); f3.position.set(0, 0.35, -1.16);
    const cv = document.createElement('canvas'); cv.width = cv.height = 128;
    const cx2 = cv.getContext('2d')!;
    const grd = cx2.createRadialGradient(64, 64, 4, 64, 64, 64);
    grd.addColorStop(0, 'rgba(255,255,255,0.85)');
    grd.addColorStop(0.45, 'rgba(255,255,255,0.28)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    cx2.fillStyle = grd; cx2.fillRect(0, 0, 128, 128);
    this.flameGlow = new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(cv), color: NOS[this.nos].outer, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
    const glowGeo = new THREE.PlaneGeometry(3.4, 5.2); glowGeo.rotateX(-Math.PI / 2);
    const glow = new THREE.Mesh(glowGeo, this.flameGlow);
    glow.position.set(0, 0.06, -0.6); glow.renderOrder = 5;
    flame.add(f1, f2, f3, glow);
    flame.visible = false;
    this.flame = flame;
    this.flameMeshes = [f1, f2, f3];
    this.car.add(flame);
  }
  buildBot() {
    const car = new THREE.Group();
    const M = (c: number) => { const m = new THREE.MeshLambertMaterial({ color: c }); this.botMats.push(m); return m; };
    const main = M(0x9a5cf0), white = M(0xffffff), glass = M(0x2f3a5c), dark = M(0x2b2b3a), yel = M(0xfff27a), red = M(0xff2244);
    const bx = (w: number, h: number, d: number, x: number, y: number, z: number, m: THREE.Material) => {
      const b = new THREE.Mesh(this.boxGeo, m);
      b.scale.set(w, h, d); b.position.set(x, y, z); b.castShadow = true;
      car.add(b); return b;
    };
    bx(1.4, 0.55, 2.0, 0, 0.55, 0, main);
    bx(1.5, 0.22, 1.9, 0, 0.36, 0, white);
    bx(1.2, 0.7, 1.05, 0, 1.15, -0.2, main);
    bx(1.26, 0.42, 0.9, 0, 1.18, -0.2, glass);
    bx(1.05, 0.45, 1.12, 0, 1.18, -0.2, glass);
    bx(0.28, 0.22, 0.08, -0.45, 0.62, 1.0, yel);
    bx(0.28, 0.22, 0.08, 0.45, 0.62, 1.0, yel);
    bx(0.5, 0.1, 0.06, 0, 0.45, 1.02, dark);
    bx(0.25, 0.15, 0.08, -0.5, 0.62, -1.0, red);
    bx(0.25, 0.15, 0.08, 0.5, 0.62, -1.0, red);
    for (const [x, z] of [[-0.68, 0.62], [0.68, 0.62], [-0.68, -0.62], [0.68, -0.62]]) {
      bx(0.3, 0.5, 0.5, x, 0.25, z, dark);
      bx(0.32, 0.2, 0.2, x, 0.25, z, white);
    }
    car.scale.setScalar(0.85);
    car.visible = false;
    this.botCar = car;
    this.scene.add(car);
  }
  buildSpidey() {
    const L = (c: number) => new THREE.MeshLambertMaterial({ color: c });
    const red = L(0xd63a3a), blue = L(0x2f5fd0), white = L(0xffffff), dark = L(0x23232e);
    const root = new THREE.Group();
    const body = new THREE.Group();
    const bx = (w: number, h: number, d: number, x: number, y: number, z: number, m: THREE.Material) => {
      const b = new THREE.Mesh(this.boxGeo, m);
      b.scale.set(w, h, d); b.position.set(x, y, z); b.castShadow = true;
      body.add(b); return b;
    };
    bx(0.5, 0.35, 0.35, 0, 0.95, 0, blue);
    bx(0.55, 0.55, 0.38, 0, 1.35, 0, red);
    bx(0.2, 0.5, 0.1, 0, 1.35, 0.2, dark);
    bx(0.42, 0.42, 0.42, 0, 1.85, 0, red);
    bx(0.16, 0.12, 0.06, -0.12, 1.9, 0.2, white);
    bx(0.16, 0.12, 0.06, 0.12, 1.9, 0.2, white);
    const mkLimb = (x: number, y: number, w: number, l: number, m: THREE.Material, boot: boolean) => {
      const piv = new THREE.Group(); piv.position.set(x, y, 0);
      const a = new THREE.Mesh(this.boxGeo, m); a.scale.set(w, l, w); a.position.y = -l / 2; a.castShadow = true; piv.add(a);
      if (boot) { const bt = new THREE.Mesh(this.boxGeo, red); bt.scale.set(w + 0.04, 0.14, w + 0.12); bt.position.set(0, -l - 0.04, 0.03); bt.castShadow = true; piv.add(bt); }
      body.add(piv); return piv;
    };
    this.armL = mkLimb(-0.37, 1.55, 0.16, 0.55, red, false);
    this.armR = mkLimb(0.37, 1.55, 0.16, 0.55, red, false);
    this.legL = mkLimb(-0.15, 0.78, 0.18, 0.6, blue, true);
    this.legR = mkLimb(0.15, 0.78, 0.18, 0.6, blue, true);
    root.add(body);
    root.visible = false;
    this.spideyRoot = root; this.spideyBody = body;
    this.car.add(root);
  }
  updateSpidey(dt: number, t: number) {
    if (this.state === 'crash') {
      this.armL.rotation.x = Math.sin(t * 21) * 1.2;
      this.armR.rotation.x = Math.sin(t * 23 + 1) * 1.2;
      this.legL.rotation.x = Math.sin(t * 19 + 2) * 1.0;
      this.legR.rotation.x = Math.sin(t * 22 + 3) * 1.0;
      return;
    }
    const D = Math.min(1, dt * 14);
    let aL = 0, aR = 0, lL = 0, lR = 0;
    if (this.attached) { aR = -2.7; aL = 0.9; lL = 0.85; lR = -0.55; }
    else {
      this.runPhase += dt * (6 + this.effV * 0.12);
      const p = this.runPhase;
      lL = Math.sin(p) * 0.75; lR = Math.sin(p + Math.PI) * 0.75;
      aL = Math.sin(p + Math.PI) * 0.6; aR = Math.sin(p) * 0.6;
    }
    this.armL.rotation.x += (aL - this.armL.rotation.x) * D;
    this.armR.rotation.x += (aR - this.armR.rotation.x) * D;
    this.legL.rotation.x += (lL - this.legL.rotation.x) * D;
    this.legR.rotation.x += (lR - this.legR.rotation.x) * D;
  }
  buildBlds(seg: Seg) {
    const g = new THREE.Group();
    const n = Math.max(2, Math.round(seg.len / 4));
    for (let i = 0; i <= n; i++) {
      const sp = sample(seg, i / n);
      for (const sd of [-1, 1]) {
        if (Math.random() < 0.15) continue;
        const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
        const off = sd * (W / 2 + rand(3.5, 8));
        const w = rand(3, 6.5), dpt = rand(3, 6.5);
        const topY = sp.y + rand(-5, 7);
        const hgt = rand(25, 55);
        const b = new THREE.Mesh(this.boxGeo, this.bldMats[(Math.random() * this.bldMats.length) | 0]);
        b.position.set(sp.x + rx * off, topY - hgt / 2, sp.z + rz * off);
        b.scale.set(w, hgt, dpt);
        b.rotation.y = sp.h;
        g.add(b);
        const cap = new THREE.Mesh(this.boxGeo, this.bldCapMat);
        cap.position.set(b.position.x, topY + 0.15, b.position.z);
        cap.scale.set(w + 0.3, 0.3, dpt + 0.3);
        cap.rotation.y = sp.h;
        g.add(cap);
        if (Math.random() < 0.3) {
          const bc = new THREE.Mesh(this.boxGeo, this.bldBeaconMat);
          bc.position.set(b.position.x, topY + 0.7, b.position.z);
          bc.scale.setScalar(0.4);
          g.add(bc);
        }
      }
    }
    seg.bld = g;
    this.scene.add(g);
  }
  setMusicStyle(s2: MusicStyle) { this.musicStyle = s2; this.music.setStyle(s2); }
  cycleCam(): CamMode { this.camMode = ((this.camMode + 1) % 3) as CamMode; return this.camMode; }
  edgeTol() { return this.edge === 'flat' ? W / 2 + 1.05 : this.edge === 'rail' ? W / 2 + 0.35 : W / 2 + 0.7; }
  spideyRoot!: THREE.Group; spideyBody!: THREE.Group;
  armL!: THREE.Group; armR!: THREE.Group; legL!: THREE.Group; legR!: THREE.Group;
  runPhase = 0;
  street!: THREE.Mesh;
  bldMats: THREE.MeshLambertMaterial[] = [];
  bldCapMat = new THREE.MeshLambertMaterial({ color: 0xe8e6f5 });
  bldBeaconMat = new THREE.MeshBasicMaterial({ color: 0xff4455 });
  tangentAtDist(d: number): number {
    for (let i = this.cur; i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (!sg) break;
      if (d <= sg.d0 + sg.len) {
        const t = Math.min(1, Math.max(0, (d - sg.d0) / Math.max(0.001, sg.len)));
        return sg.type === 'r' || sg.type === 's' ? sg.h : Math.PI / 2 - ((sg.a0 + sg.s * sg.sweep * t) + sg.s * Math.PI / 2);
      }
    }
    return this.h;
  }

  freeUpdate(dt: number, sp: number) {
    const manual = this.mode === 'free' || (this.holding && !this.attached && this.nosActive());
    if (!this.holding || !manual) {
      this.freeDir *= Math.exp(-6 * dt);
      this.freeSlide *= Math.exp(-4 * dt);
      this.pos.x += this.freeSX * this.freeSlide * dt;
      this.pos.z += this.freeSZ * this.freeSlide * dt;
      this.driftAcc = 0;
      return;
    }
    let d = 0, R = 7, onArc = false, ox = 0, oz = 0;
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.type !== 'a') continue;
      if (i === this.cur) {
        const p = project(sg, this.pos.x, this.pos.z);
        if (p.lat < W / 2 + 3) {
          d = -sg.s; R = sg.R;
          if (p.lat < W / 2 + 1.5) {
            onArc = true;
            const l = Math.hypot(this.pos.x - sg.cx, this.pos.z - sg.cz) || 1;
            ox = (this.pos.x - sg.cx) / l; oz = (this.pos.z - sg.cz) / l;
          }
          break;
        }
      } else if (sg.d0 - this.dist < (this.mode === 'free' ? 25 : 40)) { d = -sg.s; R = sg.R; break; }
    }
    this.freeDir = d;
    if (d !== 0) {
      const rate = sp / Math.max(3, R * (onArc ? 0.95 : 1.4));
      this.h += d * rate * dt * (onArc ? 1 : 0.45);
    }
    const slideT = onArc ? sp * 0.3 : 0;
    this.freeSlide += (slideT - this.freeSlide) * Math.min(1, dt * 3);
    if (onArc) { this.freeSX = ox; this.freeSZ = oz; }
    this.pos.x += this.freeSX * this.freeSlide * dt;
    this.pos.z += this.freeSZ * this.freeSlide * dt;
    if (onArc) {
      this.driftAcc += dt;
      if (this.driftAcc >= 0.8) { this.driftAcc -= 0.8; this.score++; this.cb.onScore(this.score, this.combo); this.sfx.tick(); }
    } else this.driftAcc = 0;
  }
  freeLate(): boolean {
    const sg = this.seg(this.cur);
    if (!sg || sg.type !== 'a') return false;
    const p = project(sg, this.pos.x, this.pos.z);
    return p.t > 0.6 && p.lat < W;
  }
  posAtDist(d: number) {
    const startI = Math.max(this.base, this.cur - 4);
    for (let i = startI; i < this.base + this.segs.length; i++) {
      const sg = this.seg(i);
      if (!sg) break;
      if (d >= sg.d0 && d <= sg.d0 + sg.len) {
        const p = sample(sg, (d - sg.d0) / Math.max(0.001, sg.len));
        return { x: p.x, y: p.y, z: p.z, h: p.h };
      }
      if (d < sg.d0 && i > startI) {
        const pv = this.seg(i - 1);
        if (pv) {
          const e0 = sample(pv, 1), e1 = sample(sg, 0);
          const gap = Math.max(0.01, sg.d0 - (pv.d0 + pv.len));
          const t = Math.min(1, Math.max(0, (d - (pv.d0 + pv.len)) / gap));
          const hop = Math.sin(t * Math.PI) * 2.2;
          return { x: e0.x + (e1.x - e0.x) * t, y: e0.y + (e1.y - e0.y) * t + hop, z: e0.z + (e1.z - e0.z) * t, h: Math.atan2(e1.x - e0.x, e1.z - e0.z) };
        }
      }
    }
    const fst = this.seg(startI);
    if (fst && d < fst.d0) {
      const p = sample(fst, 0);
      const back = fst.d0 - d;
      return { x: p.x - Math.sin(p.h) * back, y: p.y, z: p.z - Math.cos(p.h) * back, h: p.h };
    }
    const last = this.segs[this.segs.length - 1];
    if (last) { const p = sample(last, 1); return { x: p.x, y: p.y, z: p.z, h: p.h }; }
    return { x: 0, y: 0, z: 4, h: 0 };
  }
  finishRace(win: boolean) {
    if (this.state === 'done') return;
    this.state = 'done';
    this.attached = null; this.ropeT = 0; this.hideRope();
    this.setBoostFx(false); this.setHint('');
    if (win) {
      for (let k = 0; k < 3; k++) this.burst(this.pos.clone().add(new THREE.Vector3(rand(-3, 3), 2 + k, rand(-3, 3))), [0xffd23f, 0xff5c8a, 0x7cf0ff, 0xffffff], 20);
      this.sfx.fanfare();
      navigator.vibrate?.([30, 50, 30, 50, 60]);
    }
    this.cb.onRaceEnd?.(win, this.score);
  }
  jumpAhead(): boolean {
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.jmp !== 2) continue;
      const gapD = sg.d0 + sg.len - this.dist;
      if (gapD > -2 && gapD < 22) return true;
    }
    return false;
  }
  launch(sp: number) {
    const nosing = this.nosActive();
    const sg = this.seg(this.cur);
    const lip = sg?.launch ?? 0.4;
    this.airborne = true;
    this.airT = 0;
    this.airVy = Math.min(sp * lip, 8) * (nosing ? 1 : 0.45);
    this.airLaunchY = this.pos.y;
    if (nosing) { this.sfx.whoosh(); this.shake = Math.max(this.shake, 0.25); }
  }
  updateAir(dt: number, sp: number) {
    this.airT += dt;
    this.airVy -= 30 * dt;
    this.pos.x += Math.sin(this.h) * sp * dt;
    this.pos.z += Math.cos(this.h) * sp * dt;
    this.pos.y += this.airVy * dt;
    this.dist += sp * dt;
    if (Math.random() < 0.4) {
      this.spawn(new THREE.Vector3(this.pos.x, this.pos.y + 0.3, this.pos.z), 0xffffff,
        new THREE.Vector3(rand(-1, 1), rand(0, 1), rand(-1, 1)), 0.25, 0.4, 1.5);
    }
    if (this.airVy < 0) {
      for (let i = this.cur; i < this.cur + 6; i++) {
        const sg = this.seg(i);
        if (!sg) continue;
        const p = project(sg, this.pos.x, this.pos.z);
        if (p.lat < this.edgeTol() && p.t > -0.02 && p.t < 1.02) {
          const ry = sample(sg, Math.min(1, Math.max(0, p.t))).y;
          if (this.pos.y <= ry + 0.15) {
            this.airborne = false;
            this.pos.y = ry;
            if (i > this.cur) { this.score += i - this.cur; this.cur = i; this.ensureTrack(); }
            this.dist = sg.d0 + p.t * sg.len;
            const bonus = 2 + Math.floor(this.airT);
            this.score += bonus;
            this.cb.onScore(this.score, this.combo);
            this.cb.onPopup(`AIR +${bonus}!`, '#7cf0ff');
            this.vis.sqV = -5;
            this.shake = Math.max(this.shake, 0.3);
            this.sfx.land();
            this.burst(this.pos, [0xffffff, 0x9aa0b8], 14);
            navigator.vibrate?.([20, 40, 20]);
            return;
          }
          break;
        }
      }
    }
    if (this.pos.y < this.airLaunchY - 12 || this.airT > 3) {
      if (this.raceOn()) { this.finishRace(false); return; }
      this.state = 'crash';
      this.crashT = 0;
      this.airborne = false;
      this.settled = false; this.overSent = false;
      this.setBoostFx(false);
      this.crashVel.set(Math.sin(this.h) * sp * 0.7, Math.min(0, this.airVy), Math.cos(this.h) * sp * 0.7);
      this.shake = 0.9;
      this.cb.onPopup('OOPS!', '#ff5c8a');
      this.sfx.crash();
      this.setHint('');
      navigator.vibrate?.(120);
    }
  }

  resize = () => {
    this.renderer.setSize(innerWidth, innerHeight);
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
  };

  // ---------- cute voxel cars ----------
  buildCars() {
    const car = new THREE.Group();
    const L = (c: number) => new THREE.MeshLambertMaterial({ color: c });
    const dark = L(0x2b2b3a), white = L(0xffffff), glass = L(0x2f3a5c), yel = L(0xfff27a),
      red = L(0xff2244), pink = L(0xff9db4), chrome = L(0xd8dce8);
    const bx = (parent: THREE.Group, w: number, h: number, d: number, x: number, y: number, z: number, m: THREE.Material) => {
      const b = new THREE.Mesh(this.boxGeo, m);
      b.scale.set(w, h, d); b.position.set(x, y, z); b.castShadow = true;
      parent.add(b); return b;
    };
    const wheels = (parent: THREE.Group, hub: THREE.Material) => {
      for (const [x, z] of [[-0.68, 0.62], [0.68, 0.62], [-0.68, -0.62], [0.68, -0.62]]) {
        bx(parent, 0.3, 0.5, 0.5, x, 0.25, z, dark);
        bx(parent, 0.32, 0.2, 0.2, x, 0.25, z, hub);
      }
    };
    const face = (parent: THREE.Group, lamp: THREE.Material, smileAt = 1.02) => {
      bx(parent, 0.28, 0.22, 0.08, -0.45, 0.62, smileAt, lamp);
      bx(parent, 0.28, 0.22, 0.08, 0.45, 0.62, smileAt, lamp);
      bx(parent, 0.5, 0.1, 0.06, 0, 0.45, smileAt + 0.02, dark);
      bx(parent, 0.18, 0.12, 0.05, -0.62, 0.48, smileAt - 0.02, pink);
      bx(parent, 0.18, 0.12, 0.05, 0.62, 0.48, smileAt - 0.02, pink);
    };

    // 1) TAXI — yellow cute (default)
    {
      const b = new THREE.Group();
      const main = L(0xffc93c);
      bx(b, 1.4, 0.55, 2.0, 0, 0.55, 0, main);
      bx(b, 1.5, 0.22, 1.9, 0, 0.36, 0, white);
      bx(b, 1.2, 0.7, 1.05, 0, 1.15, -0.2, main);
      bx(b, 1.26, 0.42, 0.9, 0, 1.18, -0.2, glass);
      bx(b, 1.05, 0.45, 1.12, 0, 1.18, -0.2, glass);
      bx(b, 1.22, 0.12, 1.07, 0, 1.55, -0.2, white);
      bx(b, 0.2, 0.06, 0.95, -0.27, 0.86, 0.5, white);
      bx(b, 0.2, 0.06, 0.95, 0.27, 0.86, 0.5, white);
      bx(b, 0.2, 0.06, 1.0, -0.27, 1.63, -0.2, white);
      bx(b, 0.2, 0.06, 1.0, 0.27, 1.63, -0.2, white);
      bx(b, 0.25, 0.15, 0.08, -0.5, 0.62, -1.0, red);
      bx(b, 0.25, 0.15, 0.08, 0.5, 0.62, -1.0, red);
      bx(b, 0.06, 0.4, 0.06, 0.4, 1.8, -0.5, dark);
      bx(b, 0.18, 0.18, 0.18, 0.4, 2.05, -0.5, yel);
      face(b, yel);
      wheels(b, white);
      car.add(b); this.carBodies.taxi = b;
    }
    // 2) PANDA 86 — Initial-D style, white/black two-tone
    {
      const b = new THREE.Group();
      const black = L(0x23232e);
      bx(b, 1.4, 0.55, 2.0, 0, 0.55, 0, white);
      bx(b, 0.08, 0.3, 1.9, -0.71, 0.55, 0, black); // side bands
      bx(b, 0.08, 0.3, 1.9, 0.71, 0.55, 0, black);
      bx(b, 0.09, 0.08, 1.9, -0.71, 0.74, 0, red); // red pinstripe
      bx(b, 0.09, 0.08, 1.9, 0.71, 0.74, 0, red);
      bx(b, 1.2, 0.09, 0.65, 0, 0.86, 0.62, black); // black hood
      bx(b, 1.5, 0.2, 1.9, 0, 0.34, 0, black); // black skirt
      bx(b, 1.2, 0.65, 1.0, 0, 1.12, -0.25, white);
      bx(b, 1.26, 0.38, 0.86, 0, 1.15, -0.25, glass);
      bx(b, 1.05, 0.4, 1.06, 0, 1.15, -0.25, glass);
      bx(b, 1.22, 0.1, 1.02, 0, 1.5, -0.25, black); // black roof
      bx(b, 1.25, 0.07, 0.28, 0, 1.0, -1.1, black); // spoiler
      bx(b, 0.25, 0.14, 0.08, -0.5, 0.6, -1.0, red);
      bx(b, 0.25, 0.14, 0.08, 0.5, 0.6, -1.0, red);
      bx(b, 0.34, 0.16, 0.1, -0.42, 0.92, 0.95, black); // pop-up lamps
      bx(b, 0.34, 0.16, 0.1, 0.42, 0.92, 0.95, black);
      face(b, yel);
      wheels(b, chrome);
      car.add(b); this.carBodies.panda = b;
    }
    // 3) DAMKAR — cute fire truck
    {
      const b = new THREE.Group();
      const fklam = L(0xef2d3c), silver = L(0xc9cede), blue = L(0x3f8cff);
      bx(b, 1.45, 0.72, 2.0, 0, 0.62, 0, fklam);
      bx(b, 1.47, 0.22, 2.02, 0, 0.74, 0, white); // white belt
      bx(b, 1.25, 0.62, 0.85, 0, 1.28, 0.45, fklam); // cab
      bx(b, 1.0, 0.38, 0.12, 0, 1.3, 0.88, glass); // windshield
      bx(b, 1.27, 0.34, 0.7, 0, 1.3, 0.45, glass); // side windows
      bx(b, 0.3, 0.16, 0.26, -0.32, 1.68, 0.45, red); // light bar
      bx(b, 0.3, 0.16, 0.26, 0.32, 1.68, 0.45, blue);
      bx(b, 0.08, 0.1, 1.1, -0.26, 1.14, -0.35, silver); // ladder rails
      bx(b, 0.08, 0.1, 1.1, 0.26, 1.14, -0.35, silver);
      for (const z of [-0.75, -0.5, -0.25, 0.0]) bx(b, 0.6, 0.07, 0.09, 0, 1.14, z, silver);
      bx(b, 0.5, 0.3, 0.1, 0, 0.55, 1.0, chrome); // front bumper
      bx(b, 0.25, 0.15, 0.08, -0.5, 0.55, -1.0, red);
      bx(b, 0.25, 0.15, 0.08, 0.5, 0.55, -1.0, red);
      face(b, yel);
      wheels(b, chrome);
      car.add(b); this.carBodies.damkar = b;
    }
    // 4) TANK — cute chibi tank
    {
      const b = new THREE.Group();
      const olive = L(0x8a9a5b), oliveD = L(0x6b7a45), track = L(0x3a3a45), pupil = L(0x1a1a22);
      bx(b, 0.42, 0.52, 2.0, -0.56, 0.3, 0, track); // tracks
      bx(b, 0.42, 0.52, 2.0, 0.56, 0.3, 0, track);
      for (const [x, z] of [[-0.56, 0.55], [0.56, 0.55], [-0.56, -0.55], [0.56, -0.55]])
        bx(b, 0.44, 0.24, 0.34, x, 0.3, z, white);
      bx(b, 1.0, 0.5, 1.8, 0, 0.72, 0, olive); // hull
      bx(b, 1.02, 0.18, 0.5, 0, 0.62, 0.85, oliveD); // glacis
      bx(b, 0.8, 0.45, 0.9, 0, 1.18, -0.2, oliveD); // turret
      bx(b, 0.18, 0.18, 1.25, 0, 1.18, 0.7, oliveD); // barrel
      bx(b, 0.28, 0.28, 0.22, 0, 1.18, 1.3, track); // muzzle
      bx(b, 0.3, 0.12, 0.3, -0.2, 1.45, -0.3, olive); // hatch
      bx(b, 0.34, 0.3, 0.06, 0.42, 1.18, -0.2, white); // star patch
      bx(b, 0.06, 0.45, 0.06, -0.3, 1.6, -0.5, dark); // antenna
      // cute eyes on the hull
      bx(b, 0.24, 0.24, 0.08, -0.25, 0.78, 0.92, white);
      bx(b, 0.24, 0.24, 0.08, 0.25, 0.78, 0.92, white);
      bx(b, 0.11, 0.11, 0.09, -0.25, 0.78, 0.92, pupil);
      bx(b, 0.11, 0.11, 0.09, 0.25, 0.78, 0.92, pupil);
      bx(b, 0.4, 0.09, 0.06, 0, 0.55, 0.94, dark);
      bx(b, 0.16, 0.11, 0.05, -0.42, 0.58, 0.92, pink);
      bx(b, 0.16, 0.11, 0.05, 0.42, 0.58, 0.92, pink);
      car.add(b); this.carBodies.tank = b;
    }
    // 5) VW — cute mint beetle
    {
      const b = new THREE.Group();
      const mint = L(0x6fd6c4);
      bx(b, 1.4, 0.5, 2.0, 0, 0.55, 0, mint);
      bx(b, 1.2, 0.32, 0.45, 0, 0.78, 0.82, mint); // round hood hint
      bx(b, 1.05, 0.6, 1.1, 0, 1.1, -0.1, mint); // dome cabin
      bx(b, 1.1, 0.36, 0.95, 0, 1.12, -0.1, glass);
      bx(b, 0.9, 0.38, 1.16, 0, 1.12, -0.1, glass);
      bx(b, 1.0, 0.1, 1.0, 0, 1.44, -0.1, white); // white roof
      bx(b, 1.5, 0.15, 0.16, 0, 0.35, 1.02, chrome); // chrome bumpers
      bx(b, 1.5, 0.15, 0.16, 0, 0.35, -1.02, chrome);
      bx(b, 0.16, 0.1, 1.2, -0.76, 0.3, 0, white); // running boards
      bx(b, 0.16, 0.1, 1.2, 0.76, 0.3, 0, white);
      bx(b, 0.3, 0.3, 0.08, -0.45, 0.68, 1.0, white); // big round lamps
      bx(b, 0.3, 0.3, 0.08, 0.45, 0.68, 1.0, white);
      bx(b, 0.14, 0.14, 0.09, -0.45, 0.68, 1.0, yel);
      bx(b, 0.14, 0.14, 0.09, 0.45, 0.68, 1.0, yel);
      bx(b, 0.25, 0.15, 0.08, -0.5, 0.6, -1.0, red);
      bx(b, 0.25, 0.15, 0.08, 0.5, 0.6, -1.0, red);
      bx(b, 0.5, 0.1, 0.06, 0, 0.48, 1.03, dark);
      bx(b, 0.18, 0.12, 0.05, -0.62, 0.5, 1.0, pink);
      bx(b, 0.18, 0.12, 0.05, 0.62, 0.5, 1.0, pink);
      wheels(b, white);
      car.add(b); this.carBodies.vw = b;
    }
    // 6) VIPER — Dodge ala NFS Most Wanted: biru, strip putih, kap panjang
    {
      const b = new THREE.Group();
      const vip = L(0x2456d8);
      bx(b, 1.35, 0.42, 2.2, 0, 0.5, 0.1, vip);
      bx(b, 1.45, 0.2, 2.1, 0, 0.33, 0.05, dark);
      bx(b, 1.0, 0.55, 0.9, 0, 1.0, -0.45, vip);
      bx(b, 1.06, 0.34, 0.78, 0, 1.02, -0.45, glass);
      bx(b, 0.9, 0.36, 0.9, 0, 1.02, -0.45, glass);
      bx(b, 1.02, 0.08, 0.92, 0, 1.3, -0.45, vip);
      bx(b, 0.2, 0.05, 2.0, -0.16, 0.73, 0.1, white);
      bx(b, 0.2, 0.05, 2.0, 0.16, 0.73, 0.1, white);
      bx(b, 0.2, 0.05, 0.9, -0.16, 1.35, -0.45, white);
      bx(b, 0.2, 0.05, 0.9, 0.16, 1.35, -0.45, white);
      bx(b, 0.34, 0.14, 0.08, -0.42, 0.58, 1.18, yel);
      bx(b, 0.34, 0.14, 0.08, 0.42, 0.58, 1.18, yel);
      bx(b, 0.5, 0.1, 0.06, 0, 0.42, 1.2, dark);
      bx(b, 0.18, 0.12, 0.05, -0.6, 0.44, 1.16, pink);
      bx(b, 0.18, 0.12, 0.05, 0.6, 0.44, 1.16, pink);
      bx(b, 0.25, 0.14, 0.08, -0.5, 0.55, -1.0, red);
      bx(b, 0.25, 0.14, 0.08, 0.5, 0.55, -1.0, red);
      bx(b, 1.2, 0.07, 0.25, 0, 0.95, -1.12, vip);
      bx(b, 0.1, 0.12, 0.7, -0.72, 0.3, 0.1, chrome);
      bx(b, 0.1, 0.12, 0.7, 0.72, 0.3, 0.1, chrome);
      bx(b, 0.12, 0.1, 0.1, -0.68, 1.05, 0.15, vip);
      bx(b, 0.12, 0.1, 0.1, 0.68, 1.05, 0.15, vip);
      wheels(b, chrome);
      car.add(b); this.carBodies.viper = b;
    }

    car.scale.setScalar(0.85);
    this.car = car;
    this.scene.add(car);
    this.setCar(this.carName);
  }

  // ---------- road ----------
  buildChunk(seg: Seg, t0: number, t1: number, dEnd: number): Chunk {
    if (this.mode === 'spidey') {
      const midS = sample(seg, (t0 + t1) / 2);
      const g0 = new THREE.Group();
      g0.position.set(midS.x, midS.y, midS.z);
      g0.visible = false;
      this.scene.add(g0);
      const ch0: Chunk = { g: g0, d: dEnd, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), by: midS.y, spawned: false, spawnT: 0, spawnDelay: 0 };
      this.chunks.push(ch0);
      return ch0;
    }
    const hw = W / 2;
    const sliceLen = (t1 - t0) * seg.len;
    const n = Math.max(2, Math.ceil(sliceLen / 0.25));
    const pts = [] as ReturnType<typeof sample>[];
    for (let i = 0; i <= n; i++) pts.push(sample(seg, t0 + ((t1 - t0) * i) / n));
    const mid = sample(seg, (t0 + t1) / 2);
    const dStart = seg.d0 + t0 * seg.len;
    const pos: number[] = [], nor: number[] = [], col: number[] = [], idx: number[] = [];
    const P = this.pal;

    const quadTop = (A: typeof mid, B: typeof mid, lo: number, hi: number, y: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * lo - mid.x, A.y + y - mid.y, A.z + rzA * lo - mid.z);
      pos.push(A.x + rxA * hi - mid.x, A.y + y - mid.y, A.z + rzA * hi - mid.z);
      pos.push(B.x + rxB * lo - mid.x, B.y + y - mid.y, B.z + rzB * lo - mid.z);
      pos.push(B.x + rxB * hi - mid.x, B.y + y - mid.y, B.z + rzB * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(0, 1, 0); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 2, b + 1, b + 1, b + 2, b + 3);
    };
    const quadDown = (A: typeof mid, B: typeof mid, lo: number, hi: number, y: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * lo - mid.x, A.y + y - mid.y, A.z + rzA * lo - mid.z);
      pos.push(A.x + rxA * hi - mid.x, A.y + y - mid.y, A.z + rzA * hi - mid.z);
      pos.push(B.x + rxB * lo - mid.x, B.y + y - mid.y, B.z + rzB * lo - mid.z);
      pos.push(B.x + rxB * hi - mid.x, B.y + y - mid.y, B.z + rzB * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(0, -1, 0); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };
    const quadSide = (A: typeof mid, B: typeof mid, off: number, yT: number, yB: number, nx: number, nz: number, c: THREE.Color) => {
      const rxA = Math.cos(A.h), rzA = -Math.sin(A.h), rxB = Math.cos(B.h), rzB = -Math.sin(B.h);
      const b = pos.length / 3;
      pos.push(A.x + rxA * off - mid.x, A.y + yT - mid.y, A.z + rzA * off - mid.z);
      pos.push(A.x + rxA * off - mid.x, A.y + yB - mid.y, A.z + rzA * off - mid.z);
      pos.push(B.x + rxB * off - mid.x, B.y + yT - mid.y, B.z + rzB * off - mid.z);
      pos.push(B.x + rxB * off - mid.x, B.y + yB - mid.y, B.z + rzB * off - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(nx, 0, nz); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };
    const capRect = (sp: typeof mid, lo: number, hi: number, yT: number, yB: number, c: THREE.Color, sign: number) => {
      const fx = Math.sin(sp.h) * sign, fz = Math.cos(sp.h) * sign;
      const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
      const b = pos.length / 3;
      pos.push(sp.x + rx * lo - mid.x, sp.y + yT - mid.y, sp.z + rz * lo - mid.z);
      pos.push(sp.x + rx * hi - mid.x, sp.y + yT - mid.y, sp.z + rz * hi - mid.z);
      pos.push(sp.x + rx * lo - mid.x, sp.y + yB - mid.y, sp.z + rz * lo - mid.z);
      pos.push(sp.x + rx * hi - mid.x, sp.y + yB - mid.y, sp.z + rz * hi - mid.z);
      for (let k = 0; k < 4; k++) { nor.push(fx, 0, fz); col.push(c.r, c.g, c.b); }
      idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    };

    const botLo = this.edge === 'hidden' ? -hw : this.edge === 'rail' ? -hw - 0.4 : -hw - 0.55;
    const botHi = -botLo;
    for (let j = 0; j < n; j++) {
      const A = pts[j], B = pts[j + 1];
      const dMid = dStart + (sliceLen * (j + 0.5)) / n;
      // asphalt slab
      quadTop(A, B, -hw, hw, 0, P.road);
      quadDown(A, B, botLo, botHi, -1.1, P.roadBottom);
      quadSide(A, B, -hw, 0, -1.1, -Math.cos(A.h), Math.sin(A.h), P.roadSide);
      quadSide(A, B, hw, 0, -1.1, Math.cos(A.h), -Math.sin(A.h), P.roadSide);
      if (this.edge === 'flat') {
        // soft red-white stripes, flush with the road (drivable)
        const red = Math.floor(dMid / 1.0) % 2 === 0;
        const cTop = red ? EDGE.flatA : EDGE.flatB;
        const cSide = red ? EDGE.flatSideA : EDGE.flatSideB;
        quadTop(A, B, -hw - 0.55, -hw, 0.03, cTop);
        quadTop(A, B, hw, hw + 0.55, 0.03, cTop);
        quadSide(A, B, -hw - 0.55, 0.03, -1.1, -Math.cos(A.h), Math.sin(A.h), cSide);
        quadSide(A, B, hw + 0.55, 0.03, -1.1, Math.cos(A.h), -Math.sin(A.h), cSide);
      } else if (this.edge === 'rail') {
        // raised guard rails like the reference — soft solid maroon
        quadTop(A, B, -hw - 0.4, -hw, 0.55, EDGE.rail);
        quadTop(A, B, hw, hw + 0.4, 0.55, EDGE.rail);
        quadSide(A, B, -hw, 0.55, 0, Math.cos(A.h), -Math.sin(A.h), EDGE.rail);
        quadSide(A, B, hw, 0.55, 0, -Math.cos(A.h), Math.sin(A.h), EDGE.rail);
        quadSide(A, B, -hw - 0.4, 0.55, -1.1, -Math.cos(A.h), Math.sin(A.h), EDGE.railSide);
        quadSide(A, B, hw + 0.4, 0.55, -1.1, Math.cos(A.h), -Math.sin(A.h), EDGE.railSide);
      }
      if (Math.floor(dMid / 2.4) % 2 === 0) quadTop(A, B, -0.09, 0.09, 0.015, P.line);
    }
    for (const [sp, sign] of [[pts[0], -1], [pts[n], 1]] as const) {
      capRect(sp, -hw, hw, 0, -1.1, P.roadSide, sign);
      if (this.edge === 'flat') {
        const dCap = sign < 0 ? dStart : dStart + sliceLen;
        const red = Math.floor(dCap / 1.0) % 2 === 0;
        const cSide = red ? EDGE.flatSideA : EDGE.flatSideB;
        capRect(sp, -hw - 0.55, -hw, 0.03, -1.1, cSide, sign);
        capRect(sp, hw, hw + 0.55, 0.03, -1.1, cSide, sign);
      } else if (this.edge === 'rail') {
        capRect(sp, -hw - 0.4, -hw, 0.55, -1.1, EDGE.railSide, sign);
        capRect(sp, hw, hw + 0.4, 0.55, -1.1, EDGE.railSide, sign);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx);
    const mesh = new THREE.Mesh(geo, this.roadMat);
    mesh.receiveShadow = true;
    const g = new THREE.Group();
    g.position.set(mid.x, mid.y, mid.z);
    g.add(mesh);
    if (seg.type === 's' && this.mode === 'drift' && Math.random() < 0.4) this.addCone(g, seg, (t0 + t1) / 2, mid);
    g.visible = false;
    this.scene.add(g);
    const chunk: Chunk = { g, d: dEnd, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), geo, by: mid.y, spawned: false, spawnT: 0, spawnDelay: 0 };
    this.chunks.push(chunk);
    return chunk;
  }

  addCone(g: THREE.Group, seg: Seg, tc: number, mid: ReturnType<typeof sample>) {
    const sp = sample(seg, tc);
    const side = (Math.random() < 0.5 ? -1 : 1) * (W / 2 - 0.6);
    const rx = Math.cos(sp.h), rz = -Math.sin(sp.h);
    const cone = new THREE.Group();
    const b1 = new THREE.Mesh(this.boxGeo, this.coneMat); b1.scale.set(0.34, 0.42, 0.34); b1.position.y = 0.21; b1.castShadow = true;
    const b2 = new THREE.Mesh(this.boxGeo, this.coneStripeMat); b2.scale.set(0.36, 0.1, 0.36); b2.position.y = 0.24;
    const b3 = new THREE.Mesh(this.boxGeo, this.coneMat); b3.scale.set(0.2, 0.22, 0.2); b3.position.y = 0.5; b3.castShadow = true;
    cone.add(b1, b2, b3);
    cone.position.set(sp.x + rx * side - mid.x, sp.y - mid.y, sp.z + rz * side - mid.z);
    cone.rotation.y = rand(0, 3);
    g.add(cone);
  }

  addChevron(seg: Seg, firstChunk: Chunk) {
    const p0 = sample(seg, 0);
    const ox = p0.x - seg.cx, oz = p0.z - seg.cz;
    const l = Math.hypot(ox, oz) || 1;
    const wx = p0.x + (ox / l) * (W / 2 + 1.6), wz = p0.z + (oz / l) * (W / 2 + 1.6);
    const g = new THREE.Group();
    const pole = new THREE.Mesh(this.boxGeo, this.signPoleMat); pole.scale.set(0.28, 2.2, 0.28); pole.position.y = 1.1; pole.castShadow = true;
    const board = new THREE.Mesh(this.boxGeo, this.signBoardMat); board.scale.set(1.9, 1.05, 0.18); board.position.y = 2.6; board.castShadow = true;
    g.add(pole, board);
    for (const k of [-0.42, 0.42]) {
      const a1 = new THREE.Mesh(this.boxGeo, this.signArrowMat); a1.scale.set(0.16, 0.62, 0.06);
      a1.position.set(k - 0.16 * seg.s, 2.6, 0.13); a1.rotation.z = 0.6 * seg.s;
      const a2 = new THREE.Mesh(this.boxGeo, this.signArrowMat); a2.scale.set(0.16, 0.62, 0.06);
      a2.position.set(k + 0.16 * seg.s, 2.6, 0.13); a2.rotation.z = -0.6 * seg.s;
      g.add(a1, a2);
    }
    g.position.set(wx - firstChunk.g.position.x, p0.y - firstChunk.g.position.y, wz - firstChunk.g.position.z);
    g.rotation.y = p0.h;
    firstChunk.g.add(g);
  }

  addSeg(seg: Seg) {
    const nc = Math.max(1, Math.round(seg.len / CHUNK));
    let first: Chunk | null = null;
    const made: Chunk[] = [];
    for (let i = 0; i < nc; i++) {
      const c = this.buildChunk(seg, i / nc, (i + 1) / nc, seg.d0 + (seg.len * (i + 1)) / nc);
      made.push(c);
      if (!first) first = c;
    }
    if (seg.type === 'a' && first && this.mode !== 'spidey') this.addChevron(seg, first);
    const atD = (d: number) => made[Math.min(nc - 1, Math.max(0, Math.floor((d - seg.d0) / seg.len * nc)))];
    const put = (mesh: THREE.Object3D, x: number, y: number, z: number, d: number) => {
      const ch = atD(d);
      mesh.position.set(x - ch.g.position.x, y - ch.g.position.y, z - ch.g.position.z);
      ch.g.add(mesh);
      return ch;
    };
    if (seg.type === 's' && !seg.jmp && Math.floor(seg.d0 / 10) % 3 === 0) {
      const side = Math.floor(seg.d0 / 10) % 2 === 0 ? -1 : 1;
      for (let k = 0; k < 6; k++) {
        const cd = seg.d0 + 1.5 + k * 1.3;
        if (cd > seg.d0 + seg.len - 0.6) break;
        const cp = sample(seg, (cd - seg.d0) / seg.len);
        const m = new THREE.Mesh(this.coinGeo, this.coinMat);
        m.rotation.y = Math.random() * 3;
        const ch = put(m, cp.x + Math.cos(cp.h) * side * (W / 2 - 0.6), cp.y + 0.55, cp.z - Math.sin(cp.h) * side * (W / 2 - 0.6), cd);
        this.coins.push({ m, d: cd, chunk: ch, got: false });
      }
    }
    if (this.raceOn() && seg.d0 < this.finishD && seg.d0 + seg.len >= this.finishD) {
      const fp = sample(seg, (this.finishD - seg.d0) / seg.len);
      const rx = Math.cos(fp.h), rz = -Math.sin(fp.h);
      for (const sd of [-1, 1]) {
        const post = new THREE.Mesh(this.boxGeo, this.poleMat);
        post.scale.set(0.4, 5, 0.4);
        put(post, fp.x + rx * sd * (W / 2 + 0.9), fp.y + 2.5, fp.z + rz * sd * (W / 2 + 0.9), this.finishD);
      }
      const ban = new THREE.Mesh(this.boxGeo, new THREE.MeshLambertMaterial({ map: this.checkerTex }));
      ban.scale.set(W + 2.2, 1.0, 0.25);
      ban.rotation.y = fp.h;
      put(ban, fp.x, fp.y + 5.2, fp.z, this.finishD);
    }
    if (seg.type === 'a' && this.mode !== 'free') {
      const ym = (seg.y0 + seg.y1) / 2;
      const g = new THREE.Group();
      g.position.set(seg.cx, ym, seg.cz);
      const pm = new THREE.Mesh(this.boxGeo, this.poleMat);
      pm.scale.set(0.5, 30, 0.5); pm.position.y = -13; pm.castShadow = true;
      const top = new THREE.Mesh(this.boxGeo, new THREE.MeshLambertMaterial({ color: 0xffd23f, emissive: 0x000000 }));
      top.scale.setScalar(1.1); top.position.y = 2.4; top.castShadow = true;
      const ring = new THREE.Mesh(this.boxGeo, this.ringMat);
      ring.scale.set(0.85, 0.3, 0.85); ring.position.y = 1.6;
      g.add(pm, top, ring);
      g.visible = false;
      this.scene.add(g);
      seg.poleTop = top;
      this.chunks.push({ g, d: seg.d0 + seg.len + 2, falling: false, vy: 0, t: 0, spin: new THREE.Vector3(), by: ym, spawned: false, spawnT: 0, spawnDelay: 0 });
    }
    this.segs.push(seg);
  }

  genStraight(len: number) {
    const g = this.gen;
    const y1 = g.y - len * 0.03;
    this.addSeg({ type: 's', y0: g.y, y1, len, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0 });
    g.x += Math.sin(g.h) * len; g.z += Math.cos(g.h) * len; g.y = y1; g.d += len;
  }

  canJump(n: number) { if (this.mode !== 'drift') return false; return n > 10 && (n - this.lastJumpN) > 10 && Math.random() < 0.26; }
  genJump(n: number) {
    this.lastJumpN = n;
    const g = this.gen;
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const appLen = 9;
    const yA = g.y - appLen * 0.03;
    this.addSeg({ type: 's', y0: g.y, y1: yA, len: appLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 1 });
    g.x += fx * appLen; g.z += fz * appLen; g.y = yA; g.d += appLen;
    const rampLen = 6, rise = 1.3;
    const lip = (2 * rise / rampLen) / Math.hypot(1, 2 * rise / rampLen);
    this.addSeg({ type: 'r', y0: g.y, y1: g.y + rise, len: rampLen, d0: g.d, sx: g.x, sz: g.z, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 2, launch: lip });
    g.x += fx * rampLen; g.z += fz * rampLen; g.y += rise; g.d += rampLen;
    const gap = 11, landLen = 17;
    const lx = g.x + fx * gap, lz = g.z + fz * gap;
    const ly0 = g.y - 0.6, ly1 = ly0 - landLen * 0.03;
    this.addSeg({ type: 's', y0: ly0, y1: ly1, len: landLen, d0: g.d + gap, sx: lx, sz: lz, h: g.h, cx: 0, cz: 0, R: 0, a0: 0, s: 1, sweep: 0, jmp: 3 });
    g.x = lx + fx * landLen; g.z = lz + fz * landLen; g.y = ly1; g.d += gap + landLen;
  }

  genArc() {
    const g = this.gen;
    const diff = Math.min(1, (this.base + this.segs.length) / 40);
    const r = Math.random();
    let sweep = r < 0.55 - diff * 0.2 ? Math.PI / 2 : r < 0.85 ? Math.PI : Math.PI * 1.5;
    const R = rand(5.8, 8.5) - diff;
    const ok = (s: number) => Math.abs(wrap(g.h - s * sweep)) <= Math.PI / 2 + 0.01;
    let opts = [1, -1].filter(ok);
    if (!opts.length) { sweep = Math.PI / 2; opts = [1, -1].filter(ok); }
    let s = opts[Math.floor(Math.random() * opts.length)];
    if (opts.length === 2 && Math.abs(g.x) > 25) {
      s = opts.find((o) => Math.sign(Math.sin(wrap(g.h - o * sweep))) === -Math.sign(g.x)) ?? s;
    }
    const fx = Math.sin(g.h), fz = Math.cos(g.h);
    const nx = s * -fz, nz = s * fx;
    const cx = g.x + nx * R, cz = g.z + nz * R;
    const a0 = Math.atan2(-nz, -nx);
    const y1 = g.y - sweep * 1.7;
    const len = R * sweep;
    this.addSeg({ type: 'a', y0: g.y, y1, len, d0: g.d, sx: 0, sz: 0, h: 0, cx, cz, R, a0, s, sweep });
    const a1 = a0 + s * sweep;
    g.x = cx + R * Math.cos(a1); g.z = cz + R * Math.sin(a1);
    g.h = wrap(g.h - s * sweep); g.y = y1; g.d += len;
  }

  ensureTrack() {
    while (this.base + this.segs.length < this.cur + 10) {
      const n = this.base + this.segs.length;
      if (n % 2 === 0) {
        if (this.canJump(n)) this.genJump(n);
        else if (n > 12 && Math.random() < 0.18) this.genStraight(rand(22, 30));
        else this.genStraight(n === 0 ? 20 : rand(6, 12) - Math.min(3, n / 30));
      } else this.genArc();
    }
    while (this.cur - this.base > 4) { const old = this.segs.shift()!; if (old.bld) this.scene.remove(old.bld); this.base++; }
  }

  seg(i: number) { return this.segs[i - this.base]; }
  removeChunk(c: Chunk) { this.scene.remove(c.g); c.geo?.dispose(); if (this.coins.length) this.coins = this.coins.filter((k) => k.chunk !== c); }

  reset() {
    for (const c of this.chunks) this.removeChunk(c);
    this.chunks = [];
    for (const sg of this.segs) if (sg.bld) this.scene.remove(sg.bld);
    this.segs = []; this.base = 0; this.cur = 0; this.dist = 0;
    this.gen = { x: 0, z: 0, h: 0, y: 0, d: 0 };
    this.ensureTrack();
    const ordered = [...this.chunks].sort((a, b) => a.d - b.d);
    ordered.forEach((c, i) => { c.spawnDelay = i * 0.035; c.spawned = false; c.spawnT = 0; });
    this.pos.set(0, 0, 4); this.h = 0; this.v = 13;
    this.attached = null; this.holding = false;
    this.airborne = false; this.airVy = 0; this.airT = 0;
    this.score = 0; this.combo = 0;
    this.car.rotation.set(0, 0, 0);
    this.vis = { yaw: 0, yawV: 0, roll: 0, sq: 1, sqV: 0, pitch: 0, pitchV: 0 };
    this.camPos.set(0, 20, -9);
    this.applyMode();
    this.fovKick = 0; this.slope = 0; this.settled = false; this.overSent = false; this.nosN = 0; this.nosKey = false; this.nosToggleOn = false; this.comboKey = false; this.nosMul = 1; this.effV = 13; this.setBoostFx(false); this.botDist = -8; this.botV = 13; this.botOff = 0; this.bumpX = 0; this.bumpZ = 0; this.bumpCD = 0; this.botPush = 0; this.bumpSlow = 0; this.raceAcc = 0; this.coins = []; this.coinStreak = 0; this.botCar.position.set(0, 0, 4); this.botCar.rotation.set(0, 0, 0);
    this.state = 'idle';
    this.hideRope(); this.ropeT = 0; this.ropeWob = 0;
    this.setHint('');
  }

  start() {
    this.sfx.init();
    if (this.sfx.ctx) this.music.begin(this.sfx.ctx, this.sfx.master, this.sfx.noiseBuf);
    this.reset();
    this.finishD = 1100;
    this.bumpCD = 2.5;
    this.state = 'play';
    this.botCar.visible = this.raceOn();
    this.sfx.start();
    this.cb.onScore(0, 0);
  }
  unlockAudio() { this.sfx.init(); if (this.sfx.ctx) this.music.begin(this.sfx.ctx, this.sfx.master, this.sfx.noiseBuf); }
  setHint(h: string) { if (h !== this.lastHint) { this.lastHint = h; this.cb.onHint?.(h); } }

  press() { this.holding = true; this.tryAttach(); }

  tryAttach() {
    if (this.mode === 'free') return;
    if (this.state !== 'play' || this.attached) return;
    let best: Seg | null = null, bd = Infinity;
    for (let i = this.cur; i < this.cur + 3; i++) {
      const sg = this.seg(i);
      if (!sg || sg.type !== 'a') continue;
      const d = Math.hypot(this.pos.x - sg.cx, this.pos.z - sg.cz);
      if (d < bd) { bd = d; best = sg; }
    }
    const nosing = this.nosActive();
    if (!best || bd > best.R + W * (nosing ? 2.2 : 1)) return;
    const rx = this.pos.x - best.cx, rz = this.pos.z - best.cz;
    const fx = Math.sin(this.h), fz = Math.cos(this.h);
    this.orbit = { r: bd, a: Math.atan2(rz, rx), s: rx * fz - rz * fx >= 0 ? 1 : -1 };
    this.attached = best;
    this.attachErr = Math.abs(bd - best.R);
    this.vis.sqV = -3.5;
    this.vis.yawV += -this.orbit.s * 2.2;
    this.vis.pitchV += -1.5; // nose dive — berat depan saat nyangkut
    this.ropeT = 0; this.ropeWob = 1; // tali melesat + bergetar
    this.shake = Math.max(this.shake, 0.2);
    this.sfx.attach();
    navigator.vibrate?.(10);
  }

  release() {
    this.holding = false;
    if (this.mode === 'free' && this.combo > 0 && this.state === 'play') { this.combo = 0; this.cb.onScore(this.score, 0); }
    if (this.state !== 'play' || !this.attached) return;
    const sDir = this.orbit.s;
    this.attached = null;
    this.ropeWob = 1.6; // tali menyentak balik lentur
    const err = this.attachErr;
    if (err < 0.9) {
      this.combo++;
      this.score += this.combo;
      this.cb.onPopup(this.combo > 1 ? `PERFECT x${this.combo}` : 'PERFECT!', '#ffd23f');
      this.burst(this.pos, [0xffd23f, 0xff5c8a, 0x7cf0ff, 0xffffff], 30);
      this.shake = 0.4;
      this.fovKick = Math.min(7, this.fovKick + 2);
      this.sfx.perfect(this.combo);
      navigator.vibrate?.([15, 30, 15]);
    } else if (err < 1.8) {
      this.combo = 0;
      this.cb.onPopup('NICE', '#ffffff');
      this.sfx.nice();
    } else { this.combo = 0; this.sfx.release(); }
    this.vis.sqV = 3;
    this.vis.yawV += sDir * (this.nosActive() ? 3 : 2); // counter-steer flick
    this.vis.pitchV += 2; // squat ke belakang
    this.fovKick = Math.min(7, this.fovKick + 3.5);
    this.cb.onScore(this.score, this.combo);
  }

  spawn(p: THREE.Vector3, color: number, vel: THREE.Vector3, size: number, life: number, grow: number, grav = false) {
    const pt = this.parts[this.partIdx++ % this.parts.length];
    pt.m.visible = true; pt.m.position.copy(p); pt.m.scale.setScalar(size);
    (pt.m.material as THREE.MeshBasicMaterial).color.set(color);
    pt.m.rotation.set(Math.random() * 3, Math.random() * 3, 0);
    pt.v.copy(vel); pt.life = life; pt.max = life; pt.grow = grow; pt.grav = grav;
  }

  burst(p: THREE.Vector3, colors: number[], n: number) {
    for (let i = 0; i < n; i++) {
      this.spawn(p.clone().add(new THREE.Vector3(0, 1, 0)), colors[i % colors.length],
        new THREE.Vector3(rand(-8, 8), rand(5, 13), rand(-8, 8)), rand(0.25, 0.5), rand(0.6, 1.1), -0.3, true);
    }
  }

  skid(x: number, y: number, z: number, yaw: number) {
    const s = this.skids[this.skidIdx++ % this.skids.length];
    s.m.visible = true; s.m.position.set(x, y + 0.03, z); s.m.rotation.y = yaw; s.life = 2.5;
    (s.m.material as THREE.MeshBasicMaterial).opacity = 0.5;
  }

  update(dt: number) {
    const t = performance.now() / 1000;
    let yawTarget = 0;
    if (this.state === 'play') {
      this.v = Math.min(25, 13.5 + this.cur * 0.12);
      const nosTarget = this.nosActive() ? 2 : 1;
      this.nosMul += (nosTarget - this.nosMul) * Math.min(1, dt * 2.4);
      if (Math.abs(this.nosMul - nosTarget) < 0.01) this.nosMul = nosTarget;
      const sp = this.v * this.nosMul * (1 - 0.25 * this.bumpSlow);
      this.effV = sp;
      if (this.holding && !this.attached) this.tryAttach();
      const prevH = this.h;
      if (this.attached) {
        const sg = this.attached;
        const o = this.orbit;
        const nosDrift = this.nosActive();
        o.r += ((sg.R + (nosDrift ? 2.0 : 0)) - o.r) * Math.min(1, dt * 2.0);
        o.a += (o.s * sp / o.r) * dt;
        this.pos.x = sg.cx + o.r * Math.cos(o.a);
        this.pos.z = sg.cz + o.r * Math.sin(o.a);
        const tangent = Math.PI / 2 - (o.a + o.s * Math.PI / 2);
        this.h += wrap(tangent - this.h) * Math.min(1, dt * (nosDrift ? 18 : 10));
        yawTarget = -o.s * (nosDrift ? 1.05 : 0.8);
        const top = new THREE.Vector3(sg.cx, (sg.y0 + sg.y1) / 2 + 1.6, sg.cz);
        const a = new THREE.Vector3(this.pos.x, this.pos.y + this.ropeAY(), this.pos.z);
        this.ropeT = Math.min(1, this.ropeT + dt * 7);
        this.ropeB.copy(top);
        const slackT = THREE.MathUtils.clamp((sg.R - o.r) / Math.max(0.5, sg.R), 0, 1) * 0.9 + 0.03;
        this.ropeSlack += (slackT - this.ropeSlack) * Math.min(1, dt * 6);
        this.ropeTmpE.set(a.x + (top.x - a.x) * this.ropeT, a.y + (top.y - a.y) * this.ropeT, a.z + (top.z - a.z) * this.ropeT);
        this.renderRope(a, this.ropeTmpE, t);
        if (sg.poleTop) (sg.poleTop.material as THREE.MeshLambertMaterial).emissive.setHex(Math.sin(t * 30) > 0 ? 0x775500 : 0x332200);
      } else if (!this.airborne) {
        this.freeUpdate(dt, sp);
        this.pos.x += Math.sin(this.h) * sp * dt;
        this.pos.z += Math.cos(this.h) * sp * dt;
      }
      if (this.airborne) this.updateAir(dt, sp);

      const tol = this.edgeTol();
      let found = -1, ty = this.pos.y, pr = { t: 0, lat: 0, slat: 0 };
      for (let i = this.cur; i < this.cur + 3; i++) {
        const sg = this.seg(i);
        if (!sg) continue;
        const p = project(sg, this.pos.x, this.pos.z);
        if (p.lat < tol) { found = i; pr = p; ty = sample(sg, p.t).y; break; }
      }
      if (!this.airborne && !this.attached && found < 0) {
        if (this.raceOn()) { this.finishRace(false); } else {
        this.state = 'crash';
        this.crashT = 0;
        this.settled = false; this.overSent = false;
        this.attached = null; this.ropeT = 0; this.hideRope();
        this.nosN = 0; this.nosKey = false; this.comboKey = false; this.setBoostFx(false);
        this.crashVel.set(Math.sin(this.h) * this.v * 0.7, 7, Math.cos(this.h) * this.v * 0.7);
        this.shake = 0.9;
        this.burst(this.pos, [0xffc93c, 0xffffff, 0x2b2b3a], 24);
        this.cb.onPopup('OOPS!', '#ff5c8a');
        this.sfx.crash();
        this.setHint('');
        navigator.vibrate?.(120);
        }
      } else if (!this.airborne && found >= 0) {
        const sg = this.seg(found);
        if (found > this.cur) {
          const exited = this.seg(this.cur);
          if (this.mode === 'free' && exited && exited.type === 'a' && this.holding) {
            this.combo++;
            this.score += this.combo;
            this.cb.onPopup(this.combo > 1 ? `DRIFT x${this.combo}!` : 'DRIFT!', '#ffd23f');
            this.burst(this.pos, [0xffd23f, 0xffffff, 0x7cf0ff], 16);
            this.sfx.perfect(this.combo);
          }
          this.score += found - this.cur;
          this.cur = found;
          this.cb.onScore(this.score, this.combo);
          this.sfx.tick();
          this.ensureTrack();
        }
        this.dist = sg.d0 + pr.t * sg.len;
        const aheadT = Math.min(1, pr.t + 2.5 / Math.max(1, sg.len));
        this.slope = THREE.MathUtils.clamp(Math.atan2(sample(sg, aheadT).y - ty, 2.5) * 0.45, -0.18, 0.18);
        this.pos.y += (ty - this.pos.y) * Math.min(1, dt * 20);
        if (!this.attached) {
          // mode bebas: tanpa ngepot mobil bablas lurus — tidak ada setir otomatis di tikungan!
          const free = this.mode === 'free';
          const target = (free && sg.type !== 's') ? this.h : this.tangentAtDist(this.dist + 4.5);
          this.h += wrap(target - this.h) * Math.min(1, dt * (free ? 2.2 : 2.0));
          if (sg.type === 's') {
            const k = Math.min(1, dt * 1.1) * pr.slat;
            this.pos.x -= Math.cos(sg.h) * k;
            this.pos.z += Math.sin(sg.h) * k;
          }
        }
        if (sg.jmp === 2 && pr.t > 0.9 && !this.attached) this.launch(sp);
      }

      if (this.state === 'play' && !this.airborne) {
        if (this.attached) this.setHint('LEPAS!');
        else if (this.mode === 'free' && this.holding && this.freeLate()) this.setHint('LEPAS!');
        else if (this.jumpAhead()) this.setHint('NOS!!');
        else {
          let near = false;
          for (let i = this.cur; i < this.cur + 3; i++) {
            const sg = this.seg(i);
            if (!sg || sg.type !== 'a') continue;
            if (i === this.cur) { const p = project(sg, this.pos.x, this.pos.z); if (p.lat < W / 2 + 2.5) { near = true; break; } }
            else if (sg.d0 - this.dist < 15) { near = true; break; }
          }
          this.setHint(near ? (this.mode === 'free' ? (this.holding ? '' : 'DRIFT!') : (this.mode === 'spidey' ? 'JARING!' : 'TAHAN!')) : '');
        }
      }

      this.pos.x += this.bumpX * dt; this.pos.z += this.bumpZ * dt;
      if (this.raceOn()) {
        if (this.dist >= this.finishD) this.finishRace(true);
        else {
          const diff = this.botDist - this.dist;
          this.botV = THREE.MathUtils.clamp(this.effV + THREE.MathUtils.clamp(-diff * 0.25, -4, 6), 6, 60);
          this.botDist += (this.botV + this.botPush) * dt;
          if (this.dist - this.botDist > 40) this.botDist = this.dist - 25;
          if (this.botDist >= this.finishD) this.finishRace(false);
        }
      }
      if (this.botCar.visible) {
        const bp = this.posAtDist(this.botDist);
        this.botCar.position.set(bp.x + Math.cos(bp.h) * this.botOff, bp.y, bp.z - Math.sin(bp.h) * this.botOff);
        this.botCar.rotation.y = bp.h;
        this.botH = bp.h;
      }
      // fisika senggolan realistis: dempetan sustained + transfer momentum, tanpa mental
      this.bumpCD = Math.max(0, this.bumpCD - dt);
      this.bumpX *= Math.exp(-2.2 * dt); this.bumpZ *= Math.exp(-2.2 * dt);
      this.botPush *= Math.exp(-2.5 * dt);
      this.botOff *= Math.exp(-1.6 * dt);
      if (this.raceOn() && this.bot === 'solid' && this.state === 'play') {
        const dx = this.pos.x - this.botCar.position.x, dz = this.pos.z - this.botCar.position.z;
        const dy = this.pos.y - this.botCar.position.y;
        const d2 = dx * dx + dz * dz;
        const touching = d2 < 4.84 && Math.abs(dy) < 2.2;
        this.bumpSlow += ((touching ? 1 : 0) - this.bumpSlow) * Math.min(1, dt * 5);
        if (touching) {
          const d = Math.sqrt(Math.max(0.01, d2));
          const nx = dx / d, nz = dz / d;
          // 1) pisah posisi tegas tapi bukan mental
          const sep = Math.min(2.2 - d, 4 * dt);
          this.pos.x += nx * sep * 0.65; this.pos.z += nz * sep * 0.65;
          const brx = Math.cos(this.botH), brz = -Math.sin(this.botH);
          this.botOff = THREE.MathUtils.clamp(this.botOff - (nx * brx + nz * brz) * sep * 0.6, -3.2, 3.2);
          // 2) transfer momentum lembek (restitusi kecil = berat)
          const pvx = Math.sin(this.h) * sp + this.bumpX, pvz = Math.cos(this.h) * sp + this.bumpZ;
          const bvx = Math.sin(this.botH) * this.botV, bvz = Math.cos(this.botH) * this.botV;
          const rvn = (pvx - bvx) * nx + (pvz - bvz) * nz;
          if (rvn < 0) {
            const j = -(1 + 0.12) * rvn * 0.5;
            this.bumpX += nx * j; this.bumpZ += nz * j;
            const bm = Math.hypot(this.bumpX, this.bumpZ);
            if (bm > 8) { this.bumpX *= 8 / bm; this.bumpZ *= 8 / bm; }
            this.botPush += -(nx * Math.sin(this.botH) + nz * Math.cos(this.botH)) * j;
            if (this.bumpCD <= 0) {
              this.bumpCD = 0.5;
              this.shake = Math.max(this.shake, Math.min(0.35, -rvn * 0.03));
              this.sfx.thud(Math.min(14, 4 - rvn));
              this.burst(this.pos, [0xffd23f, 0xffffff], 8);
              navigator.vibrate?.(40);
            }
          }
          // 3) dempetan: gerinda + bunga api + ngeden bareng
          this.sfx.rumble();
          if (Math.random() < 0.35) {
            this.spawn(new THREE.Vector3((this.pos.x + this.botCar.position.x) / 2 + rand(-0.5, 0.5), this.pos.y + 0.5, (this.pos.z + this.botCar.position.z) / 2 + rand(-0.5, 0.5)), Math.random() < 0.5 ? 0xffd23f : 0xfff6d8, new THREE.Vector3(rand(-3, 3), rand(2, 6), rand(-3, 3)), 0.22, 0.4, 0.5);
          }
        }
      }
      if (this.coins.length) {
        this.coinT += dt;
        if (this.coinT > 3) { this.coinT = 0; this.coinStreak = 0; }
        for (const k of this.coins) {
          if (k.got) continue;
          if (Math.abs(k.d - this.dist) > 30) continue;
          k.m.rotation.y += dt * 4;
          if (Math.abs(k.d - this.dist) < 1.4 && k.chunk.spawned && !k.chunk.falling) {
            k.m.getWorldPosition(this.ropeTmp1);
            if (this.pos.distanceToSquared(this.ropeTmp1) < 1.7) {
              k.got = true; k.m.visible = false;
              this.score += 2;
              this.coinStreak++;
              this.coinT = 0;
              this.cb.onScore(this.score, this.combo);
              this.sfx.coin(this.coinStreak);
              this.burst(this.ropeTmp1, [0xffd23f, 0xffffff], 6);
            }
          }
        }
      }
      this.raceAcc += dt;
      if (this.raceOn() && this.state === 'play' && this.raceAcc > 0.25) {
        this.raceAcc = 0;
        this.cb.onRace?.(Math.min(1, this.dist / this.finishD), Math.min(1, this.botDist / this.finishD), Math.max(0, Math.round(this.finishD - this.dist)));
      }
      const bx = -Math.sin(this.h), bz = -Math.cos(this.h);
      const vy = this.h + this.vis.yaw;
      if (this.attached || (this.holding && this.freeDir !== 0)) {
        const ncol2 = NOS[this.nos].outer;
        const nosSmoke = this.nosActive();
        for (const side of [-0.55, 0.55]) {
          const rx = Math.cos(vy) * side, rz = -Math.sin(vy) * side;
          const px = this.pos.x - Math.sin(vy) * 0.6 + rx, pz = this.pos.z - Math.cos(vy) * 0.6 + rz;
          if (this.mode === 'drift') this.skid(px, this.pos.y, pz, vy);
          if (Math.random() < 0.6)
            this.spawn(new THREE.Vector3(px, this.pos.y + 0.25, pz), (nosSmoke && Math.random() < 0.4 ? ncol2 : (Math.random() < 0.55 ? 0xffffff : (Math.random() < 0.5 ? 0xdde1ec : 0xb9c0d4))),
              new THREE.Vector3(rand(-1, 1) + bx, rand(1, 2.5), rand(-1, 1) + bz), 0.45, 0.7, 2.2);
        }
      } else if (Math.random() < 0.25) {
        this.spawn(new THREE.Vector3(this.pos.x + bx * 0.9, this.pos.y + 0.3, this.pos.z + bz * 0.9), 0xffffff, new THREE.Vector3(0, 1, 0), 0.2, 0.3, 1);
      }
      this.ropeWob *= Math.exp(-4.5 * dt);
      if (!this.attached && this.ropeT > 0 && this.state === 'play') {
        this.ropeT -= dt * 9;
        if (this.ropeT <= 0) { this.ropeT = 0; this.hideRope(); }
        else {
          const ax = this.pos.x, ay = this.pos.y + this.ropeAY(), az = this.pos.z;
          this.ropeTmpA.set(ax, ay, az);
          this.ropeTmpE.set(ax + (this.ropeB.x - ax) * this.ropeT, ay + (this.ropeB.y - ay) * this.ropeT, az + (this.ropeB.z - az) * this.ropeT);
          this.renderRope(this.ropeTmpA, this.ropeTmpE, t);
        }
      }
      const turnRate = wrap(this.h - prevH) / Math.max(dt, 1e-4);
      this.vis.roll += (THREE.MathUtils.clamp(-turnRate * 0.05, -0.16, 0.16) - this.vis.roll) * Math.min(1, dt * 10);
    } else if (this.state === 'crash') {
      this.crashT += dt;
      this.crashVel.y -= 32 * dt;
      this.pos.addScaledVector(this.crashVel, dt);
      // tabrakan dengan aspal — mobil memantul, tidak boleh nembus jalan
      let underY = -Infinity, onRoad = false;
      for (let i = this.cur; i < this.cur + 4; i++) {
        const sg2 = this.seg(i);
        if (!sg2) continue;
        const pp = project(sg2, this.pos.x, this.pos.z);
        if (pp.lat < this.edgeTol() + 0.4 && pp.t > -0.05 && pp.t < 1.05) {
          underY = sample(sg2, Math.min(1, Math.max(0, pp.t))).y;
          onRoad = true;
          break;
        }
      }
      const clearance = 0.42;
      if (onRoad && this.pos.y < underY + clearance && this.crashVel.y < 0) {
        this.pos.y = underY + clearance;
        const impact = Math.abs(this.crashVel.y);
        if (impact > 3) {
          this.crashVel.y = impact * 0.42;
          this.crashVel.x *= 0.55; this.crashVel.z *= 0.55;
          this.car.rotation.x *= 0.6; this.car.rotation.z *= 0.6;
          this.shake = Math.max(this.shake, Math.min(0.5, impact * 0.04));
          this.sfx.thud(impact);
          this.burst(this.pos, [0x9aa0b8, 0xffffff], 8);
          navigator.vibrate?.(30);
        } else {
          this.crashVel.y = 0;
          this.settled = true;
        }
      }
      if (this.settled) {
        this.crashVel.x *= Math.exp(-4 * dt); this.crashVel.z *= Math.exp(-4 * dt);
        this.car.rotation.x *= Math.exp(-3 * dt); this.car.rotation.z *= Math.exp(-3 * dt);
      } else {
        this.car.rotation.x += dt * (6 + this.crashVel.length() * 0.15);
        this.car.rotation.z += dt * 4;
      }
      const cSpeed = this.crashVel.length();
      const done = (onRoad && this.settled && cSpeed < 4 && this.crashT > 0.9) || (!onRoad && this.crashT > 1.0) || this.crashT > 2.6 || this.pos.y < underY - 10;
      if (done && !this.overSent) { this.overSent = true; if (this.raceOn()) this.finishRace(false); else this.cb.onGameOver(this.score); }
    } else {
      yawTarget = Math.sin(t * 2) * 0.2;
    }

    const nowS = performance.now() / 1000;
    // V2: jalan tersusun rapi — plank naik bergelombang dari bawah
    for (const c of this.chunks) {
      if (c.spawned) continue;
      if (this.fx === 'V1' || this.roadBuild === 'instant') { c.spawned = true; c.g.visible = true; continue; }
      if (this.state !== 'idle' && c.d - this.dist > 26) continue;
      if (!c.spawnT) { c.spawnT = nowS + (this.state === 'idle' ? c.spawnDelay : 0); c.spawnDelay = 0; }
      const a = (nowS - c.spawnT) / 0.45;
      if (a <= 0) continue;
      c.g.visible = true;
      if (a >= 1) {
        c.spawned = true;
        c.g.position.y = c.by;
        c.g.scale.setScalar(1);
      } else {
        c.g.position.y = c.by + (backOut(a) - 1) * 7;
        c.g.scale.setScalar(Math.min(1, 0.3 + a * 1.4));
      }
    }

    // runtuh ke belakang
    const collapseAt = this.dist - 11;
    const dust = SKINS[this.skin].dust;
    for (let i = this.chunks.length - 1; i >= 0; i--) {
      const c = this.chunks[i];
      if (!c.falling) {
        if (this.state !== 'idle' && c.spawned && c.d < collapseAt) {
          c.falling = true;
          c.t = this.fx === 'V2' ? -Math.random() * 0.07 : 0;
          c.vy = this.fx === 'V2' ? 0 : -1;
          if (this.fx === 'V1') c.spin.set(rand(-0.5, 0.5), rand(-0.25, 0.25), rand(-0.5, 0.5));
          else c.spin.set(rand(-1, 1) * 1.4, 0, rand(-1, 1) * 1.4);
          if (this.state === 'play') this.sfx.rumble();
          for (let k = 0; k < 2; k++)
            this.spawn(c.g.position.clone().add(new THREE.Vector3(rand(-2, 2), -0.5, rand(-2, 2))), dust[k % dust.length],
              new THREE.Vector3(rand(-1.5, 1.5), rand(0, 2.5), rand(-1.5, 1.5)), rand(0.3, 0.55), 0.9, -0.2, true);
        }
        continue;
      }
      c.t += dt;
      if (this.fx === 'V2') {
        // V2: jatuh lurus + menyusut, rapi berurutan tanpa putaran
        if (c.t < 0) continue;
        c.vy -= 34 * dt;
        c.g.position.y += c.vy * dt;
        c.g.position.x += c.spin.x * c.t * dt;
        c.g.position.z += c.spin.z * c.t * dt;
        c.g.scale.setScalar(Math.max(0.001, 1 - c.t / 0.95));
        if (c.t > 1.0) { this.removeChunk(c); this.chunks.splice(i, 1); }
        continue;
      }
      if (c.t < 0.14) { c.g.position.x += (Math.random() - 0.5) * 0.1; continue; }
      c.vy -= 30 * dt;
      c.g.position.y += c.vy * dt;
      c.g.rotation.x += c.spin.x * dt; c.g.rotation.y += c.spin.y * dt; c.g.rotation.z += c.spin.z * dt;
      if (c.t > 2.6) { this.removeChunk(c); this.chunks.splice(i, 1); }
    }

    if (this.state === 'play' && !this.attached) yawTarget = this.freeDir * 0.55;
    this.vis.yawV += ((yawTarget - this.vis.yaw) * 45 - this.vis.yawV * 7) * dt;
    this.vis.yaw += this.vis.yawV * dt;
    const pitchTarget = this.state === 'play' ? -this.slope : 0;
    this.vis.pitchV += ((pitchTarget - this.vis.pitch) * 90 - this.vis.pitchV * 11) * dt;
    this.vis.pitch += this.vis.pitchV * dt;
    this.vis.sqV += (1 - this.vis.sq) * 200 * dt;
    this.vis.sqV *= Math.exp(-11 * dt);
    this.vis.sq += this.vis.sqV * dt;
    this.vis.sq = THREE.MathUtils.clamp(this.vis.sq, 0.82, 1.18);
    this.car.position.copy(this.pos);
    if (this.state !== 'crash') {
      this.car.rotation.y = this.h + this.vis.yaw;
      this.carBody.rotation.z = this.vis.roll;
      this.carBody.rotation.x = this.airborne ? THREE.MathUtils.clamp(-this.airVy * 0.05, -0.45, 0.55) : this.vis.pitch;
    }
    this.carBody.scale.set(1 / Math.sqrt(this.vis.sq), this.vis.sq, 1 / Math.sqrt(this.vis.sq));
    this.carBody.position.x = THREE.MathUtils.clamp(this.vis.roll * 0.4, -0.12, 0.12);
    this.carBody.position.y = this.state === 'play' ? Math.abs(Math.sin(t * 20)) * 0.03 : 0;
    if (this.mode === 'spidey') this.updateSpidey(dt, t);
    // NOS plasma flame — manual: klik kanan / jari kedua / Shift
    const nosing = this.state === 'play' && this.nosActive();
    this.flame.visible = nosing && this.mode === 'drift';
    this.setBoostFx(nosing);
    if (nosing) {
      const fl = (0.9 + Math.sin(t * 55) * 0.1 + Math.random() * 0.07) * (0.45 + 0.55 * Math.min(1, Math.max(0, this.nosMul - 1)));
      this.flameMeshes[0].scale.set(0.44, 0.44, 0.92 * fl);
      this.flameMeshes[1].scale.set(0.27, 0.27, 0.72 * fl);
      this.flameMeshes[2].scale.set(0.14, 0.14, 0.5 * fl);
      this.flameGlow.opacity = 0.4;
      const fx0 = Math.sin(this.h), fz0 = Math.cos(this.h);
      const rx0 = Math.cos(this.h), rz0 = -Math.sin(this.h);
      const ncol = NOS[this.nos].outer;
      for (const sd of [-0.25, 0.25]) {
        if (Math.random() < 0.6) {
          this.spawn(new THREE.Vector3(this.pos.x - fx0 * 1.0 + rx0 * sd, this.pos.y + 0.35, this.pos.z - fz0 * 1.0 + rz0 * sd),
            Math.random() < 0.25 || this.mode === 'spidey' ? 0xffffff : ncol,
            new THREE.Vector3(-fx0 * 4 + rand(-1, 1), rand(1, 2.5), -fz0 * 4 + rand(-1, 1)), 0.27, 0.32, 1.6);
        }
      }
    } else {
      this.flameGlow.opacity = 0;
    }

    for (const p of this.parts) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.m.visible = false; continue; }
      p.m.position.addScaledVector(p.v, dt);
      if (p.grav) p.v.y -= 25 * dt;
      p.m.scale.multiplyScalar(1 + p.grow * dt);
      p.m.rotation.x += dt * 4;
      (p.m.material as THREE.MeshBasicMaterial).opacity = Math.min(1, (p.life / p.max) * 1.5);
    }
    for (const s of this.skids) {
      if (s.life <= 0) continue;
      s.life -= dt;
      (s.m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, Math.min(0.5, s.life * 0.32));
      if (s.life <= 0) s.m.visible = false;
    }

    // ---- 3 camera modes ----
    const portrait = innerWidth < innerHeight;
    const fx = Math.sin(this.h), fz = Math.cos(this.h);
    const crashY = this.state === 'crash' ? this.crashT * 4 : 0;
    let want: THREE.Vector3, look: THREE.Vector3, fovT: number, lerp: number;
    if (this.camMode === 1) {
      want = new THREE.Vector3(this.pos.x - fx * 10.5, this.pos.y + 8.2, this.pos.z - fz * 10.5);
      look = new THREE.Vector3(this.pos.x + fx * 7, this.pos.y + 1.4 + crashY * 0.3, this.pos.z + fz * 7);
      fovT = 62 + (this.attached ? 4 : 0);
      lerp = Math.min(1, dt * 5);
    } else if (this.camMode === 2) {
      want = new THREE.Vector3(this.pos.x, this.pos.y + 34, this.pos.z - 9);
      look = new THREE.Vector3(this.pos.x, this.pos.y, this.pos.z + 3);
      fovT = 55;
      lerp = Math.min(1, dt * 4);
    } else {
      const lead = this.state === 'play' ? 5 : 2;
      const hgt = portrait ? 25 : 20;
      want = new THREE.Vector3(this.pos.x, this.pos.y + hgt + crashY * 0.4, this.pos.z - 13 + lead);
      look = new THREE.Vector3(this.pos.x, this.pos.y - 0.5, this.pos.z + 1.5);
      fovT = (portrait ? 60 : 48) + (this.attached ? 5 : 0) + (this.holding && this.freeDir !== 0 ? 4 : 0) + ((this.attached && this.nosActive()) ? 3 : 0) + (this.effV - 13) * 0.3;
      lerp = Math.min(1, dt * 4);
    }
    this.camPos.lerp(want, lerp);
    this.camera.position.copy(this.camPos);
    this.shake *= Math.exp(-6 * dt);
    this.camera.position.x += (Math.random() - 0.5) * this.shake;
    this.camera.position.y += (Math.random() - 0.5) * this.shake;
    this.fovKick *= Math.exp(-4 * dt);
    fovT += this.fovKick;
    this.camera.lookAt(look);
    this.camera.fov += (fovT - this.camera.fov) * Math.min(1, dt * 4);
    this.camera.updateProjectionMatrix();

    this.light.position.set(this.pos.x + 10, this.pos.y + 25, this.pos.z + 5);
    this.light.target.position.copy(this.pos);

    if (this.mode === 'spidey') this.street.position.set(this.pos.x, this.pos.y - 45, this.pos.z);
    for (const c of this.clouds) {
      if (c.position.z < this.pos.z - 40) { c.position.z += 180; c.position.x = this.pos.x + rand(-70, 70); }
      if (c.position.y > this.pos.y - 12) c.position.y = this.pos.y - rand(15, 40);
      if (c.position.y < this.pos.y - 60) c.position.y = this.pos.y - rand(15, 40);
    }
  }

  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min(0.033, (now - this.last) / 1000);
    this.last = now;
    this.update(dt / 2); this.update(dt / 2);
    this.sfx.update(this.state === 'play', this.effV, !!this.attached || (this.holding && this.freeDir !== 0));
    this.music.update(dt, this.state !== 'idle', this.state === 'play' ? 1 : 0.55, !!this.attached && this.state === 'play', this.combo);
    this.renderer.render(this.scene, this.camera);
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.resize);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
