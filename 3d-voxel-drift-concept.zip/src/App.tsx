import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Game, CARS, CAM_NAMES, NOS, type BotMode, type CamMode, type CarName, type EdgeName, type FxName, type Mode, type NosColor, type RoadBuild, type SkinName } from './game';
import type { MusicStyle } from './audio';

type Screen = 'menu' | 'play' | 'over';

const CAM_ICON = ['🎥', '🏎️', '🛸'];
const EDGES: { id: EdgeName; icon: string; label: string }[] = [
  { id: 'hidden', icon: '🙈', label: 'Hidden' },
  { id: 'flat', icon: '▬', label: 'Flat' },
  { id: 'rail', icon: '🛡️', label: 'Rail' },
];
const FXS: { id: FxName; icon: string; label: string }[] = [
  { id: 'V1', icon: '🧃', label: 'Juicer' },
  { id: 'V2', icon: '🧱', label: 'Rapi' },
];
const ROADBUILDS: { id: RoadBuild; icon: string; label: string }[] = [
  { id: 'instant', icon: '✨', label: 'Langsung' },
  { id: 'wave', icon: '🌊', label: 'Bangun' },
];
const MUSICS: { id: MusicStyle; icon: string; label: string }[] = [
  { id: 'off', icon: '🔇', label: 'Off' },
  { id: 'ceria', icon: '🌈', label: 'Ceria' },
  { id: 'ngebut', icon: '🔥', label: 'Ngebut' },
];
const NOSS: { id: NosColor; label: string }[] = [
  { id: 'blue', label: 'Biru' },
  { id: 'purple', label: 'Ungu' },
  { id: 'green', label: 'Hijau' },
];
const MODES: { id: Mode; icon: string; label: string }[] = [
  { id: 'drift', icon: '🏎️', label: 'Drift' },
  { id: 'free', icon: '💨', label: 'Bebas' },
  { id: 'spidey', icon: '🕷️', label: 'Spidey' },
];
const BOTS: { id: BotMode; icon: string; label: string }[] = [
  { id: 'off', icon: '🚫', label: 'Off' },
  { id: 'ghost', icon: '👻', label: 'Ghost' },
  { id: 'solid', icon: '🧱', label: 'Solid' },
];
const MODE_LABEL: Record<Mode, string> = { drift: 'Drift', free: 'Bebas', spidey: 'Spidey' };
const nosHex = (c: NosColor) => '#' + NOS[c].outer.toString(16).padStart(6, '0');
const bestKey = (m: Mode) => (m === 'spidey' ? 'slingdrift3d-best-spidey' : m === 'free' ? 'slingdrift3d-best-free' : 'slingdrift3d-best');

const pill = (active: boolean) =>
  `rounded-full px-3 py-1.5 text-[13px] leading-none transition-all active:scale-95 ${active ? 'bg-slate-900 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`;

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <div className="mb-1.5 text-[10px] font-bold tracking-[0.22em] text-slate-400">{label}</div>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  );
}

export default function App() {
  const mount = useRef<HTMLDivElement>(null);
  const game = useRef<Game | null>(null);
  const [screen, setScreen] = useState<Screen>('menu');
  const screenRef = useRef<Screen>('menu');
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [mode, setMode] = useState<Mode>(() => (localStorage.getItem('slingdrift3d-mode') as Mode) || 'drift');
  const modeRef = useRef<Mode>((localStorage.getItem('slingdrift3d-mode') as Mode) || 'drift');
  const [best, setBest] = useState(() => Number(localStorage.getItem(bestKey(modeRef.current)) || 0));
  const [popup, setPopup] = useState<{ text: string; color: string; id: number } | null>(null);
  const [bump, setBump] = useState(0);
  const [hint, setHint] = useState('');
  const [boosting, setBoosting] = useState(false);
  const [race, setRace] = useState({ pp: 0, bp: 0, rem: 1100 });
  const [raceResult, setRaceResult] = useState<'win' | 'lose' | null>(null);
  const [skin, setSkin] = useState<SkinName>(() => (localStorage.getItem('slingdrift3d-skin') as SkinName) || 'asphalt');
  const [cam, setCam] = useState<CamMode>(() => Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
  const [edge, setEdge] = useState<EdgeName>(() => (localStorage.getItem('slingdrift3d-edge') as EdgeName) || 'hidden');
  const [car, setCar] = useState<CarName>(() => (localStorage.getItem('slingdrift3d-car') as CarName) || 'viper');
  const [fx, setFx] = useState<FxName>(() => (localStorage.getItem('slingdrift3d-fx') as FxName) || 'V2');
  const [roadBuild, setRoadBuild] = useState<RoadBuild>(() => (localStorage.getItem('slingdrift3d-roadbuild') as RoadBuild) || 'instant');
  const [musik, setMusik] = useState<MusicStyle>(() => (localStorage.getItem('slingdrift3d-music') as MusicStyle) || 'ceria');
  const [nos, setNos] = useState<NosColor>(() => (localStorage.getItem('slingdrift3d-nos') as NosColor) || 'blue');
  const [nosFire, setNosFire] = useState<'hold' | 'toggle'>(() => (localStorage.getItem('slingdrift3d-nosfire') as 'hold' | 'toggle') || 'hold');
  const [bot, setBot] = useState<BotMode>(() => (localStorage.getItem('slingdrift3d-bot') as BotMode) || 'off');
  const canRestart = useRef(true);
  const nosBtn = useRef(false);
  const nosBtnUp = () => { if (nosBtn.current) { nosBtn.current = false; game.current?.nosUp(); } };

  const go = (s: Screen) => { screenRef.current = s; setScreen(s); };
  const startFromMenu = () => {
    if (screenRef.current === 'play' || !canRestart.current) return;
    const g = game.current; if (!g) return;
    setRaceResult(null);
    g.unlockAudio(); g.start(); go('play');
  };

  useEffect(() => {
    const g = new Game(mount.current!, {
      onScore: (s, c) => { setScore(s); setCombo(c); setBump((b) => b + 1); },
      onPopup: (text, color) => setPopup({ text, color, id: Math.random() }),
      onHint: (h) => setHint(h),
      onBoost: (on) => setBoosting(on),
      onRace: (pp, bp, rem) => setRace({ pp, bp, rem }),
      onRaceEnd: (win, s) => {
        const k = bestKey(modeRef.current);
        setBest((b) => { const nb = Math.max(b, s); localStorage.setItem(k, String(nb)); return nb; });
        canRestart.current = false;
        setTimeout(() => (canRestart.current = true), 600);
        setRaceResult(win ? 'win' : 'lose');
        go('over');
      },
      onGameOver: (s) => {
        const k = bestKey(modeRef.current);
        setBest((b) => { const nb = Math.max(b, s); localStorage.setItem(k, String(nb)); return nb; });
        canRestart.current = false;
        setTimeout(() => (canRestart.current = true), 600);
        go('over');
      },
    });
    g.setSkin((localStorage.getItem('slingdrift3d-skin') as SkinName) || 'asphalt');
    g.setCam(Number(localStorage.getItem('slingdrift3d-cam') || 0) as CamMode);
    g.setEdge((localStorage.getItem('slingdrift3d-edge') as EdgeName) || 'hidden');
    g.setCar((localStorage.getItem('slingdrift3d-car') as CarName) || 'viper');
    g.setFx((localStorage.getItem('slingdrift3d-fx') as FxName) || 'V2');
    g.setRoadBuild((localStorage.getItem('slingdrift3d-roadbuild') as RoadBuild) || 'instant');
    g.setMusicStyle((localStorage.getItem('slingdrift3d-music') as MusicStyle) || 'ceria');
    g.setNos((localStorage.getItem('slingdrift3d-nos') as NosColor) || 'blue');
    g.setNosMode((localStorage.getItem('slingdrift3d-nosfire') || 'hold') === 'toggle');
    g.setMode((localStorage.getItem('slingdrift3d-mode') as Mode) || 'drift');
    const b0 = (localStorage.getItem('slingdrift3d-bot') as BotMode) || 'off';
    g.setBot(g.mode === 'spidey' ? 'off' : b0);
    game.current = g;

    let driftPtr: number | null = null;
    const down = (e: PointerEvent) => {
      if ((e.target as HTMLElement)?.closest?.('[data-ui]')) return;
      if (e.button === 2) { g.nosDown(); return; }
      if (driftPtr !== null) { g.nosDown(); return; }
      driftPtr = e.pointerId;
      if (screenRef.current !== 'play') { startFromMenu(); return; }
      g.press();
    };
    const up = (e: PointerEvent) => {
      if (e.button === 2) { g.nosUp(); return; }
      if (e.pointerId === driftPtr) { driftPtr = null; g.release(); }
      else g.nosUp();
    };
    const kd = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        (document.activeElement as HTMLElement)?.blur?.();
        if (screenRef.current !== 'play') { startFromMenu(); return; }
        g.comboDown();
      }
      if (e.code === 'KeyC' && !e.repeat) {
        const m = g.cycleCam();
        localStorage.setItem('slingdrift3d-cam', String(m));
        setCam(m);
      }
      if ((e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') && !e.repeat) g.nosKeyDown();
    };
    const ku = (e: KeyboardEvent) => {
      if (e.code === 'Space') { g.comboUp(); }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight' || e.code === 'KeyN') g.nosKeyUp();
    };
    const ctx = (e: Event) => e.preventDefault();
    window.addEventListener('pointerdown', down);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);
    window.addEventListener('contextmenu', ctx);
    return () => {
      window.removeEventListener('pointerdown', down);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('contextmenu', ctx);
      g.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pick = (key: string, value: string, apply: () => void, set: (v: never) => void) => {
    set(value as never);
    localStorage.setItem(key, value);
    apply();
  };
  const pickMode = (m: Mode) => {
    setMode(m); modeRef.current = m;
    localStorage.setItem('slingdrift3d-mode', m);
    setBest(Number(localStorage.getItem(bestKey(m)) || 0));
    if (m === 'spidey' && bot !== 'off') {
      setBot('off'); localStorage.setItem('slingdrift3d-bot', 'off');
      game.current?.setBot('off');
    }
    game.current?.setMode(m);
  };
  const pickBot = (b: BotMode) => {
    setBot(b); localStorage.setItem('slingdrift3d-bot', b);
    game.current?.setBot(b);
  };
  const pickNosFire = (f: 'hold' | 'toggle') => {
    setNosFire(f); localStorage.setItem('slingdrift3d-nosfire', f);
    game.current?.setNosMode(f === 'toggle');
  };

  return (
    <div className="fixed inset-0 select-none overflow-hidden touch-none font-black" style={{ fontFamily: "'Lilita One', system-ui, sans-serif" }}>
      <div ref={mount} className="absolute inset-0" />

      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-200"
        style={{ opacity: boosting && screen === 'play' ? 1 : 0, background: `radial-gradient(ellipse at center, transparent 52%, rgba(${NOS[nos].css},0.42) 100%)` }}
      />

      {screen === 'play' && (
        <>
          <div className="pointer-events-none absolute inset-x-0 top-5 flex flex-col items-center">
            <div className="text-xs tracking-[0.3em] text-white/90" style={{ textShadow: '0 2px 0 #2b2b3a' }}>SCORE</div>
            <div key={bump} className="score-pop text-7xl leading-none text-white" style={{ WebkitTextStroke: '3px #2b2b3a', paintOrder: 'stroke fill', textShadow: '0 6px 0 #2b2b3a' }}>{score}</div>
            {combo > 1 && (
              <div key={'c' + combo} className="score-pop mt-2 rounded-full bg-gradient-to-b from-yellow-200 to-yellow-400 px-5 py-1 text-xl text-pink-600 shadow-[0_4px_0_#d99a00]">🔥 COMBO x{combo}</div>
            )}
            {bot !== 'off' && (
              <div className="mt-2 flex w-56 flex-col items-center gap-1">
                <div className="rounded-full bg-black/45 px-3 py-0.5 text-sm text-white">🏁 {race.rem}m</div>
                <div className="w-full overflow-hidden rounded-full bg-black/40" title="kamu">
                  <div className="h-2 rounded-full bg-yellow-300 transition-all" style={{ width: `${Math.round(race.pp * 100)}%` }} />
                </div>
                <div className="w-full overflow-hidden rounded-full bg-black/40" title="bot">
                  <div className="h-2 rounded-full bg-purple-400 transition-all" style={{ width: `${Math.round(race.bp * 100)}%` }} />
                </div>
              </div>
            )}
          </div>
          <button
            data-ui
            onPointerDown={(e) => { e.stopPropagation(); const m = game.current?.cycleCam(); if (m !== undefined) { setCam(m); localStorage.setItem('slingdrift3d-cam', String(m)); } }}
            className="absolute right-4 top-4 rounded-2xl border-2 border-white/70 bg-black/45 px-3 py-2 text-lg text-white active:scale-90"
          >
            {CAM_ICON[cam]} {CAM_NAMES[cam]}
          </button>
          <div data-ui className="absolute bottom-8 left-4 flex flex-col items-center gap-1">
            <button
              onPointerDown={(e) => { e.stopPropagation(); if (!nosBtn.current) { nosBtn.current = true; game.current?.nosDown(); } }}
              onPointerUp={nosBtnUp}
              onPointerCancel={nosBtnUp}
              onPointerLeave={nosBtnUp}
              onContextMenu={(e) => e.preventDefault()}
              className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-white/80 bg-gradient-to-b from-sky-400 to-blue-600 text-4xl transition-transform active:translate-y-1"
              style={{ boxShadow: `0 6px 0 rgba(0,0,0,0.4), 0 0 22px ${nosHex(nos)}` }}
            >
              🔥
            </button>
            <div className="rounded-full bg-black/45 px-3 py-0.5 text-sm text-white">NOS</div>
          </div>
          {hint && (
            <div className="pointer-events-none absolute bottom-10 right-4">
              <div key={hint + bump} className="hint-pop text-5xl text-yellow-300" style={{ WebkitTextStroke: '2px #2b2b3a', paintOrder: 'stroke fill', textShadow: '0 5px 0 #2b2b3a' }}>
                {hint}
              </div>
            </div>
          )}
        </>
      )}

      {popup && (
        <div key={popup.id} className="popup pointer-events-none absolute inset-x-0 top-[34%] text-center text-6xl" style={{ color: popup.color, WebkitTextStroke: '3px #2b2b3a', paintOrder: 'stroke fill', textShadow: '0 6px 0 #2b2b3a' }}>
          {popup.text}
        </div>
      )}

      {screen === 'menu' && (
        <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-indigo-950/30 via-transparent to-black/30">
          <div className="mx-auto flex min-h-full w-full max-w-[320px] flex-col items-center justify-center gap-4 px-5 py-8">
            <div className="pointer-events-none text-center">
              <div className="mb-2 inline-block rounded-full bg-white/90 px-4 py-1 text-[11px] tracking-[0.25em] text-slate-600 shadow">HYPERCASUAL • VOXEL DRIFT</div>
              <div className="title text-6xl leading-[0.85] text-white" style={{ WebkitTextStroke: '2px #1e1b2e', paintOrder: 'stroke fill', textShadow: '0 5px 0 #ef2d3c, 0 10px 0 #1e1b2e' }}>
                SLING<br /><span className="text-yellow-300">DRIFT</span>
              </div>
              <div className="mt-2 text-sm font-bold text-white/90" style={{ textShadow: '0 2px 0 #1e1b2e' }}>
                {mode === 'spidey' ? 'Tahan = tembak jaring • Lepas = melayang! 🕸️' : mode === 'free' ? 'Tahan = ngepot • Lepas = lurus! Tanpa tali! 💨' : 'Klik kiri = drift • SPACE = NOS! Independen 🔥'}
              </div>
            </div>

            <div data-ui className="w-full space-y-3.5 rounded-3xl bg-white/95 p-4 shadow-2xl backdrop-blur">
              <Row label="🎮 MODE">
                {MODES.map((m) => (
                  <button key={m.id} onPointerDown={(e) => e.stopPropagation()} onClick={() => pickMode(m.id)} className={pill(mode === m.id)}>
                    {m.icon} {m.label}
                  </button>
                ))}
              </Row>
              {mode !== 'spidey' && (
                <Row label="🤖 LAWAN BOT">
                  {BOTS.map((b) => (
                    <button key={b.id} onPointerDown={(e) => e.stopPropagation()} onClick={() => pickBot(b.id)} className={pill(bot === b.id)}>
                      {b.icon} {b.label}
                    </button>
                  ))}
                </Row>
              )}
              {mode !== 'spidey' && (
                <Row label="🛣️ TRACK">
                  {(['asphalt', 'candy'] as SkinName[]).map((s) => (
                    <button key={s} onPointerDown={(e) => e.stopPropagation()} onClick={() => pick('slingdrift3d-skin', s, () => game.current?.setSkin(s), setSkin as (v: never) => void)} className={pill(skin === s)}>
                      {s === 'asphalt' ? 'Aspal' : 'Candy'}
                    </button>
                  ))}
                </Row>
              )}
              {mode !== 'spidey' && (
                <Row label="🧱 PINGGIRAN">
                  {EDGES.map((e) => (
                    <button key={e.id} onPointerDown={(e2) => e2.stopPropagation()} onClick={() => pick('slingdrift3d-edge', e.id, () => game.current?.setEdge(e.id), setEdge as (v: never) => void)} className={pill(edge === e.id)}>
                      {e.icon} {e.label}
                    </button>
                  ))}
                </Row>
              )}
              <Row label={mode === 'spidey' ? '🕸️ WEB BOOST' : '💨 NOS FLAME'}>
                {NOSS.map((n) => (
                  <button key={n.id} onPointerDown={(e2) => e2.stopPropagation()} onClick={() => pick('slingdrift3d-nos', n.id, () => game.current?.setNos(n.id), setNos as (v: never) => void)} className={pill(nos === n.id)}>
                    <span className="mr-1.5 inline-block h-2.5 w-2.5 rounded-full align-baseline" style={{ background: nosHex(n.id), boxShadow: `0 0 6px ${nosHex(n.id)}` }} />
                    {n.label}
                  </button>
                ))}
              </Row>
              <Row label="🔥 CARA NOS">
                {(['hold', 'toggle'] as const).map((f) => (
                  <button key={f} onPointerDown={(e) => e.stopPropagation()} onClick={() => pickNosFire(f)} className={pill(nosFire === f)}>
                    {f === 'hold' ? '💨 Tahan' : '🔒 Toggle'}
                  </button>
                ))}
              </Row>
              <Row label="✨ EFEK JALAN">
                {FXS.map((f) => (
                  <button key={f.id} onPointerDown={(e2) => e2.stopPropagation()} onClick={() => pick('slingdrift3d-fx', f.id, () => game.current?.setFx(f.id), setFx as (v: never) => void)} className={pill(fx === f.id)}>
                    {f.icon} {f.label}
                  </button>
                ))}
              </Row>
              <Row label="🛤️ JALAN DEPAN">
                {ROADBUILDS.map((r) => (
                  <button key={r.id} onPointerDown={(e2) => e2.stopPropagation()} onClick={() => pick('slingdrift3d-roadbuild', r.id, () => game.current?.setRoadBuild(r.id), setRoadBuild as (v: never) => void)} className={pill(roadBuild === r.id)}>
                    {r.icon} {r.label}
                  </button>
                ))}
              </Row>
              <Row label="🎵 MUSIK">
                {MUSICS.map((m) => (
                  <button key={m.id} onPointerDown={(e2) => e2.stopPropagation()} onClick={() => pick('slingdrift3d-music', m.id, () => game.current?.setMusicStyle(m.id), setMusik as (v: never) => void)} className={pill(musik === m.id)}>
                    {m.icon} {m.label}
                  </button>
                ))}
              </Row>
              <Row label="🎥 KAMERA">
                {([0, 1, 2] as CamMode[]).map((m) => (
                  <button key={m} onPointerDown={(e) => e.stopPropagation()} onClick={() => pick('slingdrift3d-cam', String(m), () => game.current?.setCam(m), (v: never) => setCam(Number(v) as CamMode))} className={pill(cam === m)}>
                    {CAM_ICON[m]} {CAM_NAMES[m]}
                  </button>
                ))}
              </Row>
              {mode !== 'spidey' && (
                <Row label="🚗 GARASI">
                  {CARS.map((c) => (
                    <button key={c.id} onPointerDown={(e) => e.stopPropagation()} onClick={() => pick('slingdrift3d-car', c.id, () => game.current?.setCar(c.id), setCar as (v: never) => void)} className={pill(car === c.id)}>
                      {c.icon} {c.label}
                    </button>
                  ))}
                </Row>
              )}
            </div>

            <button
              data-ui
              onPointerDown={(e) => e.stopPropagation()}
              onClick={startFromMenu}
              className="pulse w-full rounded-2xl bg-white py-4 text-3xl text-slate-900 shadow-[0_7px_0_rgba(0,0,0,0.35)] transition-transform active:translate-y-1 active:shadow-none"
            >
              ▶ MAIN
            </button>
            {best > 0 && (
              <div className="rounded-full bg-black/45 px-5 py-1.5 text-lg text-yellow-300">🏆 Terbaik {MODE_LABEL[mode]}: {best}</div>
            )}
          </div>
        </div>
      )}

      {screen === 'over' && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center bg-indigo-900/35 backdrop-blur-[2px]">
          <div className="popin relative rounded-[2rem] border-4 border-white bg-gradient-to-b from-white to-pink-50 px-12 pb-8 pt-10 text-center shadow-[0_12px_0_#2b2b3a]">
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 rotate-[-3deg] rounded-xl bg-gradient-to-r from-red-500 to-orange-400 px-5 py-1 text-2xl text-white shadow-[0_4px_0_#2b2b3a]">
              {raceResult === 'win' ? '🏆 MENANG!' : raceResult === 'lose' ? '😅 KALAH' : 'GAME OVER'}
            </div>
            <div className="text-lg tracking-widest text-pink-400">SCORE</div>
            <div className="text-8xl leading-none text-indigo-600">{score}</div>
            <div className="mt-3 rounded-full bg-yellow-100 px-4 py-1 text-xl text-yellow-600">
              {raceResult === 'win' ? (score >= best && score > 0 ? '⭐ NEW BEST! ⭐' : `🏆 BEST ${best}`) : raceResult === 'lose' ? 'Bot lebih cepat! Coba lagi 🏁' : (score >= best && score > 0 ? '⭐ NEW BEST! ⭐' : `🏆 BEST ${best}`)}
            </div>
          </div>
          <div className="pulse mt-10 rounded-full bg-white px-10 py-4 text-3xl text-indigo-600 shadow-[0_7px_0_#2b2b3a]">↻ RETRY</div>
        </div>
      )}
    </div>
  );
}
