// ============================================================================
// Simulation: Tiny Vintage Scuba Diver + 5 Companion Bots + Vintage Submarine
// + 60% Smaller Miniature Mode + Megalophobia / POV / 3D Cockpit Cameras
// + 10x Giant Colossus Manta Rays (with dramatic front submarine flyby!)
// ============================================================================
import {
  sin, cos, sqrt, min, max, abs, floor, PI, atan2, hypot, exp, TAU,
  ernd, err, clamp, mix, sstep, wrapAngle, qAxis, qMul, qRot,
} from './math.js';
import { CAB } from './meshes.js';

export const N_DIVERS = 6;    // 0 = Player, 1..5 = 5 Companion Bots
export const N_BEAMS = 8;     // 0..1 = Submarine Twin Searchlights, 2..7 = 6 Diver Helmet Lamps
export const N_DYNBUB = 480;  // Live rising bubbles from helmets, sub propeller & hatch
export const N_COLOSSUS = 2;  // 2 Giant 10x Manta Rays (alongside all 6 original normal mantas!)

// Normal Manta in Noniv/abyssal-garden is ~3.8 scale (7.6m wingspan).
// 10x Giant Manta = 38.0 scale -> colossal 76.0-meter wingspan!
const GIANT_MANTA_SCALE = 38.0;
const SUB_K = 3.8; // Submarine is 1.9x larger than the original

// Base Little Nightmares vintage scuba crew (~50 cm standard; ~20 cm in -60% Mungil mode!)
const CREW_SPEC = [
  { name: 'Captain Ashford',     suit: [0.76, 0.51, 0.12], badge: 0.11, scale: 0.52 },
  { name: 'Nathaniel',     suit: [0.21, 0.36, 0.50], badge: 0.56, scale: 0.51 },
  { name: 'Beatrice',    suit: [0.60, 0.25, 0.16], badge: 0.03, scale: 0.50 },
  { name: 'Theodore', suit: [0.31, 0.40, 0.22], badge: 0.01, scale: 0.54 },
  { name: 'Eleanor',    suit: [0.23, 0.47, 0.41], badge: 0.44, scale: 0.49 },
  { name: 'Percival',      suit: [0.64, 0.55, 0.40], badge: 0.16, scale: 0.45 },
];

// Scenic points of wonder that the 5 companion bots glance & drift toward
const WONDERS = [
  [-5, -36, -4],     // Giant stone whale fluke
  [59.5, -24, 6],    // Sunken wooden ship
  [0, -24, -106],    // Surface-reaching kelp pillar
  [-62, -35, 2],     // Barrel sponge canyon garden
  [8, -32, -88],     // Sunlit kelp basin mound
  [6, -34, 84],      // Glowing purple grotto
  [19, -21, -15],    // Rock window tunnel
  [-23, -10, -16],   // High stone arch
];

// Squad formation offsets [right, forward, up] relative to the squad heading.
// Bots flank the player (never parked dead-ahead in the line of sight / line of fire).
const FORM_OFF = [
  [0, 0, 0],
  [-1.25, 0.35, 0.10],
  [1.30, 0.25, 0.16],
  [-2.15, -0.75, 0.30],
  [2.10, -0.85, 0.24],
  [0.15, -1.75, 0.42],
];
export const N_SEG = 220;     // Harpoon capsule instances (guns, spears, tethers, speared fish)
export const FISH_NAMES = ['Ikan Badut', 'Ikan Kupu-kupu', 'Ikan Singa', 'Ikan Tang Biru', 'Ikan Sarden'];
const FISH_PAT = [3, 4, 5, 6, 7];
const FISH_RGB = [[1, 0.4, 0.08], [1, 0.82, 0.12], [0.8, 0.2, 0.1], [0.1, 0.3, 0.95], [0.75, 0.85, 0.92]];

// Camera modes:
// 0 = STANDAR (polished 3rd-person, never clips floor)
// 1 = MEGALOPHOBIA (wide-angle low-upward cinematic lens amplifying colossal scale!)
// 2 = KOKPIT / POV (true 1st-person Mark V helmet POV for diver, full 3D animated bridge cockpit in sub!)
export const CAM_LABELS = ['Standar', 'Megalophobia', 'POV / Kokpit'];

function orientQuat(yaw, pitch, roll = 0) {
  return qMul(qAxis(0, 1, 0, -yaw), qMul(qAxis(1, 0, 0, pitch), qAxis(0, 0, -1, roll)));
}

function diverQuat(yaw, bodyTilt, roll = 0) {
  return qMul(qAxis(0, 1, 0, -yaw), qMul(qAxis(1, 0, 0, -bodyTilt), qAxis(0, 1, 0, roll)));
}

export function createSimulation(sdAt, gradAt, audioHooks, fishInstances = new Float32Array(0)) {
  // Preallocated GPU instance arrays
  const diverData = new Float32Array(N_DIVERS * 28);
  const subData = new Float32Array(16);
  const cockpitData = new Float32Array(20);
  const colossusData = new Float32Array(N_COLOSSUS * 8);
  const beamData = new Float32Array(N_BEAMS * 12);
  const bubData = new Float32Array(N_DYNBUB * 8);
  const bubSim = new Float32Array(N_DYNBUB * 7);
  let bubCursor = 0;
  let fishDirty = false;
  const fishInventory = [0, 0, 0, 0, 0];
  const teamInventory = [0, 0, 0, 0, 0];
  const segData = new Float32Array(N_SEG * 16);
  const caughtData = new Float32Array(6 * 8); // speared fish drawn with the real fish mesh/shader
  let segN = 0, segCount = 0;
  const mkSpear = () => ({
    phase: 'ready', timer: 0, flightTime: 0.24, reelDuration: 0.9,
    targetIndex: -1, fishKind: 0, autoReel: false, recoil: 0,
    originX: 0, originY: 0, originZ: 0,
    tipX: 0, tipY: 0, tipZ: 0,
    fishX: 0, fishY: 0, fishZ: 0,
    dirX: 0, dirY: 0, dirZ: -1,
    hitX: 0, hitY: 0, hitZ: 0,
    range: 0, hit: false, fishSize: 0.4, tether: 0, struggle: 0,
  });
  const spears = Array.from({ length: 6 }, mkSpear);
  const harpoon = spears[0];
  const fishSample = [0, 0, 0, 0, 0, 0];
  const vm = { swayX: 0, swayY: 0, bob: 0, reelSpin: 0, mx: 0, my: 0, mz: 0, kick: 0, roll: 0, helmX: 0, helmY: 0, breath: 0 };
  const crumbs = [];
  let lastCrumbX = 1e9, lastCrumbY = 0, lastCrumbZ = 0, botToastT = 0;

  function spawnBub(x, y, z, sz, vy = 1.15, spread = 0.04, vx0 = 0, vz0 = 0, maxAge = 3.6) {
    if (y > -0.6) return;
    const i = bubCursor;
    bubCursor = (bubCursor + 1) % N_DYNBUB;
    const o8 = i * 8, o7 = i * 7;
    const sd = ernd();
    bubData[o8] = x + err(-spread, spread);
    bubData[o8 + 1] = y + err(-spread * 0.5, spread * 0.5);
    bubData[o8 + 2] = z + err(-spread, spread);
    bubData[o8 + 3] = sz * 0.4;
    bubData[o8 + 4] = sd;
    bubData[o8 + 5] = 0.9;
    bubData[o8 + 6] = 0;
    bubData[o8 + 7] = 0;
    bubSim[o7] = vx0 + err(-0.16, 0.16);
    bubSim[o7 + 1] = vy * err(0.82, 1.22);
    bubSim[o7 + 2] = vz0 + err(-0.16, 0.16);
    bubSim[o7 + 3] = 0.001;
    bubSim[o7 + 4] = maxAge * err(0.75, 1.3);
    bubSim[o7 + 5] = sz;
    bubSim[o7 + 6] = sd;
  }

  function burstBubbles(x, y, z, count, szMin = 0.02, szMax = 0.09, spread = 0.25) {
    for (let k = 0; k < count; k++) {
      spawnBub(x, y, z, err(szMin, szMax), err(1.0, 2.1), spread, err(-0.35, 0.35), err(-0.35, 0.35), err(2.2, 4.4));
    }
  }

  function moveSphere(ent, dx, dy, dz, rad) {
    const dist = hypot(dx, dy, dz);
    const steps = floor(dist / max(rad * 0.65, 0.12)) + 1;
    let floorHit = false;
    for (let s = 0; s < steps; s++) {
      ent.x += dx / steps;
      ent.y += dy / steps;
      ent.z += dz / steps;
      const rXZ = hypot(ent.x, ent.z);
      if (rXZ > 150) { ent.x *= 150 / rXZ; ent.z *= 150 / rXZ; }
      ent.y = clamp(ent.y, -52.5, -1.05);
      for (let k = 0; k < 2; k++) {
        const d = sdAt(ent.x, ent.y, ent.z) + rad;
        if (d <= 0) break;
        const g = gradAt(ent.x, ent.y, ent.z);
        if (!g) break;
        ent.x -= g[0] * d;
        ent.y -= g[1] * d;
        ent.z -= g[2] * d;
        if (-g[1] > 0.62) floorHit = true;
        const vn = ent.vx * g[0] + ent.vy * g[1] + ent.vz * g[2];
        if (vn > 0) {
          ent.vx -= g[0] * vn;
          ent.vy -= g[1] * vn;
          ent.vz -= g[2] * vn;
        }
      }
    }
    return floorHit;
  }

  const CLEAR_OFFS = [[0, 0, 0], [0, -0.55, 0], [1.0, 0, 0], [-1.0, 0, 0], [0, 0, 1.0], [0, 0, -1.0]];
  function findClearSpot(x, y, z, clearR) {
    const rXZ = hypot(x, z);
    if (rXZ > 146) { x *= 146 / rXZ; z *= 146 / rXZ; }
    const big = clearR > 0.55;
    const sc = min(clearR, 1.0);
    const rad = min(clearR, 0.86);
    let px = x, py = clamp(y, -50.5, -2.2), pz = z;
    for (let iter = 0; iter < 16; iter++) {
      let worst = 0, wx = px, wy = py, wz = pz;
      if (big) {
        for (const o of CLEAR_OFFS) {
          const ox = px + o[0] * sc, oy = py + o[1] * sc, oz = pz + o[2] * sc;
          const d = sdAt(ox, oy, oz) + rad;
          if (d > worst) { worst = d; wx = ox; wy = oy; wz = oz; }
        }
      } else {
        worst = sdAt(px, py, pz) + rad;
      }
      if (worst <= 0) break;
      const g = gradAt(wx, wy, wz);
      if (g) {
        px -= g[0] * max(worst, 0.18);
        py -= g[1] * max(worst, 0.18);
        pz -= g[2] * max(worst, 0.18);
      } else {
        py += 0.45;
      }
      py = clamp(py, -50.5, -2.2);
    }
    return [px, py, pz];
  }

  // Safety net for bots pushed outside the world / hopelessly stuck. They re-enter from BEHIND the camera
  // (outside the view frustum) so nobody ever pops in or vanishes in front of you.
  function recoverBot(b, index) {
    const pl = divers[0], sc = state.scaleMul;
    const fScale = mix(sc, 1.0, 0.24);
    const fx = sin(state.camYaw), fz = -cos(state.camYaw);
    const rx = cos(state.camYaw), rz = sin(state.camYaw);
    const side = index % 2 ? -1 : 1;
    const back = (povView() ? 1.6 : state.curDist + 1.4) * fScale + 0.6;
    let p = null;
    for (let k = 0; k < 4 && !p; k++) {
      const bx = (k < 2 ? state.camX : pl.x) - fx * back * (k % 2 ? 0.6 : 1) + rx * side * (0.9 + index * 0.25) * fScale;
      const bz = (k < 2 ? state.camZ : pl.z) - fz * back * (k % 2 ? 0.6 : 1) + rz * side * (0.9 + index * 0.25) * fScale;
      const c = findClearSpot(bx, pl.y + (0.3 + FORM_OFF[index][2]) * fScale, bz, 0.23 * sc);
      if (sdAt(c[0], c[1], c[2]) < -0.05) p = c;
    }
    if (!p) p = findClearSpot(pl.x + rx * side * 0.8 * fScale, pl.y + 0.4 * fScale, pl.z + rz * side * 0.8 * fScale, 0.23 * sc);
    b.x = p[0]; b.y = p[1]; b.z = p[2];
    b.vx = pl.vx; b.vy = pl.vy; b.vz = pl.vz;
    b.wanderX = b.wanderY = b.wanderZ = 0;
    b.wanderTimer = 1.4 + index * 0.17;
    b.stuckTimer = 0; b.unstickT = 0; b.hasNav = false;
    b.lastX = p[0]; b.lastY = p[1]; b.lastZ = p[2];
    b.aboard = false;
    b.swimBlend = 1;
    b.bodyTilt = 0.32;
  }

  // 6 Vintage Scuba Divers (0 = Player, 1..5 = Friend Bots)
  const divers = CREW_SPEC.map((sp, idx) => ({
    idx,
    name: sp.name,
    suit: sp.suit,
    badge: sp.badge,
    baseScale: sp.scale,
    scale: sp.scale,
    x: 10, y: -42, z: 7,
    vx: 0, vy: 0, vz: 0,
    yaw: -0.8,
    bodyTilt: 0.22,
    roll: 0,
    swimBlend: 1,
    moveAmp: 0,
    phase: idx * 1.17,
    headYaw: 0,
    headPitch: 0.22,
    waveAmt: 0,
    waveTimer: 0,
    bubTimer: ernd() * 0.8,
    aboard: false,
    boardTimer: 0,
    exitDelay: 0,
    stuckTimer: 0,
    lastX: 10, lastY: -42, lastZ: 7,
    wanderX: 0, wanderY: 0, wanderZ: 0,
    wanderTimer: idx * 0.9,
    lookTarget: -1,
    aimPitch: 0, aimBlend: 0, aimHold: 0,
    huntCool: 5 + idx * 2.3, huntState: 0, huntT: 0, huntTarget: -1,
    losT: idx * 0.07, navX: 0, navY: 0, navZ: 0, hasNav: false, unstickT: 0,
  }));

  // Vintage Expedition Submarine + Cockpit Instrument state
  const sub = {
    x: 8, y: -41, z: 5,
    vx: 0, vy: 0, vz: 0,
    yaw: -0.78,
    pitch: 0,
    roll: 0,
    scale: 1.0,
    propAngle: 0,
    propSpeed: 1.4,
    rudder: 0,
    plane: 0,
    wheelAngle: 0,
    throttleLev: 0,
    diveLev: 0,
    pendulum: 0,
    hatchOpen: 0,
    hatchTimer: 0,
    lightsOn: 1,
    lightSmooth: 1,
    bubTimer: 0,
    summonActive: false,
    summonX: 0, summonY: 0, summonZ: 0,
    wakeRock: 0,       // Gentle hull sway when the 76m 10x Giant Manta Ray sweeps past your bow!
    q: [0, 0, 0, 1],
  };

  // 2 Giant 10x Colossus Manta Rays (scale = 38.0 -> 76m wingspan, 10x normal 3.8 manta!)
  // Colossus[0] performs a breathtaking front-of-submarine flyby when you board the submarine,
  // then blends smoothly back into its grand canyon patrol alongside the normal mantas!
  // Colossus[1] majestically circles the sunlit northern kelp basin & shipwreck vista!
  const colossi = [
    {
      x: -14, y: -23, z: -22,
      yaw: 1.45, pitch: -0.03, roll: -0.18,
      scale: GIANT_MANTA_SCALE,
      flap: 0.4,
      // Orbit parameters (central canyon & whale fluke vista — right above normal manta!)
      cx: -4, cy: -18.5, cz: -14, R: 48, spd: 0.042, ph0: 2.35,
      // Dramatic close-front submarine flyby parameters
      flyActive: false,
      flyT: 0,
      flyDur: 22.0,
      sx: 0, sy: 0, sz: 0,
      mx: 0, my: 0, mz: 0,
      ex: 0, ey: 0, ez: 0,
      ancX: 0, ancY: 0, ancZ: 0,
      lastFlybyTime: -999,
      roared: false,
    },
    {
      x: 18, y: -14, z: -68,
      yaw: -1.2, pitch: 0.02, roll: 0.20,
      scale: GIANT_MANTA_SCALE,
      flap: 2.8,
      // Orbit parameters (northern sunlit kelp basin & shipwreck channel)
      cx: 16, cy: -13.5, cz: -56, R: 58, spd: -0.036, ph0: 0.65,
      flyActive: false,
      flyT: 0,
      flyDur: 22,
      sx: 0, sy: 0, sz: 0, mx: 0, my: 0, mz: 0, ex: 0, ey: 0, ez: 0,
      lastFlybyTime: -999,
      roared: false,
    },
  ];

  // Camera, Scale Mode & Gameplay State
  const state = {
    inSub: false,
    miniMode: false,      // true = -60% Smaller Mode (scaleMul = 0.40 for Diver, 5 Bots & Submarine!)
    scaleMul: 1.0,        // Smoothly animated: 1.0 (Standard) <-> 0.40 (Mungil -60%)
    midnightMode: false,  // No sunlight or ambient fill: only helmet & submarine lamps illuminate the abyss!
    viewMode: 0,          // 0 = Standar (3P), 1 = Megalophobia (Wide Low-Angle), 2 = POV / Kokpit 3D
    tanh: 0.68,           // Wider underwater camera baseline; POV and cockpit widen further
    diverZoom: 2.30,      // Clean fixed 3rd-person distance (shows diver + 5 friends + sub + vista!)
    subZoom: 6.80,        // Clean 3rd-person submarine chase distance
    curDist: 2.30,
    pivX: 10, pivY: -41.5, pivZ: 7,
    camX: 10, camY: -41.2, camZ: 7,
    camYaw: -0.8,
    camPitch: 0.08,
    squadYaw: -0.8,
    // Cockpit relative head-look offset so you can freely glance around the glass dome, skylight & instruments!
    cockpitYaw: 0,
    cockpitPitch: 0.04,
    nearSub: true,
    subDist: 3.1,
    mantaDist: 45,
    mantaFlyby: false,
    botsAboard: 0,
    firstBoardDone: false,
    toastEvent: '',
    toastSeq: 0,
  };

  function emitToast(msg) {
    state.toastEvent = msg;
    state.toastSeq++;
  }

  const fract = (v) => v - floor(v);

  // Mirrors W_ANIM.vsFish so harpoons hit exactly the fish drawn by the GPU (school + reef fish).
  function sampleSchoolFish(index, time, out = fishSample) {
    const o = index * 8;
    if (o + 7 >= fishInstances.length) return false;
    const cx = fishInstances[o], cy = fishInstances[o + 1], cz = fishInstances[o + 2];
    const R = max(abs(fishInstances[o + 3]), 0.1);
    const seed = fishInstances[o + 4], rate = fishInstances[o + 5], size = fishInstances[o + 6], phase = fishInstances[o + 7];
    if (!Number.isFinite(cx + cy + cz + R + seed + rate + size + phase) || abs(cx) > 1000) return false;
    const reef = size > 0.4;
    const ya = reef ? 0.7 : 2.2, spr = reef ? 0.45 : 1;
    const fh = (v) => fract(sin(v * 127.1) * 43758.5453);
    const h0 = fh(seed), h1 = fh(seed + 0.37), h2 = fh(seed + 0.71);
    const ta = time * rate + phase * 6.3 + (h0 - 0.5) * (26 / R);
    const ph = phase * 17;
    let px = cx + R * cos(ta);
    let py = cy + ya * sin(3 * ta + ph);
    let pz = cz + R * 0.6 * sin(ta);
    let tx = -R * sin(ta), ty = 3 * ya * cos(3 * ta + ph), tz = R * 0.6 * cos(ta);
    const tl = hypot(tx, ty, tz) || 1;
    const dir = rate < 0 ? -1 : 1;
    tx = tx / tl * dir; ty = ty / tl * dir; tz = tz / tl * dir;
    let sx = tz, sz = -tx;
    const sl = hypot(sx, sz) || 1; sx /= sl; sz /= sl;
    const ux = ty * sz, uy = tz * sx - tx * sz, uz = -ty * sx;
    const ox = ((h1 - 0.5) * 5 + sin(time * 0.6 + seed * 40) * 0.5) * spr;
    const oy = ((h2 - 0.5) * 3.2 + cos(time * 0.5 + seed * 31) * 0.4) * spr;
    out[0] = px + sx * ox + ux * oy; out[1] = py + uy * oy; out[2] = pz + sz * ox + uz * oy;
    out[3] = size * (0.75 + 0.5 * h2); out[4] = seed; out[5] = reef ? min(3, floor(seed * 4)) : 4;
    return true;
  }

  function camBasis() {
    const pitch = state.camPitch, yaw = state.camYaw, cp = cos(pitch);
    const fx = cp * sin(yaw), fy = sin(pitch), fz = -cp * cos(yaw);
    const rx = cos(yaw), rz = sin(yaw);
    return { fx, fy, fz, rx, rz, ux: -rz * fy, uy: rz * fx - rx * fz, uz: rx * fy };
  }

  // Clear line between two points (no rock)?
  function segClear(ax, ay, az, bx, by, bz, n = 7) {
    for (let k = 1; k < n; k++) {
      const u = k / n;
      if (sdAt(ax + (bx - ax) * u, ay + (by - ay) * u, az + (bz - az) * u) > -0.04) return false;
    }
    return true;
  }

  // March a ray against the rock SDF; returns hit distance or maxD
  function rayRock(ox, oy, oz, dx, dy, dz, maxD) {
    let t = 0.3;
    while (t < maxD) {
      const d = sdAt(ox + dx * t, oy + dy * t, oz + dz * t);
      if (d > -0.05) return t;
      t += max(0.18, -d * 0.6);
    }
    return maxD;
  }

  // Ray vs fish with a little aim assist that widens with distance
  function findFishOnRay(ox, oy, oz, dx, dy, dz, time, maxD = 26, assist = 1) {
    let best = null, bestScore = Infinity;
    const count = floor(fishInstances.length / 8);
    for (let i = 0; i < count; i++) {
      const o = i * 8;
      if (fishInstances[o] > 9999) continue;
      const qx = fishInstances[o] - ox, qy = fishInstances[o + 1] - oy, qz = fishInstances[o + 2] - oz;
      const R = fishInstances[o + 3] + 6;
      if (qx * qx + qy * qy + qz * qz > (maxD + R) * (maxD + R)) continue;
      if (!sampleSchoolFish(i, time, fishSample)) continue;
      const vx = fishSample[0] - ox, vy = fishSample[1] - oy, vz = fishSample[2] - oz;
      const along = vx * dx + vy * dy + vz * dz;
      if (along < 0.4 || along > maxD) continue;
      const px = vx - dx * along, py = vy - dy * along, pz = vz - dz * along;
      const perp = sqrt(px * px + py * py + pz * pz);
      const hitR = (0.12 + fishSample[3] * 0.5) * assist + along * 0.022 * assist;
      if (perp <= hitR) {
        const score = along + perp * 6;
        if (score < bestScore) {
          bestScore = score;
          best = { index: i, along, x: fishSample[0], y: fishSample[1], z: fishSample[2], kind: fishSample[5], size: fishSample[3] };
        }
      }
    }
    return best;
  }

  const _rx = (v, a) => { const c = cos(a), s2 = sin(a); return [v[0], v[1] * c - v[2] * s2, v[1] * s2 + v[2] * c]; };
  const _ry = (v, a) => { const c = cos(a), s2 = sin(a); return [v[0] * c + v[2] * s2, v[1], -v[0] * s2 + v[2] * c]; };
  const _rz = (v, a) => { const c = cos(a), s2 = sin(a); return [v[0] * c - v[1] * s2, v[0] * s2 + v[1] * c, v[2]]; };
  // World position of a point on diver's gun, mirroring W_DIVER's part-9 animation
  function gunPoint(d, lx, ly, lz) {
    const sw = d.swimBlend, mv = d.moveAmp, ph = d.phase, aim = d.aimBlend;
    const armX = mix(mix(sin(ph + PI) * 0.48 * mv, -0.28 + sin(ph * 0.5 + PI) * 0.24, sw), d.aimPitch, aim);
    const armZ = mix(mix(0.16, 0.30, sw), 0.05, aim);
    const hp2 = clamp(d.headPitch * 0.35, -0.28, 0.35) * (1 - aim);
    const hy2 = clamp(d.headYaw * 0.55, -0.38, 0.38) * (1 - aim);
    let v = [lx - 0.145, ly - 0.545, lz];
    v = _rz(_rx(v, armX), armZ);
    v = _ry(_rx(v, hp2), hy2);
    const rec = d.idx === 0 ? harpoon.recoil : spears[d.idx].recoil;
    const walkBob = abs(sin(ph)) * 0.026 * mv * (1 - sw);
    const loc = [0.145 + v[0], 0.545 + v[1] - rec * 0.018 + walkBob - 0.48, v[2] + rec * 0.085];
    const q = diverQuat(d.yaw, d.bodyTilt, d.roll);
    const w = qRot(q, loc[0] * d.scale, loc[1] * d.scale, loc[2] * d.scale);
    return [d.x + w[0], d.y + w[1], d.z + w[2]];
  }

  function povView() { return !state.inSub && state.viewMode === 2; }

  function muzzleOf(i) {
    if (i === 0 && povView() && (vm.mx !== 0 || vm.mz !== 0) && hypot(vm.mx - state.camX, vm.my - state.camY, vm.mz - state.camZ) < 2) return [vm.mx, vm.my, vm.mz];
    return gunPoint(divers[i], 0.205, 0.358, -0.37);
  }
  function muzzlePosition() { return muzzleOf(0); }

  // Launch a spear from diver i toward a world point (optionally locked on a fish)
  function launchSpear(i, tx, ty, tz, hit) {
    const sp = spears[i];
    const o = muzzleOf(i);
    sp.originX = o[0]; sp.originY = o[1]; sp.originZ = o[2];
    sp.tipX = o[0]; sp.tipY = o[1]; sp.tipZ = o[2];
    sp.timer = 0; sp.autoReel = i > 0; sp.recoil = 1;
    sp.hit = !!hit;
    sp.targetIndex = hit ? hit.index : -1;
    sp.fishKind = hit ? hit.kind : 0;
    sp.fishSize = hit ? hit.size : 0.4;
    sp.fishSeed = hit ? fishInstances[hit.index * 8 + 4] : 0.5;
    sp.fishRaw = hit ? fishInstances[hit.index * 8 + 6] : 0.4;
    sp.hitX = tx; sp.hitY = ty; sp.hitZ = tz;
    sp.fishX = tx; sp.fishY = ty; sp.fishZ = tz;
    sp.range = max(0.5, hypot(tx - o[0], ty - o[1], tz - o[2]));
    sp.flightTime = clamp(sp.range / 26, 0.1, 0.85);
    const l = sp.range;
    sp.dirX = (tx - o[0]) / l; sp.dirY = (ty - o[1]) / l; sp.dirZ = (tz - o[2]) / l;
    sp.phase = 'flying';
    sp.struggle = 0;
    burstBubbles(o[0], o[1], o[2], i === 0 ? 9 : 4, 0.006, 0.022, 0.03);
  }

  function fireHarpoon(time = 0) {
    if (state.inSub || harpoon.phase !== 'ready') return false;
    const b = camBasis();
    const ox = state.camX, oy = state.camY, oz = state.camZ;
    const rock = rayRock(ox, oy, oz, b.fx, b.fy, b.fz, 26);
    const hit = findFishOnRay(ox, oy, oz, b.fx, b.fy, b.fz, time, min(26, rock + 0.2), 1);
    const d = hit ? hit.along : rock;
    const pl = divers[0];
    pl.aimHold = 1.6;
    pl.aimBlend = max(pl.aimBlend, 0.85);
    pl.yaw = mix(pl.yaw, state.camYaw, 0.7);
    launchSpear(0, hit ? hit.x : ox + b.fx * d, hit ? hit.y : oy + b.fy * d, hit ? hit.z : oz + b.fz * d, hit);
    harpoon.rockHit = !hit && rock < 26;
    vm.kick = 1;
    audioHooks.onHarpoonShot?.(!!hit);
    return true;
  }

  function startReel(sp) {
    sp.phase = 'reeling';
    sp.timer = 0;
    sp.range = hypot(sp.fishX - sp.originX, sp.fishY - sp.originY, sp.fishZ - sp.originZ);
    sp.reelDuration = clamp(sp.range / 5.5, 0.55, 3.2);
  }

  function reelHarpoon() {
    if (state.inSub) return false;
    if (harpoon.phase === 'flying') { harpoon.autoReel = true; audioHooks.onHarpoonReel?.(); return true; }
    if (harpoon.phase !== 'tethered') return false;
    startReel(harpoon);
    audioHooks.onHarpoonReel?.();
    return true;
  }

  function removeFish(index) {
    const o = index * 8;
    fishInstances[o] = 100000; fishInstances[o + 1] = 100000; fishInstances[o + 2] = 100000;
    fishDirty = true;
  }

  function updateSpear(i, dt, time) {
    const sp = spears[i];
    sp.recoil = max(0, sp.recoil - dt * 4.2);
    const m = muzzleOf(i);
    sp.originX = m[0]; sp.originY = m[1]; sp.originZ = m[2];
    if (sp.phase === 'flying') {
      sp.timer += dt;
      if (sp.targetIndex >= 0 && sampleSchoolFish(sp.targetIndex, time, fishSample)) {
        sp.fishX = fishSample[0]; sp.fishY = fishSample[1]; sp.fishZ = fishSample[2];
      }
      const u = clamp(sp.timer / sp.flightTime, 0, 1);
      const e = 1 - (1 - u) * (1 - u) * 0.35 - 0.65 * (1 - u); // fast launch, water drag
      const ex = sp.hit ? sp.fishX : sp.hitX, ey = sp.hit ? sp.fishY : sp.hitY, ez = sp.hit ? sp.fishZ : sp.hitZ;
      const nx = mix(sp.originX, ex, e), ny = mix(sp.originY, ey, e) - sin(u * PI) * 0.015 * sp.range, nz = mix(sp.originZ, ez, e);
      const ddx = nx - sp.tipX, ddy = ny - sp.tipY, ddz = nz - sp.tipZ, dl = hypot(ddx, ddy, ddz);
      if (dl > 1e-4) { sp.dirX = ddx / dl; sp.dirY = ddy / dl; sp.dirZ = ddz / dl; }
      sp.tipX = nx; sp.tipY = ny; sp.tipZ = nz;
      if (ernd() < dt * 30) spawnBub(nx, ny, nz, err(0.004, 0.012), 0.6, 0.01, 0, 0, 1.2);
      if (u >= 1) {
        if (sp.hit && sp.targetIndex >= 0) {
          removeFish(sp.targetIndex);
          sp.phase = 'tethered'; sp.timer = 0;
          sp.hitX = sp.fishX; sp.hitY = sp.fishY; sp.hitZ = sp.fishZ;
          burstBubbles(sp.fishX, sp.fishY, sp.fishZ, 10, 0.006, 0.02, 0.06);
          if (i === 0) {
            emitToast(`${FISH_NAMES[sp.fishKind]} kena! · Klik kanan untuk menarik tali`);
            audioHooks.onHarpoonHit?.();
          }
          if (sp.autoReel) { startReel(sp); if (i === 0) audioHooks.onHarpoonReel?.(); }
        } else {
          sp.phase = 'miss'; sp.timer = 0;
          burstBubbles(sp.tipX, sp.tipY, sp.tipZ, 7, 0.006, 0.02, 0.05);
          if (i === 0) audioHooks.onHarpoonMiss?.();
        }
      }
    } else if (sp.phase === 'tethered') {
      // Speared fish thrashes on the line; it drifts away slowly until you reel it in.
      sp.timer += dt;
      sp.struggle = sin(time * 17 + i) * 0.5 + sin(time * 11.3) * 0.5;
      const dx = sp.hitX - sp.originX, dy = sp.hitY - sp.originY, dz = sp.hitZ - sp.originZ, dl = hypot(dx, dy, dz) || 1;
      const drift = dl < 14 ? 0.35 * dt : 0;
      sp.hitX += dx / dl * drift; sp.hitY += dy / dl * drift + sin(time * 2.1) * 0.05 * dt; sp.hitZ += dz / dl * drift;
      sp.fishX = sp.hitX + sin(time * 13 + i) * 0.05; sp.fishY = sp.hitY + cos(time * 9.7) * 0.04; sp.fishZ = sp.hitZ + cos(time * 12.1) * 0.05;
      sp.tipX = sp.fishX; sp.tipY = sp.fishY; sp.tipZ = sp.fishZ;
      sp.dirX = dx / dl; sp.dirY = dy / dl; sp.dirZ = dz / dl;
      if (sp.timer > (i === 0 ? 12 : 0.4)) startReel(sp);
    } else if (sp.phase === 'reeling') {
      sp.timer += dt;
      const u = clamp(sp.timer / sp.reelDuration, 0, 1);
      const e = u * u * (3 - 2 * u);
      sp.struggle = sin(time * 19 + i) * (1 - u);
      sp.tipX = mix(sp.hitX, m[0], e) + sin(time * 15) * 0.04 * (1 - u);
      sp.tipY = mix(sp.hitY, m[1], e);
      sp.tipZ = mix(sp.hitZ, m[2], e) + cos(time * 13) * 0.04 * (1 - u);
      sp.fishX = sp.tipX; sp.fishY = sp.tipY; sp.fishZ = sp.tipZ;
      const dx = sp.hitX - m[0], dy = sp.hitY - m[1], dz = sp.hitZ - m[2], dl = hypot(dx, dy, dz) || 1;
      sp.dirX = dx / dl; sp.dirY = dy / dl; sp.dirZ = dz / dl;
      if (i === 0) vm.reelSpin += dt * 22;
      if (u >= 1) {
        const kind = sp.fishKind;
        sp.phase = 'ready'; sp.timer = 0; sp.targetIndex = -1; sp.hit = false; sp.autoReel = false;
        burstBubbles(m[0], m[1], m[2], 6, 0.006, 0.02, 0.04);
        if (i === 0) {
          fishInventory[kind]++;
          emitToast(`+1 ${FISH_NAMES[kind]} masuk inventori · total ${fishInventory.reduce((a, c) => a + c, 0)} ikan`);
          audioHooks.onFishCatch?.();
        } else {
          teamInventory[kind]++;
          if (time - botToastT > 5) { botToastT = time; emitToast(`${divers[i].name} menangkap ${FISH_NAMES[kind]}!`); }
        }
      }
    } else if (sp.phase === 'miss') {
      // Spear sticks for a beat, then the line yanks it back to the gun.
      sp.timer += dt;
      const back = clamp((sp.timer - 0.3) / 0.6, 0, 1);
      const e = back * back * (3 - 2 * back);
      sp.tipX = mix(sp.hitX, m[0], e); sp.tipY = mix(sp.hitY, m[1], e) - sin(back * PI) * 0.1; sp.tipZ = mix(sp.hitZ, m[2], e);
      if (i === 0 && back > 0) vm.reelSpin += dt * 26;
      if (back >= 1) { sp.phase = 'ready'; sp.timer = 0; }
    }
  }

  function updateHarpoon(dt, time) {
    for (let i = 0; i < 6; i++) {
      const sp = spears[i];
      if (divers[i].aboard || (i === 0 && state.inSub)) {
        if (sp.phase !== 'ready') {
          if (sp.hit && (sp.phase === 'tethered' || sp.phase === 'reeling')) (i === 0 ? fishInventory : teamInventory)[sp.fishKind]++;
          sp.phase = 'ready'; sp.hit = false; sp.targetIndex = -1;
        }
        if (i > 0) divers[i].huntState = 0;
        continue;
      }
      updateSpear(i, dt, time);
    }
  }

  function toggleMidnight(force) {
    state.midnightMode = typeof force === 'boolean' ? force : !state.midnightMode;
    if (state.midnightMode) sub.lightsOn = 1;
    audioHooks.onSwitch?.(state.midnightMode);
    emitToast(state.midnightMode
      ? 'MODE MIDNIGHT · Gelap total — hanya lampu helm & lampu sorot kapal'
      : 'Mode Siang · Sinar matahari kembali');
    return state.midnightMode;
  }

  function projectToScreen(x, y, z) {
    const dx = x - state.camX, dy = y - state.camY, dz = z - state.camZ;
    const b = camBasis();
    const depth = dx * b.fx + dy * b.fy + dz * b.fz;
    if (depth <= 0.05) return null;
    const aspect = typeof innerWidth !== 'undefined' && innerHeight > 0 ? innerWidth / innerHeight : 16 / 9;
    const nx = (dx * b.rx + dz * b.rz) / (depth * max(state.tanh, 0.1) * aspect);
    const ny = (dx * b.ux + dy * b.uy + dz * b.uz) / (depth * max(state.tanh, 0.1));
    return [nx, ny, depth];
  }

  function harpoonScreenPoint() {
    if (harpoon.phase === 'ready') return { visible: false, x: 0.5, y: 0.5 };
    const p = projectToScreen(harpoon.tipX, harpoon.tipY, harpoon.tipZ);
    if (!p) return { visible: false, x: 0.5, y: 0.5 };
    return { visible: abs(p[0]) <= 1.1 && abs(p[1]) <= 1.1, x: clamp(0.5 + p[0] * 0.5, 0, 1), y: clamp(0.5 - p[1] * 0.5, 0, 1) };
  }

  function onScreen(x, y, z, margin = 1.05) {
    const p = projectToScreen(x, y, z);
    return !!p && p[2] < 45 && abs(p[0]) < margin && abs(p[1]) < margin;
  }

  // Evaluate quadratic Bezier curve & tangent for silky-smooth 10x Giant Manta Ray front flyby!
  function bezPos(c, u) {
    const v = 1 - u;
    return [
      v * v * c.sx + 2 * v * u * c.mx + u * u * c.ex,
      v * v * c.sy + 2 * v * u * c.my + u * u * c.ey,
      v * v * c.sz + 2 * v * u * c.mz + u * u * c.ez,
    ];
  }
  function bezTan(c, u) {
    return [
      2 * (1 - u) * (c.mx - c.sx) + 2 * u * (c.ex - c.mx),
      2 * (1 - u) * (c.my - c.sy) + 2 * u * (c.ey - c.my),
      2 * (1 - u) * (c.mz - c.sz) + 2 * u * (c.ez - c.mz),
    ];
  }

  // Schedule the 10x Giant Manta Ray (76m wingspan!) to glide right across the front of your submarine!
  function triggerGiantMantaFlyby(force = false, curTime = 0) {
    const c = colossi[0];
    if (!force && (c.flyActive || curTime - c.lastFlybyTime < 18)) return;
    const fx = sin(sub.yaw), fz = -cos(sub.yaw); // Submarine forward
    const rx = cos(sub.yaw), rz = sin(sub.yaw); // Submarine right

    // Sunlit clearance height above submarine & canyon structures so its 76m body blazes with god-rays & caustics!
    const passY = clamp(sub.y + 13.5, -27.0, -10.5);
    // Enters immediately from front-starboard (sunlit open canyon), sweeps DEAD-CENTER 31m right in front of your
    // submarine cockpit windshield alongside the normal mantas, then ascends gracefully to port!
    c.ancX = sub.x; c.ancY = sub.y; c.ancZ = sub.z;

    c.sx = sub.x + fx * 39 + rx * 32;
    c.sy = clamp(passY + 1.5, -26.5, -9.5);
    c.sz = sub.z + fz * 39 + rz * 32;

    c.mx = sub.x + fx * 32 - rx * 2;
    c.my = clamp(sub.y + 10.5, -29.5, -11.0);
    c.mz = sub.z + fz * 32 - rz * 2;

    c.ex = sub.x + fx * 40 - rx * 52;
    c.ey = clamp(passY + 6.5, -21.0, -8.5);
    c.ez = sub.z + fz * 40 - rz * 52;

    c.flyActive = true;
    c.flyT = 0;
    c.flyDur = 20.0;
    c.lastFlybyTime = curTime;
    c.roared = false;
    c.x = c.sx; c.y = c.sy; c.z = c.sz;
    const tg = bezTan(c, 0);
    c.yaw = atan2(tg[0], -tg[2]);
    c.pitch = atan2(tg[1], max(hypot(tg[0], tg[2]), 0.1));
    c.roll = 0.22; // Graceful bank tilting its colossal 76m wingspan toward your submarine cockpit!
    emitToast('Manta Ray Raksasa (10x) Melintas di Hadapan Kapal Selam!');
  }

  // Update both 10x Giant Colossus Manta Rays
  function stepColossi(dt, time) {
    for (let i = 0; i < N_COLOSSUS; i++) {
      const c = colossi[i];
      // Slow, majestic, ponderous mega-wingbeat (much slower & heavier than normal mantas!)
      c.flap = (c.flap + 0.62 * dt) % (TAU * 100);

      if (c.flyActive) {
        c.flyT += dt;
        const u = clamp(c.flyT / c.flyDur, 0, 1);
        // Smooth gentle ease so it lingers majestically right in front of your submarine nose!
        const eu = mix(u, u * u * (3 - 2 * u), 0.28);
        const p = bezPos(c, eu);
        const tg = bezTan(c, eu);
        // Smoothly pace submarine motion during crossing so even while cruising forward it sweeps right across your bow!
        const pace = state.inSub ? 0.65 * (1 - sstep(0.65, 1.0, u)) : 0;
        const px = clamp(p[0] + (sub.x - c.ancX) * pace, -145, 145);
        const py = clamp(p[1] + (sub.y - c.ancY) * pace * 0.4 + sin(c.flap) * 0.45, -34, -7.5);
        const pz = clamp(p[2] + (sub.z - c.ancZ) * pace, -145, 145);
        c.x = px;
        c.y = py;
        c.z = pz;
        const tyaw = atan2(tg[0], -tg[2]);
        const tpit = clamp(atan2(tg[1], max(hypot(tg[0], tg[2]), 0.1)), -0.35, 0.35);
        c.yaw += wrapAngle(tyaw - c.yaw) * (1 - exp(-dt * 4));
        c.pitch = mix(c.pitch, tpit, 1 - exp(-dt * 4));
        // Bank gracefully toward the submarine so both its dorsal chevrons and giant ventral gills catch the sunbeams!
        c.roll = mix(c.roll, 0.22 * sin(u * PI), 1 - exp(-dt * 3));

        // Deep resonant leviathan call + gentle hydro-wake rock as its 76m body crosses dead-center!
        if (!c.roared && c.flyT > 1.6) {
          c.roared = true;
          audioHooks.onLeviathan?.();
        }
        if (state.inSub && u > 0.18 && u < 0.72) {
          sub.wakeRock = sin((u - 0.18) / 0.54 * TAU * 1.5) * 0.055 * sin((u - 0.18) / 0.54 * PI);
        } else if (i === 0) {
          sub.wakeRock *= exp(-dt * 3);
        }

        if (c.flyT >= c.flyDur) {
          c.flyActive = false;
          // Seamlessly re-phase patrol orbit from current heading/angle so it never teleports!
          c.ph0 = atan2((c.z - c.cz) / 0.78, c.x - c.cx) - time * c.spd;
        }
      } else {
        // Grand panoramic ocean patrol (slow, peaceful, visible across the entire world!)
        const ta = time * c.spd + c.ph0;
        const gx = c.cx + c.R * cos(ta);
        const gy = c.cy + 2.8 * sin(2 * ta + i * 1.7);
        const gz = c.cz + c.R * 0.78 * sin(ta);
        const vx = -c.R * sin(ta) * c.spd;
        const vy = 5.6 * cos(2 * ta + i * 1.7) * c.spd;
        const vz = c.R * 0.78 * cos(ta) * c.spd;
        const sm = dt >= 0.9 ? 1 : 1 - exp(-dt * 1.4);
        c.x = mix(c.x, gx, sm);
        c.y = mix(c.y, gy, sm);
        c.z = mix(c.z, gz, sm);
        const tyaw = atan2(vx, -vz);
        c.yaw += wrapAngle(tyaw - c.yaw) * (dt >= 0.9 ? 1 : 1 - exp(-dt * 2.2));
        c.pitch = mix(c.pitch, atan2(vy, max(hypot(vx, vz), 1e-4)), sm);
        c.roll = mix(c.roll, -0.20 * Math.sign(c.spd), sm);
        if (i === 0) sub.wakeRock *= exp(-dt * 3);
      }

      const o = i * 8;
      colossusData[o] = c.x;
      colossusData[o + 1] = c.y;
      colossusData[o + 2] = c.z;
      colossusData[o + 3] = c.scale;
      colossusData[o + 4] = c.yaw;
      colossusData[o + 5] = c.pitch;
      colossusData[o + 6] = c.roll;
      colossusData[o + 7] = c.flap;
    }

    const ax = state.inSub ? sub.x : divers[0].x;
    const ay = state.inSub ? sub.y : divers[0].y;
    const az = state.inSub ? sub.z : divers[0].z;
    const d0 = hypot(colossi[0].x - ax, colossi[0].y - ay, colossi[0].z - az);
    const d1 = hypot(colossi[1].x - ax, colossi[1].y - ay, colossi[1].z - az);
    state.mantaDist = min(d0, d1);
    state.mantaFlyby = colossi[0].flyActive;
  }

  // Sync scales of all 6 divers & the submarine for Normal (1.0) vs Mungil -60% (0.40) mode
  function applyScale(mul) {
    state.scaleMul = mul;
    sub.scale = mul * SUB_K;
    for (const d of divers) d.scale = d.baseScale * mul;
  }

  // Place player, 5 friend bots, and vintage submarine cleanly at any of the 6 iconic viewpoints!
  function placeAtPose(pose, keepInSub = state.inSub) {
    const sc = state.miniMode ? 0.40 : 1.0;
    applyScale(sc);

    const [px, py, pz, tx, ty, tz] = pose;
    const dx = tx - px, dy = ty - py, dz = tz - pz;
    const yaw = atan2(dx, -dz);
    // Clean, level-to-slightly-upward opening angle so third-person camera NEVER hits the floor or blocks the view!
    const rawPitch = atan2(dy, hypot(dx, dz));
    state.camYaw = yaw;
    state.camPitch = clamp(rawPitch * 0.24, -0.12, 0.11);
    state.cockpitYaw = 0;
    state.cockpitPitch = 0.05;

    const fx = sin(yaw), fz = -cos(yaw);
    const rx = cos(yaw), rz = sin(yaw);
    const sCam = mix(sc, 1.0, 0.35);

    state.inSub = !!keepInSub;
    if (keepInSub) {
      const sp = findClearSpot(px + fx * 1.8 * SUB_K, py + 1.25 * sub.scale + 0.35, pz + fz * 1.8 * SUB_K, 1.2 * sub.scale);
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
      sub.vx = sub.vy = sub.vz = 0;
      sub.yaw = yaw; sub.pitch = 0.04; sub.roll = 0;
      sub.summonActive = false;
      for (const d of divers) {
        d.x = sub.x; d.y = sub.y; d.z = sub.z;
        d.vx = d.vy = d.vz = 0;
        d.aboard = true;
      }
      state.pivX = sub.x; state.pivY = sub.y + 0.55 * sub.scale; state.pivZ = sub.z;
      state.curDist = state.viewMode === 2 ? 0 : (state.viewMode === 1 ? 9.2 : state.subZoom) * sCam * SUB_K;
    } else {
      // Place tiny vintage scuba player cleanly in foreground facing the iconic vista
      const pp = findClearSpot(px + fx * 1.5, py - 0.55 + 0.25 * sc, pz + fz * 1.5, 0.26 * sc);
      const pl = divers[0];
      pl.x = pp[0]; pl.y = pp[1]; pl.z = pp[2];
      pl.vx = pl.vy = pl.vz = 0;
      pl.yaw = yaw; pl.bodyTilt = 0.18; pl.roll = 0;
      pl.swimBlend = 0.65;
      pl.headYaw = 0; pl.headPitch = 0.18;
      pl.aboard = false;

      // Place all 5 vintage-scuba friend bots right beside you in a cozy explorer squad!
      const fScale = mix(sc, 1.0, 0.22);
      for (let i = 1; i < N_DIVERS; i++) {
        const fo = FORM_OFF[i];
        const bp = findClearSpot(
          pl.x + rx * fo[0] * fScale + fx * fo[1] * fScale,
          pl.y + fo[2] * fScale + 0.08,
          pl.z + rz * fo[0] * fScale + fz * fo[1] * fScale,
          0.25 * sc
        );
        const b = divers[i];
        b.x = bp[0]; b.y = bp[1]; b.z = bp[2];
        b.vx = b.vy = b.vz = 0;
        b.yaw = yaw + err(-0.32, 0.32);
        b.bodyTilt = 0.24; b.roll = 0;
        b.aboard = false; b.exitDelay = 0;
        b.stuckTimer = 0; b.lastX = b.x; b.lastY = b.y; b.lastZ = b.z;
        b.waveTimer = 1.6 + i * 0.25;
      }

      // Park the Vintage Submarine RIGHT NEXT TO THE CREW (~3.1m in Standard, ~1.7m in -60% Mungil mode!)
      // Framed cleanly on the right-front side of the squad, facing the open canyon ahead, instantly boardable with [F]!
      const parkR = 2.15 * mix(sc, 1.0, 0.25) * SUB_K * 0.92;
      const parkF = 2.25 * mix(sc, 1.0, 0.25) * SUB_K * 0.92;
      const sp = findClearSpot(
        pl.x + rx * parkR + fx * parkF,
        pl.y + 0.92 * sub.scale + 0.18,
        pl.z + rz * parkR + fz * parkF,
        1.15 * sc * SUB_K
      );
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
      sub.vx = sub.vy = sub.vz = 0;
      // Aim submarine straight toward the landmark vista (slightly angled inward so its glowing glass nose greets the crew!)
      sub.yaw = yaw - 0.18;
      sub.pitch = 0.02; sub.roll = 0;
      sub.summonActive = false;

      state.pivX = pl.x; state.pivY = pl.y + 0.34 * sCam; state.pivZ = pl.z;
      state.curDist = state.viewMode === 2 ? 0 : (state.viewMode === 1 ? 3.55 : state.diverZoom) * sCam;
    }

    const pl0 = divers[0];
    const boardRange = 5.8 * mix(sc, 1.0, 0.45) * SUB_K * 0.82;
    state.subDist = keepInSub ? 0 : hypot(pl0.x - sub.x, pl0.y - sub.y, pl0.z - sub.z);
    state.nearSub = !keepInSub && state.subDist <= boardRange;

    stepColossi(1.0, 0);
    updateCamera(1.0, 0);
    packBuffers(0);
  }

  // Board / Disembark Submarine (Key F)
  function toggleSubmarine(curTime = 0) {
    const pl = divers[0];
    const sc = state.scaleMul;
    const boardRange = 6.2 * mix(sc, 1.0, 0.45) * SUB_K * 0.82;

    if (!state.inSub) {
      const dist = hypot(pl.x - sub.x, pl.y - sub.y, pl.z - sub.z);
      if (dist > boardRange) return false;
      state.inSub = true;
      sub.summonActive = false;
      sub.hatchTimer = 2.2;
      pl.aboard = true;
      pl.vx = pl.vy = pl.vz = 0;
      for (let i = 1; i < N_DIVERS; i++) divers[i].boardTimer = 0;

      // Align camera cleanly with submarine's forward vista & tilt slightly upward to greet the 10x Giant Manta Ray!
      state.camYaw = sub.yaw;
      state.camPitch = 0.10;
      state.cockpitYaw = 0;
      state.cockpitPitch = 0.12;

      // On very first boarding, automatically give a clean, dramatic view & trigger the 10x Giant Manta Ray front flyby!
      const firstTime = !state.firstBoardDone;
      state.firstBoardDone = true;
      triggerGiantMantaFlyby(firstTime, curTime);

      burstBubbles(sub.x, sub.y + 1.22 * sub.scale, sub.z, 26, 0.025 * sub.scale, 0.11 * sub.scale, 0.32 * sub.scale);
      audioHooks.onHatch?.(true);
      return true;
    } else {
      // Disembark smoothly right beside the submarine along with all 5 vintage-scuba friend bots!
      state.inSub = false;
      sub.hatchTimer = 2.2;
      sub.vx *= 0.22; sub.vy *= 0.22; sub.vz *= 0.22;
      state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw);
      state.camPitch = clamp(state.camPitch, -0.35, 0.25);
      state.cockpitYaw = 0;

      const rx = cos(sub.yaw), rz = sin(sub.yaw);
      const fx = sin(sub.yaw), fz = -cos(sub.yaw);
      const ep = findClearSpot(
        sub.x - rx * (1.35 * sub.scale + 0.25) + fx * 0.25 * sub.scale,
        sub.y + 0.65 * sub.scale,
        sub.z - rz * (1.35 * sub.scale + 0.25) + fz * 0.25 * sub.scale,
        0.26 * sc
      );
      pl.x = ep[0]; pl.y = ep[1]; pl.z = ep[2];
      pl.vx = -rx * 0.9; pl.vy = 0.45; pl.vz = -rz * 0.9;
      pl.yaw = state.camYaw;
      pl.bodyTilt = 0.45;
      pl.swimBlend = 1;
      pl.aboard = false;
      for (let i = 1; i < N_DIVERS; i++) {
        if (divers[i].aboard) divers[i].exitDelay = 0.13 * i;
      }
      burstBubbles(sub.x, sub.y + 1.24 * sub.scale, sub.z, 28, 0.025 * sub.scale, 0.12 * sub.scale, 0.35 * sub.scale);
      audioHooks.onHatch?.(false);
      return true;
    }
  }

  // Toggle 60% Smaller Miniature Mode (1.0 <-> 0.40 scale for Player, 5 Bots, and Submarine!)
  function toggleMiniMode(forceVal) {
    state.miniMode = typeof forceVal === 'boolean' ? forceVal : !state.miniMode;
    const pl = divers[0];
    const cx = state.inSub ? sub.x : pl.x;
    const cy = state.inSub ? sub.y : pl.y;
    const cz = state.inSub ? sub.z : pl.z;
    burstBubbles(cx, cy + 0.3, cz, 22, 0.02, 0.08, 0.45);
    // If shrinking while outside, nudge parked submarine closer to crew so it stays cozy beside them!
    if (!state.inSub && state.subDist < 8) {
      const targetS = state.miniMode ? 0.40 : 1.0;
      const dx = sub.x - pl.x, dz = sub.z - pl.z;
      const d = hypot(dx, dz) || 1;
      const wantD = (state.miniMode ? 2.1 : 3.2) * SUB_K * 0.92;
      const sp = findClearSpot(pl.x + (dx / d) * wantD, pl.y + 0.92 * targetS + 0.15, pl.z + (dz / d) * wantD, 1.1 * targetS * SUB_K);
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
    }
    audioHooks.onSwitch?.(state.miniMode);
    emitToast(state.miniMode ? 'Mode Mungil -60% Aktif (Penyelam & Kapal Selam Mini!)' : 'Ukuran Standar Little Nightmares');
  }

  // Standing helm spot right near the steering wheel (wheel is at z = -0.315, floor y = -0.48)
  const PILOT_X = 0, PILOT_FY = -0.48, PILOT_Z = -0.23;

  function inSubInterior() {
    return state.inSub && (state.inside !== 'pilot' || state.viewMode === 0 || state.viewMode === 2);
  }

  // Camera Modes:
  // 0 = Standar / Kabin 3rd Person (default outside & inside sub — preserved seamlessly when grabbing helm!)
  // 1 = Megalophobia (wide low-angle exterior view)
  // 2 = POV (1st-person Scuba Helmet outside, 1st-person POV Kemudi / Kabin inside sub — optional toggle!)
  // 3 = Luar Kapal 3rd Person (exterior submarine chase camera when piloting)
  function setViewMode(mode) {
    const maxModes = state.inSub && state.inside === 'pilot' ? 4 : 3;
    let next = ((mode % maxModes) + maxModes) % maxModes;
    if (!state.inSub && next === 3) next = 0;
    if (state.inSub && state.inside === 'walk' && (next === 1 || next === 3)) next = 0;

    const wasInterior = inSubInterior();
    state.viewMode = next;
    const nowInterior = inSubInterior();

    if (state.inSub) {
      if (!wasInterior && nowInterior) {
        state.cockpitYaw = clamp(wrapAngle(state.camYaw - sub.yaw), -1.1, 1.1);
        state.cockpitPitch = clamp(state.camPitch - sub.pitch, -0.5, 0.65);
      } else if (wasInterior && !nowInterior) {
        state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw);
        state.camPitch = clamp(sub.pitch + state.cockpitPitch * 0.5, -0.7, 0.7);
      }
    }
    audioHooks.onSwitch?.(true);
    const label = next === 0
      ? (state.inSub ? 'Kamera: Kabin 3rd Person' : 'Kamera: Standar (3rd Person)')
      : next === 1
        ? 'Kamera: Megalophobia (Wide Low-Angle)'
        : next === 3
          ? 'Kamera: Luar Kapal (3rd Person)'
          : state.inSub
            ? (state.inside === 'pilot' ? 'Kamera: Mode POV Kemudi' : 'Kamera: Mode POV Kabin')
            : 'Kamera: POV Helm Scuba 1.4x';
    emitToast(label);
  }

  function cycleView() {
    if (state.inSub && state.inside === 'pilot') {
      const order = [0, 2, 3, 1];
      const idx = order.indexOf(state.viewMode);
      setViewMode(order[(idx + 1) % order.length]);
    } else if (state.inSub && state.inside === 'walk') {
      setViewMode(state.viewMode === 2 ? 0 : 2);
    } else {
      setViewMode((state.viewMode + 1) % 3);
    }
  }

  // Quick toggle specifically for POV mode (Key K — optional POV camera while steering or diving!)
  function toggleCockpit() {
    setViewMode(state.viewMode === 2 ? 0 : 2);
  }

  // Quick toggle specifically for Megalophobia camera mode (Key J)
  function toggleMegalophobia() {
    if (state.inSub && state.inside === 'walk') {
      emitToast('Pegang kemudi dulu untuk kamera eksterior Megalophobia');
      return;
    }
    setViewMode(state.viewMode === 1 ? 0 : 1);
  }

  function toggleLights() {
    sub.lightsOn = sub.lightsOn ? 0 : 1;
    audioHooks.onSwitch?.(!!sub.lightsOn);
    emitToast(sub.lightsOn ? 'Lampu Sorot Nyala' : 'Lampu Sorot Mati');
  }

  function zoom(deltaY) {
    const k = exp(clamp(deltaY, -180, 180) * 0.0012);
    if (state.inSub && !inSubInterior()) state.subZoom = clamp(state.subZoom * k, 3.8, 22);
    else if (state.inSub) state.cabZoom = clamp((state.cabZoom || 0.58) * k, 0.34, 0.88);
    else state.diverZoom = clamp(state.diverZoom * k, 1.05, 5.8);
    if (state.viewMode === 2 && deltaY > 0) setViewMode(0);
  }

  function callFriends() {
    if (state.inSub) {
      // Inside submarine, calling triggers the 10x Manta sonar greeting if cooldown passed!
      triggerGiantMantaFlyby(true, 0);
      audioHooks.onSonar?.();
      return;
    }
    const pl = divers[0];
    pl.waveTimer = 1.7;
    burstBubbles(pl.x, pl.y + 0.4 * state.scaleMul, pl.z, 10, 0.012, 0.04, 0.08);
    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i];
      b.wanderX = b.wanderY = b.wanderZ = 0;
      b.wanderTimer = 4.2;
      b.waveTimer = 2.2 + i * 0.18;
      b.lookTarget = 0;
      burstBubbles(b.x, b.y + 0.38 * state.scaleMul, b.z, 7, 0.012, 0.036, 0.07);
    }
    audioHooks.onBell?.();
    emitToast('5 Teman Penyelam Mendekat & Melambai');
  }

  function summonSubmarine() {
    if (state.inSub) return;
    const pl = divers[0];
    const sc = state.scaleMul;
    const pScale = mix(sc, 1.0, 0.25) * SUB_K * 0.92;
    const fx = sin(state.camYaw), fz = -cos(state.camYaw);
    const rx = cos(state.camYaw), rz = sin(state.camYaw);
    const goal = findClearSpot(pl.x + fx * 2.5 * pScale + rx * 2.0 * pScale, pl.y + 0.95 * sc + 0.2, pl.z + fz * 2.5 * pScale + rz * 2.0 * pScale, 1.15 * sub.scale);
    sub.summonX = goal[0]; sub.summonY = goal[1]; sub.summonZ = goal[2];
    const d = hypot(sub.x - goal[0], sub.y - goal[1], sub.z - goal[2]);
    if (d > 34) {
      const start = findClearSpot(goal[0] + fx * 16, clamp(goal[1] + 4.5, -44, -4), goal[2] + fz * 16, 1.2 * sub.scale);
      sub.x = start[0]; sub.y = start[1]; sub.z = start[2];
      sub.yaw = atan2(goal[0] - sub.x, -(goal[2] - sub.z));
    }
    sub.summonActive = true;
    audioHooks.onSonar?.();
    emitToast('Kapal Selam Mendekat ke Kru…');
  }

  // Scaled multi-point submarine hull collision
  const SUB_PROBES = [
    [0, 0, -1.75, 0.72],
    [0, 0, 0.0, 0.85],
    [0, 0, 1.55, 0.62],
    [0, 0.78, -0.18, 0.48],
    [0, -0.35, -0.4, 0.62],
  ];
  function moveSubmarine(dt) {
    const sc = sub.scale;
    const dx = sub.vx * dt, dy = sub.vy * dt, dz = sub.vz * dt;
    const steps = floor(hypot(dx, dy, dz) / max(0.32 * sc, 0.18)) + 1;
    const q = orientQuat(sub.yaw, sub.pitch, sub.roll);
    for (let s = 0; s < steps; s++) {
      sub.x += dx / steps;
      sub.y += dy / steps;
      sub.z += dz / steps;
      const rXZ = hypot(sub.x, sub.z);
      if (rXZ > 149) { sub.x *= 149 / rXZ; sub.z *= 149 / rXZ; }
      sub.y = clamp(sub.y, -52.0, -1.2 - 0.85 * sc);
      for (const pr of SUB_PROBES) {
        const off = qRot(q, pr[0] * sc, pr[1] * sc, pr[2] * sc);
        const wx = sub.x + off[0], wy = sub.y + off[1], wz = sub.z + off[2];
        const d = sdAt(wx, wy, wz) + pr[3] * sc;
        if (d > 0) {
          const g = gradAt(wx, wy, wz);
          if (!g) continue;
          sub.x -= g[0] * d;
          sub.y -= g[1] * d;
          sub.z -= g[2] * d;
          const vn = sub.vx * g[0] + sub.vy * g[1] + sub.vz * g[2];
          if (vn > (sub.impact || 0)) {
            sub.impact = vn;
            const iq = [-q[0], -q[1], -q[2], q[3]], lg = qRot(iq, g[0], g[1], g[2]);
            sub.impLocal = [pr[0] + lg[0] * pr[3], pr[1] + lg[1] * pr[3], pr[2] + lg[2] * pr[3]];
          }
          if (vn > 0) {
            sub.vx -= g[0] * vn;
            sub.vy -= g[1] * vn;
            sub.vz -= g[2] * vn;
          }
        }
      }
    }
  }

  // Clamp a cockpit-local 3rd-person camera point strictly inside the submarine cabin & doorway
  function clampCabinCam(px, py, pz, tx, ty, tz) {
    let bx = px, by = py, bz = pz;
    for (let s = 1; s <= 8; s++) {
      const u = s / 8;
      let x = mix(px, tx, u), y = mix(py, ty, u), z = mix(pz, tz, u);
      if (z < -0.42 || z > 3.35) break;
      const minY = z < 0.16 ? -0.41 : CAB.FLOOR + 0.05;
      if (y < minY) y = minY;
      // Doorway arch between forward observation room and mess (z = CAB.DOOR = 1.6)
      if ((pz - CAB.DOOR) * (z - CAB.DOOR) <= 0 || abs(z - CAB.DOOR) < 0.09) {
        if (abs(x) > 0.22 || y > 0.35) {
          x = clamp(x, -0.21, 0.21);
          y = min(y, 0.34);
        }
      }
      const maxRX = z < 0.16 ? 0.47 : 0.51, maxRY = z < 0.16 ? 0.40 : 0.46;
      const er = hypot(x / maxRX, (y + 0.02) / maxRY);
      if (er > 1) { x /= er; y = -0.02 + (y + 0.02) / er; }
      bx = x; by = y; bz = z;
    }
    return [bx, by, bz];
  }

  // Polished Camera System:
  //   0 = Standar / Kabin 3rd Person (preserved seamlessly before & during submarine steering!)
  //   1 = Megalophobia (wide-angle dramatic low-angle exterior lens)
  //   2 = POV (1st-person 1.4x Scuba Helmet outside, optional 1st-person POV Kemudi / Kabin inside sub!)
  //   3 = Luar Kapal 3rd Person (exterior submarine chase camera while piloting)
  function updateCamera(dt, time = 0) {
    const pl = divers[0];
    const sc = state.scaleMul;
    const sCam = mix(sc, 1.0, 0.30);
    const instant = dt >= 0.9;

    // Smoothly interpolate FOV (TANH) per camera mode!
    const wantTanh = state.viewMode === 1
      ? (state.miniMode ? 1.0 : 0.96)
      : state.viewMode === 2
        ? (state.inSub ? 1.02 : 1.14)
        : inSubInterior()
          ? 0.86
          : (state.miniMode ? 0.72 : 0.68);
    state.tanh = instant ? wantTanh : mix(state.tanh, wantTanh, 1 - exp(-dt * 6.5));

    // --- INSIDE THE SUBMARINE CABIN / BRIDGE (both Walking AND Steering!) ---
    if (inSubInterior()) {
      const cs = cockpitScale();
      const totRoll = sub.roll + sub.wakeRock;
      const sq = orientQuat(sub.yaw, sub.pitch, totRoll);
      const O = interiorOrigin(sq, cs);
      const w = state.walk;

      if (state.viewMode === 2) {
        // Optional 1st-Person POV inside submarine (POV Kabin when walking, POV Kemudi when standing near wheel!)
        state.curDist = 0;
        if (state.inside === 'walk') {
          const eyeH = w.pose === 'sit' ? 0.30 : w.pose === 'lie' ? 0.08 : 0.39;
          const bob = w.pose === 'stand' ? sin(w.phase * 2) * 0.008 * w.move : 0;
          const e = qRot(sq, w.x * cs, (w.fy + eyeH + bob) * cs, w.z * cs);
          state.camX = O[0] + e[0]; state.camY = O[1] + e[1]; state.camZ = O[2] + e[2];
          state.camYaw = wrapAngle(sub.yaw + w.yaw);
          state.camPitch = clamp(sub.pitch + state.walkPitch + (w.pose === 'lie' ? 0.9 : 0), -1.35, 1.45);
        } else {
          // Standing right near the steering wheel (PILOT_Z = -0.23): eye at (-0.085, -0.185) right behind wheel!
          const cabinSway = sin(time * 0.43) * 0.003 + sub.wakeRock * 0.12;
          const cabinBob = sin(time * 0.68) * 0.0025;
          const e = qRot(sq, cabinSway * cs, (-0.085 + cabinBob) * cs, -0.185 * cs);
          state.camX = O[0] + e[0]; state.camY = clamp(O[1] + e[1], -52.2, -0.72); state.camZ = O[2] + e[2];
          state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw + sin(time * 0.31) * 0.002);
          state.camPitch = clamp(sub.pitch + state.cockpitPitch + cos(time * 0.39) * 0.002, -1.25, 1.38);
        }
        state.pivX = state.camX; state.pivY = state.camY; state.pivZ = state.camZ;
        return;
      }

      // Default Mode 0: Kabin 3rd Person — stays identical before & after pressing F on the helm wheel!
      const isPilot = state.inside === 'pilot';
      const pxL = isPilot ? PILOT_X : w.x;
      const pyL = isPilot
        ? PILOT_FY + 0.41
        : w.fy + (w.pose === 'lie' ? 0.14 : w.pose === 'sit' ? 0.30 : 0.39);
      const pzL = isPilot ? PILOT_Z : w.z;
      const lyaw = isPilot ? state.cockpitYaw : w.yaw;
      const lpit = clamp(isPilot ? state.cockpitPitch : state.walkPitch, -0.75, 0.85);
      const distL = state.cabZoom || (isPilot ? 0.60 : 0.56);
      const cpL = cos(lpit), spL = sin(lpit);
      const fxL = cpL * sin(lyaw), fyL = spL, fzL = -cpL * cos(lyaw);
      const wantL = clampCabinCam(pxL, pyL, pzL, pxL - fxL * distL, pyL - fyL * distL + 0.055, pzL - fzL * distL);

      const smCab = instant ? 1 : 1 - exp(-dt * 14);
      state.cabCamX = state.cabCamX === undefined || instant ? wantL[0] : mix(state.cabCamX, wantL[0], smCab);
      state.cabCamY = state.cabCamY === undefined || instant ? wantL[1] : mix(state.cabCamY, wantL[1], smCab);
      state.cabCamZ = state.cabCamZ === undefined || instant ? wantL[2] : mix(state.cabCamZ, wantL[2], smCab);

      const cw = qRot(sq, state.cabCamX * cs, state.cabCamY * cs, state.cabCamZ * cs);
      const pw = qRot(sq, pxL * cs, pyL * cs, pzL * cs);
      state.camX = O[0] + cw[0];
      state.camY = clamp(O[1] + cw[1], -52.2, -0.72);
      state.camZ = O[2] + cw[2];
      state.pivX = O[0] + pw[0]; state.pivY = O[1] + pw[1]; state.pivZ = O[2] + pw[2];
      state.camYaw = wrapAngle(sub.yaw + lyaw);
      state.camPitch = clamp(sub.pitch + lpit + (!isPilot && w.pose === 'lie' ? 0.45 : 0), -1.25, 1.35);
      state.curDist = distL * cs;
      return;
    }

    // --- MODE 2 OUTSIDE SUB: FIRST-PERSON POV (1.4x SCUBA HELMET) ---
    if (state.viewMode === 2) {
      state.curDist = 0;
      const dq = diverQuat(pl.yaw, pl.bodyTilt, pl.roll);
      const breathY = sin(time * 1.25) * 0.0035 * sc;
      const headDrift = sin(time * 0.37) * 0.0025 * sc;
      const eye = qRot(dq, headDrift, 0.33 * pl.scale + breathY, -0.18 * pl.scale);
      const kb = pl.moveAmp * (1 - pl.aimBlend * 0.6);
      const bobU = sin(pl.phase * 2.0) * 0.011 * kb * mix(sc, 1, 0.5);
      const bobS = sin(pl.phase) * 0.008 * kb * mix(sc, 1, 0.5);
      const rx = cos(state.camYaw), rz = sin(state.camYaw);
      state.camX = pl.x + eye[0] + rx * bobS;
      state.camY = clamp(pl.y + eye[1] + bobU, -52.2, -0.68);
      state.camZ = pl.z + eye[2] + rz * bobS;
      state.pivX = pl.x; state.pivY = pl.y + 0.25 * sc; state.pivZ = pl.z;
      return;
    }

    // --- MODE 0 (STANDAR) & MODE 1 (MEGALOPHOBIA) ---
    const isMega = state.viewMode === 1;
    let tx, ty, tz, wantD, liftY;

    if (state.inSub) {
      tx = sub.x;
      // Megalophobia frames the tiny submarine low against towering 40m kelp, sunken ship & 76m Giant Manta Ray!
      ty = sub.y + (isMega ? 1.35 : 0.62) * sCam * SUB_K;
      tz = sub.z;
      wantD = (isMega ? state.subZoom * 1.38 : state.subZoom) * sCam * SUB_K;
      liftY = (isMega ? -0.45 : 0.48) * sCam * SUB_K;
    } else {
      // Frame the tiny vintage diver in the lower-third so the vast abyss & 5 friends shine above without occlusion!
      tx = pl.x;
      ty = pl.y + (isMega ? 0.92 : 0.42) * sCam;
      tz = pl.z;
      wantD = (isMega ? state.diverZoom * 1.58 : state.diverZoom) * sCam;
      liftY = (isMega ? -0.26 : 0.22) * sCam;
    }

    // Subtle deep-sea current sway in Megalophobia mode for living cinematic scale
    if (isMega && !instant) {
      tx += sin(time * 0.45) * 0.08 * sCam;
      ty += cos(time * 0.37) * 0.06 * sCam;
    }

    const sm = instant ? 1 : 1 - exp(-dt * (isMega ? 7.5 : 11.5));
    state.pivX = mix(state.pivX, tx, sm);
    state.pivY = mix(state.pivY, ty, sm);
    state.pivZ = mix(state.pivZ, tz, sm);
    state.curDist = instant ? wantD : mix(state.curDist, wantD, 1 - exp(-dt * 6.5));

    const effPitch = isMega ? clamp(state.camPitch + 0.09, -1.25, 1.42) : state.camPitch;
    const cp = cos(effPitch), sp = sin(effPitch);
    const fx = cp * sin(state.camYaw), fy = sp, fz = -cp * cos(state.camYaw);

    // Smart collision-free third-person positioning:
    // March backward; if the seafloor pushes from below when looking UP, glide camera smoothly ABOVE the floor
    // instead of slamming close into the diver's scuba tanks!
    const maxD = state.curDist;
    const minD = (state.inSub ? 2.5 * SUB_K : 0.72) * sCam;
    let cx = state.pivX - fx * maxD;
    let cy = state.pivY - fy * maxD + liftY;
    let cz = state.pivZ - fz * maxD;

    const steps = 10;
    for (let s = 1; s <= steps; s++) {
      const d = maxD * (s / steps);
      if (d < minD) continue;
      let tx2 = state.pivX - fx * d;
      let ty2 = clamp(state.pivY - fy * d + liftY * (d / max(maxD, 0.1)), -52.2, -0.72);
      let tz2 = state.pivZ - fz * d;
      const pen = sdAt(tx2, ty2, tz2) + 0.32;
      if (pen > 0) {
        const g = gradAt(tx2, ty2, tz2);
        // If hitting horizontal seafloor from above, smoothly skim just above the sand!
        if (g && -g[1] > 0.58) {
          ty2 += pen + 0.04;
          if (sdAt(tx2, ty2, tz2) + 0.24 <= 0) {
            cx = tx2; cy = ty2; cz = tz2;
            continue;
          }
        }
        // Otherwise hitting a vertical rock wall/arch: stop cleanly right in front of the wall!
        const safeD = max(minD, maxD * ((s - 1) / steps));
        cx = state.pivX - fx * safeD;
        cy = clamp(state.pivY - fy * safeD + liftY * (safeD / max(maxD, 0.1)), -52.2, -0.72);
        cz = state.pivZ - fz * safeD;
        break;
      }
      cx = tx2; cy = ty2; cz = tz2;
    }

    // Final gentle rock pushout so camera lens never clips a grain of sand
    const finPen = sdAt(cx, cy, cz) + 0.28;
    if (finPen > 0) {
      const g = gradAt(cx, cy, cz);
      if (g) { cx -= g[0] * finPen; cy -= g[1] * finPen; cz -= g[2] * finPen; }
    }

    state.camX = cx;
    state.camY = clamp(cy, -52.2, -0.72);
    state.camZ = cz;
    const rXZ = hypot(state.camX, state.camZ);
    if (rXZ > 151) { state.camX *= 151 / rXZ; state.camZ *= 151 / rXZ; }
  }

  // Pack all GPU buffers (Submarine, 3D Cockpit, 6 Vintage Divers, Beams)
  function packBuffers(time) {
    const sc = state.scaleMul;
    const inCockpit = inSubInterior();
    const totRoll = sub.roll + sub.wakeRock;
    const sq = orientQuat(sub.yaw, sub.pitch, totRoll);
    sub.q = sq;

    let crewMask = 0, botsIn = 0;
    if (divers[0].aboard) crewMask |= 1;
    for (let i = 1; i < N_DIVERS; i++) {
      if (divers[i].aboard) {
        crewMask |= (1 << i);
        botsIn++;
      }
    }
    state.botsAboard = botsIn;
    const crewTotal = botsIn + (divers[0].aboard ? 1 : 0);

    // 1. Pack Exterior Submarine (hidden when inside 3D Cabin/Cockpit so exterior bubble glass never double-draws!)
    subData[0] = sub.x; subData[1] = sub.y; subData[2] = sub.z;
    subData[3] = inCockpit ? 0.0 : sub.scale;
    subData[4] = sq[0]; subData[5] = sq[1]; subData[6] = sq[2]; subData[7] = sq[3];
    subData[8] = sub.propAngle; subData[9] = sub.rudder; subData[10] = sub.plane; subData[11] = sub.hatchOpen;
    subData[12] = sub.lightSmooth; subData[13] = crewMask; subData[14] = crewTotal; subData[15] = time;

    // 2. Pack Full 3D Vintage Submarine Cockpit Interior (fixed to hull via interiorOrigin!)
    if (inCockpit) {
      const c0 = colossi[0], c1 = colossi[1];
      const d0 = hypot(c0.x - sub.x, c0.z - sub.z), d1 = hypot(c1.x - sub.x, c1.z - sub.z);
      const mc = d0 <= d1 ? c0 : c1;
      const mdx = mc.x - sub.x, mdz = mc.z - sub.z;
      const fx = sin(sub.yaw), fz = -cos(sub.yaw), rx = cos(sub.yaw), rz = sin(sub.yaw);
      const sonarRange = 95.0;
      let sx = (mdx * rx + mdz * rz) / sonarRange;
      let sy = (mdx * fx + mdz * fz) / sonarRange;
      const sl = hypot(sx, sy);
      if (sl > 0.86) { sx *= 0.86 / sl; sy *= 0.86 / sl; }

      const subSpd = hypot(sub.vx, sub.vy, sub.vz);
      const cs = cockpitScale();
      const O = interiorOrigin(sq, cs);
      cockpitData[0] = O[0]; cockpitData[1] = O[1]; cockpitData[2] = O[2];
      state.doorS = mix(state.doorS || 0, state.doorOpen ? 1 : 0, 0.08);
      cockpitData[3] = cs;
      placeCabinCrew(cockpitData[0], cockpitData[1], cockpitData[2], sq, cs);
      cockpitData[4] = sq[0]; cockpitData[5] = sq[1]; cockpitData[6] = sq[2]; cockpitData[7] = sq[3];
      cockpitData[8] = sub.wheelAngle;
      cockpitData[9] = sub.throttleLev;
      cockpitData[10] = sub.diveLev;
      cockpitData[11] = sub.pendulum;
      cockpitData[12] = clamp(-sub.y / 54.0, 0, 1);         // Live Depth needle (0..54m)
      cockpitData[13] = clamp(subSpd / 24.0, 0, 1);         // Live Speed/Knot needle
      cockpitData[14] = sub.yaw;                            // Live Gimbaled Compass heading
      cockpitData[15] = sub.lightSmooth;                    // Searchlight jewel status
      cockpitData[16] = crewTotal;                          // 1..6 crew bulbs & Tempat Helm stowed helmets!
      cockpitData[17] = sx;                                 // 10x Manta Sonar X
      cockpitData[18] = sy;                                 // 10x Manta Sonar Y
      cockpitData[19] = state.doorS || 0;                   // inner airlock door swing
    } else {
      cockpitData[3] = 0.0;
    }

    // 3. Pack Submarine Twin Volumetric Searchlight Beams (scaled cleanly with miniMode!)
    const beamQ = orientQuat(sub.yaw, sub.pitch - 0.04, totRoll);
    for (let s = 0; s < 2; s++) {
      const sx = (s === 0 ? -0.56 : 0.56) * sub.scale;
      const lp = qRot(sq, sx, -0.34 * sub.scale, -2.02 * sub.scale);
      const o = s * 12;
      beamData[o] = sub.x + lp[0];
      beamData[o + 1] = sub.y + lp[1];
      beamData[o + 2] = sub.z + lp[2];
      beamData[o + 3] = (state.inSub ? 30.0 : 16.0) * mix(sc, 1.0, 0.55);
      beamData[o + 4] = beamQ[0]; beamData[o + 5] = beamQ[1]; beamData[o + 6] = beamQ[2]; beamData[o + 7] = beamQ[3];
      beamData[o + 8] = 0.11 * sub.scale;
      beamData[o + 9] = (state.inSub ? 4.6 : 2.6) * mix(sc, 1.0, 0.5);
      beamData[o + 10] = sub.lightSmooth * (inCockpit ? 0.65 : state.inSub ? 1.05 : 0.72);
      beamData[o + 11] = 0.0;
    }

    // 4. Pack 6 Divers + 6 1.4x Helmet Headlamp Beams
    for (let i = 0; i < N_DIVERS; i++) {
      const d = divers[i];
      const o = i * 28;
      const dq = diverQuat(d.yaw, d.bodyTilt, d.roll + (d.trick || 0));
      const pivOff = qRot(dq, 0, -0.48 * d.scale, 0);
      const vis = i === 0
        ? (state.inSub ? (inCockpit && state.viewMode !== 2 ? 1 : 0) : (state.viewMode !== 2 ? 1 : 0))
        : ((!d.aboard) || (d.aboard && inCockpit) ? 1 : 0);

      diverData[o] = d.x + pivOff[0];
      diverData[o + 1] = d.y + pivOff[1];
      diverData[o + 2] = d.z + pivOff[2];
      diverData[o + 3] = d.scale;
      diverData[o + 4] = dq[0]; diverData[o + 5] = dq[1]; diverData[o + 6] = dq[2]; diverData[o + 7] = dq[3];
      diverData[o + 8] = d.suit[0]; diverData[o + 9] = d.suit[1]; diverData[o + 10] = d.suit[2]; diverData[o + 11] = d.phase;
      diverData[o + 12] = d.swimBlend; diverData[o + 13] = d.moveAmp; diverData[o + 14] = d.headYaw; diverData[o + 15] = d.headPitch;
      diverData[o + 16] = d.waveAmt; diverData[o + 17] = d.badge; diverData[o + 18] = sub.lightSmooth; diverData[o + 19] = vis;
      diverData[o + 20] = spears[i].recoil;
      diverData[o + 21] = d.aimPitch;
      diverData[o + 22] = spears[i].phase !== 'ready' ? 1 : 0;
      diverData[o + 23] = d.aimBlend;
      const wantHol = (d.waveAmt > 0.05 || (d.aboard && d.aimBlend < 0.3) || (i === 0 && state.inSub) || d.sit > 0.1 || d.lie) && d.aimBlend < 0.5 && spears[i].phase === 'ready' ? 1 : 0;
      d.hol = (d.hol || 0) + (wantHol - (d.hol || 0)) * 0.14;
      const helmetOn = d.aboard || (i === 0 && state.inSub) ? 0 : 1;
      const steerCode = (i === 0 && state.inSub && state.inside === 'pilot') ? (10.0 + sub.wheelAngle) : 0;
      diverData[o + 24] = d.hol;
      diverData[o + 25] = d.sit || 0;
      diverData[o + 26] = helmetOn;
      diverData[o + 27] = steerCode;

      const bo = (2 + i) * 12;
      if (!d.aboard && sub.lightSmooth > 0.02 && !(i === 0 && state.viewMode === 2)) {
        const hq = qMul(dq, qMul(qAxis(0, 1, 0, d.headYaw), qAxis(1, 0, 0, d.headPitch)));
        const lampPos = qRot(dq, 0, 1.09 * d.scale, -0.095 * d.scale);
        beamData[bo] = diverData[o] + lampPos[0];
        beamData[bo + 1] = diverData[o + 1] + lampPos[1];
        beamData[bo + 2] = diverData[o + 2] + lampPos[2];
        const mn = state.midnightMode ? 1 : 0;
        beamData[bo + 3] = (i === 0 ? mix(3.2, 9.5, mn) : mix(2.3, 7.5, mn)) * mix(sc, 1.0, 0.4);
        beamData[bo + 4] = hq[0]; beamData[bo + 5] = hq[1]; beamData[bo + 6] = hq[2]; beamData[bo + 7] = hq[3];
        beamData[bo + 8] = 0.024 * d.scale;
        beamData[bo + 9] = (i === 0 ? 0.62 : 0.44) * mix(sc, 1.0, 0.4) * (1 + mn * 1.6);
        beamData[bo + 10] = sub.lightSmooth * (i === 0 ? 0.62 : 0.42) * (1 + mn * 0.25);
        beamData[bo + 11] = 0.35;
      } else {
        beamData[bo + 10] = 0;
      }
    }
    buildSegments(time);
  }

  // ================================================================ SUBMARINE LIFE: hull, airlock, free-walk & helm
  const ZERO_INP = { dyaw: 0, dpitch: 0, mf: 0, mr: 0, mu: 0, boost: false };
  Object.assign(state, {
    hull: 100, inside: 'pilot', proc: null, fade: 0, crewBoarding: false, repairing: false,
    walk: { x: 0, z: 3.2, yaw: 0, fy: CAB.FLOOR, vx: 0, vz: 0, move: 0, phase: 0, pose: 'stand' },
    walkPitch: 0, interactTarget: null, doorOpen: false, hatchDist: 99,
  });
  const dents = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];
  let impactCool = 0;
  function addDent(lx, ly, lz, depth) {
    let k = dents.findIndex((d) => d[3] > 0 && hypot(d[0] - lx, d[1] - ly, d[2] - lz) < 0.35);
    if (k < 0) { k = 0; for (let j = 1; j < 4; j++) if (dents[j][3] < dents[k][3]) k = j; dents[k][0] = lx; dents[k][1] = ly; dents[k][2] = lz; dents[k][3] = 0; }
    dents[k][3] = min(0.17, dents[k][3] + depth);
  }
  function damageHull(amount, lx, ly, lz) {
    const before = state.hull;
    state.hull = max(0, state.hull - amount);
    addDent(lx, ly, lz, 0.012 + amount * 0.005);
    state.shake = max(state.shake || 0, min(1, 0.2 + amount / 25));
    audioHooks.onHatch?.(false);
    if (state.hull <= 0 && before > 0) emitToast('LAMBUNG RUSAK BERAT! Mesin tinggal 30% — perbaiki di panel buritan');
    else if (before > 30 && state.hull <= 30) emitToast('ALARM: lambung kritis ' + state.hull.toFixed(0) + '% — segera perbaiki!');
    else emitToast(`Tabrakan! Lambung -${amount.toFixed(0)}% · tersisa ${state.hull.toFixed(0)}%`);
  }
  function processHullImpact(dt) {
    impactCool -= dt;
    const v = sub.impact || 0;
    if (v > 1.3 && impactCool <= 0 && sub.impLocal) {
      const amt = (v - 1.3) * 6.5;
      if (amt > 1) {
        damageHull(amt, sub.impLocal[0], sub.impLocal[1], sub.impLocal[2]);
        const w = qRot(sub.q, sub.impLocal[0] * sub.scale, sub.impLocal[1] * sub.scale, sub.impLocal[2] * sub.scale);
        burstBubbles(sub.x + w[0], sub.y + w[1], sub.z + w[2], 30, 0.02, 0.1, 0.8);
        impactCool = 0.7;
      }
    }
    sub.impact = 0;
  }

  // Interior mesh origin, fixed inside the hull near the bow
  function interiorOrigin(sq, cs) {
    const e = qRot(sq, 0, 0.14 * sub.scale, -1.72 * sub.scale), o = qRot(sq, 0, 0, 0.3 * cs);
    return [sub.x + e[0] - o[0], sub.y + e[1] - o[1], sub.z + e[2] - o[2]];
  }
  const floorAt = (z) => (z < 0.16 ? -0.48 : CAB.FLOOR);
  const OBST = [
    [-0.14, 0.14, CAB.MESS - 0.21, CAB.MESS + 0.21], [0.21, 0.5, 2.66, 3.27], [-0.5, -0.21, 2.66, 3.27],
    [-0.52, -0.29, 2.24, 2.66], [0.29, 0.52, 2.24, 2.66], // Tempat Helm Scuba racks on port & starboard
    [-0.52, -0.25, 0.87, 1.23], [0.23, 0.5, 0.72, 1.0],
    [-0.5, -0.27, 1.575, 1.625], [0.27, 0.5, 1.575, 1.625], [-0.5, 0.5, -0.7, -0.31], [0.37, 0.5, 3.18, 3.42],
  ];
  function blocked(x, z) {
    const r = 0.07;
    if (z < -0.245 || z > 3.34) return true;
    if (Math.abs(x) > (z < 0.16 ? 0.42 : 0.46)) return true;
    for (const o of OBST) if (x > o[0] - r && x < o[1] + r && z > o[2] - r && z < o[3] + r) return true;
    return false;
  }
  const SEATS = [
    { kind: 'helm', x: PILOT_X, z: PILOT_Z, r: 0.34, label: 'Pegang kemudi kapal selam (berdiri dekat kemudi)' },
    { kind: 'rack', x: 0, z: 2.47, r: 0.26, label: 'Lihat Tempat Helm Scuba (helm 1.4x kru)' },
    { kind: 'door', x: 0, z: 3.3, r: 0.22, label: 'Keluar lewat airlock (pakai helm kembali)' },
    { kind: 'repair', x: 0.33, z: 3.28, r: 0.16, label: 'Perbaiki lambung (panel las & pompa)' },
    { kind: 'lie', x: 0.33, z: 2.95, r: 0.24, label: 'Berbaring di ranjang', fy: CAB.FLOOR + 0.17, yaw: PI },
    { kind: 'lie', x: -0.33, z: 2.95, r: 0.24, label: 'Berbaring di ranjang', fy: CAB.FLOOR + 0.17, yaw: PI },
    { kind: 'sit', x: -0.24, z: CAB.MESS - 0.1, r: 0.13, label: 'Duduk di kursi meja makan', fy: CAB.FLOOR, yaw: PI / 2 },
    { kind: 'sit', x: -0.24, z: CAB.MESS + 0.1, r: 0.13, label: 'Duduk di kursi meja makan', fy: CAB.FLOOR, yaw: PI / 2 },
    { kind: 'sit', x: 0.24, z: CAB.MESS - 0.1, r: 0.13, label: 'Duduk di kursi meja makan', fy: CAB.FLOOR, yaw: -PI / 2 },
    { kind: 'sit', x: 0.24, z: CAB.MESS + 0.1, r: 0.13, label: 'Duduk di kursi meja makan', fy: CAB.FLOOR, yaw: -PI / 2 },
    { kind: 'sit', x: -0.36, z: 1.05, r: 0.2, label: 'Duduk di bangku dekat jendela', fy: CAB.FLOOR, yaw: PI / 2 },
  ];
  function stepWalk(dt, inp) {
    const w = state.walk;
    if (w.pose === 'stand') {
      const f0 = sin(w.yaw), f1 = -cos(w.yaw), r0 = cos(w.yaw), r1 = sin(w.yaw);
      const sp = inp.boost ? 0.7 : 0.4;
      const tx = (f0 * inp.mf + r0 * inp.mr) * sp, tz = (f1 * inp.mf + r1 * inp.mr) * sp;
      w.vx += (tx - w.vx) * (1 - exp(-dt * 7)); w.vz += (tz - w.vz) * (1 - exp(-dt * 7));
      const nx = w.x + w.vx * dt; if (!blocked(nx, w.z)) w.x = nx; else w.vx = 0;
      const nz = w.z + w.vz * dt; if (!blocked(w.x, nz)) w.z = nz; else w.vz = 0;
      w.move = clamp(hypot(w.vx, w.vz) / 0.4, 0, 1.5);
      w.phase = (w.phase + dt * (1 + w.move * 6)) % TAU;
      w.fy = mix(w.fy, floorAt(w.z), 1 - exp(-dt * 10));
      if (state.repairing && hypot(w.x - 0.33, w.z - 3.28) > 0.3) { state.repairing = false; emitToast('Perbaikan dihentikan'); }
      let best = null, bd = 1e9;
      for (const t of SEATS) { const d = hypot(w.x - t.x, w.z - t.z); if (d < t.r && d < bd) { bd = d; best = t; } }
      state.interactTarget = best;
    } else {
      state.interactTarget = null;
    }
    // player body follows (visible to the crew)
    const pl = divers[0];
    pl.sit = w.pose === 'sit' ? 1 : 0; pl.lie = w.pose === 'lie';
  }
  function interactLabel() {
    if (state.proc) return '';
    if (!state.inSub) {
      if (state.hatchDist <= hatchR()) return 'Masuk lewat palka airlock';
      if (state.nearSub || state.hatchDist < 14) return `Berenang ke palka airlock di atas kapal · ${state.hatchDist.toFixed(1)}m`;
      return '';
    }
    if (state.inside === 'pilot') return 'Lepas kemudi (jalan bebas)';
    const w = state.walk;
    if (w.pose !== 'stand') return w.pose === 'lie' ? 'Bangun dari ranjang' : 'Berdiri';
    if (state.repairing) return 'Sedang memperbaiki lambung… (menjauh untuk berhenti)';
    return state.interactTarget ? state.interactTarget.label : '';
  }
  function hatchPos() { const h = qRot(sub.q, 0, 1.32 * sub.scale, -0.1 * sub.scale); return [sub.x + h[0], sub.y + h[1], sub.z + h[2]]; }
  function hatchR() { return max(2.3, 0.62 * sub.scale); }

  const ENTER_STEPS = [['Membuka palka luar', 1.4], ['Masuk ke ruang airlock', 1.3], ['Menutup & mengunci palka luar', 1.0], ['Memompa air keluar dari airlock', 3.0], ['Melepas helm scuba ke Tempat Helm · 1 ATM', 1.6], ['Membuka palka dalam', 1.4]];
  const EXIT_STEPS = [['Mengambil helm scuba 1.4x dari Tempat Helm', 1.2], ['Masuk airlock · mengunci palka dalam', 1.0], ['Membanjiri ruang airlock', 2.6], ['Menyamakan tekanan laut', 1.3], ['Membuka palka luar', 1.3]];
  function startProc(kind) {
    state.proc = { kind, idx: 0, t: 0, steps: kind === 'enter' ? ENTER_STEPS : EXIT_STEPS, sx: divers[0].x, sy: divers[0].y, sz: divers[0].z };
    if (kind === 'enter') { state.crewBoarding = true; for (let i = 1; i < N_DIVERS; i++) divers[i].boardTimer = 0; sub.hatchTimer = 4; }
    else { state.doorOpen = true; state.repairing = false; }
    audioHooks.onSwitch?.(true);
    emitToast(kind === 'enter' ? 'Prosedur airlock dimulai…' : 'Prosedur keluar kapal dimulai…');
  }
  function stepProcedure(dt, time) {
    const P = state.proc;
    if (!P) { state.fade = max(0, (state.fade || 0) - dt * 1.5); return; }
    P.t += dt;
    const pl = divers[0];
    const [stepName, dur] = P.steps[P.idx];
    const u = clamp(P.t / dur, 0, 1);
    if (P.kind === 'enter') {
      const h = hatchPos(), up = qRot(sub.q, 0, 1, 0);
      if (P.idx === 0) { sub.hatchTimer = max(sub.hatchTimer, 3); const e = u * u * (3 - 2 * u); pl.x = mix(P.sx, h[0] + up[0] * 0.5, e); pl.y = mix(P.sy, h[1] + up[1] * 0.5, e); pl.z = mix(P.sz, h[2] + up[2] * 0.5, e); pl.vx = pl.vy = pl.vz = 0; pl.bodyTilt = mix(pl.bodyTilt, 1.4, 0.05); }
      if (P.idx === 1) { pl.x = h[0] + up[0] * mix(0.5, -0.9, u); pl.y = h[1] + up[1] * mix(0.5, -0.9, u); pl.z = h[2] + up[2] * mix(0.5, -0.9, u); state.fade = u; }
      if (P.idx >= 2 && P.idx <= 4) { state.fade = 1; if (P.idx === 3 && ernd() < dt * 4) audioHooks.onSonar?.(); }
      if (P.idx === 5) {
        if (!state.inSub) doBoard(time);
        state.fade = 1 - u; state.doorOpen = u < 0.8;
      }
    } else {
      if (P.idx === 0) state.doorOpen = true;
      if (P.idx === 1) state.fade = u;
      if (P.idx === 2 || P.idx === 3) state.fade = 1;
      if (P.idx === 4) { if (state.inSub) doDisembark(); state.fade = 1 - u; }
    }
    if (P.t >= dur) {
      P.idx++; P.t = 0;
      if (P.idx >= P.steps.length) {
        state.proc = null; state.doorOpen = false; state.crewBoarding = false;
        emitToast(P.kind === 'enter'
          ? 'Di dalam kapal · Helm ditaruh di Tempat Helm depanmu · Jalan ke kemudi & tekan F'
          : 'Di luar kapal · Helm scuba 1.4x terpasang kembali');
      } else if (stepName) audioHooks.onSwitch?.(true);
    }
  }
  function doBoard(curTime) {
    const pl = divers[0];
    state.inSub = true; state.inside = 'walk';
    if (state.viewMode !== 2) state.viewMode = 0; // Kabin 3rd Person by default so you see your bare head & Tempat Helm!
    sub.summonActive = false;
    pl.aboard = true; pl.vx = pl.vy = pl.vz = 0;
    Object.assign(state.walk, { x: 0, z: 3.12, yaw: 0, fy: CAB.FLOOR, vx: 0, vz: 0, pose: 'stand' });
    state.cabCamX = undefined;
    state.walkPitch = 0.04;
    state.camYaw = sub.yaw; state.camPitch = 0.04; state.cockpitYaw = 0; state.cockpitPitch = 0.05;
    const first = !state.firstBoardDone; state.firstBoardDone = true;
    triggerGiantMantaFlyby(first, curTime);
    audioHooks.onHatch?.(true);
  }
  function doDisembark() {
    const pl = divers[0];
    state.inSub = false; state.inside = 'pilot'; state.repairing = false;
    if (state.viewMode === 3) state.viewMode = 0;
    sub.hatchTimer = 3;
    sub.vx *= 0.2; sub.vy *= 0.2; sub.vz *= 0.2;
    const h = hatchPos(), up = qRot(sub.q, 0, 1, 0);
    const ep = findClearSpot(h[0] + up[0] * 0.7, h[1] + up[1] * 0.7, h[2] + up[2] * 0.7, 0.26 * state.scaleMul);
    pl.x = ep[0]; pl.y = ep[1]; pl.z = ep[2]; pl.vx = 0; pl.vy = 0.6; pl.vz = 0;
    pl.yaw = sub.yaw; pl.aboard = false; pl.swimBlend = 1; pl.sit = 0; pl.lie = false;
    state.camYaw = sub.yaw; state.camPitch = -0.15;
    for (let i = 1; i < N_DIVERS; i++) if (divers[i].aboard) divers[i].exitDelay = 0.5 + 0.3 * i;
    burstBubbles(h[0], h[1], h[2], 30, 0.025, 0.12, 0.4);
    audioHooks.onHatch?.(false);
  }
  function interact(time = 0) {
    void time;
    if (state.proc) return false;
    if (!state.inSub) {
      if (state.hatchDist <= hatchR()) { startProc('enter'); return true; }
      if (state.nearSub || state.hatchDist < 14) { emitToast('Berenang ke palka airlock di atas kapal selam, lalu tekan F'); return true; }
      return false;
    }
    const w = state.walk;
    if (state.inside === 'pilot') {
      state.inside = 'walk';
      // Remain standing right near the helm wheel when releasing controls!
      Object.assign(w, { x: PILOT_X, z: PILOT_Z + 0.05, yaw: 0, fy: PILOT_FY, vx: 0, vz: 0, pose: 'stand' });
      if (state.viewMode === 1 || state.viewMode === 3) state.viewMode = 0;
      state.walkPitch = clamp(state.cockpitPitch, -0.45, 0.45);
      emitToast('Melepas kemudi · mode jalan bebas di dalam kapal selam');
      return true;
    }
    if (w.pose !== 'stand') { w.pose = 'stand'; if (w.standX !== undefined) { w.x = w.standX; w.z = w.standZ; } w.fy = floorAt(w.z); return true; }
    const t = state.interactTarget;
    if (!t) return false;
    if (t.kind === 'helm') {
      // Keep the camera mode identical to BEFORE interacting (no forced switch to POV!),
      // while K / POV button remains available anytime as an option during steering!
      state.inside = 'pilot';
      const wy = wrapAngle(w.yaw);
      state.cockpitYaw = abs(wy) < 0.85 ? wy : 0;
      state.cockpitPitch = clamp(state.walkPitch, -0.35, 0.35);
      emitToast('Mengemudi · Kamera tetap (tekan K untuk opsi kamera POV, V ganti kamera, F lepas kemudi)');
    } else if (t.kind === 'rack') {
      emitToast(`Tempat Helm Scuba (1.4x): ${1 + state.botsAboard}/6 helm kru tersimpan rapi di rak!`);
    } else if (t.kind === 'door') startProc('exit');
    else if (t.kind === 'repair') {
      if (state.hull >= 100) emitToast('Lambung masih utuh 100%');
      else { state.repairing = true; emitToast('Memperbaiki lambung… tetap di dekat panel'); }
    } else {
      w.standX = w.x; w.standZ = w.z;
      w.pose = t.kind; w.x = t.x; w.z = t.z; w.fy = t.fy; w.yaw = t.yaw; state.walkPitch = t.kind === 'lie' ? 0 : -0.1;
      emitToast(t.kind === 'lie' ? 'Berbaring sejenak… (F untuk bangun)' : 'Duduk santai (F untuk berdiri)');
    }
    return true;
  }

  // ================================================================ MEGALODON (night only)
  const megaData = new Float32Array(16);
  const mega = {
    active: false, phase: 'idle', beh: 'pass', x: 0, y: -30, z: 0, yaw: 0, pitch: 0, roll: 0, speed: 0,
    swim: 0, amp: 0.6, jaw: 0, jawT: 0, timer: 0, wx: 0, wy: 0, wz: 0, ex: 0, ey: 0, ez: 0, obsAng: 0,
    scale: 26, warned: false, nextAuto: 70, yawRate: 0, dist: 999,
  };
  function megaAnchor() { return state.inSub ? [sub.x, sub.y, sub.z] : [divers[0].x, divers[0].y, divers[0].z]; }
  function planMega() {
    const A = megaAnchor();
    const dx = A[0] - mega.x, dz = A[2] - mega.z, d = hypot(dx, dz) || 1;
    const sx = -dz / d, sz = dx / d, side = ernd() < 0.5 ? -1 : 1;
    if (mega.beh === 'pass') {
      mega.wx = A[0] + sx * side * 9; mega.wy = clamp(A[1] + err(1.5, 4.5), -46, -5); mega.wz = A[2] + sz * side * 9;
      mega.ex = A[0] + dx / d * 70 + sx * side * 14; mega.ey = mega.wy + 4; mega.ez = A[2] + dz / d * 70 + sz * side * 14;
    } else if (mega.beh === 'observe') {
      mega.wx = A[0] - dx / d * 14 + sx * side * 5; mega.wy = clamp(A[1] + 2, -46, -5); mega.wz = A[2] - dz / d * 14 + sz * side * 5;
    } else {
      mega.wx = A[0] - dx / d * 22; mega.wy = clamp(A[1] + 1.5, -46, -5); mega.wz = A[2] - dz / d * 22;
    }
  }
  function spawnMegalodon(auto = false) {
    if (mega.active) { if (!auto) emitToast('Megalodon sudah berkeliaran di dekatmu…'); return false; }
    const A = megaAnchor();
    let best = null;
    for (let k = 0; k < 16 && !best; k++) {
      const ang = state.camYaw + (ernd() < 0.5 ? -1 : 1) * err(0.45, 1.3) + (k > 8 ? PI : 0);
      const r = err(46, 58), x = A[0] + sin(ang) * r, z = A[2] - cos(ang) * r;
      if (hypot(x, z) > 140) continue;
      const y = clamp(A[1] + err(2, 8), -44, -7);
      if (sdAt(x, y, z) < -4 && segClear(x, y, z, A[0], A[1] + 2, A[2], 10)) best = [x, y, z];
    }
    if (!best) { const ang = state.camYaw + PI * 0.7; best = [A[0] + sin(ang) * 45, clamp(A[1] + 10, -40, -6), A[2] - cos(ang) * 45]; }
    mega.active = true; mega.x = best[0]; mega.y = best[1]; mega.z = best[2];
    mega.speed = 3; mega.timer = 0; mega.warned = false; mega.jaw = 0; mega.yawRate = 0;
    mega.yaw = atan2(A[0] - mega.x, -(A[2] - mega.z)); mega.pitch = 0; mega.roll = 0;
    const r = ernd();
    mega.beh = r < 0.36 ? 'pass' : r < (state.inSub ? 0.62 : 0.74) ? 'observe' : 'bump';
    mega.phase = 'approach';
    planMega();
    if (!auto) emitToast('Sesuatu yang sangat besar bergerak di kegelapan…');
    audioHooks.onSonar?.();
    return true;
  }
  function megaLeave() {
    const A = megaAnchor();
    const dx = mega.x - A[0], dz = mega.z - A[2], d = hypot(dx, dz) || 1;
    const sd = ernd() < 0.5 ? -1 : 1;
    mega.ex = A[0] + (dx / d) * 90 + (-dz / d) * sd * 30; mega.ez = A[2] + (dz / d) * 90 + (dx / d) * sd * 30; mega.ey = clamp(mega.y - 4, -46, -6);
    mega.phase = 'leave'; mega.timer = 0;
  }
  function megaImpact(fx, fy, fz) {
    state.shake = 1.0;
    if (state.inSub) {
      sub.vx += fx * 7; sub.vy += fy * 3 + 1.2; sub.vz += fz * 7;
      sub.yawVel = (sub.yawVel || 0) + (ernd() < 0.5 ? -0.7 : 0.7);
      sub.roll += ernd() < 0.5 ? -0.35 : 0.35;
      sub.pitch = clamp(sub.pitch + 0.2, -0.6, 0.6);
      damageHull(16 + ernd() * 8, ernd() < 0.5 ? 0.75 : -0.75, 0.1, -0.5, 0);
      emitToast('BRAKK!! Megalodon menabrak kapal selam!');
    } else {
      const pl = divers[0];
      pl.vx += fx * 3; pl.vy += 1.5; pl.vz += fz * 3;
      emitToast('Megalodon menyambar tepat di depanmu!');
    }
    const A = megaAnchor();
    burstBubbles(mix(mega.x, A[0], 0.6), mix(mega.y, A[1], 0.6), mix(mega.z, A[2], 0.6), 60, 0.02, 0.12, 1.4);
    audioHooks.onLeviathan?.();
  }
  function stepMegalodon(dt, time, isMenu) {
    state.shake = (state.shake || 0) * exp(-dt * 1.3);
    if (!mega.active) {
      megaData[3] = 0; mega.dist = 999;
      if (!isMenu) { mega.nextAuto -= dt; if (mega.nextAuto <= 0) { mega.nextAuto = state.midnightMode ? err(80, 150) : err(150, 260); spawnMegalodon(true); } }
      return;
    }
    const A = megaAnchor();
    const dA = hypot(mega.x - A[0], mega.y - A[1], mega.z - A[2]);
    mega.dist = dA;
    mega.timer += dt;
    let tx = mega.wx, ty = mega.wy, tz = mega.wz, spd = 4.5, faceA = 0;
    if (mega.phase === 'approach') {
      if (mega.beh !== 'pass' && floor(mega.timer * 2) !== floor((mega.timer - dt) * 2)) planMega();
      if (hypot(mega.x - tx, mega.y - ty, mega.z - tz) < 5 || mega.timer > 30) {
        mega.timer = 0;
        if (mega.beh === 'pass') mega.phase = 'pass';
        else if (mega.beh === 'observe') { mega.phase = 'observe'; mega.obsAng = atan2(mega.x - A[0], mega.z - A[2]); }
        else mega.phase = 'charge';
      }
    } else if (mega.phase === 'pass') {
      tx = mega.ex; ty = mega.ey; tz = mega.ez; spd = 5.2;
      if (hypot(mega.x - tx, mega.z - tz) < 8 || mega.timer > 26) { mega.active = false; megaData[3] = 0; return; }
    } else if (mega.phase === 'observe') {
      mega.obsAng += dt * 0.085 * (mega.beh === 'observe' ? 1 : -1);
      tx = A[0] + sin(mega.obsAng) * 13; ty = clamp(A[1] + 1.5, -46, -5); tz = A[2] + cos(mega.obsAng) * 13;
      spd = 1.3; faceA = 0.65;
      if (mega.timer > 3 && mega.jawT <= 0 && ernd() < dt * 0.3) mega.jawT = 1.6;
      if (mega.timer > err(8, 11)) megaLeave();
    } else if (mega.phase === 'charge') {
      tx = A[0]; ty = A[1] + (state.inSub ? 0.3 : 0.2); tz = A[2]; spd = 10.5;
      mega.jawT = max(mega.jawT, 0.4);
      const hitR = state.inSub ? 4.6 * sub.scale * 0.5 + 6.2 : 6.5;
      if (dA < hitR) {
        const cp = cos(mega.pitch);
        megaImpact(cp * sin(mega.yaw), sin(mega.pitch), -cp * cos(mega.yaw));
        mega.yaw += ernd() < 0.5 ? 0.9 : -0.9;
        mega.speed = 5;
        megaLeave();
      } else if (mega.timer > 12) megaLeave();
    } else if (mega.phase === 'leave') {
      tx = mega.ex; ty = mega.ey; tz = mega.ez; spd = 5.8;
      if (dA > 75 || mega.timer > 30) { mega.active = false; megaData[3] = 0; return; }
    }
    {
      // never clip through the submarine / diver: keep a solid body separation
      const minSep = state.inSub ? 4.6 * sub.scale * 0.5 + 5.2 : 4.2;
      if (dA < minSep && dA > 0.01) {
        const k = (minSep - dA) / dA;
        mega.x += (mega.x - A[0]) * k; mega.y += (mega.y - A[1]) * k * 0.5; mega.z += (mega.z - A[2]) * k;
      }
    }
    if (!mega.warned && dA < 42) {
      mega.warned = true;
      emitToast('MEGALODON! Predator raksasa mendekat…');
      audioHooks.onLeviathan?.();
    }
    if (dA < 22) state.shake = max(state.shake, (22 - dA) / 22 * (mega.phase === 'charge' ? 0.35 : 0.12));

    // steering with heavy inertia + rock avoidance
    let dx = tx - mega.x, dy = ty - mega.y, dz = tz - mega.z;
    const dl = hypot(dx, dy, dz) || 1; dx /= dl; dy /= dl; dz /= dl;
    const cp0 = cos(mega.pitch), fx0 = cp0 * sin(mega.yaw), fy0 = sin(mega.pitch), fz0 = -cp0 * cos(mega.yaw);
    const px = mega.x + fx0 * 9, py = mega.y + fy0 * 9, pz = mega.z + fz0 * 9;
    if (sdAt(px, py, pz) > -3.5) { const gg = gradAt(px, py, pz); if (gg) { dx -= gg[0] * 1.3; dy -= gg[1] * 1.3 - 0.7; dz -= gg[2] * 1.3; } }
    let tyaw = atan2(dx, -dz);
    if (faceA > 0) tyaw = tyaw + wrapAngle(atan2(A[0] - mega.x, -(A[2] - mega.z)) - tyaw) * faceA;
    const yd = wrapAngle(tyaw - mega.yaw);
    const wantRate = clamp(yd * 0.9, -0.55, 0.55);
    mega.yawRate += (wantRate - mega.yawRate) * (1 - exp(-dt * 1.4));
    mega.yaw += mega.yawRate * dt;
    mega.pitch = mix(mega.pitch, clamp(atan2(dy, hypot(dx, dz)), -0.4, 0.4), 1 - exp(-dt * 0.9));
    mega.roll = mix(mega.roll, clamp(-mega.yawRate * 0.9, -0.4, 0.4), 1 - exp(-dt * 1.2));
    mega.speed = mix(mega.speed, spd, 1 - exp(-dt * (mega.phase === 'charge' ? 1.4 : 0.6)));
    const cp = cos(mega.pitch);
    mega.x += cp * sin(mega.yaw) * mega.speed * dt;
    mega.y = clamp(mega.y + sin(mega.pitch) * mega.speed * dt, -48, -5);
    mega.z += -cp * cos(mega.yaw) * mega.speed * dt;
    const rr = hypot(mega.x, mega.z); if (rr > 160) { mega.x *= 160 / rr; mega.z *= 160 / rr; }
    mega.swim = (mega.swim + dt * (1.0 + mega.speed * 0.32)) % (TAU * 100);
    mega.amp = mix(mega.amp, 0.5 + 0.35 * clamp(mega.speed / 9, 0, 1) + abs(mega.yawRate) * 0.6, 1 - exp(-dt * 2));
    if (mega.jawT > 0) mega.jawT -= dt;
    const idleJaw = 0.11 + 0.06 * sin(time * 1.85); // natural predatory gill-pumping jaw gape
    mega.jaw = mix(mega.jaw, mega.jawT > 0 ? (mega.phase === 'charge' ? 1.0 : 0.78) : idleJaw, 1 - exp(-dt * 3.2));
    const q = orientQuat(mega.yaw, mega.pitch, mega.roll);
    megaData[0] = mega.x; megaData[1] = mega.y; megaData[2] = mega.z; megaData[3] = mega.scale;
    megaData[4] = q[0]; megaData[5] = q[1]; megaData[6] = q[2]; megaData[7] = q[3];
    megaData[8] = mega.swim; megaData[9] = mega.amp; megaData[10] = mega.jaw; megaData[11] = clamp(mega.yawRate * 2, -1, 1);
    megaData[12] = 1;
  }

  // ================================================================ CREW CABIN STATIONS (inside the cockpit)
  // [x, z, localYaw, floorY]
  const dZc = (CAB.Z1 - CAB.Z0) / CAB.NZ, portZ = (zi) => CAB.Z0 + (zi + 1.5) * dZc;
  // [x, z, localYaw, floorY, pose]
  const CAB_SPOTS = [
    [0.36, -0.08, 0, -0.48, 'stand'], [-0.37, -0.05, 0, -0.48, 'stand'],
    [0.37, portZ(2), PI / 2, CAB.FLOOR, 'stand'], [0.38, portZ(8) + 0.06, PI / 2, CAB.FLOOR, 'stand'],
    [-0.37, portZ(3), -PI / 2, CAB.FLOOR, 'stand'], [-0.37, portZ(9) + 0.06, -PI / 2, CAB.FLOOR, 'stand'],
    [0.06, 1.42, 0, CAB.FLOOR, 'stand'], [-0.36, 1.05, PI / 2, CAB.FLOOR, 'sit'],
    [-0.24, CAB.MESS - 0.1, PI / 2, CAB.FLOOR, 'sit'], [0.24, CAB.MESS + 0.1, -PI / 2, CAB.FLOOR, 'sit'], [0.24, CAB.MESS - 0.1, -PI / 2, CAB.FLOOR, 'sit'],
    [0.33, 2.95, PI, CAB.FLOOR + 0.17, 'lie'], [-0.33, 2.95, PI, CAB.FLOOR + 0.43, 'lie'], [0.4, portZ(16), PI / 2, CAB.FLOOR, 'stand'],
  ];
  const CAB_HOME = [0, 0, 1, 2, 4, 6];
  const cab = divers.map((d, i) => ({ spot: CAB_HOME[i], x: CAB_SPOTS[CAB_HOME[i]][0], z: CAB_SPOTS[CAB_HOME[i]][1], fy: CAB_SPOTS[CAB_HOME[i]][3], ly: 0, act: 'look', t: 2 + i, dry: 0 }));
  function cockpitScale() { return 1.05 * state.scaleMul; }
  function stepCabinCrew(dt, time) {
    const occupied = new Set();
    for (let i = 1; i < N_DIVERS; i++) occupied.add(cab[i].spot);
    // megalodon direction in sub-local space (everyone stares at it)
    let megaLY = null;
    if (mega.active && mega.dist < 48) {
      const v = [mega.x - sub.x, mega.y - sub.y, mega.z - sub.z];
      const iq = [-sub.q[0], -sub.q[1], -sub.q[2], sub.q[3]];
      const l = qRot(iq, v[0], v[1], v[2]);
      megaLY = atan2(l[0], -l[2]);
    }
    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i], c = cab[i];
      if (!b.aboard) continue;
      c.t -= dt;
      if (c.t <= 0) {
        c.t = err(4, 8.5);
        const r = ernd();
        if (r < 0.32) {
          const free = [];
          for (let k = 0; k < CAB_SPOTS.length; k++) if (!occupied.has(k)) free.push(k);
          if (free.length) { occupied.delete(c.spot); c.spot = free[(ernd() * free.length) | 0]; occupied.add(c.spot); }
          c.act = 'look';
        } else c.act = r < 0.58 ? 'wave' : r < 0.8 ? 'aim' : 'look';
        if (c.act === 'wave') b.waveTimer = err(1.6, 2.6);
      }
      const S = CAB_SPOTS[c.spot];
      let gx = S[0], gz = S[1];
      if (abs(S[1] - c.z) > 0.12) { gx = 0; gz = abs(c.x) > 0.1 ? c.z : S[1]; }
      const dx = gx - c.x, dz = gz - c.z, dd = hypot(dx, dz);
      const walking = dd > 0.02;
      if (walking) { const st = min(dd, 0.32 * dt); c.x += dx / dd * st; c.z += dz / dd * st; }
      const arrived = hypot(S[0] - c.x, S[1] - c.z) < 0.03;
      c.pose = arrived ? S[4] : 'stand';
      c.fy = mix(c.fy, arrived ? S[3] : floorAt(c.z), 1 - exp(-dt * 6));
      let wantLY = walking ? atan2(dx, -dz) : S[2];
      let hy = sin(time * 0.6 + i * 1.7) * 0.45, hp = 0.1 + sin(time * 0.43 + i) * 0.12;
      let aim = 0;
      if (!walking) {
        const tgX = state.inside === 'walk' ? state.walk.x : 0, tgZ = state.inside === 'walk' ? state.walk.z : 0.3;
        if (c.act === 'wave' && c.pose === 'stand') wantLY = atan2(tgX - c.x, -(tgZ - c.z));
        if (c.act === 'wave' && hypot(tgX - c.x, tgZ - c.z) < 0.5 && c.pose === 'stand') hy = 0;
        if (c.act === 'aim') { aim = 1; hy = 0; c.dry -= dt; if (c.dry <= 0) { c.dry = err(1.2, 2.4); spears[i].recoil = 0.7; } }
      }
      if (megaLY !== null) { wantLY = megaLY; hy = 0; hp = 0.15; aim = c.act === 'aim' ? 1 : 0; }
      c.ly += wrapAngle(wantLY - c.ly) * (1 - exp(-dt * 4));
      b.aimBlend = mix(b.aimBlend, aim, 1 - exp(-dt * 6));
      b.aimPitch = 0.15 + sin(time * 0.7 + i) * 0.2;
      b.swimBlend = 0; b.moveAmp = mix(b.moveAmp, walking ? 0.8 : 0, 1 - exp(-dt * 6));
      b.phase = (b.phase + (walking ? 6.5 : 1.2) * dt) % TAU;
      b.headYaw = mix(b.headYaw, hy, 1 - exp(-dt * 3)); b.headPitch = mix(b.headPitch, hp, 1 - exp(-dt * 3));
      b.sit = c.pose === 'sit' ? 1 : 0; b.lie = c.pose === 'lie';
      if (b.lie) { b.waveTimer = 0; aim = 0; b.aimBlend = 0; }
      b.bodyTilt = b.lie ? -1.5 : 0.04 + (state.shake || 0) * sin(time * 25 + i) * 0.3;
      b.roll = (state.shake || 0) * sin(time * 21 + i * 2) * 0.25;
      if (b.waveTimer > 0) b.waveTimer = max(0, b.waveTimer - dt);
      b.waveAmt = mix(b.waveAmt, b.waveTimer > 0 ? 1 : 0, 1 - exp(-dt * 8));
      spears[i].recoil = max(0, spears[i].recoil - dt * 3);
    }
  }
  // Place player (divers[0]) & cabin crew (divers[1..5]) in world space around the cockpit transform
  function placeCabinCrew(ox, oy, oz, sq, cs) {
    const up = qRot(sq, 0, 1, 0);
    // Place Captain Ashford (Player, divers[0]) inside the cabin: either walking or standing right near the helm wheel!
    {
      const pl = divers[0];
      if (state.inSub) {
        const isPilot = state.inside === 'pilot';
        const w = state.walk;
        const lx = isPilot ? PILOT_X : w.x;
        const lfy = isPilot ? PILOT_FY : w.fy;
        const lz = isPilot ? PILOT_Z : w.z;
        if (isPilot) {
          pl.sit = 0; pl.lie = false; pl.swimBlend = 0; pl.moveAmp = 0;
          pl.bodyTilt = 0.04; pl.roll = 0;
          pl.headYaw = clamp(-state.cockpitYaw * 0.45, -0.58, 0.58);
          pl.headPitch = clamp(-state.cockpitPitch * 0.35, -0.32, 0.35);
          pl.yaw = sub.yaw;
        } else {
          pl.swimBlend = 0;
          pl.moveAmp = w.pose === 'stand' ? w.move : 0;
          pl.phase = w.phase;
          pl.bodyTilt = pl.lie ? -1.5 : 0.03;
          pl.roll = 0;
          pl.headYaw = 0;
          pl.headPitch = pl.lie ? 0 : clamp(-state.walkPitch * 0.4, -0.35, 0.35);
          pl.yaw = wrapAngle(sub.yaw + w.yaw);
        }
        const f0 = qRot(sq, lx * cs, lfy * cs, lz * cs);
        const hgt0 = pl.lie ? 0.08 * pl.scale : pl.sit ? 0.33 * pl.scale : 0.48 * pl.scale;
        pl.x = ox + f0[0] + up[0] * hgt0;
        pl.y = oy + f0[1] + up[1] * hgt0;
        pl.z = oz + f0[2] + up[2] * hgt0;
      }
    }
    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i], c = cab[i];
      if (!b.aboard) continue;
      const f = qRot(sq, c.x * cs, c.fy * cs, c.z * cs);
      const hgt = b.lie ? 0.08 * b.scale : b.sit ? 0.33 * b.scale : 0.48 * b.scale;
      b.x = ox + f[0] + up[0] * hgt; b.y = oy + f[1] + up[1] * hgt; b.z = oz + f[2] + up[2] * hgt;
      b.yaw = sub.yaw + c.ly;
    }
  }

  // ================================================================ NAME LABELS (screen-space, English names)
  const labelOut = divers.map((d) => ({ name: d.name, x: 0, y: 0, z: 0, show: false, dist: 0 }));
  function getCrewLabels() {
    const inCock = inSubInterior();
    for (let i = 0; i < N_DIVERS; i++) {
      const d = divers[i], o = labelOut[i];
      o.show = !(i === 0 && (state.viewMode === 2 || state.inSub)) && (!d.aboard || (inCock && i > 0));
      const headTop = d.aboard ? 0.48 : 0.72; // bare Dear Flight hair inside sub vs 1.4x scuba helmet outside!
      o.x = d.x; o.y = d.y + headTop * d.scale + 0.06 * mix(state.scaleMul, 1, 0.5); o.z = d.z;
      o.dist = hypot(o.x - state.camX, o.y - state.camY, o.z - state.camZ);
    }
    return labelOut;
  }

  // ---------------------------------------------------------------- 3D harpoon geometry (capsule instances)
  const BRASS = [0.86, 0.6, 0.26], STEEL = [0.7, 0.74, 0.78], WOOD = [0.42, 0.19, 0.08], RUBBER = [0.07, 0.06, 0.055];
  const BAND = [0.62, 0.09, 0.05], ROPE = [0.82, 0.72, 0.5], DARK = [0.16, 0.14, 0.12];
  function seg(a, b, r0, r1, col, pat = 0, gloss = 0.3, met = 0, cap = 1, emi = 0) {
    if (segN >= N_SEG) return;
    const o = segN++ * 16;
    segData[o] = a[0]; segData[o + 1] = a[1]; segData[o + 2] = a[2]; segData[o + 3] = r0;
    segData[o + 4] = b[0]; segData[o + 5] = b[1]; segData[o + 6] = b[2]; segData[o + 7] = r1;
    segData[o + 8] = col[0]; segData[o + 9] = col[1]; segData[o + 10] = col[2]; segData[o + 11] = pat;
    segData[o + 12] = emi; segData[o + 13] = gloss; segData[o + 14] = met; segData[o + 15] = cap;
  }

  // Tether: sags & waves while slack, snaps straight under tension
  function drawRope(ax, ay, az, bx, by, bz, slack, time, r) {
    const n = 16;
    const L = hypot(bx - ax, by - ay, bz - az);
    let px = ax, py = ay, pz = az;
    const dx = (bx - ax) / (L || 1), dz = (bz - az) / (L || 1);
    const sx = -dz, sz = dx;
    for (let k = 1; k <= n; k++) {
      const u = k / n, bell = 4 * u * (1 - u);
      const sag = slack * L * 0.08 * bell;
      const wv = slack * min(L, 6) * 0.025 * sin(u * 9 - time * 6) * bell;
      const x = ax + (bx - ax) * u + sx * wv, y = ay + (by - ay) * u - sag, z = az + (bz - az) * u + sz * wv;
      seg([px, py, pz], [x, y, z], r, r, ROPE, 2, 0.15, 0, 1);
      px = x; py = y; pz = z;
    }
  }

  function drawSpear(tx, ty, tz, dx, dy, dz, len, r) {
    const tail = [tx - dx * len, ty - dy * len, tz - dz * len];
    const neck = [tx - dx * len * 0.1, ty - dy * len * 0.1, tz - dz * len * 0.1];
    seg(tail, neck, r, r, STEEL, 0, 0.85, 1, 1);
    seg(neck, [tx, ty, tz], r * 1.6, 0.0004, STEEL, 0, 0.9, 1, 0);
    // flip barbs
    const ux = abs(dy) < 0.9 ? 0 : 1, uy = abs(dy) < 0.9 ? 1 : 0;
    let px = dy * 0 - dz * uy, py = dz * ux - dx * 0, pz = dx * uy - dy * ux;
    const pl = hypot(px, py, pz) || 1; px /= pl; py /= pl; pz /= pl;
    const bb = [tx - dx * len * 0.2, ty - dy * len * 0.2, tz - dz * len * 0.2];
    for (const sg of [-1, 1]) seg(bb, [bb[0] - dx * len * 0.09 + px * sg * len * 0.05, bb[1] - dy * len * 0.09 + py * sg * len * 0.05, bb[2] - dz * len * 0.09 + pz * sg * len * 0.05], r * 0.7, r * 0.2, STEEL, 0, 0.8, 1, 1);
    // brass ferrule at the tail where the line ties on
    seg(tail, [tail[0] + dx * len * 0.05, tail[1] + dy * len * 0.05, tail[2] + dz * len * 0.05], r * 1.7, r * 1.7, BRASS, 0, 0.7, 1, 0);
    return tail;
  }

  function drawFish(cx, cy, cz, dx, dy, dz, size, kind, time, struggle) {
    // body axis roughly perpendicular to the spear, thrashing
    let ax = -dz, ay = 0.15 * struggle, az = dx;
    const al = hypot(ax, ay, az) || 1; ax /= al; ay /= al; az /= al;
    const w = sin(time * 22) * 0.35 * abs(struggle) + struggle * 0.2;
    ax += dx * w; az += dz * w; const al2 = hypot(ax, ay, az) || 1; ax /= al2; ay /= al2; az /= al2;
    const L = size * 1.06;
    const col = FISH_RGB[kind], pat = FISH_PAT[kind];
    const tailP = [cx - ax * L * 0.42, cy - ay * L * 0.42, cz - az * L * 0.42];
    const head = [cx + ax * L * 0.4, cy + ay * L * 0.4, cz + az * L * 0.4];
    seg(tailP, head, L * 0.07, L * 0.1, col, pat, 0.55, 0, 1);
    const tw = sin(time * 26) * 0.5 * (0.3 + abs(struggle));
    const tEnd = [tailP[0] - ax * L * 0.22 - dx * tw * L * 0.15, tailP[1] - ay * L * 0.22 + L * 0.02, tailP[2] - az * L * 0.22 - dz * tw * L * 0.15];
    seg(tailP, tEnd, L * 0.025, L * 0.1, col, pat === 6 ? 6 : 0, 0.4, 0, 0);
    seg([cx, cy + L * 0.07, cz], [cx - ax * L * 0.18, cy + L * 0.15, cz - az * L * 0.18], L * 0.03, L * 0.008, col, 0, 0.3, 0, 1);
    // eyes
    seg([head[0] - ax * L * 0.06, head[1] + L * 0.025, head[2] - az * L * 0.06], [head[0] - ax * L * 0.055, head[1] + L * 0.026, head[2] - az * L * 0.055], L * 0.022, L * 0.022, [0.02, 0.02, 0.02], 0, 1, 0, 1);
  }

  // First-person brass & mahogany harpoon gun held in both mittens
  function drawViewmodel(time) {
    const b = camBasis();
    const pl = divers[0];
    const kick = vm.kick;
    const shake = harpoon.phase === 'reeling' || harpoon.phase === 'tethered' ? 0.0025 : 0;
    const ox = state.camX + b.rx * (0.115 + vm.swayX) + b.ux * (-0.118 + vm.bob + vm.swayY) + b.fx * (0.07 - kick * 0.05);
    const oy = state.camY + b.uy * (-0.118 + vm.bob + vm.swayY) + b.fy * (0.07 - kick * 0.05) + sin(time * 41) * shake;
    const oz = state.camZ + b.rz * (0.115 + vm.swayX) + b.uz * (-0.118 + vm.bob + vm.swayY) + b.fz * (0.07 - kick * 0.05);
    // converge on the reticle ~9 m ahead, kick pitches the muzzle up
    let Ax = state.camX + b.fx * 9 - ox + b.ux * kick * 1.6, Ay = state.camY + b.fy * 9 - oy + b.uy * kick * 1.6, Az = state.camZ + b.fz * 9 - oz + b.uz * kick * 1.6;
    const Al = hypot(Ax, Ay, Az); Ax /= Al; Ay /= Al; Az /= Al;
    let Sx = b.rx - Ax * (b.rx * Ax + b.rz * Az), Sy = -Ay * (b.rx * Ax + b.rz * Az), Sz = b.rz - Az * (b.rx * Ax + b.rz * Az);
    const Sl = hypot(Sx, Sy, Sz) || 1; Sx /= Sl; Sy /= Sl; Sz /= Sl;
    const Wx = Sy * Az - Sz * Ay, Wy = Sz * Ax - Sx * Az, Wz = Sx * Ay - Sy * Ax;
    const P = (a, sd, w) => [ox + Ax * a + Sx * sd + Wx * w, oy + Ay * a + Sy * sd + Wy * w, oz + Az * a + Sz * sd + Wz * w];
    const suit = pl.suit;

    // forearms & mittens (canvas sleeves, rubber gloves, brass cuffs)
    seg(P(-0.13, 0.11, -0.2), P(0.055, 0.012, -0.06), 0.042, 0.03, suit, 0, 0.15, 0, 1);
    seg(P(0.05, 0.014, -0.058), P(0.066, 0.012, -0.05), 0.033, 0.033, BRASS, 0, 0.7, 1, 0);
    seg(P(0.068, 0.014, -0.05), P(0.098, 0.006, -0.068), 0.024, 0.021, RUBBER, 0, 0.35, 0, 1);
    seg(P(0.1, -0.016, -0.03), P(0.125, -0.014, -0.004), 0.008, 0.007, RUBBER, 0, 0.35, 0, 1);
    seg(P(0.16, -0.2, -0.22), P(0.305, -0.018, -0.032), 0.044, 0.028, suit, 0, 0.15, 0, 1);
    seg(P(0.295, -0.02, -0.034), P(0.312, -0.016, -0.03), 0.03, 0.03, BRASS, 0, 0.7, 1, 0);
    seg(P(0.31, -0.012, -0.03), P(0.345, 0.0, -0.022), 0.022, 0.02, RUBBER, 0, 0.35, 0, 1);

    // mahogany stock, rubber butt pad, pistol grip, trigger & guard
    seg(P(-0.01, 0, 0), P(0, 0, 0.001), 0.024, 0.024, RUBBER, 0, 0.2, 0, 0);
    seg(P(0, 0, 0.001), P(0.14, 0, 0.004), 0.022, 0.025, WOOD, 1, 0.45, 0, 0.3);
    seg(P(0.105, 0, -0.004), P(0.082, 0, -0.088), 0.0135, 0.016, WOOD, 1, 0.45, 0, 1);
    seg(P(0.128, 0, -0.018), P(0.121, 0, -0.04), 0.0032, 0.0028, STEEL, 0, 0.8, 1, 1);
    seg(P(0.108, 0, -0.052), P(0.152, 0, -0.047), 0.0034, 0.0034, BRASS, 0, 0.7, 1, 1);
    seg(P(0.152, 0, -0.047), P(0.157, 0, -0.012), 0.0034, 0.0034, BRASS, 0, 0.7, 1, 1);

    // brass barrel with rings & muzzle head
    seg(P(0.14, 0, 0.004), P(0.5, 0, 0.004), 0.0135, 0.0125, BRASS, 0, 0.78, 1, 0);
    seg(P(0.205, 0, 0.004), P(0.218, 0, 0.004), 0.0172, 0.0172, BRASS, 8, 0.7, 1, 0);
    seg(P(0.37, 0, 0.004), P(0.381, 0, 0.004), 0.0162, 0.0162, BRASS, 8, 0.7, 1, 0);
    seg(P(0.49, 0, 0.004), P(0.53, 0, 0.004), 0.021, 0.018, BRASS, 0, 0.75, 1, 0);
    seg(P(0.515, -0.034, 0.008), P(0.515, 0.034, 0.008), 0.0058, 0.0058, DARK, 0, 0.5, 1, 1);
    // glowing front sight bead & rear sight
    seg(P(0.505, 0, 0.018), P(0.505, 0, 0.027), 0.0026, 0.0022, [1, 0.75, 0.35], 0, 0.6, 0, 1, 1.4);
    seg(P(0.15, -0.007, 0.024), P(0.15, 0.007, 0.024), 0.0028, 0.0028, BRASS, 0, 0.6, 1, 1);

    const loaded = harpoon.phase === 'ready';
    // power bands: stretched to the notch when loaded, snapped forward & slack when fired
    const snap = loaded ? 0 : 1;
    for (const sd of [-1, 1]) {
      const anchor = P(0.515, sd * 0.03, 0.008);
      const notch = loaded ? P(0.27 - kick * 0.02, sd * 0.006, 0.022) : P(0.465 + sin(time * 30) * 0.004 * vm.kick, sd * 0.024, 0.016 - snap * 0.006);
      seg(anchor, notch, 0.0048, 0.0042, BAND, 0, 0.45, 0, 1);
    }
    if (loaded) {
      seg(P(0.27, -0.006, 0.022), P(0.27, 0.006, 0.022), 0.0034, 0.0034, STEEL, 0, 0.7, 1, 1);
      const a0 = P(0.1, 0, 0.022), tip = P(0.715, 0, 0.022);
      seg(a0, P(0.66, 0, 0.022), 0.0042, 0.0042, STEEL, 0, 0.88, 1, 1);
      seg(P(0.66, 0, 0.022), tip, 0.0068, 0.0003, STEEL, 0, 0.9, 1, 0);
      for (const sd of [-1, 1]) seg(P(0.63, 0, 0.022), P(0.598, sd * 0.012, 0.022), 0.0022, 0.0007, STEEL, 0, 0.8, 1, 1);
    }

    // line reel under the barrel with a spinning crank
    const rc = P(0.2, 0, -0.034);
    seg(P(0.2, -0.023, -0.034), P(0.2, 0.023, -0.034), 0.024, 0.024, BRASS, 0, 0.7, 1, 0);
    seg(P(0.2, -0.019, -0.034), P(0.2, 0.019, -0.034), 0.0255, 0.0255, ROPE, 2, 0.2, 0, 0);
    const th = vm.reelSpin;
    for (let k = 0; k < 3; k++) {
      const a = th + k * 2.094;
      seg(P(0.2, 0.025, -0.034), P(0.2 + cos(a) * 0.02, 0.025, -0.034 + sin(a) * 0.02), 0.0024, 0.0024, DARK, 0, 0.5, 1, 1);
    }
    seg(P(0.2 + cos(th) * 0.02, 0.025, -0.034 + sin(th) * 0.02), P(0.2 + cos(th) * 0.02, 0.04, -0.034 + sin(th) * 0.02), 0.0045, 0.0045, WOOD, 1, 0.4, 0, 1);
    // line running from the reel to the muzzle
    seg(P(0.2, 0, -0.01), P(0.5, 0, 0.0), 0.0016, 0.0016, ROPE, 2, 0.2, 0, 1);

    const mz = P(0.53, 0, 0.022);
    vm.mx = mz[0]; vm.my = mz[1]; vm.mz = mz[2];
    void rc;
  }

  // Captain's own natural-length arms & mittens gripping the helm wheel in POV Kemudi mode!
  // Since the captain now stands right near the wheel (z = -0.23, wheel at z = -0.315),
  // shoulder-to-hand distance is ~0.104 units — 100% matching the diver's actual real arm length!
  function drawPilotArms() {
    const cs = cockpitData[3], O = [cockpitData[0], cockpitData[1], cockpitData[2]], q = sub.q;
    const L = (x, y, z) => { const w = qRot(q, x * cs, y * cs, z * cs); return [O[0] + w[0], O[1] + w[1], O[2] + w[2]]; };
    const a = clamp(sub.wheelAngle, -1.25, 1.25), R0 = 0.096, suit = divers[0].suit;
    for (const sd of [-1, 1]) {
      const ph = sd < 0 ? 2.60 : 0.54;
      const hx = R0 * cos(ph), hy = R0 * sin(ph);
      const hand = [hx * cos(a) - hy * sin(a), -0.315 + hx * sin(a) + hy * cos(a), -0.315 + 0.010];
      // Actual standing diver shoulder position at PILOT_Z = -0.23 (y = -0.48 + 0.545 * 0.495 = -0.210)
      const sh = [sd * 0.076, -0.212, -0.218];
      const el = [(sh[0] + hand[0]) * 0.5 + sd * 0.024, (sh[1] + hand[1]) * 0.5 - 0.022, (sh[2] + hand[2]) * 0.5 + 0.012];
      const wr = [hand[0] + (el[0] - hand[0]) * 0.25, hand[1] + (el[1] - hand[1]) * 0.25, hand[2] + (el[2] - hand[2]) * 0.25];
      seg(L(...sh), L(...el), 0.021 * cs, 0.018 * cs, suit, 0, 0.15, 0, 1);
      seg(L(...el), L(...wr), 0.018 * cs, 0.016 * cs, suit, 0, 0.15, 0, 1);
      seg(L(...wr), L(wr[0] + (hand[0] - wr[0]) * 0.24, wr[1] + (hand[1] - wr[1]) * 0.24, wr[2] + (hand[2] - wr[2]) * 0.24), 0.0175 * cs, 0.0175 * cs, BRASS, 0, 0.7, 1, 0);
      seg(L(...wr), L(hand[0], hand[1], hand[2] + 0.004), 0.0145 * cs, 0.016 * cs, RUBBER, 0, 0.35, 0, 1);
      // thumb wrapped over the rim
      seg(L(hand[0], hand[1], hand[2] + 0.007), L(hand[0] * 0.91, hand[1] + 0.009, hand[2] - 0.009), 0.006 * cs, 0.0055 * cs, RUBBER, 0, 0.35, 0, 1);
    }
  }

  function buildSegments(time) {
    segN = 0;
    for (let k = 0; k < 6; k++) { caughtData[k * 8 + 3] = -1; caughtData[k * 8 + 6] = 0; }
    const sc = state.scaleMul;
    if (povView()) drawViewmodel(time);
    if (state.inSub && state.inside === 'pilot' && state.viewMode === 2 && cockpitData[3] > 0) drawPilotArms();
    for (let i = 0; i < 6; i++) {
      const sp = spears[i], d = divers[i];
      if (sp.phase === 'ready' || d.aboard) continue;
      const big = i === 0 ? mix(sc, 1, 0.55) : mix(sc, 1, 0.45) * 0.8;
      const len = 0.48 * big, r = 0.0055 * big;
      const m = muzzleOf(i);
      const tail = drawSpear(sp.tipX, sp.tipY, sp.tipZ, sp.dirX, sp.dirY, sp.dirZ, len, r);
      const slack = sp.phase === 'flying' ? 1.0 : sp.phase === 'tethered' ? 0.55 + 0.3 * sin(time * 3) : sp.phase === 'miss' ? 0.7 : 0.05;
      drawRope(m[0], m[1], m[2], tail[0], tail[1], tail[2], slack, time, 0.0028 * big);
      if (sp.hit && (sp.phase === 'tethered' || sp.phase === 'reeling')) {
        const o = i * 8;
        const ax = -sp.dirZ, az = sp.dirX;
        caughtData[o] = sp.tipX - sp.dirX * len * 0.25; caughtData[o + 1] = sp.tipY - sp.dirY * len * 0.25; caughtData[o + 2] = sp.tipZ - sp.dirZ * len * 0.25;
        caughtData[o + 3] = -1; caughtData[o + 4] = sp.fishSeed; caughtData[o + 5] = atan2(ax, -az);
        caughtData[o + 6] = sp.fishRaw; caughtData[o + 7] = sp.struggle * 0.3;
      }
    }
    const used = segN;
    for (let k = used; k < segCount; k++) { segData[k * 16 + 3] = 0; segData[k * 16 + 7] = 0; }
    segCount = used;
  }

  // Main per-frame simulation step
  let lastTime = 0;
  function step(dt, time, inp, isMenu) {
    lastTime = time;
    if (state.shakeYaw) { state.camYaw -= state.shakeYaw; state.camPitch -= state.shakePitch; state.shakeYaw = state.shakePitch = 0; }
    // Smoothly animate scale multiplier between Standard (1.0) and Mungil -60% (0.40)!
    const wantScale = state.miniMode ? 0.40 : 1.0;
    if (abs(state.scaleMul - wantScale) > 0.0005) {
      applyScale(mix(state.scaleMul, wantScale, 1 - exp(-dt * 8.5)));
    }
    const sc = state.scaleMul;
    const inCockpit = state.inSub && state.inside === 'pilot' && inSubInterior();
    stepProcedure(dt, time);

    // Update look angles
    if (state.inSub && state.inside === 'walk') {
      state.walk.yaw = wrapAngle(state.walk.yaw + inp.dyaw);
      state.walkPitch = clamp(state.walkPitch - inp.dpitch, -1.2, 1.25);
    } else if (inCockpit) {
      // Pilot look around the 3D bridge (both in Kabin 3rd Person & POV Kemudi!)
      state.cockpitYaw = wrapAngle(state.cockpitYaw + inp.dyaw);
      state.cockpitPitch = clamp(state.cockpitPitch - inp.dpitch, -0.92, 1.28);
    } else {
      state.camYaw += inp.dyaw;
      state.camPitch = clamp(state.camPitch - inp.dpitch, -1.35, 1.42);
    }

    {
      const pl0 = divers[0];
      const ke = 1 - exp(-dt * 7);
      vm.kick = max(0, vm.kick - dt * 4.5);
      vm.swayX = mix(vm.swayX, clamp(-inp.dyaw * 1.4, -0.04, 0.04), ke);
      vm.swayY = mix(vm.swayY, clamp(inp.dpitch * 1.4, -0.035, 0.035), ke);
      vm.bob = sin(pl0.phase * 2) * 0.006 * pl0.moveAmp;
      vm.roll = mix(vm.roll, clamp(-inp.dyaw * 1.6, -0.05, 0.05) + sin(pl0.phase) * 0.014 * pl0.moveAmp, 1 - exp(-dt * 4));
      vm.helmX = mix(vm.helmX, clamp(-inp.dyaw * 2.4, -0.045, 0.045) + sin(pl0.phase) * 0.007 * pl0.moveAmp, 1 - exp(-dt * 5));
      vm.helmY = mix(vm.helmY, clamp(-inp.dpitch * 2.4, -0.04, 0.04) + sin(pl0.phase * 2) * 0.006 * pl0.moveAmp, 1 - exp(-dt * 5));
      vm.breath = 0.5 + 0.5 * sin(time * 0.85);
      state.helmAmt = mix(state.helmAmt || 0, povView() ? 1 : 0, 1 - exp(-dt * 10));
      state.cockAmt = mix(state.cockAmt || 0, state.inSub && state.viewMode === 2 ? 1 : 0, 1 - exp(-dt * 10));
    }
    // Smooth light & airlock hatch animations
    sub.lightSmooth = mix(sub.lightSmooth, sub.lightsOn, 1 - exp(-dt * 9));
    if (sub.hatchTimer > 0) sub.hatchTimer = max(0, sub.hatchTimer - dt);
    sub.hatchOpen = mix(sub.hatchOpen, sub.hatchTimer > 0.2 ? 1 : 0, 1 - exp(-dt * 7));

    // ========================================================================
    // A. UPDATE 10x GIANT COLOSSUS MANTA RAYS (with dramatic front flyby!)
    // ========================================================================
    stepColossi(dt, time);
    stepMegalodon(dt, time, isMenu);
    if (state.shake > 0.01 && state.inSub) sub.wakeRock = sin(time * 19) * 0.06 * state.shake + sin(time * 7.3) * 0.03 * state.shake;

    // ========================================================================
    // B. SUBMARINE PHYSICS, PILOTING & LIVE COCKPIT CONTROLS
    // ========================================================================
    if (state.inSub && !isMenu) {
      // Heavy, momentum-driven submarine: thrust builds slowly, yaw has angular momentum,
      // hull banks into turns, side-slip bleeds off, and the boat bobs on its ballast.
      const pin = state.inside === 'pilot' && !state.proc ? inp : ZERO_INP;
      const fast = (pin.boost ? 15 : 7.2) * mix(sc, 1.0, 0.72) * (state.hull <= 0 ? 0.3 : state.hull < 30 ? 0.75 : 1);
      const mf = pin.mf, mr = pin.mr, mu = pin.mu;
      sub.yawVel = sub.yawVel || 0;
      let wantTurn = 0;
      if (inCockpit) {
        wantTurn = mr * 0.62;
        if (abs(mf) > 0.05 && abs(state.cockpitYaw) > 0.03 && abs(state.cockpitYaw) < 1.3) {
          const pull = clamp(state.cockpitYaw * 0.9, -0.7, 0.7);
          wantTurn += pull;
          state.cockpitYaw -= sub.yawVel * dt * 0.8;
        }
        if (abs(mf) > 0.05 && abs(state.cockpitPitch) > 0.02 && abs(state.cockpitYaw) < 1.3) {
          sub.pitchVel = mix(sub.pitchVel || 0, clamp(state.cockpitPitch * 0.7, -0.45, 0.45), 1 - exp(-dt * 1.4));
          state.cockpitPitch -= (sub.pitchVel || 0) * dt * 0.85;
        } else sub.pitchVel = mix(sub.pitchVel || 0, mu * 0.35, 1 - exp(-dt * 1.4));
        if (abs(mf) < 0.05 && abs(mu) < 0.02) sub.pitchVel = mix(sub.pitchVel, -sub.pitch * 0.6, 1 - exp(-dt * 1.2));
        sub.pitch = clamp(sub.pitch + sub.pitchVel * dt, -0.6, 0.6);
      } else {
        if (mf > 0.05) {
          const diff = wrapAngle(state.camYaw - sub.yaw);
          wantTurn = clamp(diff * 1.25 + mr * 0.55, -0.85, 0.85);
        } else {
          wantTurn = mr * 0.6;
          if (abs(mr) > 0.05) state.camYaw += sub.yawVel * dt * 0.9;
        }
        const wantPitch = mf > 0.05 ? clamp(state.camPitch * 0.8 + mu * 0.25, -0.6, 0.6) : clamp(mu * 0.22, -0.4, 0.4);
        sub.pitch += (wantPitch - sub.pitch) * (1 - exp(-dt * 1.3));
      }
      sub.yawVel += (wantTurn - sub.yawVel) * (1 - exp(-dt * 1.5));
      sub.yaw += sub.yawVel * dt;
      const turnRate = sub.yawVel;
      const spdN = clamp(hypot(sub.vx, sub.vy, sub.vz) / 6, 0, 1.4);
      sub.rudder = mix(sub.rudder, clamp(-wantTurn * 0.75, -0.58, 0.58), 1 - exp(-dt * 4));
      sub.roll = mix(sub.roll, clamp(-turnRate * (0.18 + 0.32 * spdN), -0.32, 0.32) + sin(time * 0.53) * 0.012, 1 - exp(-dt * 1.6));
      sub.plane = mix(sub.plane, clamp((sub.pitchVel || 0) * 1.2 + mu * 0.38, -0.52, 0.52), 1 - exp(-dt * 4));

      const wantWheel = clamp(-wantTurn * 2.6, -2.4, 2.4);
      sub.wheelAngle = mix(sub.wheelAngle, wantWheel, 1 - exp(-dt * 4.5));
      sub.throttleLev = mix(sub.throttleLev, mf * (pin.boost ? 0.68 : 0.40), 1 - exp(-dt * 5.0));
      sub.diveLev = mix(sub.diveLev, clamp(mu * 0.52 + sub.pitch * 0.35, -0.62, 0.62), 1 - exp(-dt * 5.0));
      sub.pendulum = mix(sub.pendulum, clamp(-(sub.roll + sub.wakeRock) * 1.3, -0.35, 0.35), 1 - exp(-dt * 3.0));

      const cp = cos(sub.pitch), sp = sin(sub.pitch);
      const fx = cp * sin(sub.yaw), fy = sp, fz = -cp * cos(sub.yaw);
      const rx = cos(sub.yaw), rz = sin(sub.yaw);
      // split velocity into forward / lateral / vertical and treat each with its own drag
      let vf = sub.vx * fx + sub.vy * fy + sub.vz * fz;
      let vl = sub.vx * rx + sub.vz * rz;
      let vu = sub.vy - vf * fy;
      const thrust = mf >= 0 ? mf * fast : mf * fast * 0.45;
      vf += (thrust - vf) * (1 - exp(-dt * (abs(mf) > 0.05 ? 0.55 : 0.32)));
      vl += ((inCockpit ? 0 : mr * fast * 0.12) - vl) * (1 - exp(-dt * 1.4));
      vu += (mu * fast * 0.42 + sin(time * 0.6) * 0.05 - vu) * (1 - exp(-dt * 0.9));
      sub.vx = fx * vf + rx * vl;
      sub.vz = fz * vf + rz * vl;
      sub.vy = fy * vf + vu;
      moveSubmarine(dt);

      divers[0].x = sub.x; divers[0].y = sub.y; divers[0].z = sub.z;
      divers[0].vx = sub.vx; divers[0].vy = sub.vy; divers[0].vz = sub.vz;

      const fwdSpd = sub.vx * fx + sub.vy * fy + sub.vz * fz;
      const wantProp = abs(mf) > 0.05 ? (mf > 0 ? 1 : -1) * (8 + abs(fwdSpd) * 1.4) : 1.6;
      sub.propSpeed = mix(sub.propSpeed, wantProp, 1 - exp(-dt * 5));
      sub.propAngle = (sub.propAngle + sub.propSpeed * dt) % TAU;

      const bubRate = 0.14 / (1 + abs(fwdSpd) * 0.55 + abs(mu) * 1.8);
      sub.bubTimer -= dt;
      while (sub.bubTimer <= 0) {
        sub.bubTimer += bubRate;
        const propW = qRot(orientQuat(sub.yaw, sub.pitch, sub.roll), 0, -0.04 * sub.scale, 2.28 * sub.scale);
        spawnBub(
          sub.x + propW[0], sub.y + propW[1], sub.z + propW[2],
          err(0.022, 0.088) * mix(sc, 1.0, 0.35) * (inp.boost ? 1.25 : 1),
          err(0.7, 1.5), 0.20 * sc,
          -fx * (0.6 + abs(fwdSpd) * 0.22),
          -fz * (0.6 + abs(fwdSpd) * 0.22),
          err(1.8, 3.6)
        );
      }
      audioHooks.setSubThrottle?.(clamp(hypot(sub.vx, sub.vy, sub.vz) / 14 + abs(mf) * 0.35, 0, 1.3), true);
    } else {
      // Submarine parked gently next to crew OR gliding in when summoned with R
      if (sub.summonActive) {
        const dx = sub.summonX - sub.x, dy = sub.summonY - sub.y, dz = sub.summonZ - sub.z;
        const d = hypot(dx, dy, dz);
        if (d < 0.9) {
          sub.summonActive = false;
        } else {
          const tyaw = atan2(dx, -dz);
          sub.yaw += wrapAngle(tyaw - sub.yaw) * (1 - exp(-dt * 3.2));
          const sp = min(13.5, 2.4 + d * 0.95);
          sub.vx = mix(sub.vx, (dx / d) * sp, 1 - exp(-dt * 3.8));
          sub.vy = mix(sub.vy, (dy / d) * sp, 1 - exp(-dt * 3.8));
          sub.vz = mix(sub.vz, (dz / d) * sp, 1 - exp(-dt * 3.8));
          sub.pitch = mix(sub.pitch, clamp((dy / d) * 0.42, -0.4, 0.4), 1 - exp(-dt * 3));
          sub.propSpeed = mix(sub.propSpeed, 14, 1 - exp(-dt * 5));
          sub.bubTimer -= dt;
          if (sub.bubTimer <= 0) {
            sub.bubTimer = 0.045;
            const propW = qRot(orientQuat(sub.yaw, sub.pitch, sub.roll), 0, -0.04 * sub.scale, 2.28 * sub.scale);
            spawnBub(sub.x + propW[0], sub.y + propW[1], sub.z + propW[2], err(0.025, 0.08) * sc, 1.1, 0.18 * sc);
          }
        }
      } else {
        const damp = 1 - exp(-dt * 2.5);
        sub.vx *= (1 - damp);
        sub.vy = mix(sub.vy, sin(time * 0.85) * 0.06 * sc, damp);
        sub.vz *= (1 - damp);
        sub.pitch = mix(sub.pitch, sin(time * 0.55) * 0.02, damp);
        sub.roll = mix(sub.roll, cos(time * 0.47) * 0.025, damp);
        sub.rudder = mix(sub.rudder, 0, damp);
        sub.plane = mix(sub.plane, 0, damp);
        sub.wheelAngle = mix(sub.wheelAngle, 0, damp);
        sub.throttleLev = mix(sub.throttleLev, 0, damp);
        sub.diveLev = mix(sub.diveLev, 0, damp);
        sub.propSpeed = mix(sub.propSpeed, 1.15, damp);
        sub.bubTimer -= dt;
        if (sub.bubTimer <= 0) {
          sub.bubTimer = err(0.4, 0.95);
          spawnBub(sub.x, sub.y + 0.85 * sub.scale, sub.z, err(0.018, 0.05) * mix(sc, 1.0, 0.4), 1.1, 0.2 * sc);
        }
      }
      sub.propAngle = (sub.propAngle + sub.propSpeed * dt) % TAU;
      moveSubmarine(dt);
      audioHooks.setSubThrottle?.(sub.summonActive ? 0.35 : 0, false);
    }

    // ========================================================================
    // C. TINY VINTAGE SCUBA PLAYER DIVER PHYSICS & ANIMATION
    // ========================================================================
    const pl = divers[0];
    const pRad = 0.25 * sc;
    if (state.inSub && state.inside === 'walk' && !isMenu && !state.proc) stepWalk(dt, inp);
    if (state.repairing) {
      state.hull = min(100, state.hull + 9 * dt);
      for (const d of dents) d[3] *= exp(-dt * 0.35);
      if (state.hull >= 100) { state.repairing = false; for (const d of dents) d[3] = 0; emitToast('Lambung diperbaiki 100% · semua penyok dipres kembali'); }
    }
    processHullImpact(dt);
    if (!state.inSub) {
      if (!isMenu && !state.proc) {
        // Realistic scuba propulsion: slow cruise (~1.3 m/s), heavy water inertia, momentum glide and
        // rhythmic fin-kick surges. Shift = strong kicks (~2.6 m/s), still far from "flying".
        const moving = abs(inp.mf) + abs(inp.mr) + abs(inp.mu) > 0.05;
        const kick = moving ? 0.74 + 0.5 * max(0, sin(pl.phase * 2.0)) : 1;
        const sp = (inp.boost ? 2.6 : 1.3) * mix(sc, 1.0, 0.72) * kick;
        const k = 1 - exp(-dt * (moving ? 1.05 : 0.55));
        const cp = cos(state.camPitch), sy = sin(state.camYaw), cw = cos(state.camYaw);
        let tvx = (sy * cp * inp.mf + cw * inp.mr * 0.7) * sp;
        let tvy = (sin(state.camPitch) * inp.mf * 0.85 + inp.mu * 0.75) * sp * 0.72;
        let tvz = (-cw * cp * inp.mf + sy * inp.mr * 0.7) * sp;

        const probeD = 0.34 * sc + 0.02;
        const floorD = sdAt(pl.x, pl.y - probeD, pl.z);
        const headD = sdAt(pl.x, pl.y + 0.16 * sc + 0.05, pl.z);
        const nearFloor = floorD > -0.10 && (floorD - headD) > 0.14 && tvy <= 0.42 && inp.mu <= 0;
        const walkMax = 0.95 * mix(sc, 1.0, 0.55);

        if (nearFloor && (abs(inp.mf) > 0.05 || abs(inp.mr) > 0.05) && !inp.boost && state.camPitch < 0.25) {
          tvx = (sy * inp.mf + cw * inp.mr) * walkMax;
          tvz = (-cw * inp.mf + sy * inp.mr) * walkMax;
          tvy = -0.9;
        } else {
          // Gentle deep-water current & neutral buoyancy bob
          tvx += sin(time * 0.31 + pl.y * 0.08) * 0.05;
          tvy += sin(time * 0.57 + pl.phase * 0.22) * 0.035 - (moving ? 0 : 0.02);
          tvz += cos(time * 0.27 + pl.x * 0.07) * 0.045;
        }

        pl.vx += (tvx - pl.vx) * k;
        pl.vy += (tvy - pl.vy) * k;
        pl.vz += (tvz - pl.vz) * k;

        // Soft glide around parked submarine hull
        const hullR = 1.35 * sub.scale;
        const sdx = pl.x - sub.x, sdy = pl.y + 0.15 * sub.scale - sub.y, sdz = pl.z - sub.z;
        const sd = hypot(sdx, sdy, sdz);
        if (sd < hullR && sd > 0.01) {
          const push = (hullR - sd) * 6 * dt;
          pl.x += (sdx / sd) * push; pl.y += (sdy / sd) * push; pl.z += (sdz / sd) * push;
        }

        const onFloor = moveSphere(pl, pl.vx * dt, pl.vy * dt, pl.vz * dt, pRad);
        const fBelow = sdAt(pl.x, pl.y - probeD, pl.z);
        const groundClose = (onFloor || (fBelow > -0.09 && fBelow - sdAt(pl.x, pl.y + 0.16 * sc + 0.05, pl.z) > 0.14)) && pl.vy < 0.35 && inp.mu <= 0 && !inp.boost;

        const hSpd = hypot(pl.vx, pl.vz);
        const totSpd = hypot(hSpd, pl.vy);

        pl.aimHold = max(0, pl.aimHold - dt);
        const aiming = pl.aimHold > 0 || harpoon.phase !== 'ready';
        pl.aimBlend = mix(pl.aimBlend, aiming ? 1 : 0, 1 - exp(-dt * 9));
        pl.aimPitch = clamp(state.camPitch + pl.bodyTilt * 0.6, -0.9, 1.1);
        if (state.viewMode === 2 || aiming) {
          // In POV (or while aiming the harpoon) the diver body aligns with the look yaw
          pl.yaw += wrapAngle(state.camYaw - pl.yaw) * (1 - exp(-dt * 12));
          pl.roll = mix(pl.roll, 0, 1 - exp(-dt * 6));
        } else if (hSpd > 0.18) {
          const moveYaw = atan2(pl.vx, -pl.vz);
          const yDiff = wrapAngle(moveYaw - pl.yaw);
          pl.yaw += yDiff * (1 - exp(-dt * 8.5));
          pl.roll = mix(pl.roll, clamp(-yDiff * 0.35, -0.35, 0.35) * pl.swimBlend, 1 - exp(-dt * 6));
        } else {
          pl.roll = mix(pl.roll, 0, 1 - exp(-dt * 5));
        }

        pl.swimBlend = mix(pl.swimBlend, groundClose ? 0 : 1, 1 - exp(-dt * 6.5));
        const swimPitch = totSpd > 0.28 ? atan2(pl.vy, max(hSpd, 0.2)) : 0;
        const walkTilt = clamp(hSpd / walkMax, 0, 1) * 0.17;
        const swimTilt = mix(0.24, clamp(1.26 - swimPitch * 0.92, 0.05, 2.65), sstep(0.12, 1.8, totSpd)) * (1 - pl.aimBlend * 0.75);
        pl.bodyTilt = mix(pl.bodyTilt, state.viewMode === 2 ? 0.12 : mix(walkTilt, swimTilt, pl.swimBlend), 1 - exp(-dt * 6.5));

        // Tiny 60%-smaller boots patter briskly like Six/Mono in Little Nightmares!
        const strideMul = 1 / mix(sc, 1.0, 0.45);
        pl.moveAmp = mix(pl.moveAmp, clamp(totSpd / (groundClose ? walkMax : 2.4), 0, 1.25), 1 - exp(-dt * 6));
        const rate = groundClose ? (0.8 + hSpd * 1.9 * strideMul) : (1.0 + totSpd * 1.05 * sqrt(strideMul));
        pl.phase = (pl.phase + rate * dt) % TAU;

        const relYaw = clamp(wrapAngle(state.camYaw - pl.yaw), -0.68, 0.68);
        const wantHPit = mix(clamp(state.camPitch * 0.55, -0.45, 0.55), clamp(pl.bodyTilt * 0.72 + state.camPitch * 0.25, -0.3, 1.05), pl.swimBlend);
        pl.headYaw = mix(pl.headYaw, -relYaw * 0.65, 1 - exp(-dt * 7));
        pl.headPitch = mix(pl.headPitch, wantHPit, 1 - exp(-dt * 7));
      } else {
        pl.phase = (pl.phase + 2.4 * dt) % TAU;
        pl.moveAmp = 0.14;
        pl.swimBlend = 0.85;
        pl.bodyTilt = 0.22 + sin(time * 0.9) * 0.04;
        pl.headYaw = sin(time * 0.55) * 0.24;
        pl.headPitch = 0.20;
      }

      if (pl.waveTimer > 0) pl.waveTimer = max(0, pl.waveTimer - dt);
      pl.waveAmt = mix(pl.waveAmt, pl.waveTimer > 0 ? 1 : 0, 1 - exp(-dt * 9));

      // Helmet scuba regulator exhaust bubbles (in POV mode, drift softly past side of porthole!)
      pl.bubTimer -= dt;
      if (pl.bubTimer <= 0) {
        pl.bubTimer = err(0.20, 0.54) / (1 + clamp(pl.moveAmp, 0, 1) * 1.35);
        const dq = diverQuat(pl.yaw, pl.bodyTilt, pl.roll);
        const valve = state.viewMode === 2
          ? qRot(orientQuat(state.camYaw, 0, 0), err(-0.22, 0.22), -0.06, -0.36)
          : qRot(dq, 0.08 * pl.scale, 0.42 * pl.scale, 0.06 * pl.scale);
        const bSz = err(0.011, 0.034) * mix(sc, 1.0, 0.45);
        spawnBub(pl.x + valve[0], pl.y + valve[1], pl.z + valve[2], bSz, err(0.85, 1.45), 0.025 * sc, pl.vx * 0.12, pl.vz * 0.12, err(2.4, 4.6));
      }
    }

    const boardRange = 6.2 * mix(sc, 1.0, 0.45) * SUB_K * 0.82;
    state.subDist = state.inSub ? 0 : hypot(pl.x - sub.x, pl.y - sub.y, pl.z - sub.z);
    state.nearSub = !state.inSub && state.subDist <= boardRange;
    { const hp = hatchPos(); state.hatchDist = state.inSub ? 0 : hypot(pl.x - hp[0], pl.y - hp[1], pl.z - hp[2]); }

    // ========================================================================
    // D. 5 COMPANION FRIEND BOTS (Peaceful Squad Exploration + Sub Crew!)
    // ========================================================================
    {
      const hs = hypot(pl.vx, pl.vz);
      const want = hs > 0.35 ? atan2(pl.vx, -pl.vz) : state.camYaw;
      state.squadYaw += wrapAngle(want - state.squadYaw) * (1 - exp(-dt * (hs > 0.35 ? 1.1 : 0.45)));
    }
    const pFx = sin(state.squadYaw), pFz = -cos(state.squadYaw);
    const pRx = cos(state.squadYaw), pRz = sin(state.squadYaw);
    // Breadcrumb trail of the player's path (bots follow it around rocks & through arches)
    if (!state.inSub && hypot(pl.x - lastCrumbX, pl.y - lastCrumbY, pl.z - lastCrumbZ) > 0.6 * mix(sc, 1, 0.5)) {
      crumbs.push([pl.x, pl.y, pl.z]); if (crumbs.length > 48) crumbs.shift();
      lastCrumbX = pl.x; lastCrumbY = pl.y; lastCrumbZ = pl.z;
    }
    const camB = camBasis();
    const hatchX = sub.x, hatchY = sub.y + 1.18 * sub.scale, hatchZ = sub.z;
    const fScale = mix(sc, 1.0, 0.24);
    const bRad = 0.23 * sc;

    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i];

      if (state.inSub || state.crewBoarding) {
        if (b.aboard) {
          b.x = sub.x; b.y = sub.y; b.z = sub.z;
          continue;
        }
        b.boardTimer += dt;
        const dx = hatchX - b.x, dy = hatchY - b.y, dz = hatchZ - b.z;
        const d = hypot(dx, dy, dz);
        if (d < 1.65 * sc + 0.35 || d > 28 || b.boardTimer > 0.65 + i * 0.20) {
          b.aboard = true;
          sub.hatchTimer = max(sub.hatchTimer, 0.65);
          burstBubbles(hatchX, hatchY + 0.08 * sc, hatchZ, 8, 0.018 * sc, 0.065 * sc, 0.20 * sc);
          continue;
        }
        const subSpd = hypot(sub.vx, sub.vy, sub.vz);
        const sp = max(8.5, d * 2.4) + subSpd;
        const k = 1 - exp(-dt * 8.0);
        b.vx += (sub.vx * 0.6 + (dx / d) * sp - b.vx) * k;
        b.vy += (sub.vy * 0.6 + (dy / d) * sp - b.vy) * k;
        b.vz += (sub.vz * 0.6 + (dz / d) * sp - b.vz) * k;
        moveSphere(b, b.vx * dt, b.vy * dt, b.vz * dt, bRad);
        b.yaw += wrapAngle(atan2(b.vx, -b.vz) - b.yaw) * (1 - exp(-dt * 8));
        b.swimBlend = mix(b.swimBlend, 1, 1 - exp(-dt * 8));
        b.bodyTilt = mix(b.bodyTilt, 1.2, 1 - exp(-dt * 7));
        b.moveAmp = 1.0;
        b.phase = (b.phase + 9.5 * dt) % TAU;
        b.headYaw = 0; b.headPitch = 0.85;
        continue;
      }

      if (b.aboard) {
        b.exitDelay -= dt;
        if (b.exitDelay <= 0) {
          b.aboard = false;
          const an = (i / 5) * TAU + sub.yaw;
          const ep = findClearSpot(hatchX + cos(an) * 0.85 * sc, hatchY + 0.22 * sc, hatchZ + sin(an) * 0.85 * sc, bRad);
          b.x = ep[0]; b.y = ep[1]; b.z = ep[2];
          b.vx = cos(an) * 1.9; b.vy = 1.2; b.vz = sin(an) * 1.9;
          b.yaw = atan2(b.vx, -b.vz);
          b.swimBlend = 1; b.bodyTilt = 0.7;
          b.waveTimer = 1.2;
          burstBubbles(b.x, b.y + 0.18 * sc, b.z, 7, 0.018 * sc, 0.055 * sc, 0.14 * sc);
        } else {
          continue;
        }
      }

      const pDist = hypot(pl.x - b.x, pl.y - b.y, pl.z - b.z);
      const visible = onScreen(b.x, b.y, b.z, 1.15);

      // Out-of-world / NaN: always fix. Embedded in rock: push out locally first, never vanish on screen.
      if (!Number.isFinite(b.x + b.y + b.z) || hypot(b.x, b.z) > 153 || b.y < -53 || b.y > -0.5) { recoverBot(b, i); continue; }
      if (sdAt(b.x, b.y, b.z) > -bRad * 0.5) {
        const c2 = findClearSpot(b.x, b.y, b.z, bRad);
        if (sdAt(c2[0], c2[1], c2[2]) < -0.02) { b.x = c2[0]; b.y = c2[1]; b.z = c2[2]; }
        else if (!visible) { recoverBot(b, i); continue; }
      }
      if (pDist > 32 && !visible) { recoverBot(b, i); continue; }

      b.wanderTimer -= dt;
      if (b.wanderTimer <= 0) {
        b.wanderTimer = err(3.5, 8);
        b.wanderX = err(-1.0, 1.0) * fScale;
        b.wanderY = err(-0.3, 0.7) * fScale;
        b.wanderZ = err(-1.0, 1.0) * fScale;
        for (const w of WONDERS) {
          const wd = hypot(pl.x - w[0], pl.z - w[2]);
          if (wd < 26 && wd > 4 && ernd() < 0.35) {
            b.wanderX += ((w[0] - pl.x) / wd) * 0.9 * fScale;
            b.wanderZ += ((w[2] - pl.z) / wd) * 0.9 * fScale;
            break;
          }
        }
        const r = ernd();
        b.lookTarget = r < 0.30 ? 0 : r < 0.50 ? (1 + ((ernd() * 5) | 0)) : r < 0.75 ? 10 : -1;
        if (ernd() < 0.38 && pDist < 4.5 * fScale) { b.waveTimer = err(1.2, 2.2); b.lookTarget = 0; }
        if (ernd() < 0.16 && !(b.trickT > 0) && b.huntState === 0) b.trickT = 1.5;
      }

      // ---- Fish hunting with their own harpoon gun (only when calm and near the player)
      const spB = spears[i];
      const pSpd = hypot(pl.vx, pl.vy, pl.vz);
      b.huntCool -= dt;
      if (b.huntState === 0 && b.huntCool <= 0 && spB.phase === 'ready' && pDist < 9 && pSpd < 1.8) {
        b.huntCool = err(2.5, 4);
        let best = -1, bestD = 7.5 * mix(sc, 1, 0.6);
        const count = floor(fishInstances.length / 8);
        for (let f = 0; f < count; f++) {
          const o = f * 8;
          if (fishInstances[o] > 9999) continue;
          if (abs(fishInstances[o] - b.x) > 14 || abs(fishInstances[o + 2] - b.z) > 14) continue;
          if (!sampleSchoolFish(f, time, fishSample)) continue;
          const dd = hypot(fishSample[0] - b.x, fishSample[1] - b.y, fishSample[2] - b.z);
          if (dd < bestD && dd > 1.0) { bestD = dd; best = f; }
        }
        if (best >= 0 && sampleSchoolFish(best, time, fishSample) && segClear(b.x, b.y, b.z, fishSample[0], fishSample[1], fishSample[2])) {
          b.huntState = 1; b.huntT = err(0.6, 1.0); b.huntTarget = best; b.lookTarget = -1;
        }
      }
      let huntSlow = 1;
      if (b.huntState === 1) {
        if (fishInstances[b.huntTarget * 8] > 9999 || !sampleSchoolFish(b.huntTarget, time, fishSample)) { b.huntState = 0; }
        else {
          huntSlow = 0.25;
          const fx = fishSample[0] - b.x, fy = fishSample[1] - b.y, fz = fishSample[2] - b.z;
          const fh = hypot(fx, fz);
          b.yaw += wrapAngle(atan2(fx, -fz) - b.yaw) * (1 - exp(-dt * 7));
          b.aimBlend = mix(b.aimBlend, 1, 1 - exp(-dt * 8));
          b.aimPitch = clamp(atan2(fy, max(fh, 0.1)) + b.bodyTilt * 0.6, -0.9, 1.1);
          b.huntT -= dt;
          if (b.huntT <= 0) {
            const tgt = { index: b.huntTarget, kind: fishSample[5], size: fishSample[3] };
            const m = muzzleOf(i);
            const ok = segClear(m[0], m[1], m[2], fishSample[0], fishSample[1], fishSample[2]) && ernd() < 0.8;
            launchSpear(i, fishSample[0] + (ok ? 0 : err(-0.6, 0.6)), fishSample[1] + (ok ? 0 : 0.4), fishSample[2] + (ok ? 0 : err(-0.6, 0.6)), ok ? tgt : null);
            audioHooks.onHarpoonShot?.(ok);
            b.huntState = 2; b.huntCool = err(5, 10);
          }
        }
      } else if (b.huntState === 2) {
        huntSlow = 0.4;
        if (spB.phase === 'ready') b.huntState = 0;
      }
      if (b.huntState === 0) b.aimBlend = mix(b.aimBlend, 0, 1 - exp(-dt * 4));

      // ---- Formation goal (flanking the player, relative to the smoothed squad heading)
      const fo = FORM_OFF[i];
      const bobY = sin(time * (0.65 + i * 0.11) + i * 2.1) * 0.16 * fScale;
      let gx = pl.x + pRx * fo[0] * fScale + pFx * fo[1] * fScale + b.wanderX + pl.vx * 0.35;
      let gy = clamp(pl.y + fo[2] * fScale + b.wanderY * 0.55 + bobY + pl.vy * 0.25, -51.5, -1.5);
      let gz = pl.z + pRz * fo[0] * fScale + pFz * fo[1] * fScale + b.wanderZ + pl.vz * 0.35;
      // keep the formation slot itself out of rock
      if (sdAt(gx, gy, gz) > -bRad - 0.1) { const c3 = findClearSpot(gx, gy, gz, bRad + 0.1); gx = c3[0]; gy = c3[1]; gz = c3[2]; }

      const wantWalkWithPlayer = pl.swimBlend < 0.35 && (i === 1 || i === 2 || i === 5);
      if (wantWalkWithPlayer) gy = pl.y - 0.12 * sc;

      // ---- Path finding: if a rock blocks the straight line, follow the player's breadcrumb trail
      b.losT -= dt;
      if (b.losT <= 0) {
        b.losT = 0.35 + i * 0.03;
        b.hasNav = false;
        if (!segClear(b.x, b.y, b.z, gx, gy, gz, 8)) {
          for (let k = crumbs.length - 1; k >= 0; k--) {
            const c4 = crumbs[k];
            if (segClear(b.x, b.y, b.z, c4[0], c4[1], c4[2], 6)) { b.navX = c4[0]; b.navY = c4[1]; b.navZ = c4[2]; b.hasNav = true; break; }
          }
          if (!b.hasNav) { b.navX = b.x; b.navY = b.y + 1.2; b.navZ = b.z; b.hasNav = true; }
        }
      }
      if (b.hasNav) {
        gx = b.navX; gy = b.navY; gz = b.navZ;
        if (hypot(b.x - gx, b.y - gy, b.z - gz) < 0.5) b.losT = 0;
      }

      const dx = gx - b.x, dy = gy - b.y, dz = gz - b.z;
      const dist = hypot(dx, dy, dz);
      const catchUp = pDist > 5 ? (pDist - 5) * 0.55 : 0;
      const maxSpd = min(4.5, max(1.5, pSpd * 1.25 + catchUp)) * mix(sc, 1, 0.6);
      const desSpd = (dist < 0.25 * fScale ? 0 : min(maxSpd, dist * 0.9)) * huntSlow;
      let tvx = dist > 0.04 ? (dx / dist) * desSpd : 0;
      let tvy = dist > 0.04 ? (dy / dist) * desSpd : 0;
      let tvz = dist > 0.04 ? (dz / dist) * desSpd : 0;

      // ---- Obstacle look-ahead: slide along rock instead of pushing into it
      {
        const la = 0.45 + hypot(b.vx, b.vy, b.vz) * 0.5;
        const vl = hypot(tvx, tvy, tvz) || 1;
        const px2 = b.x + tvx / vl * la, py2 = b.y + tvy / vl * la, pz2 = b.z + tvz / vl * la;
        const dAhead = sdAt(px2, py2, pz2);
        if (dAhead > -(bRad + 0.3)) {
          const g = gradAt(px2, py2, pz2);
          if (g) {
            const into = tvx * g[0] + tvy * g[1] + tvz * g[2];
            if (into > 0) { tvx -= g[0] * into * 1.2; tvy -= g[1] * into * 1.2; tvz -= g[2] * into * 1.2; }
            tvy += 0.5 * mix(sc, 1, 0.5);
          }
        }
      }

      // Soft separation between friends
      for (let j = 0; j < N_DIVERS; j++) {
        if (j === i || divers[j].aboard) continue;
        const ox = b.x - divers[j].x, oy = b.y - divers[j].y, oz = b.z - divers[j].z;
        const od = hypot(ox, oy, oz);
        const minSep = (j === 0 ? 0.95 : 0.75) * fScale;
        if (od < minSep && od > 0.001) {
          const push = ((minSep - od) / minSep) * 2.6;
          tvx += (ox / od) * push; tvy += (oy / od) * push * 0.6; tvz += (oz / od) * push;
        }
      }

      // Stay out of the player's view cone / line of fire (smart squadmates don't photobomb your shot)
      {
        const vx = b.x - state.camX, vy = b.y - state.camY, vz = b.z - state.camZ;
        const along = vx * camB.fx + vy * camB.fy + vz * camB.fz;
        if (along > 0 && along < 7) {
          const qx = vx - camB.fx * along, qy = vy - camB.fy * along, qz = vz - camB.fz * along;
          const perp = hypot(qx, qy, qz);
          const lim = (0.45 + along * 0.13) * fScale;
          if (perp < lim) {
            const pu = (lim - perp) / lim * 2.4;
            const pl2 = perp > 1e-3 ? perp : 1;
            const sx = perp > 1e-3 ? qx / pl2 : camB.rx * (i % 2 ? -1 : 1);
            const sy2 = perp > 1e-3 ? qy / pl2 : 0;
            const sz = perp > 1e-3 ? qz / pl2 : camB.rz * (i % 2 ? -1 : 1);
            tvx += sx * pu; tvy += sy2 * pu * 0.5; tvz += sz * pu;
          }
        }
      }

      // Keep clear of the parked submarine hull
      const keepSubR = 2.15 * sub.scale;
      const sx = b.x - sub.x, sy = b.y - sub.y, sz = b.z - sub.z;
      const sd = hypot(sx, sy, sz);
      if (sd < keepSubR && sd > 0.01) {
        const push = ((keepSubR - sd) / keepSubR) * 4.0;
        tvx += (sx / sd) * push; tvy += (sy / sd) * push; tvz += (sz / sd) * push;
      }

      if (wantWalkWithPlayer && dist < 3.2 * fScale) tvy = min(tvy, -0.8);

      const sm = 1 - exp(-dt * 2.2);
      b.vx += (tvx - b.vx) * sm;
      b.vy += (tvy - b.vy) * sm;
      b.vz += (tvz - b.vz) * sm;

      const hitFloor = moveSphere(b, b.vx * dt, b.vy * dt, b.vz * dt, bRad);
      const botOnFloor = (hitFloor || sdAt(b.x, b.y - (0.32 * sc + 0.02), b.z) > -0.09) && b.vy < 0.28 && pSpd < 2.2;

      // Stuck handling: first wiggle free (up & sideways), only relocate if hidden from view
      const actualStep = hypot(b.x - b.lastX, b.y - b.lastY, b.z - b.lastZ);
      if (dist > 0.8 * fScale && actualStep < 0.004) b.stuckTimer += dt;
      else b.stuckTimer = max(0, b.stuckTimer - dt * 2);
      b.lastX = b.x; b.lastY = b.y; b.lastZ = b.z;
      if (b.stuckTimer > 1.5) {
        b.vy += 1.4 * dt * 10; b.vx += pRx * (i % 2 ? -1 : 1) * 0.8; b.vz += pRz * (i % 2 ? -1 : 1) * 0.8;
        b.losT = 0;
      }
      if (b.stuckTimer > 5 && !visible) { recoverBot(b, i); continue; }

      const hSpd = hypot(b.vx, b.vz);
      const totSpd = hypot(hSpd, b.vy);
      if (b.huntState !== 1) {
        if (hSpd > 0.15) {
          const my = atan2(b.vx, -b.vz);
          const yd = wrapAngle(my - b.yaw);
          b.yaw += yd * (1 - exp(-dt * 4.5));
          b.roll = mix(b.roll, clamp(-yd * 0.35, -0.35, 0.35) * b.swimBlend, 1 - exp(-dt * 4));
        } else {
          const faceYaw = b.lookTarget === 0 ? atan2(pl.x - b.x, -(pl.z - b.z)) : state.squadYaw;
          b.yaw += wrapAngle(faceYaw - b.yaw) * (1 - exp(-dt * 1.6));
          b.roll = mix(b.roll, sin(time * 0.8 + i) * 0.05, 1 - exp(-dt * 4));
        }
      } else {
        b.roll = mix(b.roll, 0, 1 - exp(-dt * 5));
      }

      const strideMul = 1 / mix(sc, 1.0, 0.45);
      b.swimBlend = mix(b.swimBlend, botOnFloor ? 0 : 1, 1 - exp(-dt * 5.5));
      const sPitch = totSpd > 0.22 ? atan2(b.vy, max(hSpd, 0.2)) : 0;
      const wTilt = clamp(hSpd / 1.4, 0, 1) * 0.15;
      const sTilt = mix(0.26, clamp(1.24 - sPitch * 0.9, 0.08, 2.55), sstep(0.12, 1.8, totSpd)) * (1 - b.aimBlend * 0.75);
      b.bodyTilt = mix(b.bodyTilt, mix(wTilt, sTilt, b.swimBlend), 1 - exp(-dt * 4.5));
      b.moveAmp = mix(b.moveAmp, clamp(totSpd / (botOnFloor ? 1.2 : 2.4), 0, 1.2), 1 - exp(-dt * 6));
      b.phase = (b.phase + (botOnFloor ? (0.9 + hSpd * 2.6 * strideMul) : (1.1 + totSpd * 1.1 * sqrt(strideMul))) * dt) % TAU;

      let wantHY = 0, wantHP = mix(0.05, b.bodyTilt * 0.72, b.swimBlend);
      if (b.lookTarget >= 0 && b.lookTarget < N_DIVERS && b.lookTarget !== i) {
        const tgt = divers[b.lookTarget];
        const ly = atan2(tgt.x - b.x, -(tgt.z - b.z));
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62) * 0.75;
      } else if (b.lookTarget === 10) {
        const ly = atan2(colossi[0].x - b.x, -(colossi[0].z - b.z));
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62) * 0.65;
        wantHP += 0.36;
      }
      if (mega.active && mega.dist < 45) {
        const ly = atan2(mega.x - b.x, -(mega.z - b.z));
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62);
        wantHP = clamp(atan2(mega.y - b.y, hypot(mega.x - b.x, mega.z - b.z)), -0.3, 0.9);
      } else if (state.midnightMode && b.huntState === 0) {
        // In the dark, crew lamps sweep where the player is looking
        const ly = state.camYaw;
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62) * 0.8;
        wantHP = mix(wantHP, clamp(state.camPitch, -0.3, 0.8), 0.6);
      }
      b.headYaw = mix(b.headYaw, wantHY, 1 - exp(-dt * 4.5));
      b.headPitch = mix(b.headPitch, clamp(wantHP, -0.35, 1.1), 1 - exp(-dt * 4.5));

      if (b.waveTimer > 0) b.waveTimer = max(0, b.waveTimer - dt);
      b.waveAmt = mix(b.waveAmt, b.waveTimer > 0 ? 1 : 0, 1 - exp(-dt * 8));
      // playful barrel roll
      if (b.trickT > 0) { b.trickT -= dt; const u = 1 - max(0, b.trickT) / 1.5; b.trick = (u * u * (3 - 2 * u)) * TAU; if (b.trickT <= 0) b.trick = 0; }

      b.bubTimer -= dt;
      if (b.bubTimer <= 0) {
        b.bubTimer = err(0.30, 0.75) / (1 + clamp(b.moveAmp, 0, 1));
        const dq = diverQuat(b.yaw, b.bodyTilt, b.roll);
        const valve = qRot(dq, 0.08 * b.scale, 0.42 * b.scale, 0.06 * b.scale);
        spawnBub(b.x + valve[0], b.y + valve[1], b.z + valve[2], err(0.010, 0.030) * mix(sc, 1.0, 0.45), err(0.85, 1.4), 0.025 * sc, b.vx * 0.1, b.vz * 0.1, err(2.0, 4.2));
      }
    }

    // ========================================================================
    // E. UPDATE LIVE RISING BUBBLES
    // ========================================================================
    updateHarpoon(dt, time);

    const drag = exp(-dt * 2.8);
    for (let i = 0; i < N_DYNBUB; i++) {
      const o7 = i * 7;
      let age = bubSim[o7 + 3];
      if (age <= 0) continue;
      const maxA = bubSim[o7 + 4];
      age += dt;
      const o8 = i * 8;
      if (age >= maxA || bubData[o8 + 1] > -0.45) {
        bubSim[o7 + 3] = 0;
        bubData[o8 + 3] = 0;
        continue;
      }
      bubSim[o7 + 3] = age;
      const sd = bubSim[o7 + 6];
      bubSim[o7] *= drag;
      bubSim[o7 + 2] *= drag;
      const wob = 0.28 + age * 0.06;
      bubData[o8] += (bubSim[o7] + sin(time * 3.8 + sd * 40 + age * 2.1) * wob) * dt;
      bubData[o8 + 1] += bubSim[o7 + 1] * dt;
      bubData[o8 + 2] += (bubSim[o7 + 2] + cos(time * 3.3 + sd * 31 + age * 1.9) * wob) * dt;
      const life = age / maxA;
      bubData[o8 + 3] = bubSim[o7 + 5] * (0.55 + 0.72 * life) * sstep(0, 0.08, life) * sstep(1, 0.78, life);
      bubData[o8 + 5] = sstep(1, 0.72, life);
    }

    // ========================================================================
    // F. UPDATE CAMERA & PACK GPU INSTANCE BUFFERS
    // ========================================================================
    if (state.inSub) stepCabinCrew(dt, time);
    updateCamera(dt, time);
    if (state.shake > 0.003) {
      const k = state.shake * mix(state.scaleMul, 1, 0.5);
      state.camX += (sin(time * 37) + sin(time * 23.3)) * 0.5 * k * 0.07;
      state.camY += sin(time * 41.7) * k * 0.055;
      state.camZ += cos(time * 31.1) * k * 0.07;
      state.shakeYaw = sin(time * 29) * k * 0.03; state.shakePitch = cos(time * 33) * k * 0.025;
      state.camYaw += state.shakeYaw; state.camPitch += state.shakePitch;
    }
    packBuffers(time);
  }

  // Write submarine searchlight, tiny diver lantern, submarine scale & 10x Giant Manta shadow into UB[60..75]
  function writeLightUniforms(UB) {
    const q = sub.q;
    const sc = state.scaleMul;
    const bow = qRot(q, 0, -0.32 * sub.scale, -1.96 * sub.scale);
    const dir = qRot(q, 0, -0.05, -1.0);
    UB[60] = sub.x + bow[0];
    UB[61] = sub.y + bow[1];
    UB[62] = sub.z + bow[2];
    UB[63] = sub.lightSmooth * (state.inSub ? 1.55 : 0.95);
    UB[64] = dir[0];
    UB[65] = dir[1];
    UB[66] = dir[2];
    UB[67] = sub.scale; // Used by dynSh for accurate submarine shadow scale!

    const pl = divers[0];
    UB[68] = pl.x;
    UB[69] = pl.y + 0.35 * sc;
    UB[70] = pl.z;
    UB[71] = state.inSub ? 0 : (0.28 + 0.42 * sub.lightSmooth);

    // Nearest 10x Giant Manta Ray casts a sweeping colossal shadow across the seabed!
    const ax = state.inSub ? sub.x : pl.x, az = state.inSub ? sub.z : pl.z;
    const c = hypot(colossi[0].x - ax, colossi[0].z - az) <= hypot(colossi[1].x - ax, colossi[1].z - az) ? colossi[0] : colossi[1];
    UB[72] = c.x;
    UB[73] = c.y;
    UB[74] = c.z;
    UB[75] = c.scale;
    UB[76] = state.midnightMode ? 0 : 1; // Daylight scattering; Midnight keeps only local lamps.
    if (state.midnightMode) UB[71] *= 1.5;
    if (inSubInterior() && cockpitData[3] > 0) {
      // Warm tungsten cabin lanterns light the bare-headed crew & Tempat Helm inside the cabin (day & night)
      const cs = cockpitData[3], cc = qRot(sub.q, 0, 0.3 * cs, 0.75 * cs);
      UB[68] = cockpitData[0] + cc[0]; UB[69] = cockpitData[1] + cc[1]; UB[70] = cockpitData[2] + cc[2];
      UB[71] = state.midnightMode ? 1.35 : 0.90;
    }

    // Six individual 1.4x helmet lamps (spotlights) -> UB[80..103] positions, UB[104..127] directions + range
    const mn = state.midnightMode;
    const b = camBasis();
    for (let i = 0; i < 6; i++) {
      const d = divers[i], o = 80 + i * 4, od = 104 + i * 4;
      if (d.aboard || sub.lightSmooth < 0.02) { UB[o + 3] = 0; continue; }
      const dq = diverQuat(d.yaw, d.bodyTilt, d.roll);
      let px, py, pz, dx, dy, dz;
      if (i === 0) {
        if (povView()) { px = state.camX + b.ux * 0.05; py = state.camY + b.uy * 0.05; pz = state.camZ + b.uz * 0.05; }
        else { const lp = qRot(dq, 0, (1.09 - 0.48) * d.scale, -0.12 * d.scale); px = d.x + lp[0]; py = d.y + lp[1]; pz = d.z + lp[2]; }
        dx = b.fx; dy = b.fy; dz = b.fz;
      } else {
        const lp = qRot(dq, 0, (1.09 - 0.48) * d.scale, -0.12 * d.scale);
        px = d.x + lp[0]; py = d.y + lp[1]; pz = d.z + lp[2];
        let v = _ry(_rx([0, 0, -1], d.headPitch), d.headYaw);
        if (d.aimBlend > 0.5) v = _rx([0, 0, -1], d.aimPitch - d.bodyTilt * 0.6);
        const w = qRot(dq, v[0], v[1], v[2]);
        dx = w[0]; dy = w[1]; dz = w[2];
      }
      const dl = hypot(dx, dy, dz) || 1;
      UB[o] = px; UB[o + 1] = py; UB[o + 2] = pz;
      UB[o + 3] = sub.lightSmooth * (mn ? (i === 0 ? 2.3 : 1.6) : (i === 0 ? 0.3 : 0.18));
      UB[od] = dx / dl; UB[od + 1] = dy / dl; UB[od + 2] = dz / dl;
      UB[od + 3] = (mn ? (i === 0 ? 22 : 16) : 7) * mix(state.scaleMul, 1, 0.6);
    }
    // External side floodlamps light the sea outside the viewports while the crew is aboard
    if (state.inSub) {
      const side = [[1, -0.55], [1, 0.35], [-1, -0.55], [-1, 0.35]];
      for (let k = 0; k < 4; k++) {
        const o = 80 + (k + 1) * 4, od = 104 + (k + 1) * 4, sx = side[k][0], vz = side[k][1];
        const p = qRot(sub.q, sx * 0.95 * sub.scale, 0.4 * sub.scale, vz * sub.scale);
        const d = qRot(sub.q, sx * 0.88, -0.38, vz * 0.2 - 0.1), dl = hypot(d[0], d[1], d[2]) || 1;
        UB[o] = sub.x + p[0]; UB[o + 1] = sub.y + p[1]; UB[o + 2] = sub.z + p[2];
        UB[o + 3] = sub.lightSmooth * (mn ? 1.8 : 0.6);
        UB[od] = d[0] / dl; UB[od + 1] = d[1] / dl; UB[od + 2] = d[2] / dl; UB[od + 3] = 24;
      }
    }
    for (let k = 0; k < 4; k++) { UB[136 + k * 4] = dents[k][0]; UB[137 + k * 4] = dents[k][1]; UB[138 + k * 4] = dents[k][2]; UB[139 + k * 4] = dents[k][3]; }
    UB[152] = 1 - state.hull / 100;
    UB[153] = state.inSub && state.hull < 30 ? 1 : 0;
    UB[154] = 0; UB[155] = 0;
    UB[128] = state.helmAmt || 0;
    UB[129] = state.cockAmt || 0;
    UB[130] = vm.helmX;
    UB[131] = vm.helmY;
    UB[132] = clamp(hypot(pl.vx, pl.vy, pl.vz) / 2.6, 0, 1);
    UB[133] = (mn ? 1 : 0) * sub.lightSmooth;
    UB[134] = vm.roll;
    UB[135] = vm.breath;
  }

  let aimT = 0, aimLast = false;
  function aimLockCheck() {
    if (state.inSub || harpoon.phase !== 'ready') return false;
    const now = performance.now();
    if (now - aimT < 120) return aimLast;
    aimT = now;
    const b = camBasis();
    const rock = rayRock(state.camX, state.camY, state.camZ, b.fx, b.fy, b.fz, 26);
    aimLast = !!findFishOnRay(state.camX, state.camY, state.camZ, b.fx, b.fy, b.fz, lastTime, min(26, rock + 0.2), 1);
    return aimLast;
  }
  function getHudState() {
    const pl = divers[0];
    const ay = state.inSub ? sub.y : pl.y;
    const spd = state.inSub ? hypot(sub.vx, sub.vy, sub.vz) : hypot(pl.vx, pl.vy, pl.vz);
    const harpoonPoint = harpoonScreenPoint();
    return {
      inSub: state.inSub,
      miniMode: state.miniMode,
      midnightMode: state.midnightMode,
      nearSub: state.nearSub,
      subDist: state.subDist,
      depth: max(1, Math.round(-ay)),
      speed: spd,
      lightsOn: !!sub.lightsOn,
      viewMode: state.viewMode,
      botsAboard: state.botsAboard,
      summoning: sub.summonActive,
      mantaFlyby: state.mantaFlyby,
      mantaDist: Math.round(state.mantaDist),
      fishCount: fishInventory.reduce((a, b) => a + b, 0),
      fishInventory: [...fishInventory],
      teamInventory: [...teamInventory],
      teamCount: teamInventory.reduce((a, b) => a + b, 0),
      fishNames: FISH_NAMES,
      aimLock: aimLockCheck(),
      hull: Math.round(state.hull),
      inside: state.inSub ? state.inside : 'out',
      interactLabel: interactLabel(),
      proc: state.proc ? { kind: state.proc.kind, idx: state.proc.idx, steps: state.proc.steps.map((x) => x[0]), progress: clamp(state.proc.t / state.proc.steps[state.proc.idx][1], 0, 1) } : null,
      fade: state.fade || 0,
      repairing: !!state.repairing,
      hatchDist: state.hatchDist,
      megaActive: mega.active,
      megaDist: Math.round(mega.dist),
      megaPhase: mega.phase,
      harpoonPhase: harpoon.phase,
      harpoonTargetVisible: harpoonPoint.visible,
      harpoonTargetX: harpoonPoint.x,
      harpoonTargetY: harpoonPoint.y,
      harpoonRecoil: harpoon.recoil,
      toastEvent: state.toastEvent,
      toastSeq: state.toastSeq,
    };
  }

  return {
    diverData,
    subData,
    cockpitData,
    colossusData,
    beamData,
    bubData,
    fishInstances,
    consumeFishDirty: () => { const dirty = fishDirty; fishDirty = false; return dirty; },
    segData,
    caughtData,
    megaData,
    spawnMegalodon: () => spawnMegalodon(false),
    getCrewLabels,
    getSegCount: () => segCount,
    colossi,
    state,
    sub,
    divers,
    placeAtPose,
    toggleSubmarine: interact,
    interact,
    toggleMiniMode,
    toggleLights,
    toggleMidnight,
    setViewMode,
    cycleView,
    toggleCockpit,
    toggleMegalophobia,
    triggerGiantMantaFlyby,
    zoom,
    callFriends,
    fireHarpoon,
    reelHarpoon,
    summonSubmarine,
    step,
    writeLightUniforms,
    getHudState,
  };
}
