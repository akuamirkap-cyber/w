export type PlayMode = 'story' | 'survival' | 'training';
export type Panel = 'controls' | 'moves' | 'updates' | 'profile' | null;
export type PracticeStyle = 'fist' | 'foot';

export type FootPracticeRoute = 'flow' | 'mixed' | 'aerial' | 'flamingo' | 'v2' | 'v3';
export const FOOT_PRACTICE = {
  v3: {
    label: 'Foot V3', hint: 'J x6. Jurus V2 dan V1 bergantian: Yeop Chagi, Rasteira, Backlash kiri, Au Batido, Konoha Senpu, Ember Crescent.',
    keys: ['J', 'J', 'J', 'J', 'J', 'J'], moves: ['F2_YEOP', 'FT_RASTEIRA', 'F2_BACK_L', 'FT_AU', 'F2_SENPU', 'FT_EMBER'],
  },
  v2: {
    label: 'Foot V2', hint: 'J, J, J, J, K. Yeop Chagi, Flamingo Thrust, Backlash Heel kiri dan kanan, lalu Hunting Hawk.',
    keys: ['J', 'J', 'J', 'J', 'K'], moves: ['F2_YEOP', 'F2_THRUST', 'F2_BACK_L', 'F2_BACK_R', 'F2_HAWK'],
  },
  flamingo: {
    label: 'Flamingo', hint: 'I, J, J, K. Dua benturan dari Switch Double, lalu Reverse Hook dan Heel Breaker.',
    keys: ['I', 'J', 'J', 'K'], moves: ['FT_FL_DOUBLE', 'FT_FL_DOUBLE', 'FT_FL_HOOK', 'FT_FL_BREAK'],
  },
  flow: {
    label: 'Flow', hint: 'Lima tendangan capoeira: Rasteira, Side Snap, Au Batido, Lotus Wheel, Ember Crescent.',
    keys: ['J', 'J', 'J', 'J', 'J'], moves: ['FT_RASTEIRA', 'FT_SIDE', 'FT_AU', 'FT_WHEEL', 'FT_EMBER'],
  },
  mixed: {
    label: 'Mix', hint: 'Kenakan Side Snap dan Crosswind untuk membuka Cinder Dragon.',
    keys: ['J', 'J', 'K', 'J'], moves: ['FT_RASTEIRA', 'FT_SIDE', 'FT_CROSS', 'FT_DRAGON'],
  },
  aerial: {
    label: 'Udara', hint: 'Angkat partner, lompat, lalu tutup dengan Comet Drop.',
    keys: ['S + K', 'Spasi', 'J', 'J', 'K'], moves: ['FT_LAUNCH', 'FT_AIR_SCISSOR', 'FT_AIR_TORNADO', 'FT_AIR_COMET'],
  },
} as const satisfies Record<FootPracticeRoute, { label: string; hint: string; keys: readonly string[]; moves: readonly string[] }>;

export const FOOT_CONTROLS = [
  { key: 'I, J, J, K', name: 'Flamingo Rush', desc: 'Ganti kaki tumpu dengan I. Sambung Switch Double, Reverse Hook, lalu Heel Breaker.' },
  { key: 'J / klik kiri', name: 'Flow Combo', desc: 'Rasteira Sweep, Side Snap, Au Batido (kayang capoeira), Lotus Wheel, lalu Ember Crescent.' },
  { key: 'K / klik kanan', name: 'Power Combo', desc: 'Moon Sweep, Break Windmill (kincir breakdance), Tornado Heel, lalu Blazing Comet.' },
  { key: 'J, J, K, J', name: 'Crossflow', desc: 'Sambung Side Snap yang kena ke Crosswind, lalu Cinder Dragon.' },
  { key: 'S + K', name: 'Rising Lotus', desc: 'Angkat lawan untuk menyambung kombo udara.' },
  { key: 'W + K', name: 'Comet Back Kick', desc: 'Tendangan meluncur. Bisa juga dengan menyerang saat berlari atau dash.' },
  { key: 'Spasi, lalu J / K', name: 'Kombo udara', desc: 'J menyambung Sky Scissors dan Sky Tornado. K menutup dengan Comet Drop.' },
];

/** Foot Mode V3: jurus V1 dan V2 disilang bergantian. Ganti tombol di tengah kombo membuka cabang silang. */
export const FOOT_CONTROLS_V3 = [
  { key: 'J x6', name: 'Rantai Silang J', desc: 'Yeop Chagi (V2), Rasteira Sweep (V1), Backlash Heel kiri (V2), Au Batido (V1), Konoha Senpu (V2), Ember Crescent (V1).' },
  { key: 'K x5', name: 'Rantai Silang K', desc: 'Moon Sweep (V1), 540 Tornado (V2), Break Windmill (V1), Konoha Dai Senpu (V2), Hunting Hawk (V2).' },
  { key: 'J kena, lalu K', name: 'Cabang silang ke K', desc: 'Yeop > Lotus Wheel, Rasteira > Backlash kanan, Backlash kiri > Tornado Heel, Au Batido > Hunting Hawk, Konoha Senpu > Blazing Comet.' },
  { key: 'K kena, lalu J', name: 'Cabang silang ke J', desc: 'Moon Sweep > Flamingo Thrust, 540 > Side Snap, Windmill > Crosswind, Dai Senpu > Cinder Dragon.' },
  { key: 'I, J, J, K', name: 'Flamingo Rush (V1)', desc: 'Kuda-kuda Flamingo V1 tetap bisa dipakai di tengah rantai silang.' },
  { key: 'S + K', name: 'Flamingo Sky Lift (V2)', desc: 'Pelontar. Spasi untuk menyusul ke udara.' },
  { key: 'W + K / lari + serang', name: 'Comet Back Kick (V1) / Flying Side Kick (V2)', desc: 'W + K meluncur mundur-putar, serangan sambil lari menjadi tendangan terbang.' },
  { key: 'Udara: J / K', name: 'Udara silang', desc: 'J: Sky Snap, Sky Scissors, Sky Tornado. K bergantian Comet Drop dan 540 banting.' },
];

/** Foot Mode V2: delapan jurus gaya Hwoarang. Scroll mouse menukar V1, V2, dan V3. */
export const FOOT_CONTROLS_V2 = [
  { key: 'J', name: 'Yeop Chagi', desc: 'Tendangan lurus ke samping. Pembuka rantai J.' },
  { key: 'J, J', name: 'Right Flamingo Thrust', desc: 'Tendangan dorong kanan dari stance Flamingo.' },
  { key: 'J, J, J / J x4', name: 'Backlash Heel kiri / kanan', desc: 'Putaran badan diikuti hantaman tumit, kiri lalu kanan.' },
  { key: 'J x5', name: 'Konoha Senpu', desc: 'Sapuan rendah berputar ala Rock Lee. Menjegal lawan di akhir rantai J.' },
  { key: 'K, K / J x5 lalu K', name: 'Konoha Dai Senpu', desc: 'Sapuan rendah lalu tebasan tinggi berputar yang mengangkat lawan.' },
  { key: 'Lari + K', name: 'Shotgun Dropkick', desc: 'V3: Dropkick sambil lari — badan mendatar di udara, kaki depan lurus mengenai duluan, kaki belakang menyusul; dorong lawan terpental jauh, lalu badan berputar sejajar lantai dengan dagu ke dada sebelum mendarat.' },
  { key: 'S + K / I', name: 'Flamingo Sky Lift', desc: 'Tendangan pelontar untuk membuka kombo udara. Tekan Spasi untuk menyusul.' },
  { key: 'K, K, K / J x4 lalu K', name: 'Hunting Hawk', desc: 'Tiga tendangan sambil melompat. Pamungkas rantai.' },
  { key: 'K / klik kanan', name: '540 Tornado Kick', desc: 'Tendangan lompat berputar. Di udara, K membanting lawan.' },
  { key: 'W + K / lari + serang', name: 'Flying Side Kick', desc: 'Tendangan terbang untuk menutup jarak.' },
  { key: 'Spasi, lalu J', name: 'Right Sky Snap', desc: 'Tendangan kanan cepat di udara. Bisa diulang untuk juggle.' },
];

export const modes: {
  id: PlayMode;
  name: string;
  label: string;
  description: string;
  image: string;
  number: string;
}[] = [
  {
    id: 'story',
    name: 'Story Mode',
    label: 'CAMPAIGN',
    description: 'Hadapi para bos dan buka jurus baru.',
    image: 'mode-story',
    number: '01',
  },
  {
    id: 'survival',
    name: 'Survival',
    label: 'ENDLESS',
    description: 'Bertahan dari gelombang musuh tanpa akhir.',
    image: 'mode-survival',
    number: '02',
  },
  {
    id: 'training',
    name: 'Dojo Latihan',
    label: 'PRACTICE',
    description: 'Asah kombo dan sempurnakan teknikmu.',
    image: 'mode-dojo',
    number: '03',
  },
];

export function readLocal<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(`pigeon_${key}`);
    return value === null ? fallback : (JSON.parse(value) as T);
  } catch {
    return fallback;
  }
}
export function writeLocal(key: string, value: unknown) {
  try {
    localStorage.setItem(`pigeon_${key}`, JSON.stringify(value));
  } catch {
    /* Private browsing can disable storage. */
  }
}

export const controls = [
  { key: 'A / D', name: 'Gerak kiri / kanan', desc: 'Geser posisi petarung di arena.' },
  { key: 'W / S', name: 'Gerak atas / bawah', desc: 'Jelajahi arena top-down atau gunakan tangga.' },
  { key: 'J', name: 'Serangan ringan', desc: 'Alternatif: klik kiri pada arena.' },
  { key: 'O', name: 'Foot Mode', desc: 'Pilih gaya kaki. Q atau roda mouse menggilir Fist, Foot, lalu Pistol.' },
  { key: 'I', name: 'Kuda-kuda Flamingo', desc: 'Saat memakai Foot Mode, ubah kaki depan lalu sambungkan J, J, K.' },
  {
    key: 'K',
    name: 'Serangan berat / clinch',
    desc: 'Alternatif: klik kanan. Clinch aktif saat lawan goyah.',
  },
  { key: 'Shift', name: 'Dash', desc: 'Berpindah posisi dengan cepat.' },
  { key: 'Space', name: 'Lompat', desc: 'Lompat dan sambungkan serangan udara.' },
  { key: 'C', name: 'Parry', desc: 'Tangkis serangan dengan timing yang tepat.' },
  { key: 'Esc', name: 'Jeda / lanjutkan', desc: 'Hentikan atau lanjutkan sesi permainan.' },
];
