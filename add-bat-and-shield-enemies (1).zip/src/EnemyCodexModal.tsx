import { useEffect, useRef, useState } from 'react';
import { FoeShow, RagWorld } from './game/ragdoll/game';
import { audioInit, snd } from './game/ragdoll/audio';

/** one page of the enemy codex. The numbers quoted here are the ones RagWorld really uses. */
export interface FoeEntry {
  id: FoeShow;
  num: number;
  icon: string;
  name: string;
  title: string;
  tag: string;
  hp: string;
  dmg: string;
  coin: string;
  from: string;
  desc: string;
  weak: string;
  tip: string;
  accent: string;
  /** false for the prisoner: he is on the list so nobody shoots him by mistake */
  enemy: boolean;
}

export const FOE_CODEX: FoeEntry[] = [
  {
    id: 'archer', num: 1, icon: '🏹', name: 'PEMANAH', title: 'PRAJURIT PANAH', tag: 'MUSUH DASAR · LV 1–3',
    hp: 'HP 43+ (LV2 ×1.5 · LV3 ×2.1)', dmg: 'PANAH 9+', coin: '+5 KOIN', from: 'SEMUA LEVEL',
    desc: 'Stickman pemanah biasa di atas pijakan melayang. Angka di lencana merahnya adalah levelnya: makin tinggi, makin tebal nyawanya, makin cepat menarik busur, makin jitu bidikannya. Bidikannya juga membaik setiap kali dia menembak.',
    weak: 'KEPALA ×2.6 · JANTUNG (dada atas) ×1.4 · badan ×1 · tangan & kaki ×0.55',
    tip: 'Headshot hampir selalu sekali mati. Kena kaki membuatnya berlutut; kena badan atau kepala saat dia menarik busur membatalkan tembakannya.',
    accent: '#7fe9f2', enemy: true,
  },
  {
    id: 'helm', num: 2, icon: '⛑️', name: 'PEMANAH BERHELM', title: 'PRAJURIT HELM BESI', tag: 'PELINDUNG KEPALA · LV 2–3',
    hp: 'HP 64+', dmg: 'PANAH 10+', coin: '+7 KOIN', from: 'SEMUA LEVEL',
    desc: 'Pemanah veteran berhelm besi. Headshot pertama hanya memberi 30% damage dan melemparkan helmnya — setelah itu kepalanya sama rapuhnya dengan pemanah biasa.',
    weak: 'JANTUNG ×1.4 selagi berhelm · KEPALA ×2.6 setelah helm lepas',
    tip: 'Dua pilihan: tembak kepalanya dua kali (helm lepas, lalu headshot), atau abaikan helmnya dan incar dada atas. Panah MAX POWER menembus helm.',
    accent: '#cfe3ea', enemy: true,
  },
  {
    id: 'heavy', num: 3, icon: '👹', name: 'PEMANAH RAKSASA', title: 'ELIT MATA MERAH', tag: 'ELIT · LV 3+',
    hp: 'HP 111+ (SANGAT TEBAL)', dmg: 'PANAH 13+ · TEMBAK CEPAT', coin: '+12 KOIN', from: 'MULAI LEVEL 3',
    desc: 'Lebih besar dari prajurit biasa, bermata merah, nyawanya paling tebal di antara musuh non-bos. Menarik busur paling cepat, jeda antar tembakannya pendek, bidikannya nyaris tidak meleset. Di level tinggi kadang melepas dua panah sekaligus.',
    weak: 'KEPALA ×2.6 (sering berhelm) · JANTUNG ×1.4',
    tip: 'Jadikan prioritas. Setiap panah ke badan atau kepalanya saat dia menarik busur membatalkan tembakan — terus ganggu dia. Panah api dan racun menggerogoti nyawa tebalnya.',
    accent: '#ff6b5e', enemy: true,
  },
  {
    id: 'shield', num: 4, icon: '🛡️', name: 'KSATRIA TAMENG', title: 'PENJAGA PERISAI', tag: 'PERISAI PENUH · LV 2–3',
    hp: 'HP 64+ · PERISAI TAHAN 3–5 PANAH', dmg: 'PANAH 10+', coin: '+10 KOIN (+3 PERISAI HANCUR)', from: 'SEMUA LEVEL',
    desc: 'Memasang kuda-kuda di balik perisai besar yang menutup badannya dari paha sampai mata; panah yang kena perisai menancap di situ. Dia harus menyandang perisai ke punggung setiap kali memanah, berlutut, atau tersetrum.',
    weak: 'KAKI di bawah perisai → berlutut & terbuka ±2,4 detik · PUNCAK KEPALA yang mengintip',
    tip: 'Panah kakinya, lalu hajar dada atau kepala. Bisa juga: tunggu dia memanah, lambungkan panah dari atas, atau hancurkan perisainya (panah api merusak 2×, MAX POWER langsung memecahkannya).',
    accent: '#9fd8ff', enemy: true,
  },
  {
    id: 'bat', num: 5, icon: '🦇', name: 'KELELAWAR', title: 'PENGGANGGU UDARA', tag: 'TERBANG NAIK-TURUN',
    hp: 'HP 19+ (SATU PANAH KUAT)', dmg: 'GIGITAN 5+', coin: '+5 KOIN', from: '1–4 EKOR TIAP LEVEL',
    desc: 'Terbang naik-turun di jalur antara kamu dan musuh — ikut menghalangi tembakanmu. Sesekali berhenti, bergetar dengan mata merah (“AWAS GIGITAN!”), lalu menukik ke kepalamu, menggigit, dan kembali ke jalurnya. Dihitung sebagai musuh level.',
    weak: 'SELURUH BADAN — paling mudah saat dia berhenti bergetar atau menukik lurus ke arahmu',
    tip: 'Bidik sedikit di depan arah geraknya. Saat dia menukik, cukup tembak lurus ke depan. Panah MAX POWER menembusnya dan terus melaju.',
    accent: '#c99bff', enemy: true,
  },
  {
    id: 'vampire', num: 6, icon: '🧛', name: 'KELELAWAR VAMPIR', title: 'SAYAP MERAH DARAH', tag: 'KELELAWAR BESAR',
    hp: 'HP 67+ (2–3 PANAH)', dmg: 'GIGITAN 10+', coin: '+9 KOIN', from: 'MULAI LEVEL 4',
    desc: 'Kelelawar besar bersayap merah darah dan bermata merah. Nyawanya 2,4× dan gigitannya 1,5× kelelawar biasa. Kalau kena panah tapi belum mati dia terpental, menjerit, lalu kembali ke jalurnya.',
    weak: 'SELURUH BADAN — badannya lebih besar, lebih mudah dikenai',
    tip: 'Tembak dua kali berturut-turut sebelum dia sempat menukik lagi. Tarik busur penuh supaya damage maksimal.',
    accent: '#ff5a6e', enemy: true,
  },
  {
    id: 'hostage', num: 7, icon: '⛓️', name: 'TAWANAN', title: 'BUKAN MUSUH — SELAMATKAN', tag: 'JANGAN DITEMBAK',
    hp: 'TIDAK MENYERANG', dmg: 'KENA ORANGNYA: −10 KOIN', coin: 'BEBAS: +15 KOIN & +20 NYAWA', from: 'LEVEL 3, 7, 11, …',
    desc: 'Stickman berikat kepala biru yang diikat tali ke pasak di atasnya. Level belum selesai sebelum dia bebas. Putuskan talinya dengan panah — jangan sampai kena orangnya.',
    weak: 'TALI di atas kepalanya (lingkaran kuning yang berdenyut)',
    tip: 'Bebaskan lebih dulu supaya dapat +20 nyawa sebelum pertarungan memanas. Kena badannya memutus combo.',
        accent: '#7dffa0', enemy: false,
  },
  {
    id: 'fort', num: 8, icon: '🏰', name: 'ISTANA KAYU', title: 'BENTENG TIANG & PAPAN', tag: 'HARUS DIROBOHKAN',
    hp: 'TIANG 106+ · PAPAN 74–95+', dmg: 'TIDAK MENYERANG', coin: 'ROBOH: +15 KOIN', from: 'LEVEL 2, 5, 8, …',
    desc: 'Benteng dua lantai dari tiang dan papan kayu. Tiap balok punya kekuatan sendiri dan retak saat dipanah; balok yang kehilangan penyangganya ikut jatuh. Penjaga di dalamnya terlindung penuh — panahmu menancap di kayu.',
    weak: 'TIANG DEPAN BAWAH (lantai & atap ikut runtuh) · TIANG DEPAN ATAS (atap menimpa penjaga atas)',
    tip: 'Panah api membakar kayu dan apinya menjalar ke balok lain. Tarikan penuh merusak lebih besar; panah MAX POWER langsung mematahkan balok.',
    accent: '#e3b77a', enemy: true,
  },
  {
    id: 'fort', num: 9, icon: '💂', name: 'PENJAGA ISTANA', title: 'PEMANAH BENTENG', tag: 'BERLINDUNG DI BALIK TIANG · LV 2–3',
    hp: 'HP 52+', dmg: 'PANAH 9+ (LEWAT CELAH TIANG)', coin: '+8 KOIN', from: 'DUA ORANG TIAP ISTANA',
    desc: 'Pemanah berikat kepala jingga yang berjaga di tiap lantai istana. Mereka menembak lewat celah panah di tiang, dan tiang itu melindungi mereka sepenuhnya dari panahmu.',
    weak: 'TIDAK BISA DIPANAH LANGSUNG — jatuhkan lantainya, atau timpa dengan atap',
    tip: 'Penjaga atas jatuh kalau lantainya runtuh; penjaga bawah mati tertimpa reruntuhan. Setelah tiang pelindungnya hancur, mereka bisa dipanah seperti pemanah biasa.',
    accent: '#ffb02e', enemy: true,
  },
  {
    id: 'dragon', num: 10, icon: '🐉', name: 'NAGA MERAH', title: 'BOS NAGA & PENUNGGANGNYA', tag: 'BOS TERBANG · SEMBURAN BOLA API',
    hp: 'NAGA HP 366+ · PENUNGGANG HP 165+', dmg: 'BOLA API 16+ · PANAH 14+', coin: '+60 KOIN (+40 NAGA TUMBANG)', from: 'LEVEL 3, 6, 9, …',
    desc: 'Naga merah yang ditunggangi pemanah berambut perak. Penunggangnya memanahmu dari punggung naga; naganya menyembur bola api. Menang dengan menjatuhkan penunggangnya (naga kabur) atau menumbangkan naganya (penunggang ikut jatuh).',
    weak: 'MULUT saat menghirup napas (tenggorokan menyala) → api meledak di mulutnya: ±⅓ nyawa naga & terhuyung · KEPALA ×1.6',
    tip: 'Bola api bisa dipanah di udara (+5 koin). Kena sayap membatalkan semburan dan membuatnya turun. Badan naga melindungi penunggang dari bawah — lambungkan panah dari atas.',
    accent: '#ff5a4f', enemy: true,
  },
];

interface Props {
  onClose: () => void;
  /** switch to the other half of the codex: the five bosses */
  onBosses: () => void;
  /** leave the codex and face the fort or the dragon in a level right away */
  onFight?: (kind: 'fort' | 'dragon') => void;
}

/**
 * The enemy codex. Its stage is a real RagWorld in "showcase" mode: the same archer who fights on the title screen
 * takes on one kind of enemy at a time, so what is shown here is exactly how each of them behaves in a level.
 */
export default function EnemyCodexModal({ onClose, onBosses, onFight }: Props) {
  const [selected, setSelected] = useState<FoeEntry>(FOE_CODEX[0]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<RagWorld | null>(null);
  const kindRef = useRef<FoeShow>(FOE_CODEX[0].id);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const world = new RagWorld(() => {}, (w, h) => {
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      return c;
    }, true);
    worldRef.current = world;
    let lw = 0; let lh = 0;
    const fit = () => {
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(160, Math.round(r.width)); const h = Math.max(120, Math.round(r.height));
      if (w === lw && h === lh) return;
      lw = w; lh = h;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      world.resize(w, h, dpr);
      world.showcase(kindRef.current); // the stage is laid out for this size: set it again
    };
    fit();
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(fit) : null;
    ro?.observe(canvas);
    window.addEventListener('resize', fit);
    let raf = 0; let prev = 0;
    const loop = (now: number) => {
      const dt = prev ? (now - prev) / 1000 : 0.016;
      prev = now;
      world.update(dt);
      world.render(ctx);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      ro?.disconnect();
      window.removeEventListener('resize', fit);
      worldRef.current = null;
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const pick = (f: FoeEntry) => {
    audioInit(); snd.tap();
    kindRef.current = f.id;
    setSelected(f);
    worldRef.current?.showcase(f.id);
  };
  const shoot = () => { audioInit(); worldRef.current?.previewShot(); };
  const again = () => { audioInit(); snd.tap(); worldRef.current?.showcase(selected.id); };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-2 backdrop-blur-sm select-none sm:p-5">
      <div className="g-pop flex h-full max-h-[700px] w-full max-w-5xl flex-col overflow-hidden rounded-3xl border-4 border-[#041e2b] bg-[#0b2536] shadow-[0_24px_60px_rgba(0,0,0,0.75)] md:flex-row">
        {/* ============ left / top: the live stage and what it shows ============ */}
        <div className="relative flex min-h-0 flex-1 flex-col bg-[#071624]">
          <div className="z-10 flex items-center justify-between gap-2 border-b border-white/10 bg-[#05121d]/90 px-4 py-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <span className="font-game grid h-8 w-8 shrink-0 place-items-center rounded-lg text-sm text-[#041824]" style={{ backgroundColor: selected.accent }}>
                #{selected.num}
              </span>
              <div className="min-w-0">
                <h2 className="font-game truncate text-lg leading-none text-white sm:text-2xl">{selected.icon} {selected.name}</h2>
                <div className="mt-0.5 truncate text-[10px] font-black tracking-wider uppercase" style={{ color: selected.accent }}>
                  {selected.title} · {selected.tag}
                </div>
              </div>
            </div>
            <button
              onClick={() => { audioInit(); snd.tap(); onClose(); }}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border-2 border-[#09090d] bg-gradient-to-br from-[#ff3b30] to-[#a80c07] text-white shadow-[0_3px_0_#09090d] transition hover:brightness-110 active:translate-y-0.5"
              aria-label="Tutup Kamus Musuh"
            >
              <span className="font-game text-xl">X</span>
            </button>
          </div>

          <div className="relative min-h-[170px] flex-1">
            <canvas ref={canvasRef} onClick={shoot} className="absolute inset-0 h-full w-full cursor-pointer" />
            <div className="pointer-events-none absolute left-3 top-2.5 rounded-full bg-black/60 px-3 py-1 text-[11px] font-bold text-cyan-200 ring-1 ring-white/15">
              🎬 Simulasi langsung · klik panggung untuk menembak
            </div>
            {!selected.enemy && (
              <div className="pointer-events-none absolute right-3 top-2.5 rounded-full bg-[#1f8a3a]/90 px-3 py-1 text-[11px] font-black text-white ring-1 ring-white/25">
                BUKAN MUSUH
              </div>
            )}
          </div>

          <div className="z-10 max-h-[46%] overflow-y-auto border-t border-white/10 bg-[#081d2c] p-3.5 sm:p-4 md:max-h-none">
            <div className="flex flex-wrap gap-2 text-[11px] font-black">
              <span className="rounded-lg bg-white/10 px-2.5 py-1 text-amber-300">{selected.hp}</span>
              <span className="rounded-lg bg-white/10 px-2.5 py-1 text-cyan-300">{selected.dmg}</span>
              <span className="rounded-lg bg-white/10 px-2.5 py-1 text-[#ffd23f]">{selected.coin}</span>
              <span className="rounded-lg bg-white/10 px-2.5 py-1 text-emerald-300">MUNCUL: {selected.from}</span>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-white/85">{selected.desc}</p>
            <p className="mt-1.5 text-xs font-bold" style={{ color: selected.accent }}>
              🎯 {selected.enemy ? 'Titik lemah' : 'Sasaran'}: {selected.weak}
            </p>
            <p className="mt-1 text-xs font-bold text-[#ffe27a]">★ Tips: {selected.tip}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                onClick={shoot}
                className="font-game rounded-xl border-2 border-[#031a24] bg-gradient-to-b from-[#2998ff] to-[#0f62c9] px-3.5 py-2 text-xs text-white shadow-[0_3px_0_#031a24] transition hover:brightness-110 active:translate-y-0.5 sm:text-sm"
              >
                🏹 TEMBAK SEKARANG
              </button>
              <button
                onClick={again}
                className="font-game rounded-xl border-2 border-[#031a24] bg-[#163c52] px-3 py-2 text-xs text-white/85 transition hover:bg-[#1f506b] active:translate-y-0.5"
              >
                🔄 ULANGI
              </button>
              {onFight && (selected.id === 'fort' || selected.id === 'dragon') && (
                <button
                  onClick={() => { audioInit(); snd.boss(); onFight(selected.id === 'fort' ? 'fort' : 'dragon'); }}
                  className="font-game ml-auto rounded-xl border-2 border-[#031a24] bg-gradient-to-b from-[#ff5a4f] to-[#c91c14] px-4 py-2 text-xs text-white shadow-[0_3px_0_#031a24] transition hover:brightness-110 active:translate-y-0.5 sm:text-sm"
                >
                  ⚔️ LAWAN SEKARANG!
                </button>
              )}
            </div>
          </div>
        </div>

        {/* ============ right / bottom: every kind of enemy ============ */}
        <div className="flex h-[36%] w-full flex-col border-t-4 border-[#041e2b] bg-[#0e2d42] md:h-full md:w-[355px] md:border-l-4 md:border-t-0">
          <div className="flex gap-1.5 border-b border-white/10 bg-[#061826] p-2">
            <span className="font-game flex-1 rounded-xl border-2 border-[#ffd93b] bg-[#16425e] px-2 py-1.5 text-center text-xs text-[#ffd93b]">👹 SEMUA MUSUH</span>
            <button
              onClick={() => { audioInit(); snd.tap(); onBosses(); }}
              className="font-game flex-1 rounded-xl border-2 border-[#051b29] bg-[#092030] px-2 py-1.5 text-xs text-white/75 transition hover:bg-[#11354d] active:translate-y-0.5"
            >
              👑 5 BOS
            </button>
          </div>
          <div className="border-b border-white/10 bg-[#092030] px-4 py-2.5">
            <div className="font-game text-lg tracking-wide text-[#ffd23f]">📖 KAMUS SEMUA MUSUH</div>
            <div className="text-[11px] font-bold text-white/70">Kenali titik lemah tiap musuh sebelum bertarung!</div>
          </div>
          <div className="flex-1 space-y-2 overflow-y-auto p-3">
            {FOE_CODEX.map((f) => {
              const isSel = selected.num === f.num;
              return (
                <button
                  key={f.num}
                  onClick={() => pick(f)}
                  className={`flex w-full items-center gap-3 rounded-2xl border-2 p-2.5 text-left transition active:scale-[0.98] ${
                    isSel ? 'border-[#ffd93b] bg-[#16425e] shadow-[0_0_16px_rgba(255,217,59,0.3)]' : 'border-[#051b29] bg-[#092030]/80 hover:bg-[#11354d]'
                  }`}
                >
                  <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-2 border-black/40 bg-[#071624] text-2xl shadow">{f.icon}</div>
                  <div className="min-w-0 flex-1">
                    <div className="font-game truncate text-sm text-white sm:text-base">#{f.num} {f.name}</div>
                    <div className="truncate text-[10px] font-black uppercase" style={{ color: f.accent }}>{f.tag}</div>
                    <div className="mt-0.5 truncate text-[10px] font-semibold text-white/65">{f.hp} · {f.from}</div>
                  </div>
                  {isSel && <span className="font-game text-xs text-[#ffd93b]">▶</span>}
                </button>
              );
            })}
            <button
              onClick={() => { audioInit(); snd.tap(); onBosses(); }}
              className="flex w-full items-center gap-3 rounded-2xl border-2 border-[#5a1a16] bg-[#3a1210]/80 p-2.5 text-left transition hover:bg-[#51201c] active:scale-[0.98]"
            >
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border-2 border-black/40 bg-[#071624] text-2xl shadow">👑</div>
              <div className="min-w-0 flex-1">
                <div className="font-game truncate text-sm text-white sm:text-base">#11–15 LIMA BOS</div>
                <div className="truncate text-[10px] font-black uppercase text-[#ff8a80]">KAPAK · TRISULA · PEDANG · SABIT · GADA</div>
                <div className="mt-0.5 truncate text-[10px] font-semibold text-white/65">Buka kamus bos & senjata khasnya →</div>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
