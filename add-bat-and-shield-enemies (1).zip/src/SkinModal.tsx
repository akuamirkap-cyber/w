import { useEffect, useRef, useState } from 'react';
import { Ctx, V, v, add, mul, damp, dist, fromAngle } from './game/util';
import { BowId, Slab2, Stick, StickLook, angLerp, drawArrow, drawBow, drawStick, fireAngle, impulse, makeStick, onString, stepStick } from './game/ragdoll/stick';
import { HEAD_STYLES, Hair, HeadStyle, drawHead, drawHeadBack, makeHair, stepHair } from './game/ragdoll/head';
import { audioInit, snd } from './game/ragdoll/audio';

export interface SkinMeta { id: HeadStyle; name: string; tag: string; desc: string; accent: string }

/** every skin the archer can wear on his head. All of them are free: pick one and it is on. */
export const SKIN_LIST: SkinMeta[] = [
  { id: 'band', name: 'IKAT NINJA', tag: 'KLASIK', accent: '#ff6b5e', desc: 'Ikat kepala merah dengan dua ekor kain yang berkibar. Tampilan asli sang pemanah.' },
  { id: 'sephiroth', name: 'RAMBUT SEPHIROTH', tag: 'PERAK PANJANG · MENGALIR', accent: '#dfe6f2', desc: 'Rambut perak panjang sampai paha dengan dua poni khas yang melengkung. Tiap helai digerakkan gravitasi, angin, dan gerakan badanmu.' },
  { id: 'racer', name: 'HELM PEMBALAP', tag: 'FULL-FACE RACING', accent: '#ff7a6a', desc: 'Helm balap merah mengilap: visor gelap, garis balap putih, sirip belakang, dan stiker petir.' },
  { id: 'robin', name: 'TOPI ROBIN HOOD', tag: 'PEMANAH HUTAN', accent: '#5fe07a', desc: 'Topi hijau berujung lancip dengan bulu merah yang melambai tiap kamu bergerak atau melepas panah.' },
  { id: 'cowboy', name: 'TOPI KOBOI', tag: 'WILD WEST', accent: '#e3b77a', desc: 'Topi koboi cokelat bertepi lebar, lengkap dengan pita dan gesper emas. Matanya mengintip dari bawah tepi topi.' },
  { id: 'punk', name: 'RAMBUT PUNK', tag: 'MOHAWK', accent: '#ff6fb5', desc: 'Mohawk merah muda runcing yang ikut condong ke belakang saat kepalamu bergerak.' },
  { id: 'sekiro', name: 'RAMBUT SEKIRO', tag: 'SHINOBI', accent: '#c9a98f', desc: 'Rambut cokelat disisir ke belakang, kuncir pendek berikat tali putih, dan beberapa helai lepas di dahi.' },
];

const H = 1 / 120;
const SLABS: Slab2[] = [{ x0: -60, x1: 60, top: 0, bot: 30 }];
const lookOf = (style: HeadStyle): StickLook => ({
  color: '#000000', rim: '#1c5566', eye: '#ffffff', helm: false, crown: false, band: style === 'band' ? '#e5352f' : null, quiver: true,
});

/** the archer wearing a skin, layered exactly as the game draws him: long hair behind him, then him, then the rest */
export function drawSkinFigure(ctx: Ctx, k: Stick, style: HeadStyle, hair: Hair | null, t: number, bow: BowId | null) {
  drawHeadBack(ctx, k, style, hair);
  drawStick(ctx, k, lookOf(style), bow ? () => {
    drawBow(ctx, k.p[4], k.bowAng, k.s, onString(k) ? dist(k.p[4], k.p[6]) : null, 0, k.nock >= 1, bow, t);
  } : undefined);
  drawHead(ctx, k, style, hair, t);
}

/** a stickman who has stood a moment in the breeze, so his hair hangs the way it will in the game */
export function settledFigure(style: HeadStyle): { k: Stick; hair: Hair | null } {
  const k = makeStick(v(0, 0), 1, 1, false, true); const hair = makeHair(style, k);
  for (let i = 0; i < 300; i++) {
    k.base = v(0, 0); k.vigor = 1; k.muscle = 1; k.nock = 1;
    stepStick(k, SLABS);
    if (hair) stepHair(k, hair);
  }
  return { k, hair };
}

/** a head-and-shoulders portrait of a skin, painted into a square of `S` px */
export function paintSkinThumb(ctx: Ctx, S: number, style: HeadStyle) {
  const g = ctx.createLinearGradient(0, 0, 0, S);
  g.addColorStop(0, '#0c5c78'); g.addColorStop(1, '#2fd0d8');
  ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
  const { k, hair } = settledFigure(style);
  const Z = S / 60;
  ctx.save();
  ctx.translate(S / 2 + 3 - k.p[0].x * Z, S * 0.57 - k.p[0].y * Z); ctx.scale(Z, Z);
  drawSkinFigure(ctx, k, style, hair, 1.2, null);
  ctx.restore();
}
function skinThumb(style: HeadStyle): string {
  if (typeof document === 'undefined') return '';
  const S = 112; const c = document.createElement('canvas');
  c.width = S * 2; c.height = S * 2;
  const ctx = c.getContext('2d');
  if (!ctx) return '';
  ctx.scale(2, 2);
  paintSkinThumb(ctx, S, style);
  return c.toDataURL('image/png');
}

interface Shot { p: V; vel: V; life: number }

/** the preview stage: a strip of the forest, his ground, and him - close up */
export function paintSkinStage(ctx: Ctx, w: number, h: number, dpr: number, k: Stick, style: HeadStyle, hair: Hair | null, t: number, bow: BowId, arrows: Shot[]) {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#0a4767'); g.addColorStop(0.62, '#0f8097'); g.addColorStop(1, '#37ebf1');
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  const m = Math.min(w, h);
  ctx.fillStyle = 'rgba(255,255,255,0.12)';
  ctx.beginPath(); ctx.arc(w * 0.77, h * 0.26, m * 0.21, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(w * 0.77, h * 0.26, m * 0.15, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'rgba(7,95,116,0.5)';
  ctx.beginPath(); ctx.moveTo(0, h); ctx.lineTo(0, h * 0.8); ctx.quadraticCurveTo(w * 0.3, h * 0.64, w * 0.56, h * 0.8); ctx.quadraticCurveTo(w * 0.8, h * 0.92, w, h * 0.72); ctx.lineTo(w, h); ctx.closePath(); ctx.fill();
  const Z = Math.min(w / 170, h / 165);
  ctx.translate(w * 0.5 + 4 * Z, h * 0.86); ctx.scale(Z, Z);
  const glow = ctx.createLinearGradient(0, 30, 0, 68);
  glow.addColorStop(0, 'rgba(150,255,250,0.28)'); glow.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = glow; ctx.fillRect(-31, 30, 62, 38);
  ctx.fillStyle = '#0a3b48'; ctx.fillRect(-36, 0, 72, 30);
  ctx.fillStyle = '#11596a'; ctx.fillRect(-36, 0, 72, 3.5);
  drawSkinFigure(ctx, k, style, hair, t, bow);
  for (const a of arrows) drawArrow(ctx, a.p, Math.atan2(a.vel.y, a.vel.x), 1, false, bow, t);
}

/** one 120 Hz step of the preview: he stands, now and then draws and looses, so the skin is seen in motion */
export function stepSkinStage(sim: { k: Stick; hair: Hair | null; cyc: number; arrows: Shot[] }) {
  const k = sim.k;
  sim.cyc += H;
  const c = sim.cyc % 4.4;
  k.base = v(0, 0); k.vigor = 1; k.muscle = Math.min(1, k.muscle + H * 1.1);
  if (k.nock < 1) k.nock = Math.min(1, k.nock + H / 0.46);
  if (c > 1.5 && c < 3.2) {
    k.aim = angLerp(k.aim, -0.34, 1 - Math.exp(-10 * H));
    k.aiming = damp(k.aiming, 1, 9, H);
    if (k.aiming > 0.6 && onString(k)) k.pull = Math.min(0.92, k.pull + H * 1.3);
  } else {
    if (k.pull > 0.5 && onString(k)) {
      // the release: the same kick through his body as in the game - watch the hair and the feather follow it
      const dir = fromAngle(fireAngle(k)); const pull = k.pull;
      sim.arrows.push({ p: add(k.p[4], mul(dir, 14)), vel: mul(dir, 1250), life: 0 });
      impulse(k, 4, mul(dir, 100 * pull)); impulse(k, 3, mul(dir, 45 * pull));
      impulse(k, 6, mul(dir, -250 * pull)); impulse(k, 5, mul(dir, -170 * pull));
      impulse(k, 1, mul(dir, -115 * pull)); impulse(k, 0, mul(dir, -160 * pull)); impulse(k, 2, mul(dir, -45 * pull));
      k.muscle = Math.min(k.muscle, 0.58); k.pull = 0; k.nock = 0;
    }
    k.aiming = damp(k.aiming, 0, 5, H); k.pull = damp(k.pull, 0, 12, H);
  }
  k.lookAt = null;
  stepStick(k, SLABS);
  if (sim.hair) stepHair(k, sim.hair);
  for (const a of sim.arrows) { a.life += H; a.vel.y += 980 * H; a.p = add(a.p, mul(a.vel, H)); }
  sim.arrows = sim.arrows.filter((a) => a.life < 0.7);
}

interface Props {
  selected: HeadStyle;
  /** the bow he carries, so the preview shows him exactly as he will be in the game */
  bow: BowId;
  onSelect: (h: HeadStyle) => void;
  onClose: () => void;
}

/** The skin shop: every head skin as a portrait, and a live close-up of the archer wearing the one that is on. */
export default function SkinModal({ selected, bow, onSelect, onClose }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const styleRef = useRef<HeadStyle>(selected);
  const bowRef = useRef<BowId>(bow);
  bowRef.current = bow;
  const simRef = useRef<{ k: Stick; hair: Hair | null; cyc: number; arrows: Shot[]; acc: number } | null>(null);
  const [thumbs, setThumbs] = useState<Partial<Record<HeadStyle, string>>>({});
  const meta = SKIN_LIST.find((m) => m.id === selected) ?? SKIN_LIST[0];

  useEffect(() => {
    const out: Partial<Record<HeadStyle, string>> = {};
    for (const s of HEAD_STYLES) out[s] = skinThumb(s);
    setThumbs(out);
  }, []);

  // the preview wears whatever is worn
  useEffect(() => {
    styleRef.current = selected;
    const s = simRef.current;
    if (s) s.hair = makeHair(selected, s.k);
  }, [selected]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const k = makeStick(v(0, 0), 1, 1, false, true);
    const sim = { k, hair: makeHair(styleRef.current, k), cyc: 0.9, arrows: [] as Shot[], acc: 0 };
    simRef.current = sim;
    let raf = 0; let prev = 0; let rt = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, prev ? (now - prev) / 1000 : 0.016);
      prev = now; rt += dt;
      sim.acc += dt;
      let guard = 0;
      while (sim.acc >= H && guard++ < 10) { stepSkinStage(sim); sim.acc -= H; }
      if (guard >= 10) sim.acc = 0;
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(120, r.width); const h = Math.max(120, r.height);
      const cw = Math.round(w * dpr); const ch = Math.round(h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      paintSkinStage(ctx, w, h, dpr, sim.k, styleRef.current, sim.hair, rt, bowRef.current, sim.arrows);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); simRef.current = null; };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  /** a shove, to see how the skin moves */
  const nudge = () => {
    audioInit(); snd.tap();
    const s = simRef.current;
    if (!s) return;
    impulse(s.k, 0, v(-280, -50)); impulse(s.k, 1, v(-160, 0));
    s.k.muscle = Math.min(s.k.muscle, 0.5);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-2 backdrop-blur-sm select-none sm:p-5">
      <div className="g-pop flex h-full max-h-[680px] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border-4 border-[#041e2b] bg-[#0b2536] shadow-[0_24px_60px_rgba(0,0,0,0.75)] md:flex-row">
        {/* ============ the archer, close up, wearing the skin ============ */}
        <div className="relative flex min-h-0 flex-1 flex-col bg-[#071624]">
          <div className="z-10 flex items-center justify-between gap-2 border-b border-white/10 bg-[#05121d]/90 px-4 py-3">
            <div className="min-w-0">
              <h2 className="font-game truncate text-lg leading-none text-white sm:text-2xl">🎭 SKIN KEPALA</h2>
              <div className="mt-0.5 truncate text-[10px] font-black tracking-wider uppercase" style={{ color: meta.accent }}>
                DIPAKAI: {meta.name} · {meta.tag}
              </div>
            </div>
            <button
              onClick={() => { audioInit(); snd.tap(); onClose(); }}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border-2 border-[#09090d] bg-gradient-to-br from-[#ff3b30] to-[#a80c07] text-white shadow-[0_3px_0_#09090d] transition hover:brightness-110 active:translate-y-0.5"
              aria-label="Tutup Skin"
            >
              <span className="font-game text-xl">X</span>
            </button>
          </div>
          <div className="relative min-h-[190px] flex-1">
            <canvas ref={canvasRef} onClick={nudge} className="absolute inset-0 h-full w-full cursor-pointer" />
            <div className="pointer-events-none absolute left-3 top-2.5 rounded-full bg-black/60 px-3 py-1 text-[11px] font-bold text-cyan-200 ring-1 ring-white/15">
              🎬 Pratinjau langsung · klik untuk menggoyang
            </div>
          </div>
          <div className="z-10 border-t border-white/10 bg-[#081d2c] px-4 py-3">
            <div className="font-game text-base" style={{ color: meta.accent }}>{meta.name}</div>
            <p className="mt-0.5 text-xs leading-relaxed text-white/85">{meta.desc}</p>
          </div>
        </div>

        {/* ============ every skin ============ */}
        <div className="flex h-[46%] w-full flex-col border-t-4 border-[#041e2b] bg-[#0e2d42] md:h-full md:w-[360px] md:border-l-4 md:border-t-0">
          <div className="border-b border-white/10 bg-[#092030] px-4 py-2.5">
            <div className="font-game text-lg tracking-wide text-[#ffd23f]">PILIH SKIN</div>
            <div className="text-[11px] font-bold text-white/70">Semua gratis — klik untuk langsung dipakai. Bisa diganti kapan saja.</div>
          </div>
          <div className="grid flex-1 auto-rows-min grid-cols-2 gap-2 overflow-y-auto p-3">
            {SKIN_LIST.map((m) => {
              const isSel = m.id === selected;
              return (
                <button
                  key={m.id}
                  aria-pressed={isSel}
                  onClick={() => { audioInit(); onSelect(m.id); }}
                  className={`relative flex flex-col items-center gap-1 rounded-2xl border-2 p-2 text-center transition active:scale-[0.97] ${
                    isSel ? 'border-[#ffd93b] bg-[#16425e] shadow-[0_0_16px_rgba(255,217,59,0.3)]' : 'border-[#051b29] bg-[#092030]/80 hover:bg-[#11354d]'
                  }`}
                >
                  {thumbs[m.id]
                    ? <img src={thumbs[m.id]} alt="" className="h-20 w-20 rounded-xl border-2 border-black/40 shadow sm:h-24 sm:w-24" />
                    : <span className="h-20 w-20 rounded-xl border-2 border-black/40 bg-[#0c5c78] sm:h-24 sm:w-24" />}
                  <span className="font-game text-xs leading-tight text-white sm:text-sm">{m.name}</span>
                  <span className="text-[9px] font-black uppercase leading-none" style={{ color: m.accent }}>{m.tag}</span>
                  {isSel && <span className="font-game absolute right-1.5 top-1.5 rounded bg-[#ffd93b] px-1.5 text-[9px] leading-4 text-[#06202e]">DIPAKAI</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
