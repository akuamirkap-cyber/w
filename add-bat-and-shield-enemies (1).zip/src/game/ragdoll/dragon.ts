// The red dragon, seen from the side and facing left - toward the archer it has come for. Its rider is an ordinary
// fighter drawn by RagWorld on the saddle; this file is the beast: where its moving parts are, and how it is painted.
import { Ctx, V, v } from '../util';

const mix = (a: number, b: number, t: number) => a + (b - a) * t;

export interface DragonRig {
  /** points down the neck, from the shoulders to the skull */
  neck: V[];
  head: V;
  /** how far the nose points down (negative: lifted) */
  headTilt: number;
  /** where a fireball leaves it - and where an arrow has to go while it draws breath */
  mouth: V;
  saddle: V;
  /** the middle of the near wing, wherever the beat has it */
  wingMid: V;
}

/**
 * The dragon's moving parts in its own frame (scale 1, +y down, nose toward -x).
 * `flap` is the wingbeat phase; `glow` 0..1 is breath being drawn: the head rears up and back.
 */
export function dragonRig(t: number, flap: number, glow: number): DragonRig {
  const rear = glow * 11;
  const hx = -116 + Math.sin(t * 1.3) * 5 + rear * 0.9; const hy = -50 + Math.sin(t * 1.7 + 1) * 4 - rear * 0.8;
  const a = v(-46, -12); const b = v(-56, -60); const c = v(-92 + rear, -64 - rear * 0.5); const d = v(hx, hy);
  const neck: V[] = [];
  for (let i = 0; i <= 10; i++) {
    const u = i / 10; const m = 1 - u;
    neck.push(v(m * m * m * a.x + 3 * m * m * u * b.x + 3 * m * u * u * c.x + u * u * u * d.x, m * m * m * a.y + 3 * m * m * u * b.y + 3 * m * u * u * c.y + u * u * u * d.y));
  }
  const headTilt = 0.16 - glow * 0.3 + Math.sin(t * 1.1) * 0.03;
  const tw = 0.5 - 0.5 * Math.sin(flap);
  return {
    neck, head: d, headTilt,
    mouth: v(hx - Math.cos(headTilt) * 30, hy + Math.sin(headTilt) * 30 + 4),
    saddle: v(-22, -27),
    wingMid: v(mix(66, 58, tw), mix(-92, 58, tw)),
  };
}

/** a point of the dragon's own frame, out in the world */
export const dragonToWorld = (q: V, p: V, s: number, tilt: number): V => {
  const cs = Math.cos(tilt); const sn = Math.sin(tilt);
  return v(p.x + (q.x * cs - q.y * sn) * s, p.y + (q.x * sn + q.y * cs) * s);
};

export interface DragonLook {
  /** 0 shut .. 1 gaping */
  jaw: number;
  /** 0..1 fire building in the throat */
  glow: number;
  /** 0..1 flash of a hit */
  flash: number;
}

export function drawDragon(ctx: Ctx, p: V, s: number, tilt: number, t: number, flap: number, o: DragonLook) {
  const rig = dragonRig(t, flap, o.glow);
  const hot = o.flash > 0.3;
  const C = hot
    ? { top: '#ffc2b4', main: '#ff8873', dark: '#cf463a', belly: '#fff2cf', wing: '#e8675a', far: '#b23a30', bone: '#8a1a14', horn: '#ffffff', key: '#4a0a0c' }
    : { top: '#ec4733', main: '#bf1d1a', dark: '#7c0f13', belly: '#f1c46c', wing: '#9a171b', far: '#5e0c11', bone: '#3d0709', horn: '#f6e6bd', key: '#1c0405' };
  ctx.save();
  ctx.translate(p.x, p.y); ctx.rotate(tilt); ctx.scale(s, s);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';

  /** one wing as a closed shape: t 0 = thrown up over the back, 1 = swept down past the belly */
  const wing = (tt: number): number[] => {
    const sx = -4; const sy = -22;
    const wx = mix(22, 14, tt); const wy = mix(-98, 50, tt);
    const tx = mix(86, 68, tt); const ty = mix(-134, 98, tt);
    const ax = mix(120, 102, tt); const ay = mix(-86, 64, tt);
    const bx = mix(108, 96, tt); const by = mix(-40, 24, tt);
    const hx = 42; const hy = mix(-14, -4, tt);
    const scallop = (x0: number, y0: number, x1: number, y1: number, k: number, px: number, py: number) => {
      const mx = (x0 + x1) / 2; const my = (y0 + y1) / 2;
      ctx.quadraticCurveTo(mx + (px - mx) * k, my + (py - my) * k, x1, y1);
    };
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.quadraticCurveTo(mix(sx, wx, 0.5) - 11, mix(sy, wy, 0.5), wx, wy);
    ctx.quadraticCurveTo(mix(wx, tx, 0.5) - 5, mix(wy, ty, 0.5) - 7 * (1 - 2 * tt), tx, ty);
    scallop(tx, ty, ax, ay, 0.4, wx, wy);
    scallop(ax, ay, bx, by, 0.4, wx, wy);
    scallop(bx, by, hx, hy, 0.3, sx, sy);
    ctx.closePath();
    return [wx, wy, tx, ty, ax, ay, bx, by];
  };
  const tw = 0.5 - 0.5 * Math.sin(flap); const tw2 = 0.5 - 0.5 * Math.sin(flap - 0.5);
  const keyed = (fill: string, lw = 2.6) => { ctx.strokeStyle = C.key; ctx.lineWidth = lw; ctx.stroke(); ctx.fillStyle = fill; ctx.fill(); };

  // the far wing, in shadow
  ctx.save(); ctx.translate(-13, -6); wing(tw2); keyed(C.far); ctx.restore();

  // the tail: a long taper that waves, ending in a spade
  const tl = [v(46, 2), v(92, 14 + Math.sin(t * 2.1) * 6), v(124, -22 + Math.sin(t * 2.1 - 0.9) * 9), v(168, -6 + Math.sin(t * 2.1 - 1.8) * 12)];
  const tail = (u: number) => { const m = 1 - u; return v(m * m * m * tl[0].x + 3 * m * m * u * tl[1].x + 3 * m * u * u * tl[2].x + u * u * u * tl[3].x, m * m * m * tl[0].y + 3 * m * m * u * tl[1].y + 3 * m * u * u * tl[2].y + u * u * u * tl[3].y); };
  for (const [col, extra] of [[C.key, 5], [C.main, 0]] as [string, number][]) {
    ctx.strokeStyle = col;
    for (let i = 0; i < 16; i++) {
      const q0 = tail(i / 16); const q1 = tail((i + 1) / 16);
      ctx.lineWidth = mix(25, 5, i / 15) + extra;
      ctx.beginPath(); ctx.moveTo(q0.x, q0.y); ctx.lineTo(q1.x, q1.y); ctx.stroke();
    }
  }
  const te = tail(1); const tb = tail(0.93); const ta = Math.atan2(te.y - tb.y, te.x - tb.x);
  ctx.save(); ctx.translate(te.x, te.y); ctx.rotate(ta);
  ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(4, -11); ctx.lineTo(24, 0); ctx.lineTo(4, 11); ctx.closePath(); keyed(C.dark, 2.2);
  ctx.restore();

  // legs, tucked up under it, claws out
  for (const [lx, sc] of [[30, 1], [-26, 0.85]] as [number, number][]) {
    ctx.save(); ctx.translate(lx, 18); ctx.scale(sc, sc);
    ctx.beginPath(); ctx.moveTo(-10, -4); ctx.lineTo(12, -2); ctx.lineTo(9, 16); ctx.lineTo(-2, 25); ctx.lineTo(-13, 22); ctx.lineTo(-5, 12); ctx.closePath(); keyed(C.dark, 2.2);
    ctx.fillStyle = C.horn;
    for (const cx of [-13, -8, -2]) { ctx.beginPath(); ctx.moveTo(cx, 21); ctx.lineTo(cx - 5, 28); ctx.lineTo(cx + 3, 24); ctx.closePath(); ctx.fill(); }
    ctx.restore();
  }

  // the body: red above, plated belly below
  ctx.beginPath(); ctx.ellipse(0, 0, 60, 30, 0, 0, Math.PI * 2); keyed(C.main, 3);
  ctx.save();
  ctx.beginPath(); ctx.ellipse(0, 0, 60, 30, 0, 0, Math.PI * 2); ctx.clip();
  ctx.fillStyle = C.top; ctx.beginPath(); ctx.ellipse(-6, -24, 62, 16, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = C.belly; ctx.beginPath(); ctx.ellipse(-4, 30, 58, 15, 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = 'rgba(120,70,10,0.5)'; ctx.lineWidth = 1.4;
  ctx.beginPath(); for (let x = -50; x <= 46; x += 12) { ctx.moveTo(x, 14); ctx.lineTo(x + 3, 31); } ctx.stroke();
  ctx.restore();

  // the neck: thick at the shoulders, a lighter throat along its underside, spines along its back
  const N = rig.neck;
  for (const [col, extra] of [[C.key, 5], [C.main, 0]] as [string, number][]) {
    ctx.strokeStyle = col;
    for (let i = 0; i < N.length - 1; i++) {
      ctx.lineWidth = mix(29, 16, i / (N.length - 2)) + extra;
      ctx.beginPath(); ctx.moveTo(N[i].x, N[i].y); ctx.lineTo(N[i + 1].x, N[i + 1].y); ctx.stroke();
    }
  }
  ctx.strokeStyle = C.belly;
  for (let i = 0; i < N.length - 1; i++) {
    const dx = N[i + 1].x - N[i].x; const dy = N[i + 1].y - N[i].y; const l = Math.hypot(dx, dy) || 1;
    const off = mix(8.5, 4.5, i / (N.length - 2));
    ctx.lineWidth = mix(8, 4.5, i / (N.length - 2));
    ctx.beginPath(); ctx.moveTo(N[i].x + (dy / l) * off, N[i].y - (dx / l) * off); ctx.lineTo(N[i + 1].x + (dy / l) * off, N[i + 1].y - (dx / l) * off); ctx.stroke();
  }
  ctx.fillStyle = C.dark;
  for (let i = 1; i < N.length - 1; i += 2) {
    const dx = N[i + 1].x - N[i].x; const dy = N[i + 1].y - N[i].y; const l = Math.hypot(dx, dy) || 1;
    const nx = -dy / l; const ny = dx / l; const hw = mix(13, 7.5, i / (N.length - 2));
    const bx = N[i].x + nx * hw; const by = N[i].y + ny * hw;
    ctx.beginPath(); ctx.moveTo(bx - (dx / l) * 5, by - (dy / l) * 5); ctx.lineTo(bx + nx * 9 + (dx / l) * -3, by + ny * 9 + (dy / l) * -3); ctx.lineTo(bx + (dx / l) * 5, by + (dy / l) * 5); ctx.closePath(); ctx.fill();
  }
  // the fire it is drawing shows through the throat
  if (o.glow > 0.03) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 3; i < N.length; i++) {
      const g = ctx.createRadialGradient(N[i].x, N[i].y, 1, N[i].x, N[i].y, 20);
      g.addColorStop(0, `rgba(255,190,70,${0.5 * o.glow})`); g.addColorStop(1, 'rgba(255,90,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(N[i].x, N[i].y, 20, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  // the head, in its own frame: +x out along the snout, +y down
  ctx.save();
  ctx.translate(rig.head.x, rig.head.y); ctx.scale(-1, 1); ctx.rotate(rig.headTilt);
  // horns and the frill behind the jaw
  ctx.beginPath(); ctx.moveTo(-5, -12); ctx.quadraticCurveTo(-24, -16, -39, -27); ctx.quadraticCurveTo(-22, -10, -10, -4); ctx.closePath(); keyed(C.horn, 2);
  ctx.beginPath(); ctx.moveTo(-10, -5); ctx.quadraticCurveTo(-22, -5, -32, -10); ctx.quadraticCurveTo(-20, 0, -11, 1); ctx.closePath(); keyed(C.horn, 2);
  ctx.beginPath(); ctx.moveTo(-9, 3); ctx.lineTo(-24, 13); ctx.lineTo(-7, 11); ctx.closePath(); keyed(C.dark, 2);
  // lower jaw, hinged at the cheek
  ctx.save();
  ctx.translate(1, 4); ctx.rotate(o.jaw * 0.6);
  ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(29, 1); ctx.lineTo(25, 6.5); ctx.lineTo(0, 8); ctx.lineTo(-8, 4); ctx.closePath(); keyed(C.dark, 2.2);
  ctx.fillStyle = C.horn;
  for (const x of [9, 15, 21]) { ctx.beginPath(); ctx.moveTo(x - 2, 1); ctx.lineTo(x, -4.5); ctx.lineTo(x + 2, 1); ctx.closePath(); ctx.fill(); }
  ctx.restore();
  // fire in the mouth
  if (o.glow > 0.03 && o.jaw > 0.1) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const g = ctx.createRadialGradient(17, 6, 1, 17, 6, 22);
    g.addColorStop(0, `rgba(255,250,210,${0.95 * o.glow})`); g.addColorStop(0.4, `rgba(255,150,30,${0.7 * o.glow})`); g.addColorStop(1, 'rgba(255,60,0,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(17, 6, 22, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
  // skull and snout
  ctx.beginPath();
  ctx.moveTo(-13, -9); ctx.lineTo(2, -14); ctx.lineTo(13, -9.5); ctx.lineTo(24, -7.5); ctx.lineTo(33, -3.5); ctx.lineTo(32, 2.5); ctx.lineTo(4, 4.5); ctx.lineTo(-9, 6); ctx.lineTo(-15, 0);
  ctx.closePath(); keyed(C.main, 2.4);
  ctx.fillStyle = C.top;
  ctx.beginPath(); ctx.moveTo(-10, -9); ctx.lineTo(2, -13); ctx.lineTo(13, -9); ctx.lineTo(24, -7); ctx.lineTo(31, -3.5); ctx.lineTo(20, -3.5); ctx.lineTo(4, -6); ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.horn;
  for (const x of [11, 17, 23, 28.5]) { ctx.beginPath(); ctx.moveTo(x - 2, 2.6); ctx.lineTo(x, 7.6); ctx.lineTo(x + 2, 2.6); ctx.closePath(); ctx.fill(); }
  // eye under a heavy brow, and the nostril
  ctx.fillStyle = '#ffe14d'; ctx.beginPath(); ctx.ellipse(7.5, -5.4, 3.6, 2.4, 0.25, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#1a0405'; ctx.beginPath(); ctx.ellipse(8.2, -5.2, 1, 2.2, 0.25, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = C.dark; ctx.beginPath(); ctx.moveTo(1.5, -9.4); ctx.lineTo(13, -5.4); ctx.lineTo(12.2, -8.8); ctx.closePath(); ctx.fill();
  ctx.fillStyle = C.key; ctx.beginPath(); ctx.ellipse(28, -3.6, 1.8, 1, 0.3, 0, Math.PI * 2); ctx.fill();
  ctx.restore();

  // the saddle, behind the root of the neck
  ctx.beginPath(); ctx.moveTo(-37, -27); ctx.quadraticCurveTo(-22, -34, -6, -28); ctx.lineTo(-8, -20); ctx.lineTo(-35, -19); ctx.closePath(); keyed('#3a2416', 2);
  ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(-34, -22); ctx.lineTo(-9, -23); ctx.stroke();

  // the near wing: skin over an arm and three long fingers
  const [wx, wy, tx, ty, ax, ay, bx, by] = wing(tw);
  keyed(C.wing, 2.6);
  ctx.strokeStyle = C.bone;
  for (const [fx, fy, lw] of [[tx, ty, 3.4], [ax, ay, 2.8], [bx, by, 2.4]]) { ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(wx, wy); ctx.lineTo(fx, fy); ctx.stroke(); }
  ctx.strokeStyle = C.key; ctx.lineWidth = 10;
  ctx.beginPath(); ctx.moveTo(-4, -22); ctx.quadraticCurveTo(mix(-4, wx, 0.5) - 11, mix(-22, wy, 0.5), wx, wy); ctx.stroke();
  ctx.strokeStyle = C.main; ctx.lineWidth = 6.5;
  ctx.beginPath(); ctx.moveTo(-4, -22); ctx.quadraticCurveTo(mix(-4, wx, 0.5) - 11, mix(-22, wy, 0.5), wx, wy); ctx.stroke();
  ctx.fillStyle = C.horn;
  ctx.beginPath(); ctx.moveTo(wx - 3, wy - 2); ctx.lineTo(wx - 12, wy - 9 * (1 - 2 * tw)); ctx.lineTo(wx + 2, wy + 3); ctx.closePath(); ctx.fill();
  ctx.restore();
}
