// Skins: what a fighter wears on his head instead of the ninja headband. Hats and helmets are drawn in the head's
// own frame, so they tilt, nod and mirror with it. Hair is not a sticker: every lock is a chain of points pinned to
// the skull and pulled by gravity, by the breeze and by his own movement (the feather in the Robin Hood hat too,
// only stiffer), and it is painted as tapered ribbons - the long ones behind his body, bangs and side locks over it.
import { Ctx, V, v, clamp } from '../util';
import { HEAD_R, Stick } from './stick';

export type HeadStyle = 'band' | 'sephiroth' | 'racer' | 'robin' | 'cowboy' | 'punk' | 'sekiro';
export const HEAD_STYLES: HeadStyle[] = ['band', 'sephiroth', 'racer', 'robin', 'cowboy', 'punk', 'sekiro'];

/** `back`: hangs behind the body · `side`: on the near side of the head, over the body · `bang`: before the face */
type Layer = 'back' | 'side' | 'bang' | 'feather';
interface Lock {
  p: V[]; o: V[]; seg: number;
  /** where it is pinned, in the head's frame: x toward the face, y toward the neck (units of his scale) */
  x: number; y: number;
  /** half its width at the root */
  w: number;
  layer: Layer;
  /** which shade of the palette it takes: neighbours differ a little, so the mass reads as strands */
  tone: number;
  /** true: it lies over the skull and cannot pass through it · false: it hangs on the near side, in front of it */
  collide: boolean;
  /** a feather is stiff: the direction it stands in (head frame), which it springs back to */
  rest?: [number, number];
}
/** `hx`,`hy`: where the head was a step ago, so the hair can be carried along with it */
export interface Hair { style: HeadStyle; locks: Lock[]; hx?: number; hy?: number }

const H = 1 / 120;

/** the skull's own axes: `u` out of the crown, `fw` the way he faces */
const frame = (k: Stick) => {
  const dx = k.p[0].x - k.p[1].x; const dy = k.p[0].y - k.p[1].y; const l = Math.hypot(dx, dy) || 1;
  const u = v(dx / l, dy / l);
  return { u, fw: v(-u.y * k.face, u.x * k.face) };
};
/** a point of the head's frame, out in the world */
const pin = (k: Stick, x: number, y: number): V => {
  const { u, fw } = frame(k);
  return v(k.p[0].x + (fw.x * x - u.x * y) * k.s, k.p[0].y + (fw.y * x - u.y * y) * k.s);
};

/** the simulated part of a skin, if it has one: hair, or the feather in a hat */
export function makeHair(style: HeadStyle, k: Stick): Hair | null {
  const { u, fw } = frame(k);
  const lock = (x: number, y: number, n: number, seg: number, w: number, layer: Layer, tone = 0, collide = true, rest?: [number, number]): Lock => {
    const a = pin(k, x, y);
    const d = rest ? v(fw.x * rest[0] - u.x * rest[1], fw.y * rest[0] - u.y * rest[1]) : layer === 'back' ? v(-k.face * 0.78, 0.62) : v(-k.face * 0.15, 0.99);
    const p = Array.from({ length: n }, (_, i) => v(a.x + d.x * i * seg * k.s, a.y + d.y * i * seg * k.s));
    return { p, o: p.map((q) => ({ ...q })), seg, x, y, w, layer, tone, collide, rest };
  };
  if (style === 'sephiroth') {
    // silver hair to the thighs, pinned from the nape up to the crown (the higher ones lie over the lower),
    // one long lock down the near side, and the two long bangs that frame the face
    return { style, locks: [
      lock(-6.5, 8, 9, 6.8, 3.6, 'back', 2), lock(-9.2, 4.6, 10, 7, 4.2, 'back', 1), lock(-10.4, 0.5, 11, 7.2, 4.6, 'back', 0),
      lock(-10, -3.8, 11, 7.4, 4.6, 'back', 1), lock(-7.6, -7.6, 11, 7.2, 4.2, 'back', 0),
      lock(-4.6, -8.6, 8, 6, 2.3, 'side', 1, false), lock(-2.2, -9.4, 7, 5.8, 1.9, 'side', 0, false),
      lock(10.2, -9.4, 4, 4.6, 1.2, 'bang', 2), lock(11.9, -7.4, 5, 4.8, 1.5, 'bang', 0),
    ] };
  }
  if (style === 'sekiro') {
    // swept back into a short tail tied at the back, with a couple of loose strands over the brow
    return { style, locks: [
      lock(-10.5, -4.5, 6, 4.6, 2.4, 'back', 1), lock(-11, -6.5, 8, 4.8, 3.4, 'back', 0),
      lock(9.6, -8.6, 4, 4, 1.3, 'bang', 0), lock(11.2, -6.2, 3, 3.6, 1.1, 'bang', 1),
    ] };
  }
  if (style === 'robin') return { style, locks: [lock(-5, -10.5, 5, 5.8, 3.3, 'feather', 0, false, [-0.8, -0.6])] };
  return null;
}

/** one 120 Hz step: every lock swings from its pin, keeps its length, and lies over the skull, not through it */
export function stepHair(k: Stick, hair: Hair) {
  const s = k.s; const head = k.p[0]; const r = (HEAD_R + 0.8) * s;
  const { u, fw } = frame(k);
  // most of the head's own movement carries the hair with it; only the rest is felt as a pull. A blow to the head
  // then sends a wave down the hair instead of throwing it about
  const cx = hair.hx === undefined ? 0 : (head.x - hair.hx) * 0.62; const cy = hair.hy === undefined ? 0 : (head.y - hair.hy) * 0.62;
  hair.hx = head.x; hair.hy = head.y;
  for (const L of hair.locks) {
    const P = L.p; const O = L.o;
    for (let i = 1; i < P.length; i++) { P[i] = v(P[i].x + cx, P[i].y + cy); O[i] = v(O[i].x + cx, O[i].y + cy); }
    const feather = L.layer === 'feather'; const light = feather || L.layer !== 'back';
    const a = pin(k, L.x, L.y);
    const keep = feather ? 0.9 : 0.955; const top = 7 * s; // (no lock ever moves faster than this in one step: it flows, it does not whip)
    for (let i = 1; i < P.length; i++) {
      let vx = (P[i].x - O[i].x) * keep; let vy = (P[i].y - O[i].y) * keep;
      const sp = Math.hypot(vx, vy);
      if (sp > top) { vx *= top / sp; vy *= top / sp; }
      O[i] = { ...P[i] };
      // gravity, a steady breeze against the way he faces, and a shimmer so it never hangs dead still
      const wind = (-k.face * (light ? 60 : 210) + Math.sin(k.t * 1.9 + L.x * 0.7) * (light ? 28 : 36)) * H * H;
      let q = v(P[i].x + vx + wind, P[i].y + vy + (feather ? 60 : 900) * H * H + Math.cos(k.t * 2.3 + L.y * 0.6) * 18 * H * H);
      if (L.rest) {
        // a feather springs back toward where it stands
        const tx = a.x + (fw.x * L.rest[0] - u.x * L.rest[1]) * L.seg * i * s; const ty = a.y + (fw.y * L.rest[0] - u.y * L.rest[1]) * L.seg * i * s;
        q = v(q.x + (tx - q.x) * 0.1, q.y + (ty - q.y) * 0.1);
      }
      P[i] = q;
    }
    P[0] = a;
    if (!L.rest) {
      // straight hair: every point leans a little toward the line of the two before it, so a lock sweeps rather than kinks
      for (let i = 2; i < P.length; i++) {
        const ex = 2 * P[i - 1].x - P[i - 2].x; const ey = 2 * P[i - 1].y - P[i - 2].y;
        P[i] = v(P[i].x + (ex - P[i].x) * 0.02, P[i].y + (ey - P[i].y) * 0.02);
      }
    }
    for (let it = 0; it < 3; it++) {
      for (let i = 1; i < P.length; i++) {
        const dx = P[i].x - P[i - 1].x; const dy = P[i].y - P[i - 1].y; const d = Math.hypot(dx, dy) || 1;
        const give = (d - L.seg * s) / d;
        let q = v(P[i].x - dx * give, P[i].y - dy * give); // the pinned end does not give: the lock follows it
        if (L.collide) {
          const hx = q.x - head.x; const hy = q.y - head.y; const hd = Math.hypot(hx, hy) || 1;
          if (hd < r) q = v(head.x + (hx / hd) * r, head.y + (hy / hd) * r);
        }
        if (L.layer === 'back') {
          // the hair of the back of his head stays behind his face: it may stream past his chest, never over his eyes
          const lx = ((q.x - head.x) * fw.x + (q.y - head.y) * fw.y) / s; const ly = -((q.x - head.x) * u.x + (q.y - head.y) * u.y) / s;
          if (lx > -3 && ly < 14) { const push = (-3 - lx) * s * 0.6; q = v(q.x + fw.x * push, q.y + fw.y * push); }
        }
        P[i] = q;
      }
    }
  }
}

/* ------------------------------------------------ painting ------------------------------------------------ */

interface Palette { tone: string[]; deep: string; edge: string; shine: string }
const SILVER: Palette = { tone: ['#f6f8fc', '#e6ebf3', '#d5dce8'], deep: '#aeb9cc', edge: '#7f8ca4', shine: '#ffffff' };
const BROWN: Palette = { tone: ['#8a7161', '#765e4f', '#655043'], deep: '#4a3a30', edge: '#2c211b', shine: '#b39a88' };

/** a lock (or a feather) as one tapered shape along its chain; `wide(t)` is half its width at t = 0 (root) .. 1 (tip) */
function ribbon(ctx: Ctx, P: V[], wide: (t: number) => number) {
  const n = P.length; const A: V[] = []; const B: V[] = [];
  for (let i = 0; i < n; i++) {
    const a = P[Math.max(0, i - 1)]; const b = P[Math.min(n - 1, i + 1)];
    const dx = b.x - a.x; const dy = b.y - a.y; const l = Math.hypot(dx, dy) || 1; const hw = wide(i / (n - 1));
    A.push(v(P[i].x - (dy / l) * hw, P[i].y + (dx / l) * hw));
    B.push(v(P[i].x + (dy / l) * hw, P[i].y - (dx / l) * hw));
  }
  ctx.beginPath();
  ctx.moveTo(A[0].x, A[0].y);
  for (let i = 1; i < n - 1; i++) ctx.quadraticCurveTo(A[i].x, A[i].y, (A[i].x + A[i + 1].x) / 2, (A[i].y + A[i + 1].y) / 2);
  ctx.lineTo(A[n - 1].x, A[n - 1].y);
  ctx.lineTo(B[n - 1].x, B[n - 1].y);
  for (let i = n - 2; i >= 1; i--) ctx.quadraticCurveTo(B[i].x, B[i].y, (B[i].x + B[i - 1].x) / 2, (B[i].y + B[i - 1].y) / 2);
  ctx.lineTo(B[0].x, B[0].y);
  ctx.closePath();
}
/** the smooth line down the middle of a chain, from its root to its `last` point */
function strand(ctx: Ctx, P: V[], last: number) {
  ctx.beginPath();
  ctx.moveTo(P[0].x, P[0].y);
  for (let i = 1; i < last; i++) ctx.quadraticCurveTo(P[i].x, P[i].y, (P[i].x + P[i + 1].x) / 2, (P[i].y + P[i + 1].y) / 2);
  ctx.lineTo(P[last].x, P[last].y);
}

/**
 * Every lock of one layer, as one head of hair: first a soft dark edge round the whole mass (not round each lock),
 * then each lock light at the root and deeper toward its tip, a faint parting between neighbours, and a thread of
 * light down its length.
 */
function drawLocks(ctx: Ctx, hair: Hair, layer: Layer, pal: Palette, s: number) {
  const base = ctx.globalAlpha;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  const shape = (L: Lock, grow: number) => {
    const w = L.w * s + grow; const fine = L.layer === 'side';
    ribbon(ctx, L.p, (t) => w * (fine ? Math.min(1, 0.25 + 3.2 * t) : 1) * (1 - Math.pow(t, 1.7)));
  };
  ctx.fillStyle = pal.edge;
  for (const L of hair.locks) if (L.layer === layer) { shape(L, 0.9 * s); ctx.fill(); }
  for (const L of hair.locks) {
    if (L.layer !== layer) continue;
    const P = L.p; const n = P.length;
    shape(L, 0);
    const g = ctx.createLinearGradient(P[0].x, P[0].y, P[n - 1].x, P[n - 1].y);
    g.addColorStop(0, pal.tone[L.tone % pal.tone.length]); g.addColorStop(1, pal.deep);
    ctx.fillStyle = g; ctx.fill();
    ctx.globalAlpha = base * 0.22; ctx.strokeStyle = pal.edge; ctx.lineWidth = 0.5 * s; ctx.stroke();
    strand(ctx, P, n - 2);
    ctx.globalAlpha = base * 0.85; ctx.strokeStyle = pal.shine; ctx.lineWidth = Math.max(0.45, L.w * s * 0.18); ctx.stroke();
    ctx.globalAlpha = base;
  }
}

/** runs `draw` in the head's own frame: origin at the skull's centre, x toward the face, y toward the neck */
function local(ctx: Ctx, k: Stick, draw: () => void) {
  const { u, fw } = frame(k); const s = k.s;
  ctx.save();
  ctx.transform(fw.x * s, fw.y * s, -u.x * s, -u.y * s, k.p[0].x, k.p[0].y);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  draw();
  ctx.restore();
}
const curves = (ctx: Ctx, list: number[][]) => {
  for (const [x0, y0, cx, cy, x1, y1] of list) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.quadraticCurveTo(cx, cy, x1, y1); ctx.stroke(); }
};

/** the part of a skin that hangs behind the body: call this before the stickman himself is drawn */
export function drawHeadBack(ctx: Ctx, k: Stick, style: HeadStyle, hair: Hair | null | undefined) {
  if (!hair) return;
  if (style === 'sephiroth') drawLocks(ctx, hair, 'back', SILVER, k.s);
  else if (style === 'sekiro') drawLocks(ctx, hair, 'back', BROWN, k.s);
}

/** the rest of the skin, over the stickman that has just been drawn (so a visor covers his eyes, a brim shades them) */
export function drawHead(ctx: Ctx, k: Stick, style: HeadStyle, hair: Hair | null | undefined, t: number) {
  if (style === 'band') return;
  ctx.save();

  if (style === 'sephiroth') {
    local(ctx, k, () => {
      // the hair on the skull: over the crown and down the back of the head, parted above the brow
      ctx.beginPath();
      ctx.arc(0, 0, 12.8, -0.675, -4.037, true);
      ctx.lineTo(-2.5, 10.6);
      ctx.bezierCurveTo(-0.5, 5, -2.5, -2.5, 3, -6.2);
      ctx.quadraticCurveTo(6.5, -8.4, 10, -8);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -13, 0, 11);
      g.addColorStop(0, '#ffffff'); g.addColorStop(0.45, '#e3e8f0'); g.addColorStop(1, '#b4bfd0');
      ctx.fillStyle = g; ctx.fill();
      // strands sweeping back from the parting
      ctx.strokeStyle = 'rgba(126,140,163,0.7)'; ctx.lineWidth = 0.75;
      curves(ctx, [[4.5, -12, -8, -11.5, -11.6, 1.5], [5.5, -10.6, -4.5, -9.5, -8, 7], [6.4, -9.2, -0.5, -7.5, -4.5, 9.5]]);
      // the band of light across the crown
      ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = 1.7;
      ctx.beginPath(); ctx.arc(0.5, 1, 10.6, -2.55, -1.5); ctx.stroke();
    });
    if (hair) drawLocks(ctx, hair, 'side', SILVER, k.s);
    local(ctx, k, () => {
      // where the two bangs leave the parting: slim blades that rise, turn over, and come down before the face -
      // each ends exactly where its simulated length begins, at the same width
      const blade = (x0: number, y0: number, cx: number, cy: number, x1: number, y1: number, w: number, col: string) => {
        const pts: V[] = [];
        for (let i = 0; i <= 8; i++) { const q = i / 8; const m = 1 - q; pts.push(v(m * m * x0 + 2 * m * q * cx + q * q * x1, m * m * y0 + 2 * m * q * cy + q * q * y1)); }
        ribbon(ctx, pts, (q) => (w + 0.45) * (0.2 + 0.8 * q)); ctx.fillStyle = SILVER.edge; ctx.fill();
        ribbon(ctx, pts, (q) => w * (0.2 + 0.8 * q)); ctx.fillStyle = col; ctx.fill();
        ctx.beginPath(); ctx.arc(x1, y1, w, 0, Math.PI * 2); ctx.fill();
      };
      blade(1.5, -12, 7.6, -18, 10.2, -9.4, 1.2, '#d5dce8');
      blade(2.8, -12.3, 9.6, -19.4, 11.9, -7.4, 1.5, '#f6f8fc');
    });
    if (hair) drawLocks(ctx, hair, 'bang', SILVER, k.s);
  } else if (style === 'sekiro') {
    local(ctx, k, () => {
      // swept back off the brow, over the crown, down to the nape
      ctx.beginPath();
      ctx.arc(0, 0, 12.5, -0.61, -3.785, true);
      ctx.lineTo(-5.5, 6.2);
      ctx.quadraticCurveTo(-3.5, -1, 2, -5.4);
      ctx.quadraticCurveTo(6.5, -8, 10.25, -7.16);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -13, 0, 9);
      g.addColorStop(0, '#9a8170'); g.addColorStop(0.5, '#6b5546'); g.addColorStop(1, '#4a3a30');
      ctx.fillStyle = g; ctx.fill();
      // combed toward the knot
      ctx.strokeStyle = 'rgba(40,28,22,0.6)'; ctx.lineWidth = 0.8;
      curves(ctx, [[8, -9.6, 0, -13.6, -10, -8.2], [6, -6.6, -2, -9.6, -10.6, -6.6], [1, -3.6, -5, -4.6, -11, -5.4], [-4.2, 5, -9, 1, -11, -4.4]]);
      ctx.strokeStyle = 'rgba(214,190,170,0.55)'; ctx.lineWidth = 1.1;
      curves(ctx, [[5, -11.4, -3, -12.6, -8.6, -8.4]]);
      // the knot and its white cord
      ctx.fillStyle = '#5b473b';
      ctx.beginPath(); ctx.ellipse(-12.4, -6.6, 3, 2.3, -0.5, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#f2ead8'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-10.4, -8.8); ctx.lineTo(-11.4, -4.2); ctx.stroke();
    });
    if (hair) drawLocks(ctx, hair, 'bang', BROWN, k.s);
  } else if (style === 'punk') {
    local(ctx, k, () => {
      // a mohawk: spikes from the brow over the crown to the nape, lagging behind however his head moves
      const lag = clamp((k.p[0].x - k.o[0].x) * k.face * 0.5, -0.45, 0.45) + Math.sin(t * 5.2 + k.seed * 9) * 0.05;
      ctx.strokeStyle = '#b0126a'; ctx.lineWidth = 2.6;
      ctx.beginPath(); ctx.arc(0, 0, 11.2, -3.15, -0.85); ctx.stroke();
      const n = 7;
      for (let i = n - 1; i >= 0; i--) {
        const tt = i / (n - 1);                    // 0 at the brow .. 1 at the nape
        const a = 0.72 - tt * 2.3;                 // radians off the crown: + toward the face, - toward the back
        const la = a - 0.28 - lag;
        const bx = Math.sin(a) * 10.4; const by = -Math.cos(a) * 10.4;
        const px = Math.cos(a) * 3.3; const py = Math.sin(a) * 3.3;
        const len = 9 + 10 * Math.sin(Math.PI * (0.14 + 0.78 * tt));
        ctx.beginPath();
        ctx.moveTo(bx - px, by - py); ctx.lineTo(bx + Math.sin(la) * len, by - Math.cos(la) * len); ctx.lineTo(bx + px, by + py);
        ctx.closePath();
        ctx.strokeStyle = '#6d0d3f'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = i % 2 ? '#ff6fb5' : '#ff2e93'; ctx.fill();
      }
    });
  } else if (style === 'racer') {
    local(ctx, k, () => {
      // a full-face racing helmet: glossy shell, a stripe over the crown, a dark visor where his eyes were
      const R = 14.4; const cy = -0.6;
      const disc = (r: number) => { ctx.beginPath(); ctx.arc(0, cy, r, 0, Math.PI * 2); };
      const visor = () => {
        ctx.beginPath();
        ctx.moveTo(2.2, -6.4); ctx.quadraticCurveTo(9, -7.4, 15, -4.6); ctx.lineTo(15, 3);
        ctx.quadraticCurveTo(8, 3.6, 3, 2.6); ctx.quadraticCurveTo(0.2, -1.8, 2.2, -6.4);
        ctx.closePath();
      };
      // the fin behind
      ctx.beginPath(); ctx.moveTo(-10.5, -9.5); ctx.lineTo(-19.5, -12.8); ctx.lineTo(-17.2, -7.6); ctx.lineTo(-12.8, -4.6); ctx.closePath();
      ctx.fillStyle = '#a81d19'; ctx.fill(); ctx.strokeStyle = '#0b1418'; ctx.lineWidth = 1; ctx.stroke();
      // the padded collar under it
      ctx.fillStyle = '#0b1418'; ctx.beginPath(); ctx.ellipse(-0.5, 13.4, 7.6, 2.6, 0, 0, Math.PI * 2); ctx.fill();
      disc(R + 1.1); ctx.fillStyle = '#0b1418'; ctx.fill();
      const g = ctx.createRadialGradient(-3.5, -7.5, 1, 0, cy, R);
      g.addColorStop(0, '#ff7a6a'); g.addColorStop(0.45, '#e5352f'); g.addColorStop(1, '#a31c18');
      disc(R); ctx.fillStyle = g; ctx.fill();
      ctx.save();
      disc(R); ctx.clip();
      // the chin bar, a shade darker
      ctx.fillStyle = '#b3201c';
      ctx.beginPath(); ctx.moveTo(-2, 4.2); ctx.lineTo(16, 4.2); ctx.lineTo(16, 16); ctx.lineTo(-6, 16); ctx.closePath(); ctx.fill();
      // the racing stripe
      ctx.lineCap = 'butt';
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2.6; ctx.beginPath(); ctx.arc(0, cy, R - 1.3, -3.3, -0.6); ctx.stroke();
      ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(0, cy, R - 3.5, -3.3, -0.6); ctx.stroke();
      ctx.lineCap = 'round';
      // the visor: dark glass with the sky in it
      const vg = ctx.createLinearGradient(0, -7, 0, 3.5);
      vg.addColorStop(0, '#0a151b'); vg.addColorStop(1, '#1f4455');
      visor(); ctx.fillStyle = vg; ctx.fill();
      ctx.fillStyle = 'rgba(127,233,242,0.6)';
      ctx.beginPath(); ctx.moveTo(4.6, -4.9); ctx.lineTo(10.2, -5.3); ctx.lineTo(8.4, -2.4); ctx.lineTo(3.8, -2.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath(); ctx.moveTo(11.2, -5.1); ctx.lineTo(12.8, -4.9); ctx.lineTo(11.6, -2.9); ctx.lineTo(10.2, -2.8); ctx.closePath(); ctx.fill();
      visor(); ctx.strokeStyle = '#0b1418'; ctx.lineWidth = 1; ctx.stroke();
      // vents in the chin bar, and a bolt on the side
      ctx.beginPath(); ctx.moveTo(7.5, 7); ctx.lineTo(11.5, 6.4); ctx.moveTo(7, 9.3); ctx.lineTo(10.6, 8.9); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-4, -4.5); ctx.lineTo(-8.5, 1.2); ctx.lineTo(-5.6, 1.2); ctx.lineTo(-7.4, 6); ctx.lineTo(-2.2, -0.6); ctx.lineTo(-5, -0.6); ctx.closePath();
      ctx.fillStyle = '#ffd23f'; ctx.fill(); ctx.strokeStyle = '#7a4a00'; ctx.lineWidth = 0.6; ctx.stroke();
      ctx.restore();
      // a gleam on the shell
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(0, cy, R - 5.8, -2.3, -1.65); ctx.stroke();
    });
  } else if (style === 'robin') {
    local(ctx, k, () => {
      // the crown of a bycocket: a soft point leaning back, drawn out into a long beak over the brow
      ctx.beginPath();
      ctx.moveTo(-12.5, -5.5);
      ctx.bezierCurveTo(-14, -14, -9.5, -22, -2, -23);
      ctx.bezierCurveTo(5, -22.5, 10, -15.5, 24.5, -7.2);
      ctx.quadraticCurveTo(8, -4, -12.5, -5.5);
      ctx.closePath();
      const g = ctx.createLinearGradient(-12, -23, 16, -5);
      g.addColorStop(0, '#4fd062'); g.addColorStop(0.5, '#2fae3c'); g.addColorStop(1, '#1f8a34');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = '#0b2a12'; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.strokeStyle = 'rgba(11,42,18,0.45)'; ctx.lineWidth = 0.8;
      curves(ctx, [[-3, -22, 3, -15, 12, -10.5]]);
    });
    if (hair) {
      // the feather tucked into the brim: a red vane round a pale quill, and it springs as he moves
      const base = ctx.globalAlpha;
      for (const L of hair.locks) {
        const w = L.w * k.s;
        ribbon(ctx, L.p, (q) => w * Math.pow(Math.sin(Math.PI * (0.08 + 0.92 * q)), 0.7));
        ctx.fillStyle = '#e5352f'; ctx.fill();
        ctx.strokeStyle = '#7a0f12'; ctx.lineWidth = 0.8 * k.s; ctx.stroke();
        strand(ctx, L.p, L.p.length - 1);
        ctx.globalAlpha = base * 0.85; ctx.strokeStyle = '#ffd0c8'; ctx.lineWidth = 0.9 * k.s; ctx.stroke();
        ctx.globalAlpha = base;
      }
    }
    local(ctx, k, () => {
      // the brim, turned up all round and rolled highest at the back
      ctx.beginPath();
      ctx.moveTo(24.5, -7.2);
      ctx.quadraticCurveTo(8, -3.8, -13, -4.8);
      ctx.quadraticCurveTo(-17, -8.5, -14.5, -14);
      ctx.quadraticCurveTo(-4, -9.4, 24.5, -7.2);
      ctx.closePath();
      ctx.fillStyle = '#1b7a30'; ctx.fill();
      ctx.strokeStyle = '#0b2a12'; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.strokeStyle = 'rgba(140,235,150,0.75)'; ctx.lineWidth = 0.9;
      curves(ctx, [[-13.6, -12.6, -3.5, -8.6, 21, -7.4]]);
    });
  } else if (style === 'cowboy') {
    local(ctx, k, () => {
      // the crown, pinched along the top
      ctx.beginPath();
      ctx.moveTo(-11, -10);
      ctx.bezierCurveTo(-11.6, -17, -10.6, -23, -7.2, -25.4);
      ctx.quadraticCurveTo(-4.6, -27, -2, -25.2);
      ctx.quadraticCurveTo(0.2, -23.6, 2.6, -25.3);
      ctx.quadraticCurveTo(6, -27, 8.6, -24.4);
      ctx.bezierCurveTo(10.8, -21, 11.6, -16, 11.6, -10);
      ctx.closePath();
      const g = ctx.createLinearGradient(-11, 0, 12, 0);
      g.addColorStop(0, '#7a4f25'); g.addColorStop(0.55, '#9a6a35'); g.addColorStop(1, '#b98447');
      ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = '#2a1708'; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.strokeStyle = 'rgba(42,23,8,0.5)'; ctx.lineWidth = 0.8;
      curves(ctx, [[0.2, -23.6, -0.5, -19.5, 1, -17.6]]);
      // the band and its gold buckle
      ctx.fillStyle = '#2e1a0c'; ctx.fillRect(-11.4, -17.4, 23, 3.4);
      ctx.fillStyle = '#ffd23f'; ctx.fillRect(3.2, -18, 3.8, 4.6);
      ctx.fillStyle = '#2e1a0c'; ctx.fillRect(4.3, -16.9, 1.6, 2.4);
      // the brim: wide, its near edge rolled up over the foot of the crown, its ends dipping
      ctx.beginPath();
      ctx.moveTo(-25.5, -8);
      ctx.bezierCurveTo(-17, -4.6, 17, -4.6, 25.5, -8.4);
      ctx.bezierCurveTo(18, -13, 10, -13.6, 0, -13.6);
      ctx.bezierCurveTo(-10, -13.6, -18, -13, -25.5, -8);
      ctx.closePath();
      const bg = ctx.createLinearGradient(0, -13.6, 0, -5);
      bg.addColorStop(0, '#c08a4c'); bg.addColorStop(1, '#6d4520');
      ctx.fillStyle = bg; ctx.fill();
      ctx.strokeStyle = '#2a1708'; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.strokeStyle = 'rgba(232,190,130,0.85)'; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.moveTo(-21, -10.6); ctx.bezierCurveTo(-14, -12.9, -7, -13, 0, -13); ctx.bezierCurveTo(7, -13, 14, -12.9, 21, -10.8); ctx.stroke();
    });
  }
  ctx.restore();
}
