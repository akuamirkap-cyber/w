// The wooden fort: posts and planks stacked into two floors, with men sheltering behind them. Every timber has
// its own strength and knows what it rests on; RagWorld breaks them and lets whatever lost its footing fall.
// Here: the layout, and how a timber is drawn standing, splitting, burning and tumbling.
import { Ctx, V, v, clamp } from '../util';
import { BowId, drawArrow } from './stick';

export interface FortBlock {
  kind: 'post' | 'plank';
  /** at rest: centre x from the middle of the fort's ground, bottom edge above that ground, width and height */
  x: number; y: number; w: number; h: number;
  hp: number; max: number;
  /** the timbers it rests on (none: the ground itself). It comes down as soon as one of them is gone */
  on: number[];
  state: 'up' | 'fall' | 'gone';
  /** while it falls: where it is, how it moves and turns, how long it has been falling, whether it has landed yet */
  p: V; vel: V; rot: number; vr: number; life: number; landed: boolean;
  /** flash of a hit; seconds of fire left in it; whether that fire has already crept on to its neighbours */
  flash: number; burn: number; spread: boolean;
  /** arrows standing in it, in its own frame */
  stuck: { x: number; y: number; ang: number; bow: BowId }[];
}

const block = (kind: FortBlock['kind'], x: number, y: number, w: number, h: number, hp: number, on: number[] = []): FortBlock => ({
  kind, x, y, w, h, hp, max: hp, on, state: 'up',
  p: v(0, 0), vel: v(0, 0), rot: 0, vr: 0, life: 0, landed: false, flash: 0, burn: 0, spread: false, stuck: [],
});

/** the pieces RagWorld needs by name, the width of the fort's ground, and where its two guards stand */
export const FORT = { L1: 0, L2: 1, DECK: 2, U1: 3, U2: 4, ROOF: 5, W: 236, DECK_Y: 112, G1X: -28, G2X: -4 };

/**
 * Two floors: front and back posts carry the deck, two more posts on the deck carry the roof.
 * A guard stands behind the front post on each floor - out of reach until something gives way.
 */
export function makeFort(level: number): FortBlock[] {
  const k = 1 + Math.min(level, 12) * 0.06; // sturdier timber on later levels
  return [
    block('post', -98, 0, 16, 100, 100 * k),
    block('post', 98, 0, 16, 100, 100 * k),
    block('plank', 0, 100, 222, 12, 90 * k, [0, 1]),
    block('post', -66, 112, 13, 92, 70 * k, [2]),
    block('post', 66, 112, 13, 92, 70 * k, [2]),
    block('plank', 0, 204, 164, 11, 70 * k, [3, 4]),
  ];
}

/** a standing timber's box in the world, given where the middle of the fort's ground is */
export const blockBox = (b: FortBlock, gx: number, gy: number) => ({ x0: gx + b.x - b.w / 2, x1: gx + b.x + b.w / 2, y0: gy - b.y - b.h, y1: gy - b.y });
export const blockCentre = (b: FortBlock, gx: number, gy: number): V => v(gx + b.x, gy - b.y - b.h / 2);

export function drawFortBlock(ctx: Ctx, b: FortBlock, gx: number, gy: number, t: number) {
  if (b.state === 'gone') return;
  const falling = b.state === 'fall';
  const c = falling ? b.p : blockCentre(b, gx, gy);
  const w = b.w; const h = b.h; const tall = h > w;
  const base = ctx.globalAlpha;
  ctx.save();
  ctx.translate(c.x, c.y);
  if (falling) { ctx.rotate(b.rot); ctx.globalAlpha = base * clamp(2.4 - b.life, 0, 1); }
  // a dark keyline, then timber lit from the upper left
  ctx.fillStyle = '#24130a'; ctx.fillRect(-w / 2 - 1.3, -h / 2 - 1.3, w + 2.6, h + 2.6);
  const g = tall ? ctx.createLinearGradient(-w / 2, 0, w / 2, 0) : ctx.createLinearGradient(0, -h / 2, 0, h / 2);
  g.addColorStop(0, '#d8a05c'); g.addColorStop(0.3, '#ad6f35'); g.addColorStop(1, '#6d421f');
  ctx.fillStyle = g; ctx.fillRect(-w / 2, -h / 2, w, h);
  // grain along its length
  ctx.strokeStyle = 'rgba(58,28,8,0.5)'; ctx.lineWidth = 1;
  ctx.beginPath();
  for (const q of [0.32, 0.64]) {
    if (tall) {
      const x = -w / 2 + w * q;
      ctx.moveTo(x, -h / 2 + 14); ctx.lineTo(x + (q < 0.5 ? 1 : -1), -h * 0.12); ctx.moveTo(x, h * 0.03); ctx.lineTo(x, h / 2 - 14);
    } else {
      const y = -h / 2 + h * q;
      ctx.moveTo(-w / 2 + 18, y); ctx.lineTo(-w * 0.12, y); ctx.moveTo(w * 0.03, y); ctx.lineTo(w / 2 - 18, y);
    }
  }
  ctx.stroke();
  // an iron strap near each end, with a nail in it
  for (const e of [-1, 1]) {
    ctx.fillStyle = '#3b2a1e';
    if (tall) ctx.fillRect(-w / 2, e * (h / 2 - 9) - 2, w, 4); else ctx.fillRect(e * (w / 2 - 12) - 2, -h / 2, 4, h);
    ctx.fillStyle = '#ecd9b6';
    ctx.beginPath();
    if (tall) ctx.arc(0, e * (h / 2 - 9), 1.1, 0, Math.PI * 2); else ctx.arc(e * (w / 2 - 12), 0, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }
  // the post a guard stands behind has an arrow slit: that is how he shoots out
  if (tall && !falling && b.x < 0) { ctx.fillStyle = '#170b05'; ctx.fillRect(-1.7, -h * 0.2, 3.4, 16); }
  // damage: it splits across the grain
  const hurt = 1 - b.hp / b.max;
  const crack = (q: number) => {
    if (tall) { const y = -h / 2 + h * q; ctx.moveTo(-w / 2, y); ctx.lineTo(-w * 0.15, y + 4); ctx.lineTo(w * 0.1, y - 3); ctx.lineTo(w / 2, y + 2); }
    else { const x = -w / 2 + w * q; ctx.moveTo(x, -h / 2); ctx.lineTo(x + 4, -h * 0.15); ctx.lineTo(x - 3, h * 0.1); ctx.lineTo(x + 2, h / 2); }
  };
  ctx.strokeStyle = '#170b05'; ctx.lineWidth = 1.7;
  ctx.beginPath();
  if (hurt > 0.3) crack(0.38);
  if (hurt > 0.62) crack(0.7);
  ctx.stroke();
  // charred where it burns; white for a moment where it was struck
  if (b.burn > 0) { ctx.fillStyle = `rgba(20,8,2,${clamp(0.25 + (4 - b.burn) * 0.1, 0, 0.62)})`; ctx.fillRect(-w / 2, -h / 2, w, h); }
  if (b.flash > 0.02) { ctx.fillStyle = `rgba(255,255,255,${clamp(b.flash, 0, 1) * 0.7})`; ctx.fillRect(-w / 2, -h / 2, w, h); }
  for (const st of b.stuck) drawArrow(ctx, v(st.x, st.y), st.ang, 1, true, st.bow, t, false);
  ctx.restore();
}

/** the pennant on the roof - gone with the roof */
export function drawFortFlag(ctx: Ctx, roof: FortBlock, gx: number, gy: number, t: number) {
  if (roof.state !== 'up') return;
  const x = gx + roof.x + 28; const y = gy - roof.y - roof.h;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.strokeStyle = '#24130a'; ctx.lineWidth = 3.4;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 38); ctx.stroke();
  ctx.strokeStyle = '#ad6f35'; ctx.lineWidth = 1.8;
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - 38); ctx.stroke();
  const wv = (q: number) => Math.sin(t * 5 - q * 3.2) * 2.6 * q;
  ctx.fillStyle = '#e5352f';
  ctx.beginPath();
  ctx.moveTo(x, y - 37);
  ctx.quadraticCurveTo(x - 13, y - 39 + wv(0.5), x - 27, y - 31 + wv(1));
  ctx.quadraticCurveTo(x - 13, y - 27 + wv(0.5), x, y - 23);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#7a0f12'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.fillStyle = '#ffd23f';
  ctx.beginPath(); ctx.arc(x, y - 39.5, 2.2, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}
