// Panel roguelite: pilih kartu, rute, peti, layar mati "SEKALI LAGI", HUD kartu, notifikasi, PROGRES & DEBUG.
// Gaya sama dengan panel lama (g-panel biru gelap, g-ribbon, tombol g-btn, font-game).
import { ReactNode, useEffect, useRef, useState } from 'react';
import type { RagWorld, RUi } from './game/ragdoll/game';
import { CARDS, CFG, COSMETICS, CardId, FOE_NAMES, UNLOCKS, SKIN_PERKS, SKIN_RULES } from './game/ragdoll/config';
import { skinPerkLines } from './game/ragdoll/skinPerks';
import { CARD_BY, cardText } from './game/ragdoll/cards';
import { MOD_LABEL, board, dailyInfo, readLogs, unlockOf } from './game/ragdoll/meta';
import { audioInit, snd } from './game/ragdoll/audio';
import SkillTree, { TreeIcon } from './SkillTree';

type W = () => RagWorld | undefined;
const TYPE_COL: Record<string, string> = { PANAH: '#ffb02e', BERTAHAN: '#5cf08a', RISIKO: '#ff5a4f', KHUSUS: '#b98cff' };
const pct = (x: number) => Math.round(x * 100);

function GBtn({ tone, onClick, children, className = '', disabled = false }: { tone: 'orange' | 'green' | 'dark' | 'red'; onClick: () => void; children: ReactNode; className?: string; disabled?: boolean }) {
  return (
    <button disabled={disabled} onClick={() => { audioInit(); snd.tap(); onClick(); }} className={`g-btn g-${tone} font-game overflow-hidden ${disabled ? 'opacity-50 saturate-50' : ''} ${className}`}>
      {children}
    </button>
  );
}

function Shell({ ribbon, tone = '', wide = false, children }: { ribbon: string; tone?: string; wide?: boolean; children: ReactNode }) {
  return (
    <div className="g-dead-backdrop absolute inset-0 z-20 grid place-items-center overflow-y-auto bg-[#01121b]/65 px-3 py-8">
      <div className={`g-pop relative w-full ${wide ? 'max-w-[34rem]' : 'max-w-[24.5rem]'}`}>
        <div className={`g-ribbon ${tone} font-game text-xl sm:text-2xl`}>{ribbon}</div>
        <div className="g-panel px-4 pb-5 pt-10 text-white sm:px-6">{children}</div>
      </div>
    </div>
  );
}

function Chip({ children, col = 'text-white' }: { children: ReactNode; col?: string }) {
  return <span className={`g-chip font-game flex items-center gap-1 px-2.5 py-1 text-xs leading-none ${col}`}>{children}</span>;
}

export function CardChip({ id, lv }: { id: CardId; lv: number }) {
  const d = CARD_BY[id];
  return (
    <span title={`${d.name} LV${lv}: ${cardText(id, lv)}`} className="g-chip font-game flex items-center gap-1 px-2 py-0.5 text-[11px] leading-none text-white" style={{ boxShadow: `inset 0 0 0 1.5px ${TYPE_COL[d.type]}` }}>
      <span className="text-sm">{d.icon}</span>{lv}
    </span>
  );
}

/** satu kartu: klik = pilih, tekan-tahan = detail level sekarang → berikutnya */
function CardFace({ id, lv, onPick }: { id: CardId; lv: number; onPick: () => void }) {
  const d = CARD_BY[id]; const next = Math.min(d.maxLv, lv + 1);
  const [hold, setHold] = useState(false); const timer = useRef(0); const held = useRef(false);
  return (
    <button
      onPointerDown={() => { held.current = false; window.clearTimeout(timer.current); timer.current = window.setTimeout(() => { held.current = true; setHold(true); }, 380); }}
      onPointerUp={() => { window.clearTimeout(timer.current); if (held.current) { setHold(false); return; } audioInit(); onPick(); }}
      onPointerLeave={() => { window.clearTimeout(timer.current); setHold(false); }}
      onContextMenu={(e) => e.preventDefault()}
      className="g-btn g-dark relative flex min-h-[12rem] select-none flex-col items-center gap-1 px-1.5 pb-2 pt-3 text-center"
      style={{ boxShadow: `inset 0 0 0 2px ${TYPE_COL[d.type]}` }}
    >
      <span className="font-game text-[10px] tracking-wider" style={{ color: TYPE_COL[d.type] }}>{d.type}</span>
      <span className="text-3xl leading-none">{d.icon}</span>
      <span className="font-game text-[12px] leading-tight sm:text-[13px]">{d.name}</span>
      <span className="flex gap-0.5">
        {Array.from({ length: d.maxLv }, (_, i) => <span key={i} className={`h-1.5 w-3 rounded-sm ${i < lv ? 'bg-[#ffb02e]' : i < next ? 'bg-[#5cf08a]' : 'bg-black/40'}`} />)}
      </span>
      <span className="text-[10px] font-extrabold leading-tight text-cyan-100/90">{cardText(id, next)}</span>
      <span className="mt-auto text-[9px] font-black text-white/45">{lv ? `LV${lv} → LV${next}` : 'BARU'} · TAHAN = DETAIL</span>
      {hold && (
        <span className="absolute inset-0 z-10 flex flex-col justify-center gap-1.5 rounded-2xl bg-[#031a24]/95 p-2 text-left">
          <span className="font-game text-xs text-[#ffd23f]">{d.name}</span>
          <span className="text-[10px] font-bold text-white/65">SEKARANG: {lv ? `LV${lv} · ${cardText(id, lv)}` : 'BELUM PUNYA'}</span>
          <span className="text-[10px] font-bold text-[#5cf08a]">BERIKUTNYA: LV{next} · {cardText(id, next)}</span>
        </span>
      )}
    </button>
  );
}

/** "LEVEL X SELESAI!" (juga hadiah bos & peti): 3 kartu + reroll */
export function CardPickPanel({ ui, w }: { ui: RUi; w: W }) {
  const r = ui.run; const lvOf = (id: CardId) => r.cards.find(([c]) => c === id)?.[1] ?? 0;
  const free = r.rerollCost === 0;
  return (
    <Shell ribbon={r.pickTitle || `LEVEL ${ui.level} SELESAI!`} wide>
      {ui.stage === 'shop' && (
        <div className="flex justify-center gap-1 text-4xl leading-none" aria-label={`${ui.stars} bintang`}>
          {[0, 1, 2].map((i) => <span key={i} className={i < ui.stars ? 'text-[#ffd23f] drop-shadow-[0_2px_0_#031a24]' : 'text-[#0a3140]'}>★</span>)}
        </div>
      )}
      <div className="mt-1 flex items-center justify-center gap-2">
        <Chip col="text-[#ffd23f]">🪙 {ui.coins}</Chip>
        <Chip col="text-[#5cf08a]">❤ {ui.hp}/{ui.maxHp}</Chip>
      </div>
      <p className="mt-2 text-center text-[11px] font-black tracking-wider text-cyan-100/80">PILIH 1 KARTU</p>
      {r.offer.length ? (
        <div className="mt-2 grid grid-cols-3 gap-2">
          {r.offer.map((id) => <CardFace key={id} id={id} lv={lvOf(id)} onPick={() => w()?.pickCard(id)} />)}
        </div>
      ) : (
        <div className="mt-3 text-center text-sm font-bold text-white/70">
          SEMUA KARTU SUDAH MAKS!
          <GBtn tone="green" onClick={() => w()?.skipPick()} className="mt-3 h-12 w-full text-lg">LANJUT</GBtn>
        </div>
      )}
      {r.offer.length > 0 && (
        <GBtn tone="orange" disabled={!free && r.rerollCost > ui.coins} onClick={() => w()?.reroll()} className="mt-3 h-11 w-full text-base">
          🎲 REROLL {free ? `GRATIS (${r.freeRerolls})` : `· ${r.rerollCost} EMAS`}
        </GBtn>
      )}
      {r.synergies.length > 0 && <div className="mt-2 text-center text-[10px] font-black text-[#b98cff]">SINERGI AKTIF: {r.synergies.join(' · ')}</div>}
    </Shell>
  );
}

/** pilih rute: AMAN | BERISIKO | PETI */
export function RoutePanel({ ui, w }: { ui: RUi; w: W }) {
  const r = ui.run; const R = CFG.route.risk;
  const opt = (k: 'aman' | 'risiko' | 'peti', icon: string, name: string, sub: string, disabled = false) => (
    <button
      key={k}
      disabled={disabled}
      onClick={() => { audioInit(); snd.tap(); w()?.chooseRoute(k); }}
      className={`g-btn g-dark flex w-full items-center gap-3 px-3 py-2.5 text-left ${disabled ? 'opacity-50 saturate-50' : ''}`}
    >
      <span className="text-3xl">{icon}</span>
      <span className="flex flex-col">
        <span className="font-game text-lg leading-tight">{name}</span>
        <span className="text-[10px] font-black leading-tight text-cyan-100/80">{sub}</span>
      </span>
    </button>
  );
  return (
    <Shell ribbon={`MENUJU LEVEL ${ui.level + 1}`} tone="blue">
      <p className="mb-2 text-center text-[11px] font-black tracking-wider text-cyan-100/80">PILIH RUTE</p>
      <div className="flex flex-col gap-2">
        {opt('aman', '🛡️', 'AMAN', 'MUSUH NORMAL')}
        {opt('risiko', '☠️', 'BERISIKO', `MUSUH +${pct(R.hp - 1)}% HP & +${pct(R.dmg - 1)}% DMG · EMAS +${pct(R.gold - 1)}%`)}
        {opt('peti', '🎁', 'PETI', r.lastChest ? 'BARU SAJA MEMBUKA PETI' : `${r.chestCost} EMAS · 1 KARTU ATAU HEAL PENUH · TANPA PERTEMPURAN`, !r.canChest)}
      </div>
      <div className="mt-3 flex justify-center gap-2">
        <Chip col="text-[#ffd23f]">🪙 {ui.coins}</Chip>
        <Chip col="text-[#5cf08a]">❤ {ui.hp}/{ui.maxHp}</Chip>
      </div>
    </Shell>
  );
}

/** peti: 1 kartu ATAU heal penuh */
export function ChestPanel({ ui, w }: { ui: RUi; w: W }) {
  if (ui.run.offer.length) return <CardPickPanel ui={ui} w={w} />;
  return (
    <Shell ribbon="PETI HARTA" tone="blue">
      <div className="text-center text-5xl">🎁</div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <GBtn tone="orange" onClick={() => w()?.chestCard()} className="h-20 flex-col gap-1 text-base"><span className="text-2xl">🃏</span>1 KARTU</GBtn>
        <GBtn tone="green" onClick={() => w()?.chestHeal()} className="h-20 flex-col gap-1 text-base"><span className="text-2xl">❤️</span>HEAL PENUH</GBtn>
      </div>
      <div className="mt-3 flex justify-center"><Chip col="text-[#5cf08a]">❤ {ui.hp}/{ui.maxHp}</Chip></div>
    </Shell>
  );
}

/** layar mati "SEKALI LAGI" */
export function DeathPanel({ ui, w, onMenu, onMeta }: { ui: RUi; w: W; onMenu: () => void; onMeta: () => void }) {
  const r = ui.run;
  const stat = (v: ReactNode, s: string) => (
    <div className="g-chip flex flex-col items-center rounded-2xl px-2 py-2">
      <span className="font-game text-xl leading-none text-white tabular-nums">{v}</span>
      <span className="mt-1 text-[9px] font-black tracking-wider text-cyan-200/75">{s}</span>
    </div>
  );
  return (
    <Shell ribbon="GAME OVER" tone="red">
      <div className="text-center">
        <div className="text-[11px] font-black tracking-[0.18em] text-cyan-100/70">DIBUNUH OLEH</div>
        <div className="font-game text-2xl leading-tight text-[#ff5a4f]">{r.killedBy}</div>
        {r.daily && <div className="mt-1 text-[10px] font-black text-[#7fe9f2]">HARIAN: {r.daily}</div>}
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        {stat(`LV.${ui.level}`, 'LEVEL DICAPAI')}
        {stat(ui.totalKills, 'TUMBANG')}
        {stat(r.goldEarned, 'EMAS DIDAPAT')}
      </div>
      <div className="font-game mt-2 text-center text-sm text-[#ffd23f]">+{r.metaGain} KOIN META ({pct(CFG.death.metaCarry)}% EMAS)</div>
      <div className="mt-2 flex flex-wrap justify-center gap-1">
        {r.cards.length ? r.cards.map(([id, lv]) => <CardChip key={id} id={id} lv={lv} />) : <span className="text-[11px] font-bold text-white/50">TANPA KARTU</span>}
      </div>
      {r.next && (
        <div className="mt-3">
          <div className="flex justify-between text-[10px] font-black text-cyan-100/80"><span>UNLOCK BERIKUTNYA</span><span>{pct(r.nextPct)}%</span></div>
          <div className="mt-1 h-3 overflow-hidden rounded-full border-2 border-[#031a24] bg-black/50">
            <div className="h-full bg-gradient-to-r from-[#ffb02e] to-[#ffd23f]" style={{ width: `${pct(r.nextPct)}%` }} />
          </div>
          <div className="font-game mt-1 text-center text-xs text-white">{r.next}</div>
        </div>
      )}
      {r.unlocks.length > 0 && <div className="mt-2 text-center text-[11px] font-black text-[#5cf08a]">TERBUKA: {r.unlocks.map((id) => unlockOf(id)?.name ?? id).join(', ')}</div>}
      <GBtn tone="orange" onClick={() => w()?.newRun(!!r.daily)} className="g-sheen mt-4 h-15 w-full text-2xl">↻ COBA LAGI</GBtn>
      <div className="mt-2 grid grid-cols-2 gap-2">
        <GBtn tone="dark" onClick={onMeta} className="h-11 text-xs text-[#ffd23f]">SKILL TREE</GBtn>
        <GBtn tone="dark" onClick={onMenu} className="h-11 text-xs text-cyan-100">🏠 MENU</GBtn>
      </div>
    </Shell>
  );
}

/** HUD saat bermain: kartu aktif, perisai, panah ganda, pemburu, tombol skill WAKTU MELAMBAT */
export function RunHud({ ui, w, onSkin }: { ui: RUi; w: W; onSkin?: () => void }) {
  const r = ui.run;
  const skin = SKIN_PERKS[ui.skin.id];
  return (
    <>
      <div className="pointer-events-none absolute left-2 top-36 z-10 flex max-w-[55%] flex-wrap gap-1 sm:left-3.5 sm:top-[7.4rem]">
        <button onClick={onSkin} aria-label={`Kemampuan skin: ${skin.name}`} title={skinPerkLines(ui.skin.id).join('\n')} className="pointer-events-auto relative mb-1 flex w-full max-w-[220px] items-center gap-2 overflow-hidden rounded-lg border border-white/15 bg-[#031a24]/85 px-2.5 py-1.5 text-left text-white transition hover:bg-[#123b50]">
          <span className="font-game text-xs" style={{ color: skin.color }}>{skin.mark}</span>
          <span className="min-w-0"><span className="font-game block truncate text-[10px]">{skin.name}</span><span className="block truncate text-[9px] font-bold" style={{ color: ui.skin.ready ? skin.color : '#adbfcc' }}>{ui.skin.label}</span></span>
          <span aria-hidden className="absolute inset-x-0 bottom-0 h-0.5 bg-white/10"><span className="block h-full transition-all" style={{ background: skin.color, width: `${ui.skin.progress * SKIN_RULES.percent}%` }} /></span>
        </button>
        {r.cards.filter(([id]) => id !== 'ganda').map(([id, lv]) => <CardChip key={id} id={id} lv={lv} />)}
        {r.gandaMax > 0 && <Chip col={r.ganda ? 'text-[#b98cff]' : 'text-white/40'}>🏹 {r.ganda}/{r.gandaMax}</Chip>}
        {r.hunter > 1 && <Chip col="text-[#ffe14d]">🎯 x{r.hunter}</Chip>}
        {r.shieldOn && <Chip col={r.shield >= 1 ? 'text-[#7fe9f2]' : 'text-white/50'}>🔰 {r.shield >= 1 ? 'SIAP' : `${pct(r.shield)}%`}</Chip>}
        {r.route === 'risiko' && <Chip col="text-[#ff5a4f]">☠️ BERISIKO</Chip>}
        {r.daily && <Chip col="text-[#7fe9f2]">📅 {r.daily}</Chip>}
      </div>
      {r.hasSlow && (
        <button
          onClick={() => w()?.activateSlow()}
          aria-label="Waktu melambat (Q)"
          className="font-game absolute bottom-20 right-3 z-10 grid h-16 w-16 place-items-center rounded-full border-4 border-[#031a24] text-[11px] text-white shadow-lg active:scale-95 sm:bottom-24"
          style={{ background: `conic-gradient(#5cc8ff ${r.slow * 360}deg, #0b2a3a 0deg)` }}
        >
          <span className="grid h-11 w-11 place-items-center rounded-full bg-[#041926]">{r.slowOn ? 'AKTIF' : r.slow >= 1 ? '⏳ Q' : `${pct(r.slow)}%`}</span>
        </button>
      )}
    </>
  );
}

/** notifikasi layar: unlock, sinergi, hadiah */
export function Toasts({ ui }: { ui: RUi }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-24 z-40 flex flex-col items-center gap-1.5 px-3">
      {ui.toasts.map((t) => (
        <div key={t.id} className="g-pop rounded-2xl border-2 border-[#031a24] bg-gradient-to-b from-[#165770] to-[#082736] px-4 py-2 text-center shadow-lg ring-2 ring-[#ffd23f]/60">
          <div className="font-game text-sm text-[#ffd23f]">{t.title}</div>
          {t.sub && <div className="text-[10px] font-black tracking-wider text-cyan-100">{t.sub}</div>}
        </div>
      ))}
    </div>
  );
}

/** DEBUG: beri kartu, lompat level, panggil bos, emas, unlock, reset */
export function DebugPanel({ w, onClose }: { w: W; onClose: () => void }) {
  const [lv, setLv] = useState(5);
  const g = w();
  const b = (label: string, fn: () => void) => (
    <button key={label} onClick={() => { audioInit(); fn(); }} className="font-game rounded-lg bg-white/10 px-2 py-1.5 text-[10px] hover:bg-white/20">{label}</button>
  );
  return (
    <div className="absolute right-2 top-24 z-50 w-72 rounded-2xl border-2 border-[#031a24] bg-[#041926]/95 p-3 text-white shadow-xl">
      <div className="mb-2 flex items-center justify-between"><span className="font-game text-sm text-[#ff5a4f]">DEBUG</span><button onClick={onClose} className="font-game px-2">✕</button></div>
      <div className="text-[10px] font-black text-cyan-100/70">BERI KARTU (+1 LV)</div>
      <div className="mt-1 grid grid-cols-5 gap-1">
        {CARDS.map((c) => <button key={c.id} title={c.name} onClick={() => g?.debugCard(c.id)} className="rounded-lg bg-white/10 py-1 text-lg hover:bg-white/20">{c.icon}</button>)}
      </div>
      <div className="mt-2 flex items-center gap-1">
        <input type="number" min={1} value={lv} onChange={(e) => setLv(Math.max(1, Number(e.target.value) || 1))} className="w-16 rounded bg-black/40 px-2 py-1 text-sm" />
        {b('LOMPAT LEVEL', () => g?.debugLevel(lv))}
      </div>
      <div className="mt-2 grid grid-cols-2 gap-1">
        {b('BOS BESAR', () => g?.debugBoss(true))}
        {b('MINI-BOS', () => g?.debugBoss(false))}
        {b('MENANG LEVEL', () => g?.debugClear())}
        {b('+500 EMAS', () => g?.debugGold(500))}
        {b('+1000 KOIN META', () => g?.debugMeta(1000))}
        {b('BUKA SEMUA', () => g?.debugUnlockAll())}
        {b('MAX POWER', () => g?.toggleMaxPower())}
        {b('RESET SAVE', () => { if (window.confirm('HAPUS SEMUA SAVE & TELEMETRI?')) g?.resetSave(); })}
      </div>
    </div>
  );
}

type Tab = 'POHON SKILL' | 'UNLOCK' | 'STATISTIK' | 'BUKU' | 'HARIAN' | 'ATUR';
const STAT_LABEL: [string, string][] = [
  ['runs', 'RUN DIMAINKAN'], ['bestLevel', 'LEVEL TERTINGGI'], ['kills', 'MUSUH TUMBANG'], ['headshots', 'HEADSHOT'],
  ['bestStreak', 'HEADSHOT BERUNTUN TERBAIK'], ['bigBossKills', 'BOS BESAR TUMBANG'], ['forts', 'ISTANA ROBOH'],
  ['hostages', 'TAWANAN BEBAS'], ['dragonMouth', 'TEMBAKAN MULUT NAGA'], ['shieldsBroken', 'PERISAI HANCUR'], ['coinsEarned', 'TOTAL EMAS'], ['deaths', 'KEMATIAN'],
];
const BOOK = ['archer', 'helm', 'heavy', 'shield', 'guard', 'rider', 'axer', 'boss', 'bat', 'dragon', 'fort'];

/** Progression uses the same outlined, pressable game UI as the arena and equipment menus. */
export function MetaModal({ ui, w, onClose, onDaily }: { ui: RUi | null; w: W; onClose: () => void; onDaily: () => void }) {
  const [tab, setTab] = useState<Tab>('POHON SKILL');
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const key = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); closeRef.current(); return; }
      if (event.key !== 'Tab') return;
      const focusable = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input, select, a[href], [tabindex="0"]') ?? []).filter((el) => el.getClientRects().length);
      const first = focusable[0]; const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || !dialogRef.current?.contains(document.activeElement))) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !dialogRef.current?.contains(document.activeElement))) { event.preventDefault(); first?.focus(); }
    };
    window.addEventListener('keydown', key, true);
    return () => { window.removeEventListener('keydown', key, true); if (previous?.isConnected) previous.focus(); };
  }, []);
  const g = w(); const m = g?.meta;
  if (!g || !m) return null;
  void ui?.metaRev; // digambar ulang tiap meta berubah
  const today = dailyInfo(new Date());
  const row = (k: ReactNode, v: ReactNode, key?: string) => (
    <div key={key} className="flex items-center justify-between gap-2 border-b border-white/10 py-1.5 text-xs font-bold"><span className="text-cyan-100/85">{k}</span><span className="font-game text-white">{v}</span></div>
  );
  const exportCsv = () => {
    const url = URL.createObjectURL(new Blob([g.exportCsv()], { type: 'text/csv' }));
    const a = document.createElement('a'); a.href = url; a.download = `ragdoll-telemetri-${today.key}.csv`; a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };
  const toggle = (k: 'slowmo' | 'dmgNum' | 'zoom' | 'trail' | 'thunk' | 'debug', label: string) => row(label, (
    <button onClick={() => g.setSetting(k, !m.settings[k])} className={`font-game rounded-lg px-3 py-1 text-[11px] ${m.settings[k] ? 'bg-[#2b9e37]' : 'bg-white/15'}`}>{m.settings[k] ? 'NYALA' : 'MATI'}</button>
  ), k);
  return (
    <div className="progress-backdrop">
      <div ref={dialogRef} className="progress-modal g-pop" role="dialog" aria-modal="true" aria-labelledby="progress-title">
        <div className="progress-shell">
          <header className="progress-header">
            <div className="progress-heading"><div className="progress-brand">RAGDOLL ARCHER / PROGRES PERMANEN</div><h2 id="progress-title" className="progress-title font-game">JALUR LEGENDA</h2></div>
            <div className="progress-header-actions">
              <div className="progress-wallet" aria-label={`${m.coins} koin meta`}><TreeIcon icon="coin" /><div><strong className="font-game">{m.coins.toLocaleString('id-ID')}</strong><small>KOIN META</small></div></div>
              <button onClick={onClose} className="progress-close" aria-label="Tutup progres"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" /></svg></button>
            </div>
          </header>
          <div className="progress-tabs" role="tablist" aria-label="Menu progres">
            {(['POHON SKILL', 'UNLOCK', 'STATISTIK', 'BUKU', 'HARIAN', 'ATUR'] as Tab[]).map((t) => (
              <button key={t} className="font-game" role="tab" id={`progress-tab-${t.replace(/\s/g, '-')}`} aria-selected={tab === t} aria-controls="progress-content" onClick={() => { audioInit(); snd.tap(); setTab(t); }}>{t}</button>
            ))}
          </div>
          <div id="progress-content" role="tabpanel" aria-labelledby={`progress-tab-${tab.replace(/\s/g, '-')}`} className={`progress-main ${tab === 'POHON SKILL' ? 'progress-main-tree' : 'progress-main-other'}`}>
            {tab === 'POHON SKILL' && <SkillTree meta={m} onBuy={(id) => g.buySkill(id)} inRun={!!ui && !ui.demo && ui.stage !== 'dead'} />}
            {tab === 'UNLOCK' && (
              <>
                <div className="font-game text-lg text-[#efd39a]">KOLEKSI & PENCAPAIAN</div>
                <div className="mt-2 text-[10px] font-black tracking-wider text-cyan-100/70">TERBUKA {m.unlocked.length}/{UNLOCKS.length}</div>
                {UNLOCKS.map((u) => {
                  const done = m.unlocked.includes(u.id); const val = Math.min(m.stats[u.stat], u.need);
                  return (
                    <div key={u.id} className="border-b border-white/10 py-1.5">
                      <div className="flex items-center justify-between gap-2 text-xs font-bold">
                        <span className={done ? 'text-[#5cf08a]' : 'text-white'}>{done ? '✓ ' : '🔒 '}{u.name}</span>
                        {!done && u.cost !== undefined && <button onClick={() => g.buyUnlock(u.id)} className="font-game rounded-lg bg-[#ffb02e] px-2 py-0.5 text-[10px] text-[#031a24]">🪙 {u.cost}</button>}
                      </div>
                      {!done && (
                        <div className="mt-0.5 flex items-center gap-2 text-[10px] font-black text-cyan-100/70">
                          <span className="min-w-0 flex-1 truncate">{u.label}</span>
                          <span className="h-1.5 w-20 overflow-hidden rounded-full bg-black/50"><span className="block h-full bg-[#ffd23f]" style={{ width: `${pct(val / u.need)}%` }} /></span>
                          <span>{val}/{u.need}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
                <div className="mt-3 text-[10px] font-black tracking-wider text-cyan-100/70">KOSMETIK</div>
                {row('WARNA IKAT', (
                  <span className="flex gap-1">{Object.entries(COSMETICS.band).map(([id, c]) => (
                    <button key={id} title={id.toUpperCase()} onClick={() => g.setCosmetic('band', id)} className={`h-6 w-6 rounded-full border-2 ${m.cos.band === id ? 'border-white' : 'border-black/50'} ${m.unlocked.includes(c.unlock) || !c.unlock ? '' : 'opacity-30'}`} style={{ background: c.col }} />
                  ))}</span>
                ))}
                {row('JEJAK PANAH', (
                  <span className="flex gap-1">{Object.entries(COSMETICS.trail).map(([id, c]) => (
                    <button key={id} onClick={() => g.setCosmetic('trail', id)} className={`font-game rounded-lg px-2 py-0.5 text-[10px] ${m.cos.trail === id ? 'bg-white text-[#031a24]' : 'bg-white/10'} ${m.unlocked.includes(c.unlock) || !c.unlock ? '' : 'opacity-30'}`}>{id.toUpperCase()}</button>
                  ))}</span>
                ))}
                <div className="mt-1 text-[10px] font-bold text-white/50">TOPI TERKUNCI DIBUKA LEWAT PENCAPAIAN (LIHAT DAFTAR DI ATAS) · PILIH DI MENU SKIN</div>
              </>
            )}
            {tab === 'STATISTIK' && (
              <>
                {STAT_LABEL.map(([k, l]) => row(l, m.stats[k as keyof typeof m.stats], k))}
                {row('WAKTU BERMAIN', `${Math.round(m.stats.playSec / 60)} MENIT`)}
                <div className="mt-3 text-[10px] font-black tracking-wider text-cyan-100/70">PENYEBAB MATI TERBANYAK</div>
                {Object.entries(m.diedTo).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => row(k, v, k))}
                <GBtn tone="green" onClick={exportCsv} className="mt-3 h-11 w-full text-sm">⬇ EKSPOR CSV TELEMETRI ({readLogs().length} RUN)</GBtn>
              </>
            )}
            {tab === 'BUKU' && (
              <div className="grid grid-cols-2 gap-1.5">
                {BOOK.map((k) => {
                  const seen = m.seen.includes(k);
                  return (
                    <div key={k} className="g-chip rounded-xl px-2 py-2 text-center">
                      <div className="font-game text-xs">{seen ? FOE_NAMES[k] : '???'}</div>
                      <div className="text-[10px] font-black text-cyan-100/70">{seen ? `TUMBANG: ${m.killsBy[k] ?? 0}` : 'BELUM DITEMUI'}</div>
                    </div>
                  );
                })}
              </div>
            )}
            {tab === 'HARIAN' && (
              <>
                {row('TANGGAL', today.key)}
                {row('MODIFIER HARI INI', MOD_LABEL[today.mod])}
                <div className="mt-1 text-[10px] font-bold text-white/60">SEED SAMA UNTUK SEMUA PEMAIN HARI INI (KARTU & MUSUH).</div>
                <GBtn tone="orange" onClick={onDaily} className="mt-3 h-12 w-full text-lg">📅 MAIN HARIAN</GBtn>
                <div className="mt-3 text-[10px] font-black tracking-wider text-cyan-100/70">PAPAN SKOR LOKAL · {today.key}</div>
                {board(m, today.key).length ? board(m, today.key).map((e, i) => row(`#${i + 1} · LV.${e.level} · ${e.kills} KILL`, e.score, String(e.at))) : <div className="py-2 text-xs font-bold text-white/50">BELUM ADA SKOR HARI INI</div>}
              </>
            )}
            {tab === 'ATUR' && (
              <>
                {row('GETARAN LAYAR', (
                  <span className="flex gap-1">{[0, 0.5, 1].map((s) => (
                    <button key={s} onClick={() => g.setSetting('shake', s)} className={`font-game rounded-lg px-2 py-1 text-[10px] ${m.settings.shake === s ? 'bg-[#2b9e37]' : 'bg-white/15'}`}>{pct(s)}%</button>
                  ))}</span>
                ))}
                {toggle('slowmo', 'SLOW-MO KILL')}
                {toggle('dmgNum', 'ANGKA DAMAGE')}
                {toggle('zoom', 'ZOOM HEADSHOT')}
                {toggle('trail', 'JEJAK PANAH')}
                {toggle('thunk', 'SUARA THUNK')}
                {toggle('debug', 'MODE DEBUG (TOMBOL DBG / `)')}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
