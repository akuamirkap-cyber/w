// Tes unit logika kartu & rumus (dijalankan: node scripts/test.mjs)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CARDS, CFG, CardId } from '../config';
import { CARD_BY, activeSynergies, cardLv, hunterMult, levelMods, newRunState, pierceDmg, playerDmgMult, playerMaxHp, rerollCost, rollOffer, takeCard, useReroll } from '../cards';
import { arrowDmg, bigFoeLevel, enemyHp, killReward, lateHpMult, levelCounts } from '../formulas';
import { mulberry32 } from '../meta';

const all = () => true;
const unlockedDefault = (id: CardId) => !CARD_BY[id].locked;

test('HP bos senjata asli: L3 = 273, L5 = 360 (bukan 250/334)', () => {
  assert.equal(enemyHp(3, bigFoeLevel(3), true), 273);
  assert.equal(enemyHp(5, bigFoeLevel(5), true), 360);
  assert.equal(enemyHp(14, 1, false), enemyHp(20, 1, false)); // HP dasar berhenti di L14
  assert.equal(lateHpMult(14), 1);
  assert.ok(lateHpMult(15) > 1);
});

test('damage panah identik kode lama (42 × busur × (0.45 + 0.65 × tarikan))', () => {
  assert.ok(Math.abs(arrowDmg(1, 'thunder') - 42 * 1.25 * 1.1) < 1e-9);
  assert.equal(arrowDmg(0.5, 'wood'), 42 * (0.45 + 0.325));
  assert.equal(killReward('axer', true), 65);
  assert.deepEqual(levelCounts(1), { foot: 3, bats: 1, alive: 2 });
});

test('set 3 kartu: 1 PANAH + 1 BERTAHAN + 1 RISIKO, tanpa kembar, tanpa GANDA', () => {
  const rng = mulberry32(42);
  for (let i = 0; i < 2000; i++) {
    const r = newRunState(1);
    const offer = rollOffer(rng, r, all);
    assert.equal(offer.length, 3);
    assert.equal(new Set(offer).size, 3);
    assert.deepEqual(offer.map((id) => CARD_BY[id].type), ['PANAH', 'BERTAHAN', 'RISIKO']);
    assert.ok(!offer.includes('ganda'));
  }
});

test('kartu terkunci & level maks tidak muncul; slot kosong diisi kartu lain tanpa kembar', () => {
  const rng = mulberry32(7);
  const r = newRunState(0);
  r.cards.pedang = 3; r.cards.kontrak = 3; // RISIKO habis
  r.cards.petir = 3;
  for (let i = 0; i < 1000; i++) {
    const offer = rollOffer(rng, r, unlockedDefault);
    assert.equal(new Set(offer).size, offer.length);
    for (const id of offer) {
      assert.ok(cardLv(r, id) < CARD_BY[id].maxLv, `maks muncul: ${id}`);
      assert.ok(!CARD_BY[id].locked, `terkunci muncul: ${id}`);
      assert.notEqual(id, 'ganda');
    }
  }
  for (const c of CARDS) r.cards[c.id] = c.maxLv;
  assert.deepEqual(rollOffer(rng, r, all), []);
});

test('kartu sama = naik level, berhenti di maks; sinergi terdeteksi sekali', () => {
  const r = newRunState(1);
  takeCard(r, 'petir'); takeCard(r, 'petir'); takeCard(r, 'petir'); takeCard(r, 'petir');
  assert.equal(cardLv(r, 'petir'), 3);
  assert.deepEqual(takeCard(r, 'tembus'), ['PETIR MENEMBUS']);
  assert.deepEqual(takeCard(r, 'tembus'), []);
  takeCard(r, 'nyawa2'); takeCard(r, 'nyawa2'); takeCard(r, 'nyawa2');
  assert.equal(cardLv(r, 'nyawa2'), 2);
  assert.equal(activeSynergies(r.cards).length, 1);
});

test('reroll: gratis dulu, lalu 30/45/60/60', () => {
  const r = newRunState(1);
  assert.equal(rerollCost(r), 0); useReroll(r);
  const seen: number[] = [];
  for (let i = 0; i < 4; i++) { seen.push(rerollCost(r)); useReroll(r); }
  assert.deepEqual(seen, [30, 45, 60, 60]);
  assert.equal(r.rerolls, 5);
});

test('pengali: pedang, pemburu (maks x2), tembus, kontrak/rute', () => {
  const r = newRunState(0);
  assert.equal(playerMaxHp(r, 0), CFG.player.baseHp);
  assert.equal(playerMaxHp(r, 5), 115);
  takeCard(r, 'pedang');
  assert.equal(playerMaxHp(r, 0), 75);
  assert.ok(Math.abs(playerDmgMult(r) - 1.4) < 1e-9);
  r.cards.pemburu = 3; r.hunterStacks = 50;
  assert.equal(hunterMult(r), 2);
  assert.ok(Math.abs(pierceDmg(100, 2) - 72.25) < 1e-9);
  r.route = 'risiko'; takeCard(r, 'kontrak');
  const m = levelMods(r, 1, 1, 1);
  assert.ok(Math.abs(m.hp - 1.25 * 1.25) < 1e-9);
  assert.equal(m.gold, 1.5 * 2);
});

test('PANAH GANDA: 12 tembakan per level, tidak dijual', () => {
  const r = newRunState(0);
  takeCard(r, 'ganda');
  assert.equal(r.gandaLeft, 12);
  assert.equal(CARD_BY.ganda.type, 'KHUSUS');
});
