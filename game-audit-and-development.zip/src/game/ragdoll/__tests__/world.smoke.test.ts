// Tes integrasi headless: RagWorld asli (tanpa DOM) dijalankan melewati satu run penuh.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RagWorld } from '../game';
import { CARD_BY } from '../cards';
import { CFG } from '../config';
import { MetaSave } from '../meta';

type Any = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
const tick = (w: RagWorld, sec: number, until?: () => boolean) => {
  for (let i = 0; i < sec * 60; i++) { w.update(1 / 60); if (until?.()) return; }
};

test('satu run penuh: menang → kartu → reroll → rute → bos besar → Panah Ganda → mati → meta → run baru', () => {
  const w = new RagWorld(() => {}, () => ({}) as never, false);
  const W = w as unknown as Any;
  w.startRun();
  assert.equal(w.stage, 'play'); assert.equal(w.level, 1); assert.equal(w.bow, 'wood');
  tick(w, 1.5);
  w.debugClear();
  tick(w, 6, () => w.stage === 'shop');
  assert.equal(w.stage, 'shop', 'layar kartu muncul setelah level selesai');
  assert.equal(w.offer.length, 3);
  assert.equal(new Set(w.offer).size, 3);
  assert.deepEqual(w.offer.map((id) => CARD_BY[id].type), ['PANAH', 'BERTAHAN', 'RISIKO']);
  assert.ok(!w.offer.includes('ganda'), 'Panah Ganda tidak pernah ditawarkan');
  const coinsBefore = w.coins;
  w.reroll();
  assert.equal(w.coins, coinsBefore, 'reroll pertama gratis');
  assert.equal(w.run.freeRerolls, 0);
  w.pickCard(w.offer[0]);
  assert.equal(w.stage, 'route');
  w.chooseRoute('risiko');
  assert.equal(w.level, 2); assert.equal(w.stage, 'play'); assert.equal(w.run.route, 'risiko');

  // bos besar tiap 5 level: HP besar, hadiah Panah Ganda + kartu bonus
  w.debugLevel(5);
  tick(w, 0.6);
  w.debugBoss(true);
  const boss = (W.foes as Any[]).find((f) => f.bigBoss);
  assert.ok(boss, 'bos besar muncul');
  assert.ok(boss.maxHp > 360 * CFG.bigBoss.hpMult * 0.99, `HP bos besar ${boss.maxHp}`);
  W.die(boss, true);
  assert.equal(w.run.bossPending, 1);
  w.debugClear();
  tick(w, 6, () => w.stage === 'shop');
  assert.equal(w.stage, 'shop');
  assert.equal(w.pickTitle, 'HADIAH BOS BESAR!');
  assert.equal(w.run.cards.ganda, 1);
  assert.equal(w.run.gandaLeft, CFG.cards.ganda.shots[0]);
  w.pickCard(w.offer[0]);
  assert.equal(w.stage, 'shop', 'setelah hadiah bos masih ada pilihan kartu level');
  w.pickCard(w.offer[0]);
  assert.equal(w.stage, 'route');

  // peti: bayar emas → heal penuh, lalu tidak bisa peti lagi berturut-turut
  w.debugGold(500);
  w.chooseRoute('peti');
  assert.equal(w.stage, 'chest');
  w.chestHeal();
  assert.equal(w.stage, 'route'); assert.equal(w.run.lastChest, true);
  const g = w.coins; w.chooseRoute('peti');
  assert.equal(w.stage, 'route'); assert.equal(w.coins, g);
  w.chooseRoute('aman');
  assert.equal(w.stage, 'play');

  // mati → layar mati, 50% emas ke meta, statistik, telemetri; kartu reset di run baru
  const earned = w.run.goldEarned;
  const pf = W.player as Any;
  pf.hp = 0; W.die(pf, false);
  assert.equal(w.stage, 'dying');
  tick(w, 4, () => w.stage === 'dead');
  assert.equal(w.stage, 'dead');
  const m = w.meta as MetaSave;
  assert.equal(m.stats.runs, 1);
  assert.equal(m.coins, Math.floor(earned * CFG.death.metaCarry));
  assert.ok(w.exportCsv().split('\n').length >= 2, 'telemetri tercatat');
  w.newRun();
  assert.equal(w.level, 1); assert.deepEqual(w.run.cards, {}); assert.equal(w.stage, 'play');
  assert.equal(w.coins, CFG.run.startGold);
});

test('NYAWA KEDUA, PERISAI, PANAH TEMBUS & harian berjalan tanpa error', () => {
  const w = new RagWorld(() => {}, () => ({}) as never, false);
  const W = w as unknown as Any;
  w.startRun();
  w.debugCard('nyawa2'); w.debugCard('perisai'); w.debugCard('tembus'); w.debugCard('petir'); w.debugCard('lambat');
  assert.deepEqual(w.run.synergies, ['petir_tembus']);
  const pf = W.player as Any;
  pf.hp = 0; W.die(pf, false);
  assert.equal(w.stage, 'play', 'hidup lagi');
  assert.ok(pf.hp > 0 && w.run.reviveUsed);
  assert.equal(W.shieldTry({ x: 0, y: 0 }), true);
  assert.equal(W.shieldTry({ x: 0, y: 0 }), false, 'perisai cooldown');
  w.activateSlow();
  assert.ok(w.run.slowT > 0 && w.run.slowCd > 0);
  tick(w, 8); // pertempuran berjalan dengan semua kartu aktif
  w.queueDaily = true; w.toDemo(); w.startRun();
  assert.ok(w.run.daily.length === 10 && w.run.mod.length > 0, 'run harian ber-seed + modifier');
  tick(w, 2);
});
