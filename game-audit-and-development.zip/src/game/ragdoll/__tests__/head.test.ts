// Regression coverage for scalp attachment, recoil, mirroring and rendering.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Ctx, v } from '../../util';
import { Slab2, makeStick, stepStick, impulse } from '../stick';
import { HEAD_STYLES, drawHead, drawHeadBack, makeHair, stepHair } from '../head';
import { HAIR_ART, HAIR_IRISES, REFINED_HAIR, RefinedHairId } from '../config';
import { hairPoint, makeCutMotion, stepCutMotion } from '../haircuts';
import { SKIN_LIST } from '../../../SkinModal';
import { hatUnlocked, newMeta } from '../meta';

function mockCanvas() {
  const calls = { n: 0, colors: [] as string[] };
  const saved: number[] = [];
  let alpha = 0.45;
  const grad = { addColorStop(offset: number, color: string) { assert.ok(offset >= 0 && offset <= 1); calls.colors.push(color); } };
  const ctx = new Proxy({} as Record<string, unknown>, {
    get: (_t, p) => {
      if (p === 'globalAlpha') return alpha;
      if (p === 'save') return () => saved.push(alpha);
      if (p === 'restore') return () => { assert.ok(saved.length); alpha = saved.pop()!; };
      return (...args: unknown[]) => {
        for (const value of args) if (typeof value === 'number') assert.ok(Number.isFinite(value), `NON-FINITE ${String(p)}`);
        calls.n++;
        if (p === 'createLinearGradient' || p === 'createRadialGradient') return grad;
      };
    },
    set: (_t, p, value) => { if (p === 'globalAlpha') alpha = Number(value); return true; },
  }) as unknown as Ctx;
  return { ctx, calls, saved };
}

test('semua potongan tetap melekat dan stabil saat recoil, membidik, salto, dan mati', () => {
  const { ctx, calls, saved } = mockCanvas();
  const slabs: Slab2[] = [{ x0: -60, x1: 60, top: 0, bot: 30 }];
  for (const style of Object.keys(REFINED_HAIR) as RefinedHairId[]) {
    assert.ok(HEAD_STYLES.includes(style));
    const k = makeStick(v(0, 0), 1, 1, false, true);
    k.seed = 0.42;
    const hair = makeHair(style, k);
    assert.ok(hair?.cut, `${style}: HAS SCALP-BOUND MOTION`);
    assert.equal(hair.locks.length, 0, 'NO DUPLICATE VERLET SPIKES');
    const before = calls.n;
    for (let i = 0; i < 1800; i++) {
      k.base = v(0, 0); k.vigor = 1; k.muscle = 1; k.nock = 1;
      if (i === 200) { k.pull = 1; k.aiming = 1; }
      if (i === 400) { impulse(k, 0, v(-280, -50)); k.pull = 0; }
      if (i >= 600 && i < 1000) { k.victory = (i - 600) / 120; k.victoryStyle = 0; }
      if (i === 1000) k.victory = 0;
      if (i === 1400) { k.alive = false; k.muscle = 0; }
      stepStick(k, slabs); stepHair(k, hair);
      for (const value of Object.values(hair.cut)) assert.ok(Number.isFinite(value), `${style}: MOTION FINITE`);
      assert.ok(Math.abs(hair.cut.sway) <= HAIR_ART.motion.limit, `${style}: NO EXPLODING CROWN`);
      assert.ok(Math.abs(hair.cut.fringe) <= HAIR_ART.motion.limit, `${style}: NO DETACHED BANGS`);
      if (i % 100 === 0) {
        drawHeadBack(ctx, k, style, hair);
        drawHead(ctx, k, style, hair, i / 120);
        assert.equal(saved.length, 0, 'BALANCED CANVAS SAVE/RESTORE');
        assert.equal(ctx.globalAlpha, 0.45, 'PRESERVE FIGHTER FADE');
      }
    }
    assert.ok(calls.n > before + 40, `${style} menggambar sesuatu`);
  }
});

test('akar rambut tidak bergerak; hanya ujungnya bereaksi', () => {
  const k = makeStick(v(0, 0), 1, 1, false, true);
  const motion = makeCutMotion(k);
  motion.sway = HAIR_ART.motion.limit;
  motion.fringe = -HAIR_ART.motion.limit;
  assert.deepEqual(hairPoint(-2, HAIR_ART.motion.crownAnchor, 'crown', motion), [-2, HAIR_ART.motion.crownAnchor]);
  assert.deepEqual(hairPoint(3, HAIR_ART.motion.fringeAnchor, 'fringe', motion), [3, HAIR_ART.motion.fringeAnchor]);
  assert.deepEqual(hairPoint(-8, 0, 'fixed', motion), [-8, 0]);
  assert.notEqual(hairPoint(0, -30, 'crown', motion)[0], 0);
  assert.notEqual(hairPoint(-4, 8, 'fringe', motion)[0], -4);
});

test('rambut direset saat teleport atau berbalik arah tanpa terseret', () => {
  const k = makeStick(v(0, 0), 1, 1, false, true);
  const motion = makeCutMotion(k);
  motion.sway = 0.7;
  k.face = -1;
  stepCutMotion(k, motion);
  assert.equal(motion.sway, 0);
  motion.fringe = -1;
  k.p[0].x += 500;
  stepCutMotion(k, motion);
  assert.equal(motion.fringe, 0);
  const { ctx } = mockCanvas();
  for (const style of Object.keys(REFINED_HAIR) as RefinedHairId[]) {
    drawHeadBack(ctx, k, style, null);
    drawHead(ctx, k, style, null, 0);
  }
});

test('fisika skin rambut lama tidak diganti', () => {
  const k = makeStick(v(0, 0), 1, 1, false, true);
  for (const style of ['sephiroth', 'guts', 'luffy', 'sanji', 'sekiro'] as const) {
    const hair = makeHair(style, k);
    assert.ok(hair?.locks.length);
    assert.equal(hair.cut, undefined);
  }
});

test('empat skin tambahan terdaftar, unik, gratis, dan tidak mengganti Gojo lama', () => {
  const meta = newMeta();
  assert.equal(new Set(HEAD_STYLES).size, HEAD_STYLES.length);
  assert.equal(new Set(SKIN_LIST.map((s) => s.id)).size, SKIN_LIST.length);
  for (const id of ['jinwoo', 'vergil', 'gojo_blue', 'rengoku'] as const) {
    assert.ok(HEAD_STYLES.includes(id));
    assert.ok(SKIN_LIST.some((s) => s.id === id));
    assert.ok(hatUnlocked(meta, id));
    assert.ok(REFINED_HAIR[id].outline.path);
  }
  assert.ok(HEAD_STYLES.includes('gojo'));
  assert.ok(REFINED_HAIR.gojo.accessory.length);
  assert.equal(REFINED_HAIR.gojo_blue.accessory.length, 0);
  assert.equal(REFINED_HAIR.gojo_blue.back.length, 0, 'NO BLINDFOLD TAILS');
  assert.equal(REFINED_HAIR.gojo_blue.eye, 'sixEyes');
});

test('Gojo Six Eyes memakai iris biru; kedip dan kematian tidak meninggalkan mata tambahan', () => {
  const { ctx, calls } = mockCanvas();
  const k = makeStick(v(0, 0), 1, 1, false, true);
  k.lid = 0; k.hurt = 0; k.happy = 0; k.react = 'none';
  const hair = makeHair('gojo_blue', k);
  drawHead(ctx, k, 'gojo_blue', hair, 0);
  assert.ok(calls.colors.includes(HAIR_IRISES.sixEyes.middle));
  assert.ok(calls.colors.includes(HAIR_IRISES.sixEyes.rim));
  calls.colors = [];
  k.lid = 1;
  drawHead(ctx, k, 'gojo_blue', hair, 0);
  assert.ok(!calls.colors.includes(HAIR_IRISES.sixEyes.middle));
  calls.colors = [];
  k.lid = 0; k.alive = false;
  drawHead(ctx, k, 'gojo_blue', hair, 0);
  assert.ok(!calls.colors.includes(HAIR_IRISES.sixEyes.middle));
});

test('surai Rengoku bergerak di ujung dengan akar tetap dan gradasi merah yang valid', () => {
  const k = makeStick(v(0, 0), 1, 1, false, true);
  const motion = makeCutMotion(k);
  motion.sway = HAIR_ART.motion.limit; motion.fringe = HAIR_ART.motion.limit;
  const root = [-8, HAIR_ART.motion.maneAnchor] as const;
  assert.deepEqual(hairPoint(...root, 'mane', motion), [...root]);
  const tip = hairPoint(-8, 32, 'mane', motion);
  assert.ok(Math.abs(tip[0] + 8) <= HAIR_ART.motion.limit * HAIR_ART.motion.maneFlex + 1e-9);
  assert.ok(tip[0] > -8);
  for (const piece of REFINED_HAIR.rengoku.back) {
    assert.ok(piece.gradient?.every(Number.isFinite));
    for (const [stop] of piece.stops ?? []) assert.ok(stop >= 0 && stop <= 1);
  }
});
