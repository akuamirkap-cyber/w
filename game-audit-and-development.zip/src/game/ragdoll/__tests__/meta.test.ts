// Tes unit save lokal, unlock, meta upgrade, telemetri CSV, tantangan harian
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CFG } from '../config';
import { KV, META_KEY, addDaily, board, bowUnlocked, buyMetaUp, buyUnlock, cardUnlocked, dailyInfo, evaluateUnlocks, loadMeta, logRun, mulberry32, newMeta, nextUnlock, readLogs, saveMeta, toCsv } from '../meta';

const mem = (): KV => { const m = new Map<string, string>(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => void m.set(k, v) }; };

test('save lokal terbaca ulang (simulasi reload) & data rusak → default', () => {
  const kv = mem();
  const m = newMeta(); m.coins = 123; m.stats.forts = 2; m.unlocked.push('bow:fire'); m.settings.shake = 0.5;
  saveMeta(m, kv);
  const back = loadMeta(kv);
  assert.equal(back.coins, 123); assert.equal(back.stats.forts, 2); assert.equal(back.settings.shake, 0.5);
  assert.ok(bowUnlocked(back, 'fire'));
  kv.setItem(META_KEY, '{rusak');
  assert.equal(loadMeta(kv).coins, 0);
  kv.setItem(META_KEY, JSON.stringify({ coins: 9 }));
  const partial = loadMeta(kv);
  assert.equal(partial.coins, 9); assert.equal(partial.stats.kills, 0); assert.equal(partial.settings.slowmo, true);
});

test('busur selain WOOD terkunci di awal, dibuka lewat pencapaian (bukan beli)', () => {
  const m = newMeta();
  assert.ok(bowUnlocked(m, 'wood'));
  for (const b of ['fire', 'spike', 'poison', 'gold', 'thunder', 'legend']) assert.ok(!bowUnlocked(m, b));
  assert.equal(buyUnlock(m, 'bow:fire'), false);
  m.stats.forts = 2;
  assert.deepEqual(evaluateUnlocks(m).map((u) => u.id), ['bow:fire']);
  assert.deepEqual(evaluateUnlocks(m), []);
  assert.ok(bowUnlocked(m, 'fire'));
});

test('kartu terkunci dibuka via koin meta atau pencapaian', () => {
  const m = newMeta();
  assert.ok(!cardUnlocked(m, 'paku')); assert.ok(cardUnlocked(m, 'petir'));
  m.coins = 149; assert.equal(buyUnlock(m, 'card:paku'), false);
  m.coins = 150; assert.equal(buyUnlock(m, 'card:paku'), true);
  assert.equal(m.coins, 0); assert.ok(cardUnlocked(m, 'paku'));
  m.stats.bestStreak = 5; evaluateUnlocks(m);
  assert.ok(cardUnlocked(m, 'ledak'));
});

test('meta kecil: Nyawa Awal maks Lv5, reroll +1 maks 1', () => {
  const m = newMeta(); m.coins = 99999;
  for (let i = 0; i < 9; i++) buyMetaUp(m, 'hp');
  assert.equal(m.up.hp, CFG.meta.hpMaxLv);
  buyMetaUp(m, 'reroll'); buyMetaUp(m, 'reroll');
  assert.equal(m.up.reroll, 1);
});

test('bar progres: "N KOIN LAGI: GOLDEN MIDAS"', () => {
  const m = newMeta();
  m.unlocked = ['bow:fire', 'card:paku', 'cos:band_kuning', 'bow:spike', 'card:tameng', 'cos:trail_api', 'bow:poison', 'card:ledak', 'cos:hat_sephiroth', 'card:pemburu', 'cos:band_biru', 'bow:thunder', 'cos:trail_pelangi', 'bow:legend', 'cos:hat_guts'];
  m.stats.coinsEarned = 1460;
  assert.deepEqual(nextUnlock(m), { text: '40 KOIN LAGI: GOLDEN MIDAS', pct: 1460 / 1500 });
});

test('telemetri: log terbatas & CSV ter-escape', () => {
  const kv = mem();
  const row = { run: 1, date: '2026-01-01', session: 's', sessionSec: 10, level: 4, cause: 'KAPAK, "VIKING"', picked: 'petir:1', rejected: 'pedang;lifesteal', durSec: 300, rerolls: 1, unlocks: '', daily: '', gold: 210 };
  logRun(row, kv); logRun({ ...row, run: 2 }, kv);
  const logs = readLogs(kv);
  assert.equal(logs.length, 2);
  const csv = toCsv(logs).split('\n');
  assert.equal(csv[0].split(',')[0], 'run');
  assert.ok(csv[1].includes('"KAPAK, ""VIKING"""'));
});

test('harian: seed & modifier sama untuk tanggal sama, papan skor lokal urut', () => {
  const a = dailyInfo(new Date(2026, 4, 3, 9)); const b = dailyInfo(new Date(2026, 4, 3, 22));
  assert.deepEqual(a, b);
  const r1 = mulberry32(a.seed); const r2 = mulberry32(b.seed);
  for (let i = 0; i < 20; i++) assert.equal(r1(), r2());
  const m = newMeta();
  addDaily(m, { date: a.key, mod: a.mod, score: 100, level: 1, kills: 0, at: 1 });
  addDaily(m, { date: a.key, mod: a.mod, score: 900, level: 3, kills: 5, at: 2 });
  assert.deepEqual(board(m, a.key).map((e) => e.score), [900, 100]);
});
