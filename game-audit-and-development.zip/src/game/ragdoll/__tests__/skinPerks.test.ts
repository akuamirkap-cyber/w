import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SKIN_PERKS, SKIN_RULES, SkinId } from '../config';
import { HEAD_STYLES } from '../head';
import { applySkinBurn, consumeSkinBarrier, newSkinRuntime, nextSkinLevel, peekSkinShot, skinHitMult, skinIncomingMult, skinKill, skinKillGoldMult, skinParry, skinPerkLines, skinReloadMult, skinStatus, stepSkinBurn, takeSkinShot, tickSkinRuntime } from '../skinPerks';

const close = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-8, `${a} != ${b}`);

test('semua 18 skin punya identitas, bonus, dan teks angka dari config', () => {
  assert.equal(HEAD_STYLES.length, 18);
  assert.deepEqual(Object.keys(SKIN_PERKS).sort(), [...HEAD_STYLES].sort());
  assert.equal(new Set(Object.values(SKIN_PERKS).map((p) => p.name)).size, 18);
  for (const id of HEAD_STYLES) {
    const lines = skinPerkLines(id);
    assert.ok(lines.length && lines.every((line) => line === line.toUpperCase()));
    assert.ok(lines.some((line) => /\d/.test(line)), id);
    const shot = peekSkinShot(id, newSkinRuntime(), 1, 1);
    for (const n of Object.values(shot)) if (typeof n === 'number') assert.ok(Number.isFinite(n));
  }
});

test('bonus pasif: laju, isi panah, ketahanan, kepala, dorongan, dan gravitasi', () => {
  const state = newSkinRuntime();
  close(peekSkinShot('band', state, 1, 1).speed, 1.12);
  close(skinReloadMult('band'), 1.1);
  close(peekSkinShot('racer', state, 1, 1).speed, 1.22);
  close(skinIncomingMult('racer', true), 0.75);
  close(skinIncomingMult('racer', false), 1);
  close(skinIncomingMult('luffy'), 0.88);
  close(peekSkinShot('luffy', state, 1, 1).knock, 1.5);
  close(skinReloadMult('levi'), 1.2);
  close(skinHitMult(peekSkinShot('levi', state, 1, 1), false, true), 1.35);
  close(skinHitMult(peekSkinShot('levi', state, 1, 1), true, false), 1);
  close(peekSkinShot('gojo_blue', state, 1, 1).gravity, 0.75);
  close(skinHitMult(peekSkinShot('gojo_blue', state, 1, 1), true, false), 1.18);
});

test('tembakan spesial tepat di ke-3/ke-4, satu hitungan per tarikan', () => {
  for (const [id, cadence] of [['sanji', 3], ['punk', 4], ['vergil', 4]] as [SkinId, number][]) {
    const state = newSkinRuntime();
    for (let n = 1; n <= 12; n++) {
      assert.equal(takeSkinShot(id, state, 1, 1).proc, n % cadence === 0);
      assert.equal(state.shots[id], n);
    }
  }
});

test('preview lintasan tidak memakan hitungan atau charge', () => {
  const state = newSkinRuntime(); state.shadowReady = true;
  const original = JSON.stringify(state);
  for (let n = 0; n < 100; n++) peekSkinShot('jinwoo', state, 1, 1);
  assert.equal(JSON.stringify(state), original);
  takeSkinShot('jinwoo', state, 1, 1);
  assert.equal(state.shadowReady, false);
});

test('tarikan penuh dan berserker hanya aktif pada kondisi tepat', () => {
  const state = newSkinRuntime();
  close(peekSkinShot('guts', state, 1, 0.39).damage, 1.35);
  close(peekSkinShot('guts', state, 1, 0.41).damage, 1.1);
  assert.equal(peekSkinShot('sephiroth', state, 0.89, 1).pierce, 0);
  assert.equal(peekSkinShot('sephiroth', state, 0.9, 1).pierce, 1);
  close(peekSkinShot('saiyan', state, 0.9, 1).speed, 1.18);
  close(peekSkinShot('saiyan', state, 0.9, 1).damage, 1.15);
  close(peekSkinShot('saiyan', state, 0.89, 1).damage, 1);
});

test('Cowboy, Infinity, dan Arise tidak terisi ulang dengan ganti skin', () => {
  const state = newSkinRuntime();
  takeSkinShot('band', state, 1, 1);
  assert.equal(takeSkinShot('cowboy', state, 1, 1).proc, false);
  nextSkinLevel(state);
  assert.equal(takeSkinShot('cowboy', state, 1, 1).proc, true);
  assert.equal(takeSkinShot('cowboy', state, 1, 1).proc, false);
  assert.equal(consumeSkinBarrier('gojo', state), true);
  assert.equal(consumeSkinBarrier('band', state), false);
  assert.equal(consumeSkinBarrier('gojo', state), false);
  tickSkinRuntime(state, 18);
  assert.equal(consumeSkinBarrier('gojo', state), true);
  skinKill(state, 'band'); assert.equal(state.shadowReady, false);
  skinKill(state, 'jinwoo'); assert.equal(state.shadowReady, true);
  takeSkinShot('band', state, 1, 1); assert.equal(state.shadowReady, true);
  const shot = takeSkinShot('jinwoo', state, 1, 1);
  assert.equal(shot.pierce, 1); close(shot.damage, 1.3);
  assert.equal(state.shadowReady, false);
});

test('api skin disegarkan, bukan ditumpuk; total damage tepat dan Panah Ganda tetap 60%', () => {
  const state = newSkinRuntime();
  state.shots.sanji = 2;
  const shot = takeSkinShot('sanji', state, 1, 1);
  let burn = applySkinBurn(undefined, shot)!;
  burn = applySkinBurn(burn, shot)!;
  assert.equal(burn.dps, 8);
  let total = 0;
  for (let n = 0; n < 400; n++) total += stepSkinBurn(burn, 1 / 120);
  close(total, 20);
  const double = applySkinBurn(undefined, { ...shot, scale: 0.6 })!;
  total = 0;
  for (let n = 0; n < 400; n++) total += stepSkinBurn(double, 1 / 120);
  close(total, 12);
  assert.equal(SKIN_RULES.dotTick, 0.5);
});

test('skin utility memakai sumber kill/parry, bukan skin yang baru diganti', () => {
  close(skinKillGoldMult('robin'), 1.2);
  close(skinKillGoldMult('racer'), 1);
  assert.deepEqual(skinParry('sekiro'), { heal: 4, gold: 1.5 });
  assert.deepEqual(skinParry('robin'), { heal: 0, gold: 1 });
});

test('HUD menghitung kesiapan skill dan progress hanya dari state run', () => {
  const state = newSkinRuntime();
  assert.equal(skinStatus('gojo', state, 0, 1).ready, true);
  consumeSkinBarrier('gojo', state);
  assert.equal(skinStatus('gojo', state, 0, 1).progress, 0);
  state.shots.vergil = 3;
  assert.equal(skinStatus('vergil', state, 0, 1).ready, true);
  assert.equal(skinStatus('saiyan', state, 0.5, 1).ready, false);
  assert.deepEqual(newSkinRuntime(), { shots: {}, levelShots: 0, barrierCd: 0, shadowReady: false });
});