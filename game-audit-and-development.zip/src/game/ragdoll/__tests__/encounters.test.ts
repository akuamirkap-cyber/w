import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CFG } from '../config';
import { BOSS_IDS, RagWorld, RUi } from '../game';
import { encounterPlan, enemyDmg, enemyHp, enemyLevelFor, firstDragonLevel, isBossLevel, levelCounts, nextBossLevel, weaponBossIndex } from '../formulas';
import { mulberry32, newMeta } from '../meta';

type Internal = Record<string, any>;
const inside = (w: RagWorld) => w as unknown as Internal;
const world = (level = 1, daily = false) => {
  let latest: RUi | undefined;
  const w = new RagWorld((ui) => { latest = ui; }, () => ({}) as never);
  w.meta = newMeta(); w.meta.settings.zoom = false; w.meta.settings.slowmo = false;
  w.startRun(); if (daily) w.newRun(true, level); else if (level !== 1) w.startLevelRun(level);
  return { w, latest: () => latest };
};

test('kalender bos hanya kelipatan lima; naga menggantikan, bukan menambah bos', () => {
  for (let level = 1; level <= 100; level++) {
    const plan = encounterPlan(level);
    assert.equal(plan.boss, level % 5 === 0);
    assert.equal(Number(plan.dragon) + Number(plan.weapon), Number(plan.boss));
    if (plan.dragon) assert.equal(level % 5, 0);
  }
  for (const level of [0, -5, 1.5, Number.NaN, Infinity]) assert.equal(isBossLevel(level), false);
  assert.equal(firstDragonLevel(), 15);
  assert.equal(nextBossLevel(1), 5); assert.equal(nextBossLevel(5), 10);
  assert.equal(encounterPlan(3).dragon, false);
});

test('semua tipe musuh di arena satu berlevel satu, bukan hanya labelnya', () => {
  for (const kind of ['archer', 'helm', 'shield', 'heavy', 'guard']) {
    for (const roll of [0, 0.2, 0.49, 0.53, 0.81, 0.99]) {
      const rank = enemyLevelFor(1, kind, roll);
      assert.equal(rank, 1);
      assert.equal(enemyHp(1, rank, false), 43);
      assert.equal(enemyDmg(1, rank, false), 8.6);
      assert.ok(enemyLevelFor(2, kind, roll) <= 2);
    }
  }
});

test('spawn nyata level satu menghasilkan HP, damage dan AI Lv1 untuk semua hasil acak', () => {
  for (const roll of [0, 0.3, 0.7, 0.99]) {
    const { w, latest } = world(); w.srand = () => roll;
    for (let i = 0; i < levelCounts(1).foot; i++) inside(w).spawnEnemy();
    inside(w).spawnBat(); w.update(0);
    assert.ok(w.foes.length > 0);
    for (const f of w.foes) {
      assert.equal(f.lvl, 1); assert.equal(f.maxHp, 43); assert.equal(f.dmg, 8.6);
      assert.equal(f.ai.spread, 0.22); assert.equal(f.ai.floor, 0.065);
      assert.notEqual(f.kind, 'axer'); assert.notEqual(f.kind, 'boss'); assert.notEqual(f.kind, 'rider');
    }
    assert.equal(w.bats[0].lvl, 1);
    assert.equal(w.dragon, null); assert.equal(latest()?.boss, false);
    assert.ok(!inside(w).bannerText.includes('BOS'));
  }
});

test('setiap wave normal mempunyai tepat satu bos hanya di level 5, 10, 15, dan seterusnya', () => {
  for (let level = 1; level <= 30; level++) {
    const { w } = world(level); w.srand = mulberry32(level);
    const W = inside(w); const seen = [];
    while (w.spawned < levelCounts(level).foot) {
      const before = w.spawned; const previous = w.foes.length;
      W.spawnEnemy();
      assert.ok(w.spawned > before, `SPAWN TERHENTI DI L${level}`);
      assert.ok(w.spawned <= levelCounts(level).foot, `KUOTA BERLEBIH DI L${level}`);
      const added = w.foes.slice(previous);
      seen.push(...added);
      for (const f of added) W.die(f, false);
    }
    const bosses = seen.filter((f) => f.bigBoss || f.kind === 'boss' || f.kind === 'axer' || f.kind === 'rider');
    assert.equal(bosses.length, level % 5 === 0 ? 1 : 0, `JUMLAH BOS SALAH DI L${level}`);
    if (bosses.length) assert.ok(bosses[0].bigBoss);
    assert.equal(w.run.bossPending, level % 5 === 0 ? 1 : 0);
  }
});

test('mengalahkan bos tidak memunculkan mini-bos pengganti pada sisa wave', () => {
  const { w } = world(5); const W = inside(w); const total = w.total;
  assert.equal(w.spawnAxeBossNow('axer'), true);
  assert.equal(w.total, total);
  const boss = w.foes[0]; assert.equal(boss.bigBoss, true); assert.equal(boss.lvl, 5);
  W.die(boss, false);
  assert.equal(w.spawnAxeBossNow('inferno_king'), false);
  assert.equal(w.spawnDragon(), false);
  while (w.spawned < levelCounts(5).foot) W.spawnEnemy();
  assert.equal(w.foes.filter((f) => f.bigBoss).length, 1);
  assert.equal(w.total, total);
});

test('API panggil bos/naga tidak bisa menyisipkan bos pada level non-bos atau mengubah kuota', () => {
  for (const level of [1, 2, 3, 4, 6, 9, 11, 14]) {
    const { w } = world(level); const before = w.total;
    assert.equal(w.spawnAxeBossNow('axer'), false);
    assert.equal(w.spawnDragon(), false);
    w.spawnSpecial('dragon');
    assert.equal(inside(w).spawnEnemy('boss'), false);
    assert.equal(inside(w).spawnEnemy('axer'), false);
    assert.equal(w.total, before); assert.equal(w.spawned, 0); assert.equal(w.dragon, null);
  }
});

test('bos pertama Lv5; kelima bos senjata bergiliran tanpa bergantung jumlah musuh yang spawn', () => {
  const levels = [5, 10, 20, 25, 35];
  assert.deepEqual(levels.map((level) => BOSS_IDS[weaponBossIndex(level, BOSS_IDS.length)]), BOSS_IDS);
});

test('bos naga mendapat hadiah bos besar tepat sekali', () => {
  const { w, latest } = world(firstDragonLevel()); const W = inside(w);
  W.spawnEnemy(); w.update(0);
  assert.ok(w.dragon); assert.equal(w.dragon.rider?.bigBoss, true); assert.equal(latest()?.boss, true);
  W.killDragon(w.dragon); W.killDragon(w.dragon);
  assert.equal(w.run.bossPending, 1); assert.equal(w.meta.stats.bigBossKills, 1);
  W.openShop();
  assert.equal(w.pickTitle, 'HADIAH BOS BESAR!'); assert.equal(w.run.cards.ganda, 1);
});

test('Kamus mulai latihan bos di Lv5 dan pilihan bos tidak hilang karena timer transisi', () => {
  for (const choice of [...BOSS_IDS, 'dragon'] as const) {
    const { w } = world(); w.startBossRun(choice);
    assert.equal(w.level, CFG.bigBoss.every);
    while (!w.foes.some((f) => f.bigBoss)) inside(w).spawnEnemy();
    const boss = w.foes.find((f) => f.bigBoss)!;
    if (choice === 'dragon') assert.equal(boss.kind, 'rider');
    else assert.equal(boss.bossKind, choice);
  }
});

test('jadwal berlaku pada harian, restart, dan debug bos menuju level yang sah', () => {
  const { w } = world(1, true); const W = inside(w);
  W.spawnEnemy(); assert.equal(w.foes[0].lvl, 1); assert.equal(w.foes[0].bigBoss, false);
  w.debugBoss(true); assert.equal(w.level, 5); assert.ok(w.foes.some((f) => f.bigBoss));
  w.restart(); W.spawnEnemy();
  assert.equal(w.level, 1); assert.equal(w.foes[0].lvl, 1); assert.equal(w.foes[0].bigBoss, false);
});