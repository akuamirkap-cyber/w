import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RagWorld } from '../game';
import { HEAD_STYLES } from '../head';
import { CFG, SKIN_PERKS, SkinId, UNLOCKS } from '../config';
import { newMeta } from '../meta';
import { peekSkinShot } from '../skinPerks';
import { dragonRig, dragonToWorld } from '../dragon';

// Exercise real collision hooks without a DOM, render loop, or balance bot.
type Internal = Record<string, any>;
const inside = (world: RagWorld) => world as unknown as Internal;
const close = (a: number, b: number) => assert.ok(Math.abs(a - b) < 0.02, `${a} != ${b}`);
function world(id: SkinId) {
  const w = new RagWorld(() => {}, () => ({}) as never);
  w.meta = newMeta(); w.meta.unlocked = UNLOCKS.map((u) => u.id);
  w.meta.settings.slowmo = false; w.meta.settings.zoom = false;
  w.bow = 'wood'; w.setHead(id); w.startRun();
  return w;
}
function foe(w: RagWorld) {
  inside(w).spawnEnemy('archer');
  const f = w.foes[w.foes.length - 1];
  f.hp = f.maxHp = f.hpLag = 1000; f.helm = false; f.plat.state = 'on'; f.plat.rise = 1;
  return f;
}
function shot(w: RagWorld, pull = 1) {
  w.player.k.pull = pull;
  inside(w).fire(w.player);
  return w.arrows[w.arrows.length - 1];
}
function hit(w: RagWorld, a: ReturnType<typeof shot>, f: ReturnType<typeof foe>, bone = 1) {
  a.p = { ...f.k.p[bone === 0 ? 0 : 1] };
  inside(w).onHit(a, f, { stick: bone, u: 0.2 });
}
function near(f: ReturnType<typeof foe>, at: { x: number; y: number }, dx: number) {
  const x = at.x + dx - f.k.p[1].x; const y = at.y - f.k.p[1].y;
  for (const p of [...f.k.p, ...f.k.o]) { p.x += x; p.y += y; }
}
function burnSteps(w: RagWorld, n = 400) { for (let i = 0; i < n; i++) inside(w).stepSkinStatuses(); }

test('semua skin masuk ke panah nyata, tanpa mengganti busur', () => {
  for (const id of HEAD_STYLES) {
    const w = world(id); const perk = peekSkinShot(id, w.skinState, 1, 1);
    const a = shot(w);
    assert.equal(a.skin?.id, id); assert.equal(a.bow, 'wood');
    close(Math.hypot(a.vel.x, a.vel.y), (430 + 800) * 1.9 * perk.speed);
    close(a.dmg, 42 * 1.1 * perk.damage);
  }
});

test('panah menyimpan skin saat ditembakkan; ganti skin tidak menumpuk bonus', () => {
  const w = world('rengoku'); const target = foe(w); const a = shot(w);
  w.setHead('band'); hit(w, a, target);
  assert.equal(target.skinBurn?.owner, 'rengoku');
  assert.equal(target.skinBurn?.dps, 3);
  const next = shot(w);
  assert.equal(next.skin?.id, 'band'); assert.equal(next.skin?.burnDps, 0);
  close(next.skin!.speed, 1.12);
  w.setHead('gojo'); assert.equal(inside(w).shieldTry({ x: 0, y: 0 }), true);
  w.setHead('racer'); w.setHead('gojo');
  assert.equal(inside(w).shieldTry({ x: 0, y: 0 }), false);
  w.newRun(); assert.equal(w.skinState.barrierCd, 0); assert.deepEqual(w.skinState.shots, {});
});

test('Sanji: tembakan ke-3 membakar, tanpa mengubah timer elemen busur', () => {
  const w = world('sanji'); const target = foe(w);
  assert.equal(shot(w).skin?.burnDps, 0); assert.equal(shot(w).skin?.burnDps, 0);
  const a = shot(w); hit(w, a, target);
  assert.equal(target.skinBurn?.dps, 8); assert.equal(target.burnT, 0);
  const hp = target.hp; burnSteps(w); close(hp - target.hp, 20);
  const fire = world('rengoku'); fire.bow = 'fire';
  const other = foe(fire); hit(fire, shot(fire), other);
  assert.ok(other.burnT > 0); assert.equal(other.skinBurn?.dps, 3);
});

test('Panah Ganda: satu hitungan skill per tarikan dan tiap panah 60%', () => {
  const w = world('sanji'); w.run.cards.ganda = 1; w.run.gandaLeft = 12; w.skinState.shots.sanji = 2;
  const a = shot(w); const b = w.arrows[w.arrows.length - 2];
  assert.equal(w.skinState.shots.sanji, 3);
  close(a.dmg, 42 * 1.1 * 1.2 * 0.6); close(a.dmg, b.dmg);
  assert.equal(a.skin?.scale, 0.6);
  const target = foe(w); hit(w, a, target); hit(w, b, target);
  close(target.skinBurn!.dps, 8 * 0.6);
  assert.equal(w.run.gandaLeft, 11);
});

test('Punk menyambar musuh dekat, Rengoku meledakkan headshot tanpa rantai rekursif', () => {
  for (const id of ['punk', 'rengoku'] as const) {
    const w = world(id); const primary = foe(w); const secondary = foe(w); const distant = foe(w);
    const at = primary.k.p[id === 'rengoku' ? 0 : 1];
    near(secondary, at, 40); near(distant, at, 500);
    if (id === 'punk') w.skinState.shots.punk = 3;
    hit(w, shot(w), primary, id === 'rengoku' ? 0 : 1);
    assert.ok(secondary.hp < 1000); assert.equal(distant.hp, 1000);
    if (id === 'punk') { close(secondary.hp, 984); assert.ok(secondary.skinStunT! > 0); }
    else close(secondary.hp, 991);
  }
});

test('Sephiroth/Vergil menembus dan bisa digabung dengan kartu Panah Tembus', () => {
  const w = world('sephiroth'); const a = shot(w); const first = foe(w); const second = foe(w);
  hit(w, a, first); assert.equal(a.dead, false); assert.equal(a.pierceLeft, 0);
  assert.ok(a.hitIds?.has(first));
  const weaker = a.dmg; hit(w, a, second); assert.equal(a.dead, true);
  close(1000 - second.hp, Math.round(weaker));
  const v = world('vergil'); v.skinState.shots.vergil = 3; v.run.cards.tembus = 1;
  const cut = shot(v); assert.equal(cut.pierceLeft, 3); assert.equal(cut.skin?.proc, true);
});

test('Luffy/Racer mengurangi damage masuk dari panah, senjata, kelelawar, dan bola api', () => {
  for (const id of ['luffy', 'racer'] as const) {
    const w = world(id); const W = inside(w);
    const a = { ...shot(w), team: 1, skin: undefined, dmg: 20, maxPower: false, pierceLeft: 0, hitIds: undefined };
    const hp = w.player.hp; W.onHit(a, w.player, { stick: 0, u: 1 });
    close(hp - w.player.hp, Math.round(30 * (id === 'luffy' ? 0.88 : 0.75)));
    w.player.hp = 100;
    W.fireballHit({ p: { ...w.player.k.p[1] }, vel: { x: 100, y: 0 }, dmg: 20, dead: false });
    close(100 - w.player.hp, id === 'luffy' ? 18 : 20);
    w.player.hp = 100;
    W.spawnBat(); const bat = w.bats[0]; bat.dmg = 20;
    W.batBite(bat); close(100 - w.player.hp, id === 'luffy' ? 18 : 15);
    w.player.hp = 100;
    const enemy = foe(w); W.throwAxe(enemy); const axe = W.axes[W.axes.length - 1]; axe.dmg = 20;
    W.axeHit(axe, { stick: 0, u: 1 }); close(100 - w.player.hp, id === 'luffy' ? 18 : 15);
  }
});

test('Infinity memblokir sebelum kartu Perisai; cooldown tidak berjalan saat jeda', () => {
  const w = world('gojo'); w.run.cards.perisai = 1;
  assert.equal(inside(w).shieldTry({ x: 0, y: 0 }), true); assert.equal(w.run.shieldCd, 0);
  assert.equal(inside(w).shieldTry({ x: 0, y: 0 }), true); assert.equal(w.run.shieldCd, 14);
  assert.equal(inside(w).shieldTry({ x: 0, y: 0 }), false);
  w.setPaused(true); w.update(0.05); assert.equal(w.skinState.barrierCd, 18);
  w.setPaused(false); w.update(0.05); assert.ok(w.skinState.barrierCd < 18);
});

test('Robin memberi emas dan heal headshot; Jinwoo mengisi satu charge setelah kill', () => {
  const w = world('robin'); const target = foe(w); target.hp = 1;
  w.player.hp = 50; w.run.cards.lifesteal = 1;
  hit(w, shot(w), target, 0);
  assert.equal(w.coins, 12); assert.equal(w.player.hp, 55);
  inside(w).die(target, true); assert.equal(w.coins, 12, 'NO DOUBLE REWARD');
  const j = world('jinwoo'); const victim = foe(j); victim.hp = 1;
  hit(j, shot(j), victim); assert.equal(j.skinState.shadowReady, true);
  const arise = shot(j); assert.equal(arise.pierceLeft, 1); assert.equal(arise.skin?.proc, true);
  assert.equal(j.skinState.shadowReady, false);
});

test('Sekiro hanya memperoleh bonus tangkis sekali per senjata', () => {
  const w = world('sekiro'); w.player.hp = 50;
  const enemy = foe(w); inside(w).throwAxe(enemy);
  const ax = inside(w).axes[0];
  inside(w).parry(ax, shot(w)); assert.equal(w.coins, 15); assert.equal(w.player.hp, 54);
  inside(w).parry(ax, shot(w)); assert.equal(w.coins, 15); assert.equal(w.player.hp, 54);
});

test('api skin bisa membunuh kelelawar dan naga, memakai alur kematian asli', () => {
  const w = world('rengoku'); const W = inside(w);
  W.spawnBat(); const bat = w.bats[0]; bat.hp = 58;
  const a = shot(w); a.p = { ...bat.p }; W.hitBat(a, bat);
  burnSteps(w); assert.equal(bat.state, 'dead'); assert.equal(w.totalKills, 1);
  w.debugLevel(CFG.bigBoss.every);
  W.spawnDragon(); const d = w.dragon!; d.hp = 79;
  const rig = dragonRig(d.t, d.flap, d.glow, d.spit);
  const p = dragonToWorld(rig.head, d.p, d.s, d.tilt);
  W.hitDragon(shot(w), p); assert.ok(d.skinBurn);
  burnSteps(w); assert.equal(d.state, 'dying'); assert.ok(!d.rider!.k.alive);
  assert.equal(w.totalKills, 2);
});

test('Mata Enam punya gravitasi yang sesuai lintasan, dan modifier harian tidak dilewati', () => {
  const w = world('gojo_blue'); const preview = peekSkinShot(w.head, w.skinState, 1, 1);
  const a = shot(w); assert.equal(a.skin?.gravity, preview.gravity);
  const vy = a.vel.y; inside(w).step(); close(a.vel.y - vy, CFG.arrow.gravity * preview.gravity / 120);
  const r = world('rengoku'); inside(r).mods.headOnly = true;
  const primary = foe(r); const secondary = foe(r); near(secondary, primary.k.p[0], 30);
  hit(r, shot(r), primary, 0);
  assert.equal(primary.skinBurn, undefined); assert.equal(secondary.hp, 1000);
});

test('Cowboy tidak bisa mengambil tembakan pertama ulang lewat menu skin', () => {
  const w = world('band'); shot(w); w.setHead('cowboy');
  assert.equal(shot(w).skin?.proc, false);
  w.debugLevel(2); assert.equal(shot(w).skin?.proc, true);
  w.setHead('racer'); w.setHead('cowboy'); assert.equal(shot(w).skin?.proc, false);
  assert.equal(SKIN_PERKS.cowboy.signature.kind, 'opening');
});

test('kill kartu dan balok istana membawa sumber bonus skin yang benar', () => {
  const w = world('robin'); w.run.cards.petir = 1;
  const primary = foe(w); const secondary = foe(w); secondary.hp = 1;
  near(secondary, primary.k.p[1], 40);
  hit(w, shot(w), primary);
  assert.equal(w.coins, 6);
  assert.equal(secondary.lastSkin, 'robin');
  const f = world('robin'); inside(f).spawnFort();
  const fort = f.fort!; const block = fort.blocks[0];
  inside(f).hitBlock(fort, 0, shot(f));
  assert.equal(block.skinOwner, 'robin');
  inside(f).crush(fort.guards[0], block);
  assert.equal(f.coins, 10);
});

test('Levi, Chidori, dan pelindung helm memengaruhi tabrakan nyata', () => {
  const w = world('levi'); const target = foe(w); hit(w, shot(w), target, 2);
  close(1000 - target.hp, Math.round(42 * 1.1 * 0.55 * 1.35));
  const s = world('sasuke'); const stunned = foe(s); hit(s, shot(s), stunned, 0);
  close(stunned.skinStunT!, 0.75);
  close(1000 - stunned.hp, Math.round(42 * 1.1 * 2.6 * 1.15));
  const r = world('racer'); const incoming = { ...shot(r), team: 1, skin: undefined, bow: 'spike', dmg: 20, maxPower: false };
  inside(r).onHit(incoming, r.player, { stick: 0, u: 1 });
  close(100 - r.player.hp, Math.round(10 * 0.75) + Math.round(20 * 1.5 * 0.75));
});