import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CFG, SKILL_NODES, SkillId } from '../config';
import { KV, META_KEY, loadMeta, newMeta, saveMeta } from '../meta';
import { newRunState, playerMaxHp } from '../cards';
import { RagWorld } from '../game';
import { fireAngle } from '../stick';
import { SKILL_BY, normalizeSkillTree, purchaseSkill, skillCost, skillProgress, skillRank, skillState, steadyRelease, trainedArrowSpeed, trainedGuideDots, trainedSpread, trainingBonuses } from '../progression';

const close = (a: number, b: number) => assert.ok(Math.abs(a - b) < 1e-7, `${a} != ${b}`);
const memory = (): KV => { const m = new Map<string, string>(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => { m.set(k, v); } }; };
const maxTree = () => Object.fromEntries(SKILL_NODES.map((n) => [n.id, n.maxLv]));

test('tree punya ID unik, harga per level, prasyarat valid, dan tidak bersiklus', () => {
  assert.equal(new Set(SKILL_NODES.map((n) => n.id)).size, SKILL_NODES.length);
  const visited = new Set<SkillId>();
  for (const node of SKILL_NODES) {
    assert.equal(node.costs.length, node.maxLv);
    assert.ok(node.costs.every((n) => Number.isFinite(n) && n > 0));
    for (const req of node.requires) {
      assert.ok(visited.has(req.id));
      assert.ok(req.level <= SKILL_BY[req.id].maxLv);
    }
    visited.add(node.id);
  }
});

test('pembelian memakai biaya tepat, membuka cabang, dan menolak koin kurang', () => {
  const m = newMeta();
  assert.equal(skillState(m, 'speed'), 'poor');
  assert.equal(purchaseSkill(m, 'speed'), false);
  assert.equal(purchaseSkill(m, 'reload'), false);
  m.coins = 200;
  assert.equal(purchaseSkill(m, 'speed'), true); assert.equal(m.coins, 150);
  assert.equal(skillRank(m, 'speed'), 1); assert.equal(skillState(m, 'reload'), 'locked');
  assert.equal(purchaseSkill(m, 'speed'), true); assert.equal(m.coins, 70);
  assert.equal(skillState(m, 'reload'), 'available');
  assert.equal(purchaseSkill(m, 'reload'), true); assert.equal(m.coins, 5);
  const before = JSON.stringify(m);
  assert.equal(purchaseSkill(m, 'reload'), false); assert.equal(JSON.stringify(m), before);
});

test('mastery butuh SEMUA prasyarat, bukan hanya koin atau satu cabang', () => {
  const m = newMeta(); m.coins = 10000;
  m.tree = { speed: 5, reload: 3 };
  assert.equal(purchaseSkill(m, 'full_speed'), false);
  m.tree.draw = 2;
  assert.equal(purchaseSkill(m, 'full_speed'), false);
  m.tree.draw = 3;
  assert.equal(purchaseSkill(m, 'full_speed'), true);
  assert.equal(skillState(m, 'full_speed'), 'mastered');
});

test('semua node berhenti di level maksimal tanpa memotong koin lagi', () => {
  const m = newMeta(); m.coins = 50000;
  let spent = 0;
  for (const node of SKILL_NODES) {
    for (let i = 0; i < node.maxLv; i++) { assert.equal(purchaseSkill(m, node.id), true); spent += node.costs[i]; }
    assert.equal(skillCost(m, node.id), null);
    const coins = m.coins;
    for (let i = 0; i < 5; i++) assert.equal(purchaseSkill(m, node.id), false);
    assert.equal(m.coins, coins);
    assert.equal(skillRank(m, node.id), node.maxLv);
  }
  assert.equal(m.coins, 50000 - spent);
  assert.deepEqual(skillProgress(m), { current: 34, max: 34 });
});

test('save lama HP/reroll dimigrasi tanpa biaya, kehilangan rank, atau bonus ganda', () => {
  const kv = memory();
  kv.setItem(META_KEY, JSON.stringify({ v: 1, coins: 1234, up: { hp: 3, reroll: 1 }, unlocked: ['bow:fire'], stats: { runs: 7 } }));
  const m = loadMeta(kv);
  assert.equal(m.coins, 1234); assert.equal(m.stats.runs, 7); assert.ok(m.unlocked.includes('bow:fire'));
  assert.equal(m.tree.vitality, 3); assert.equal(m.tree.reroll, 1);
  assert.equal(m.up.hp, 3); assert.equal(m.up.reroll, 1);
  close(trainingBonuses(m).hpBonus, 0.09);
  assert.equal(trainingBonuses(m).freeRerolls, 1);
  saveMeta(m, kv); const again = loadMeta(kv);
  assert.deepEqual(again.tree, m.tree); assert.equal(again.coins, 1234);
});

test('save corrupt: level dibatasi dan mastery ilegal tidak memberi bonus', () => {
  assert.deepEqual(normalizeSkillTree({ full_speed: 1, speed: -5, accuracy: 'infinite', invalid: 999 }), {});
  const tree = normalizeSkillTree({ speed: 999, reload: 999, draw: 999, full_speed: 999, vitality: 999, reroll: 999 });
  assert.equal(tree.speed, 5); assert.equal(tree.reload, 3); assert.equal(tree.full_speed, 1); assert.equal(tree.vitality, 5); assert.equal(tree.reroll, 1);
  const m = newMeta(); m.coins = Number.NaN;
  assert.equal(purchaseSkill(m, 'speed'), false);
  assert.equal(purchaseSkill(m, '__proto__' as SkillId), false);
  const kv = memory(); kv.setItem(META_KEY, '{broken'); assert.deepEqual(loadMeta(kv).tree, {});
});

test('bonus maksimal benar dan tidak mengandung damage permanen', () => {
  const m = newMeta(); m.tree = maxTree(); const b = trainingBonuses(m);
  assert.deepEqual(b, { arrowSpeed: 0.2, reloadSpeed: 0.2, drawSpeed: 0.12, stability: 0.5, spreadReduction: 0.24, guideDots: 18, hpBonus: 0.2, clearHeal: 9, freeRerolls: 1 });
  assert.equal(trainedGuideDots(b), 42);
  close(trainedArrowSpeed(100, b), 120); close(trainedSpread(0.1, b), 0.076);
  const run = newRunState(0);
  assert.equal(playerMaxHp(run, 0, b.hpBonus), 120);
  run.cards.pedang = 1; assert.equal(playerMaxHp(run, 0, b.hpBonus), 90);
  assert.equal('damage' in b, false);
});

test('accuracy mengurangi deviasi pelepasan, bukan membidik musuh otomatis', () => {
  close(steadyRelease(0.5, 0.1, 0.5), 0.3);
  close(steadyRelease(0.5, 0.1, 0), 0.5);
  close(steadyRelease(0.1, 0.1, 0.5), 0.1);
  const wrapped = steadyRelease(Math.PI - 0.1, -Math.PI + 0.1, 0.5);
  close(wrapped, Math.PI);
});

type Internal = Record<string, any>;
const inside = (w: RagWorld) => w as unknown as Internal;
const world = (trained = false) => {
  const w = new RagWorld(() => {}, () => ({}) as never);
  w.meta = newMeta(); if (trained) w.meta.tree = maxTree();
  w.bow = 'wood'; w.head = 'band'; w.startRun();
  return w;
};
const shoot = (w: RagWorld) => { w.player.k.pull = 1; inside(w).fire(w.player); return w.arrows[w.arrows.length - 1]; };

test('kecepatan meta nyata bertumpuk dengan skin tanpa mengubah damage busur', () => {
  const base = world(); const trained = world(true);
  const a = shoot(base); const b = shoot(trained);
  close(Math.hypot(b.vel.x, b.vel.y) / Math.hypot(a.vel.x, a.vel.y), 1.2);
  close(a.dmg, b.dmg); assert.equal(b.bow, 'wood');
});

test('akurasi dan formasi rapat terhubung ke sudut panah asli', () => {
  const w = world(true); const k = w.player.k;
  k.aim = -0.4; k.p[4] = { x: 120, y: 100 }; k.p[6] = { x: 100, y: 100 };
  const expected = steadyRelease(fireAngle(k), k.aim, 0.5);
  close(shoot(w).ang, expected);
  w.run.gandaLeft = 12; shoot(w);
  const [a, b] = w.arrows.slice(-2);
  close(Math.abs(a.ang - b.ang), CFG.cards.ganda.spread * 0.76);
  close(a.dmg, 42 * 1.1 * CFG.cards.ganda.pct);
});

test('HP, reroll, reload, dan pemulihan level menggunakan bonus tree', () => {
  const w = world(true);
  assert.equal(w.player.maxHp, 120); assert.equal(w.run.freeRerolls, 2);
  w.player.k.nock = 0; inside(w).step();
  close(w.player.k.nock, (1 / 120) * 1.1 * 1.2 / 0.46);
  w.player.hp = 20; inside(w).beginClear(null); inside(w).clearT = 3.86;
  w.update(0.02);
  assert.equal(w.stage, 'shop'); assert.equal(w.player.hp, 77);
});

test('membeli di tengah run aktif pada run berikutnya dan tersimpan', () => {
  const w = world(); w.meta.coins = 1000;
  assert.equal(w.buySkill('speed'), true); assert.equal(w.meta.coins, 950);
  assert.equal(w.meta.tree.speed, 1); assert.equal(w.training.arrowSpeed, 0);
  const old = shoot(w);
  w.newRun(); const next = shoot(w);
  close(Math.hypot(next.vel.x, next.vel.y) / Math.hypot(old.vel.x, old.vel.y), 1.03);
  assert.equal(w.training.arrowSpeed, 0.03);
  const kv = memory(); saveMeta(w.meta, kv); assert.equal(loadMeta(kv).tree.speed, 1);
});

test('tree tidak mengubah kecepatan serangan musuh', () => {
  const w = world(true); inside(w).spawnEnemy('archer');
  const f = w.foes[w.foes.length - 1]; f.lvl = 1; f.k.pull = 1;
  inside(w).fire(f); const a = w.arrows[w.arrows.length - 1];
  close(Math.hypot(a.vel.x, a.vel.y), 430 + 800);
  assert.equal(a.skin, undefined);
});

test('Tarikan Kilat mempercepat tarikan di input pemain asli', () => {
  const base = world(); const trained = world(true);
  for (const w of [base, trained]) {
    inside(w).drag = { on: true, sx: 600, sy: 300, x: 450, y: 300 };
    w.player.k.nock = 1; w.player.k.clutch = 0; w.player.k.pull = 0;
    inside(w).step();
  }
  assert.ok(trained.player.k.pull > base.player.k.pull);
  const target = Math.min(1, (150 - 6) / trained.pullPx);
  close(trained.player.k.pull, target * (1 - Math.exp(-17 * 1.12 / 120)));
});