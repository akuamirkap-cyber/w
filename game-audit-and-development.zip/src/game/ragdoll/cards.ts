// Logika murni kartu & run: set 3 kartu, naik level, reroll, sinergi, pengali damage/emas/HP.
import { CARDS, CFG, CardDef, CardId, SET_TYPES, SYNERGIES } from './config';

export type RouteId = 'aman' | 'risiko';
export interface RunState {
  cards: Partial<Record<CardId, number>>;
  freeRerolls: number; paidRerolls: number; rerolls: number;
  reviveUsed: boolean; shieldCd: number; slowCd: number; slowT: number; gandaLeft: number;
  hunterStacks: number; headStreak: number;
  synergies: string[]; picked: string[]; rejected: string[]; unlocks: string[];
  goldEarned: number; metaGain: number; startedAt: number; index: number; ended: boolean;
  route: RouteId; lastChest: boolean; bossPending: number; killedBy: string;
  daily: string; mod: string;
}

export function newRunState(freeRerolls: number): RunState {
  return {
    cards: {}, freeRerolls, paidRerolls: 0, rerolls: 0,
    reviveUsed: false, shieldCd: 0, slowCd: 0, slowT: 0, gandaLeft: 0,
    hunterStacks: 0, headStreak: 0,
    synergies: [], picked: [], rejected: [], unlocks: [],
    goldEarned: 0, metaGain: 0, startedAt: 0, index: 0, ended: false,
    route: 'aman', lastChest: false, bossPending: 0, killedBy: 'TIDAK DIKETAHUI',
    daily: '', mod: '',
  };
}

export const CARD_BY = Object.fromEntries(CARDS.map((c) => [c.id, c])) as Record<CardId, CardDef>;
export const cardLv = (r: RunState, id: CardId) => r.cards[id] ?? 0;

/**
 * 3 kartu: 1 PANAH + 1 BERTAHAN + 1 RISIKO. Tanpa kembar, tanpa kartu level maks, tanpa kartu terkunci,
 * tidak pernah PANAH GANDA. Kalau satu tipe habis, slotnya diisi kartu lain yang masih sah.
 */
export function rollOffer(rng: () => number, r: RunState, unlocked: (id: CardId) => boolean): CardId[] {
  const pool = CARDS.filter((c) => c.type !== 'KHUSUS' && unlocked(c.id) && cardLv(r, c.id) < c.maxLv);
  const out: CardId[] = [];
  const pick = (list: CardDef[]) => {
    const l = list.filter((c) => !out.includes(c.id));
    if (!l.length) return false;
    out.push(l[Math.min(l.length - 1, Math.floor(rng() * l.length))].id);
    return true;
  };
  for (const t of SET_TYPES) if (!pick(pool.filter((c) => c.type === t))) pick(pool);
  return out;
}

/** ambil kartu (naik level, maks per kartu); kembalikan sinergi yang BARU aktif */
export function takeCard(r: RunState, id: CardId): string[] {
  const def = CARD_BY[id];
  r.cards[id] = Math.min(def.maxLv, cardLv(r, id) + 1);
  if (id === 'ganda') r.gandaLeft = gandaShots(r);
  const fresh = activeSynergies(r.cards).filter((s) => !r.synergies.includes(s.id));
  for (const s of fresh) r.synergies.push(s.id);
  return fresh.map((s) => s.name);
}

export const activeSynergies = (cards: Partial<Record<CardId, number>>) =>
  SYNERGIES.filter((s) => s.need.every((id) => (cards[id] ?? 0) > 0));
export const hasSyn = (r: RunState, id: string) => r.synergies.includes(id);

/** biaya reroll berikutnya: 0 selama masih ada jatah gratis */
export function rerollCost(r: RunState): number {
  if (r.freeRerolls > 0) return 0;
  const c = CFG.reroll.costs;
  return c[Math.min(r.paidRerolls, c.length - 1)];
}
export function useReroll(r: RunState): number {
  const cost = rerollCost(r);
  if (r.freeRerolls > 0) r.freeRerolls--; else r.paidRerolls++;
  r.rerolls++;
  return cost;
}

/** nilai per-level dari tabel config (lv 1-based, 0 = tidak punya) */
export const lvVal = (arr: number[], lv: number) => (lv > 0 ? arr[Math.min(lv, arr.length) - 1] : 0);

export function playerMaxHp(r: RunState, metaHpLv: number, extraMetaHp = 0): number {
  const base = CFG.player.baseHp * (1 + CFG.meta.hpPerLv * Math.min(metaHpLv, CFG.meta.hpMaxLv) + extraMetaHp);
  return Math.max(1, Math.round(base * (1 - lvVal(CFG.cards.pedang.hp, cardLv(r, 'pedang')))));
}
export const playerDmgMult = (r: RunState) => 1 + lvVal(CFG.cards.pedang.dmg, cardLv(r, 'pedang'));
export function hunterMult(r: RunState): number {
  const lv = cardLv(r, 'pemburu');
  if (!lv) return 1;
  return Math.min(lvVal(CFG.cards.pemburu.max, lv), 1 + lvVal(CFG.cards.pemburu.step, lv) * r.hunterStacks);
}
export const gandaShots = (r: RunState) => lvVal(CFG.cards.ganda.shots, cardLv(r, 'ganda'));
/** damage panah tembus setelah n tembusan */
export const pierceDmg = (base: number, n: number) => base * Math.pow(1 - CFG.cards.tembus.falloff, n);

/** pengali level dari rute + kartu risiko + modifier harian + skala L15+ */
export function levelMods(r: RunState, modHp: number, lateHp: number, lateDmg: number) {
  const risk = r.route === 'risiko'; const R = CFG.route.risk; const k = cardLv(r, 'kontrak');
  return {
    hp: (risk ? R.hp : 1) * (1 + lvVal(CFG.cards.kontrak.hp, k)) * modHp * lateHp,
    dmg: (risk ? R.dmg : 1) * lateDmg,
    gold: (risk ? R.gold : 1) * (k ? lvVal(CFG.cards.kontrak.gold, k) : 1),
  };
}

const pc = (x: number) => Math.round(x * 100);
/** teks efek kartu pada level lv (1-based) — untuk kartu & tampilan tekan-tahan */
export function cardText(id: CardId, lv: number): string {
  const C = CFG.cards; const v = (a: number[]) => lvVal(a, lv);
  switch (id) {
    case 'ledak': return `HEADSHOT MELEDAK: ${pc(v(C.ledak.pct))}% DMG AREA · RADIUS ${v(C.ledak.radius)}`;
    case 'petir': return `SETRUM MENYAMBAR ${v(C.petir.jumps)} MUSUH · ${pc(v(C.petir.pct))}% DMG`;
    case 'paku': return `MEMAKU MUSUH · STUN ${v(C.paku.stun)} DTK`;
    case 'tameng': return `PANAH MEMANTUL DARI TAMENG · ${pc(v(C.tameng.pct))}% DMG`;
    case 'tembus': return `TEMBUS ${v(C.tembus.pierce)} MUSUH · -${pc(C.tembus.falloff)}% DMG/TEMBUSAN`;
    case 'pemburu': return `HEADSHOT BERUNTUN +${pc(v(C.pemburu.step))}% EMAS & DMG · MAKS x${v(C.pemburu.max)}`;
    case 'lifesteal': return `+${v(C.lifesteal.hp)} HP TIAP KILL`;
    case 'perisai': return `BLOK 1 SERANGAN · CD ${v(C.perisai.cd)} DTK`;
    case 'nyawa2': return `SEKALI PER RUN: HIDUP LAGI ${pc(v(C.nyawa2.pct))}% HP`;
    case 'lambat': return `SKILL [Q]: SLOW-MO ${C.lambat.dur} DTK · CD ${v(C.lambat.cd)} DTK`;
    case 'pedang': return `DAMAGE +${pc(v(C.pedang.dmg))}% · MAX HP -${pc(v(C.pedang.hp))}%`;
    case 'kontrak': return `EMAS x${v(C.kontrak.gold)} · HP MUSUH +${pc(v(C.kontrak.hp))}%`;
    case 'ganda': return `${C.ganda.arrows} PANAH @${pc(C.ganda.pct)}% · ${v(C.ganda.shots)} TEMBAKAN/LEVEL`;
  }
}
