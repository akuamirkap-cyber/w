import { CSSProperties, useEffect, useId, useRef, useState } from 'react';
import { SKILL_BRANCHES, SKILL_NODES, SKILL_RULES, SKILL_TREE_ART, SkillBranch, SkillId, SkillNodeDef, TrainingBonuses } from './game/ragdoll/config';
import type { MetaSave } from './game/ragdoll/meta';
import { SKILL_BY, SKILL_EFFECT_NAMES, formatSkillEffect, skillCost, skillProgress, skillRank, skillRequirements, skillState } from './game/ragdoll/progression';
import { audioInit, snd } from './game/ragdoll/audio';
import { SkillForest, SkillGlyph, TreeArcher } from './SkillTreeArt';
import './skill-tree-game.css';

export function TreeIcon({ icon, className = '' }: { icon: SkillNodeDef['icon'] | 'lock' | 'coin' | 'check'; className?: string }) {
  const paths: Record<typeof icon, string> = {
    wind: 'M3 8h11c5 0 5-6 1-6M2 12h18M5 16h9c5 0 5 6 1 6M19 12l3-2m-3 2 3 2',
    quiver: 'M6 9l2 12h9l2-12H6zm2-2L6 2m6 5V1m4 6 3-5M5 3l2-1M11 2h2m5 1 2 1M10 12l1 6m3-6 1 6',
    bow: 'M7 2c13 5 13 15 0 20M7 2l4 10-4 10M3 12h18m-4-3 4 3-4 3',
    wing: 'M12 18c-2-7-5-8-10-9l6-6 4 7 4-7 6 6c-5 1-8 2-10 9zM5 10l3 4m11-4-3 4M12 18v4',
    target: 'M12 3a9 9 0 1 0 9 9M12 7a5 5 0 1 0 5 5M12 12l9-9m-5 0h5v5',
    trajectory: 'M3 20c3-17 10-18 18-7M3 20h4m-4 0v-4M17 13h4V9M11 17h.1M16 20h.1',
    arrows: 'M5 21V4m-3 3 3-4 3 4M12 21V4m-3 3 3-4 3 4M19 21V4m-3 3 3-4 3 4',
    eye: 'M2 12c5-10 15-10 20 0-5 10-15 10-20 0zM12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 1v3m0 16v3',
    heart: 'M12 21C-4 11 4-3 12 6c8-9 16 5 0 15zM5 12h4l2-4 2 8 2-4h4',
    leaf: 'M4 20C-2 9 9 3 21 3c0 12-5 20-17 17zM4 20 16 8M7 17v-6m4 2h6',
    reroll: 'M4 8a9 9 0 0 1 15-3l2 3M21 2v6h-6M20 16A9 9 0 0 1 5 19l-2-3M3 22v-6h6',
    shield: 'M12 2 3 6v6c0 5 5 8 9 10 4-2 9-5 9-10V6l-9-4zM8 12l3 3 6-7',
    lock: 'M6 10h12v11H6V10zm3 0V6a3 3 0 0 1 6 0v4M12 14v3',
    coin: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12zM12 9v6',
    check: 'm5 12 4 4L20 5',
  };
  if (icon === 'coin' || icon === 'lock') return <SkillGlyph icon={icon} className={className} />;
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true"><path d={paths[icon]} /></svg>;
}

const branchOf = (node: SkillNodeDef) => SKILL_BRANCHES.find((b) => b.id === node.branch)!;
const themeStyle = (branch: SkillBranch): CSSProperties => ({
  '--branch-color': SKILL_BRANCHES.find((b) => b.id === branch)!.color,
  '--branch-top': SKILL_TREE_ART.branches[branch].top,
  '--branch-bottom': SKILL_TREE_ART.branches[branch].bottom,
}) as CSSProperties;

export default function SkillTree({ meta, onBuy, inRun }: { meta: MetaSave; onBuy: (id: SkillId) => boolean; inRun: boolean }) {
  const [selected, setSelected] = useState<SkillId>('speed');
  const [burst, setBurst] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const unique = useId().replace(/:/g, '');
  const layout = SKILL_RULES.tree;
  const node = SKILL_BY[selected];
  const branch = branchOf(node);
  const rank = skillRank(meta, selected);
  const state = skillState(meta, selected);
  const cost = skillCost(meta, selected);
  const progress = skillProgress(meta);
  const requirements = skillRequirements(meta, selected);
  const effects = Object.entries(node.effects) as [keyof TrainingBonuses, number][];
  const next = Math.min(rank + 1, node.maxLv);
  const choose = (id: SkillId) => { audioInit(); snd.tap(); setSelected(id); setAnnouncement(''); };

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  const purchase = () => {
    audioInit();
    if (!onBuy(selected)) return;
    setBurst(`${selected}-${next}`);
    setAnnouncement(next === node.maxLv ? `${node.name}: LEVEL MAKSIMAL!` : `${node.name} NAIK KE LEVEL ${next}`);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setBurst(''), SKILL_RULES.purchaseMotionMs);
  };

  return (
    <div className="skill-tree-layout">
      <section className="skill-tree-scene" aria-label="Peta pohon skill">
        <div className="skill-tree-canvas">
          <SkillForest />
          <div className="tree-fireflies" aria-hidden="true"><i /><i /><i /><i /></div>
          <svg className="tree-connections" viewBox={`0 0 ${layout.width} ${layout.height}`} preserveAspectRatio="none" aria-hidden="true">
            <defs>
              {SKILL_BRANCHES.map((b) => <linearGradient key={b.id} id={`${unique}-${b.id}`} x1="0" y1="1" x2="0" y2="0"><stop offset="0" stopColor="#76b6bc" /><stop offset="1" stopColor={b.color} /></linearGradient>)}
            </defs>
            {SKILL_NODES.map((n) => {
              // Transitive requirements remain in the detail panel, not duplicated as crossing edges.
              const direct = n.requires.filter((r) => !n.requires.some((other) => SKILL_BY[other.id].requires.some((parent) => parent.id === r.id)));
              const parents = direct.length ? direct.map((r) => SKILL_BY[r.id]) : [{ id: 'root', x: layout.rootX, y: layout.rootY }];
              return parents.map((parent) => {
                const owned = skillRank(meta, n.id) > 0;
                const open = skillState(meta, n.id) !== 'locked';
                const color = branchOf(n).color;
                const outer = n.id === 'reroll';
                const curve = outer
                  ? `M ${parent.x} ${parent.y} C ${layout.width - layout.lineBend} ${layout.height - layout.lineBend} ${layout.width - layout.lineBend} ${n.y + layout.lineBend} ${n.x} ${n.y}`
                  : `M ${parent.x} ${parent.y} C ${parent.x} ${parent.y - layout.lineBend} ${n.x} ${n.y + layout.lineBend} ${n.x} ${n.y}`;
                return <g key={`${parent.id}-${n.id}`}>
                  <path d={curve} stroke={SKILL_TREE_ART.links.outline} strokeWidth={SKILL_TREE_ART.links.outlineWidth} strokeLinecap="round" fill="none" />
                  <path d={curve} stroke={owned ? `url(#${unique}-${n.branch})` : SKILL_TREE_ART.links.idle} strokeWidth={SKILL_TREE_ART.links.fillWidth} strokeOpacity={owned ? 1 : open ? 0.8 : SKILL_TREE_ART.links.idleOpacity} strokeDasharray={owned ? undefined : '5 8'} strokeLinecap="round" fill="none" />
                  {owned && <path className="tree-energy-flow" d={curve} stroke={color} strokeWidth={SKILL_TREE_ART.links.liveWidth} strokeDasharray="4 24" strokeLinecap="round" fill="none" />}
                </g>;
              });
            })}
          </svg>

          {SKILL_BRANCHES.map((b) => {
            const p = skillProgress(meta, b.id);
            return <div key={b.id} className="tree-branch-heading" style={{ left: `${b.x / layout.width * 100}%`, top: `${layout.headingY / layout.height * 100}%`, ...themeStyle(b.id) }}>
              <button className="tree-branch-select font-game" onClick={() => choose(b.id)} aria-label={`Pilih jalur ${b.name}`}>{b.name}</button>
              <span className="tree-branch-progress font-game">{p.current}<span> / {p.max} LEVEL</span></span>
            </div>;
          })}

          {SKILL_NODES.map((n) => {
            const level = skillRank(meta, n.id); const status = skillState(meta, n.id);
            const isSelected = selected === n.id;
            return <div key={n.id} className={`tree-node-anchor ${n.mastery ? 'tree-node-mastery' : ''}`} style={{ left: `${n.x / layout.width * 100}%`, top: `${n.y / layout.height * 100}%`, ...themeStyle(n.branch) }}>
              <button
                type="button" data-skill-id={n.id} data-state={status}
                className={`tree-node tree-node-${status} ${isSelected ? 'is-selected' : ''} ${level > 0 ? 'is-learned' : ''}`}
                aria-label={`${n.name}, LEVEL ${level}/${n.maxLv}, ${status === 'mastered' ? 'MAKSIMAL' : status === 'locked' ? 'TERKUNCI' : 'TERBUKA'}`}
                aria-pressed={isSelected} onClick={() => choose(n.id)}
              >
                <span className="tree-node-glyph"><SkillGlyph icon={n.icon} /></span>
                {!n.mastery && <span className="tree-node-pips" aria-hidden="true">{Array.from({ length: n.maxLv }, (_, i) => <i key={i} className={i < level ? 'filled' : ''} />)}</span>}
                {status === 'locked' && <span className="tree-node-lock"><TreeIcon icon="lock" /></span>}
                {n.mastery && <span className="tree-mastery-crown"><SkillGlyph icon="crown" /></span>}
                <span className="tree-node-level font-game">{status === 'mastered' ? 'MAKS' : `${level}/${n.maxLv}`}</span>
                <span className="tree-node-name font-game">{n.short}</span>
                {burst.startsWith(`${n.id}-`) && <span key={burst} className="tree-rank-burst" />}
              </button>
            </div>;
          })}

          <div className="tree-root" style={{ left: `${layout.rootX / layout.width * 100}%`, top: `${layout.rootY / layout.height * 100}%` }}>
            <div className="tree-root-emblem"><TreeArcher /></div>
            <span className="tree-root-caption font-game">{progress.current}<span> / {progress.max} LEVEL</span></span>
          </div>
          <div className="tree-map-hint">PILIH SIMPUL UNTUK MELIHAT POTENSINYA</div>
        </div>
      </section>

      <aside className="skill-detail" style={themeStyle(branch.id)} aria-label="Detail skill" key={selected}>
        <div className="skill-detail-top">
          <span className="skill-detail-category">{node.mastery ? 'PUNCAK KEAHLIAN' : `JALUR ${branch.name}`}</span>
          <span className="skill-detail-rank">LV. {rank}<span>/{node.maxLv}</span></span>
        </div>
        <div className="skill-detail-title"><span className="skill-detail-badge"><SkillGlyph icon={node.icon} /></span><h3 className="font-game">{node.name}</h3></div>
        <div className="skill-level-track" aria-label={`${rank} dari ${node.maxLv} level`}>
          {Array.from({ length: node.maxLv }, (_, i) => <span key={i} className={i < rank ? 'filled' : ''} />)}
        </div>
        <p className="skill-description">{node.description}</p>
        <div className="skill-effect-list">
          {effects.map(([key, amount]) => {
            const related = SKILL_NODES.filter((n) => n.branch === node.branch);
            const currentValue = node.mastery ? related.reduce((sum, n) => sum + (n.effects[key] ?? 0) * skillRank(meta, n.id), 0) : amount * rank;
            const maxValue = node.mastery ? related.reduce((sum, n) => sum + (n.effects[key] ?? 0) * n.maxLv, 0) : amount * node.maxLv;
            const nextValue = node.mastery && state === 'locked' ? maxValue : currentValue + amount * (next - rank);
            return <div className="skill-effect" key={key}>
              <span className="skill-effect-label">{SKILL_EFFECT_NAMES[key]}{node.mastery && ' / TOTAL JALUR'}</span>
              <div className="skill-effect-values"><span><small>SEKARANG</small><strong className="font-game">{formatSkillEffect(key, currentValue)}</strong></span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16m-6-6 6 6-6 6" /></svg><span><small>{state === 'mastered' ? 'MAKSIMAL' : node.mastery && state === 'locked' ? 'JALUR PENUH' : 'BERIKUTNYA'}</small><strong className="next-value font-game">{formatSkillEffect(key, nextValue)}</strong></span></div>
              <span className="skill-effect-max">{node.mastery ? 'MAKS JALUR' : `MAKS LV.${node.maxLv}`}: {formatSkillEffect(key, maxValue)}</span>
            </div>;
          })}
        </div>
        {requirements.length > 0 && <div className="skill-requirements"><span className="skill-section-label">PRASYARAT</span>{requirements.map((r) => <button key={r.id} onClick={() => choose(r.id)} className={r.met ? 'met' : ''}><TreeIcon icon={r.met ? 'check' : 'lock'} /><span>{SKILL_BY[r.id].short}</span><strong>{r.current}/{r.level}</strong></button>)}</div>}
        <div className="skill-purchase-area">
          {cost !== null && <div className="skill-price"><span>BIAYA LATIHAN</span><strong className="font-game"><TreeIcon icon="coin" />{cost}<small>KOIN</small></strong></div>}
          <button type="button" className={`skill-buy font-game ${state === 'mastered' ? 'skill-buy-mastered' : ''}`} disabled={state !== 'available'} onClick={purchase}>
            {state === 'mastered' ? <><TreeIcon icon="check" />LEVEL MAKSIMAL</> : state === 'locked' ? <><TreeIcon icon="lock" />SELESAIKAN PRASYARAT</> : state === 'poor' ? 'KOIN BELUM CUKUP' : <>{rank === 0 ? 'PELAJARI SKILL' : 'NAIKKAN LEVEL'}<span>+</span></>}
          </button>
          <p className="skill-purchase-note">{state === 'poor' && cost !== null ? `BUTUH ${Math.max(0, cost - meta.coins)} KOIN META LAGI.` : state === 'mastered' ? 'LATIHAN TUNTAS. KEAHLIAN MENJADI MILIKMU.' : 'TIDAK HILANG SAAT MATI.'}</p>
        </div>
        <div className="skill-next-run"><TreeIcon icon="shield" /><span>{inRun ? 'UPGRADE BARU AKTIF DI RUN BERIKUTNYA.' : 'BONUS PERMANEN. AKTIF MULAI RUN BARU.'}</span></div>
      </aside>
      <div className="sr-only" aria-live="polite">{announcement}</div>
    </div>
  );
}