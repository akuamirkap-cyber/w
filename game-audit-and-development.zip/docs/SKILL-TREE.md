# Jalur Legenda

Buka **SKILL TREE** dari menu utama, layar mati, atau menu jeda. Tiga cabang memiliki total 12 node dan 34 level latihan. Semua biaya, bonus, posisi node, batas level, dan prasyarat ada di `src/game/ragdoll/config.ts` pada `SKILL_NODES`, `SKILL_BRANCHES`, dan `SKILL_RULES`.

## Tampilan

Pohon memakai latar hutan dari renderer arena yang sama (`paintScene`), ikon berwarna dengan outline hitam, bingkai node tebal, mahkota keahlian puncak, dan tombol upgrade hijau. Pemanah stickman menjadi pangkal jalurnya. Status terkunci, terpilih, dan MAKS memiliki tampilan berbeda.

Implementasi visual ada di `src/SkillTree.tsx`, `src/SkillTreeArt.tsx`, dan `src/skill-tree-game.css`. Parameter latar serta warna cabang ada di `SKILL_TREE_ART`. Redesign ini tidak mengubah harga, bonus, prasyarat, level maksimal, atau format save.

## Cabang

| Jalur | Node awal | Percabangan | Keahlian puncak |
| --- | --- | --- | --- |
| KECEPATAN | LESAT PANAH, maks Lv5 | TANGAN SIGAP dan TARIKAN KILAT, masing-masing maks Lv3 | FULL SPEED, maks Lv1 |
| AKURASI | BIDIKAN MANTAP, maks Lv5 | MATA ELANG dan FORMASI RAPAT, masing-masing maks Lv3 | FULL ACCURACY, maks Lv1 |
| KETAHANAN | NYAWA AWAL, maks Lv5 | NAPAS KEDUA, maks Lv3; KESEMPATAN BARU, maks Lv1 | JIWA BAJA, maks Lv1 |

Node percabangan membutuhkan Lv2 dari node awalnya. Reroll tambahan tetap dapat dibeli sejak awal, agar upgrade lama tidak kehilangan fungsinya. Node puncak membutuhkan seluruh prasyarat di jalurnya sampai level maksimal.

## Bonus Jalur Penuh

| Jalur selesai | Total bonus dari seluruh node di jalur tersebut |
| --- | --- |
| FULL SPEED | Kecepatan panah +20%, laju isi panah +20%, laju tarikan +12%. |
| FULL ACCURACY | Deviasi pelepasan -50%, sebaran Panah Ganda -24%, 18 titik lintasan tambahan. |
| JIWA BAJA | Nyawa maksimal +20%, pemulihan setelah level +9 HP, 1 reroll gratis tambahan per run. |

Panel detail node biasa menunjukkan kontribusi node tersebut. Pada node puncak, label **TOTAL JALUR** menunjukkan bonus gabungan jalurnya; pratinjau node puncak terkunci menampilkan hasil **JALUR PENUH** setelah semua prasyarat tuntas. Tidak ada bonus damage meta permanen. Batas level berlaku untuk node latihan, bukan hard cap level musuh atau total kecepatan dari skin dan kartu.

## Akurasi Nyata

Kode lama memiliki deviasi fisika antara arah kedua tangan dan arah bidikan pemain (`fireAngle`). Latihan akurasi mengurangi deviasi itu menuju arah bidikan pemain. Tidak ada peluang akurasi acak baru, pencarian target, auto-aim, atau panah yang otomatis mengejar musuh. FULL ACCURACY berarti jalur latihannya selesai, bukan jaminan 100% tembakan kena.

Garis lintasan memakai sudut dan kecepatan yang sama dengan panah asli. Formasi rapat hanya mengurangi sudut antar-panah; jumlah panah dan damage tiap panah tetap mengikuti aturan Panah Ganda.

## Penyimpanan

- Upgrade dibayar memakai koin meta dan tidak hilang saat mati.
- Pembelian ditolak jika prasyarat belum terpenuhi, koin tidak cukup, atau level sudah maksimal.
- HP dan reroll dari save lama dimigrasikan tanpa biaya tambahan. Koin, unlock, kosmetik, dan statistik lama dipertahankan.
- Data level tidak valid dibersihkan saat load; node puncak tidak dapat diperoleh lewat prasyarat yang tidak sah.
- Bonus dicatat saat run baru dimulai. Pembelian saat jeda berlaku mulai run berikutnya, sehingga tidak mengubah HP atau lintasan di tengah pertempuran.
- Tidak ada dependensi runtime baru.

## Verifikasi

`npx tsc --noEmit`

`node scripts/test.mjs`

`npm run build`

Tes UI opsional: `node scripts/check-skill-tree.mjs`. Siapkan Playwright sesuai komentar di skrip dan jalankan server Vite pada port 5173.

Playtest manusia tetap diperlukan untuk menala biaya dan kekuatan bonus. Tes otomatis memeriksa transaksi, prasyarat, level maksimal, migrasi, save/reload, dan pengaruh bonus pada game.