# Jadwal Musuh dan Bos

- Level 1 hanya berisi musuh Lv1. Rank tersebut dipakai oleh HP, damage, dan profil AI, bukan sekadar lencana.
- Rank musuh tidak melebihi level arena. Variasi veteran/elit pada level yang lebih tinggi tetap memakai pola sebelumnya.
- Bos hanya dijadwalkan pada level 5, 10, 15, 20, dan seterusnya. Tidak ada lagi mini-bos otomatis setiap level.
- Satu encounter bos normal memakai satu slot wave. Membunuhnya tidak memunculkan bos pengganti.
- Naga menggantikan bos senjata pada setiap milestone bos ketiga: 15, 30, 45. Ia tetap memberi hadiah bos besar, termasuk Panah Ganda, tepat sekali.
- Istana tetap merupakan set-piece dengan penjaga biasa, bukan bos. Jadwal istana tidak diubah.
- Tombol melawan bos di Kamus dari menu utama membuka latihan di level 5. Pemanggilan bos saat run berjalan ditolak di luar level bos atau jika bos level itu sudah muncul.
- Tombol DEBUG bos berpindah ke level bos berikutnya jika perlu. Pemanggilan tambahan secara eksplisit tetap tersedia untuk pengujian, tetapi tidak menyisipkan bos ke level non-bos.
- Adegan demo menu dan pratinjau Kamus bukan run kampanye; keduanya tetap bisa memperagakan jenis musuh yang dipilih.

Angka berada di `src/game/ragdoll/config.ts`: `CFG.bigBoss.every`, `CFG.encounters`, dan `CFG.enemy.ranks`. Aturan murni berada di `formulas.ts`; semua jalur spawn memakai aturan tersebut di `game.ts`.