# Kemampuan Skin

Semua angka baru berada di `src/game/ragdoll/config.ts`, bagian `SKIN_PERKS` dan `SKIN_RULES`. Logika yang dapat diuji ada di `skinPerks.ts`; tabrakan dan efek diterapkan di `game.ts`.

## Daftar Awal

| Skin | Kemampuan |
| --- | --- |
| Ikat Ninja | Kecepatan panah +12%; laju isi panah +10%. |
| Guts | Damage panah +10%; tambahan +25% ketika HP <=40%. |
| Luffy | Damage diterima -12%; dorongan ragdoll +50%. |
| Sanji | Laju isi +12%. Setiap tembakan ke-3: damage +20%, bakar 8 HP/detik selama 2,5 detik. |
| Sephiroth | Tarikan >=90%: damage +18% dan tembus 1 musuh tambahan. |
| Sekiro | Kecepatan +8%. Menembak jatuh senjata bos: +4 HP dan hadiah tangkis +50%. |
| Helm Pembalap | Kecepatan +22%; damage masuk ke kepala -25%. |
| Robin Hood | Emas per kill +20%; headshot mematikan memulihkan 3 HP. |
| Koboi | Kecepatan +8%; tembakan pertama tiap level mendapat damage +45%. |
| Punk | Laju isi +12%. Setiap tembakan ke-4 menyambar 1 musuh terdekat: 35% damage panah dan stun 0,7 detik. |
| Super Saiyan | Tarikan >=90%: kecepatan +18% dan damage +15%. |
| Gojo Berpenutup Mata | Infinity memblokir satu serangan, cooldown 18 detik. |
| Sasuke | Damage headshot +15%; headshot menyetrum selama 0,75 detik. |
| Levi | Laju isi +20%; damage lengan/kaki +35%. |
| Jinwoo | Damage +5%. Setelah kill: tembakan berikutnya mendapat tambahan +25% dan tembus 1 musuh. |
| Vergil | Kecepatan +10%. Setiap tembakan ke-4: damage +25% dan tembus 2 musuh tambahan. |
| Gojo Six Eyes | Gravitasi panah -25%; damage headshot +18%. |
| Rengoku | Semua panah membakar musuh 3 HP/detik selama 2 detik. Headshot meledak: 20% damage panah, radius 80. |

## Aturan Interaksi

- Hanya satu skin kepala dipakai. Warna ikat dan kosmetik jejak panah tidak menambah bonus kedua.
- Tidak ada bonus damage meta permanen atau perubahan statistik dasar tujuh busur.
- Bonus damage kondisional skin dijumlahkan dengan bonus damage dasar skin, lalu dikalikan bersama damage busur/kartu.
- Bonus isi panah adalah peningkatan laju, bukan pengurangan durasi dengan persentase yang sama.
- Tiap tarikan dihitung sekali. Panah Ganda tetap mengeluarkan dua panah masing-masing 60% damage; damage bakar skin juga mengikuti pengali ini.
- Panah menyimpan skin saat dilepaskan. Mengganti skin tidak mengubah panah yang sudah terbang.
- Ganti skin tidak menghapus hitungan tembakan atau cooldown Infinity. Tembakan pembuka Koboi dipakai secara global per level, bukan diulang setiap ganti skin.
- Api skin menyegarkan durasi dan tidak menumpuk dengan dirinya sendiri. Api yang lebih lemah tidak menggantikan api skin yang lebih kuat. Elemen asli busur memakai timer terpisah.
- Api skin berlaku pada musuh, kelelawar, dan naga; tidak menambah pembakaran balok istana. Mekanik api busur pada istana tetap seperti sebelumnya.
- Bonus kill ikut bekerja pada kill kartu dan runtuhan istana yang dapat dilacak ke panah pemain.
- Infinity digunakan sebelum kartu Perisai; satu serangan tidak menghabiskan kedua pelindung sekaligus.
- Cooldown berjalan saat bermain, bukan saat jeda. Status sementara direset pada run baru. Pilihan skin tersimpan lokal.
- Efek damage sekunder skin tidak melewati aturan tantangan harian "HANYA HEADSHOT".
- Skin pada musuh tetap kosmetik. Bonus ini hanya untuk pemain.

## Pemeriksaan

Jalankan `npx tsc --noEmit`, `node scripts/test.mjs`, dan `npm run build`.

Pengujian browser opsional: `node scripts/check-skin-perks-ui.mjs` dengan Vite berjalan di port 5173 dan Playwright terpasang sesuai komentar skrip.

Untuk playtest manual, pilih skin di menu SKIN, periksa deskripsi angka, lalu mainkan. Klik indikator kemampuan di HUD untuk melihat kembali detail atau berganti skin. Uji khusus: tiga tembakan Sanji, empat tembakan Vergil/Punk, parry Sekiro, headshot Rengoku, dan dua serangan berurutan ketika Gojo memakai kartu Perisai.

Angka di atas adalah nilai awal. Kekuatan relatif antarskin masih perlu ditala lewat playtest manusia; tes otomatis memeriksa kebenaran mekanik, bukan rasa permainan atau retensi.