// Optional UI QA: npm install --prefix /tmp/ragdoll-visual playwright
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const require = createRequire('/tmp/ragdoll-visual/package.json');
const { chromium } = require('playwright');
const dir = 'node_modules/.cache/skin-perks';
mkdirSync(dir, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
const skinButton = (name) => page.getByRole('button').filter({ has: page.getByText(name, { exact: true }) });

try {
  await page.goto(process.env.GAME_URL ?? 'http://localhost:5173');
  await page.waitForTimeout(1000);
  await page.getByRole('button', { name: /Ganti Skin Kepala/ }).click();
  await skinButton('RAMBUT GUTS').click();
  assert.equal(await skinButton('RAMBUT GUTS').getAttribute('aria-pressed'), 'false');
  assert.ok(await page.getByText('TERKUNCI: BUNUH 300 MUSUH', { exact: true }).isVisible());
  assert.equal(await page.evaluate(() => localStorage.getItem('perfectshot.ragdoll.head') ?? 'band'), 'band');
  await page.screenshot({ path: `${dir}/locked-preview.png` });

  await page.evaluate(() => localStorage.setItem('perfectshot.ragdoll.meta.v1', JSON.stringify({ v: 1, unlocked: ['cos:hat_guts', 'cos:hat_sephiroth'] })));
  await page.reload(); await page.waitForTimeout(900);
  const skins = await page.evaluate(async () => {
    const { SKIN_LIST } = await import('/src/SkinModal.tsx');
    const { SKIN_PERKS } = await import('/src/game/ragdoll/config.ts');
    const { skinPerkLines } = await import('/src/game/ragdoll/skinPerks.ts');
    return SKIN_LIST.map((s) => ({ id: s.id, name: s.name, perk: SKIN_PERKS[s.id].name, lines: skinPerkLines(s.id) }));
  });
  assert.equal(skins.length, 18);
  await page.getByRole('button', { name: /Ganti Skin Kepala/ }).click();
  for (const skin of skins) {
    await skinButton(skin.name).click(); await page.waitForTimeout(100);
    assert.equal(await skinButton(skin.name).getAttribute('aria-pressed'), 'true');
    const details = await page.getByRole('list', { name: `Bonus ${skin.name}` }).textContent();
    for (const line of skin.lines) assert.ok(details.includes(line), `${skin.id}: ${line}`);
    assert.equal(await page.evaluate(() => localStorage.getItem('perfectshot.ragdoll.head') ?? 'band'), skin.id);
    console.log(`${skin.id}: BONUS TEXT, EQUIP, SAVE OK`);
  }
  await page.screenshot({ path: `${dir}/desktop-menu.png` });
  await page.getByRole('button', { name: 'Tutup Skin' }).click();
  await page.getByRole('button', { name: 'Mulai bermain', exact: true }).click({ force: true });
  await page.waitForTimeout(1100);
  const ability = page.getByRole('button', { name: 'Kemampuan skin: NAPAS API' });
  assert.ok(await ability.isVisible());
  await page.screenshot({ path: `${dir}/desktop-hud.png` });
  await ability.click();
  await skinButton('RAMBUT GOJO').click();
  await page.getByRole('button', { name: 'Tutup Skin' }).click();
  await page.getByRole('button', { name: 'Kemampuan skin: INFINITY' }).waitFor({ state: 'visible' });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(250);
  await page.screenshot({ path: `${dir}/mobile-hud.png` });
  await page.getByRole('button', { name: 'Kemampuan skin: INFINITY' }).click();
  await skinButton('RAMBUT SANJI').click();
  assert.ok(await page.getByRole('list', { name: 'Bonus RAMBUT SANJI' }).isVisible());
  await page.screenshot({ path: `${dir}/mobile-menu.png` });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  assert.deepEqual(errors, []);
  writeFileSync(`${dir}/results.json`, JSON.stringify({ skins: skins.length, lockedPreview: true, menuNumbersMatchConfig: true, liveHud: true, mobile: true, errors }, null, 2));
  console.log('LOCKED PREVIEW, LIVE HUD, MOBILE: OK');
} finally {
  await browser.close();
}