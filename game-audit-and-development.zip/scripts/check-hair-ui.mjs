// Optional browser QA: npm install --prefix /tmp/ragdoll-visual playwright
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const require = createRequire('/tmp/ragdoll-visual/package.json');
const { chromium } = require('playwright');
const dir = 'node_modules/.cache/hair-preview';
mkdirSync(dir, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
const url = process.env.GAME_URL ?? 'http://localhost:5173';
const skins = process.argv.includes('--new')
  ? [['jinwoo', 'JINWOO'], ['vergil', 'VERGIL'], ['gojo_blue', 'GOJO SIX EYES'], ['rengoku', 'RENGOKU']]
  : [['saiyan', 'SUPER SAIYAN'], ['gojo', 'GOJO'], ['sasuke', 'SASUKE'], ['levi', 'LEVI']];
const skinButton = (name) => page.getByRole('button').filter({ has: page.getByText(`RAMBUT ${name}`, { exact: true }) });

try {
  await page.goto(url);
  await page.waitForTimeout(1200);
  for (const [id, name] of skins) {
    await page.getByRole('button', { name: /Ganti Skin Kepala/ }).click();
    const option = skinButton(name);
    await option.click();
    await page.waitForTimeout(400);
    assert.equal(await option.getAttribute('aria-pressed'), 'true');
    assert.equal(await page.evaluate(() => localStorage.getItem('perfectshot.ragdoll.head')), id);
    await page.screenshot({ path: `${dir}/desktop-${id}.png` });
    await page.locator('canvas').last().click({ position: { x: 100, y: 100 } });
    await page.getByRole('button', { name: /TES FREESTYLE MENANG/ }).click();
    await page.waitForTimeout(600);
    await page.getByRole('button', { name: 'Tutup Skin' }).click();
    // MAIN pulses continuously, so its bounding box never passes Playwright's stability wait.
    await page.getByRole('button', { name: 'Mulai bermain', exact: true }).click({ force: true });
    await page.waitForTimeout(900);
    const arena = await page.getByLabel('Arena ragdoll archer', { exact: true }).boundingBox();
    assert.ok(arena);
    await page.mouse.move(arena.x + arena.width * 0.38, arena.y + arena.height * 0.55);
    await page.mouse.down();
    await page.mouse.move(arena.x + arena.width * 0.22, arena.y + arena.height * 0.59, { steps: 12 });
    await page.waitForTimeout(400);
    await page.mouse.up();
    await page.waitForTimeout(1300);
    await page.screenshot({ path: `${dir}/game-${id}.png` });
    await page.reload();
    await page.waitForTimeout(900);
    assert.equal(await page.evaluate(() => localStorage.getItem('perfectshot.ragdoll.head')), id);
    console.log(`${id}: SELECT, RECOIL, FREESTYLE, LIVE SHOT, SAVE/RELOAD OK`);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: /Ganti Skin Kepala/ }).click();
  await skinButton(skins[skins.length - 1][1]).scrollIntoViewIfNeeded();
  await page.screenshot({ path: `${dir}/mobile.png` });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  assert.deepEqual(errors, [], 'NO BROWSER RUNTIME ERRORS');
  writeFileSync(`${dir}/browser-results.json`, JSON.stringify({ skins: skins.map(([id]) => id), saveReload: true, recoilFreestyle: true, liveShots: true, mobileOverflow: false, errors }, null, 2));
  console.log('MOBILE LAYOUT OK; NO BROWSER ERRORS');
} finally {
  await browser.close();
}