// Optional browser QA: npm install --prefix /tmp/ragdoll-visual playwright
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const require = createRequire('/tmp/ragdoll-visual/package.json');
const { chromium } = require('playwright');
const dir = 'node_modules/.cache/skill-tree';
mkdirSync(dir, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
const open = async () => {
  await page.getByRole('button', { name: 'Skill tree, progres, unlock & statistik' }).click();
  await page.getByRole('dialog', { name: 'JALUR LEGENDA' }).waitFor({ state: 'visible' });
  await page.waitForTimeout(600);
};
const node = (id) => page.locator(`[data-skill-id="${id}"]`);

try {
  await page.goto(process.env.GAME_URL ?? 'http://localhost:5173');
  await page.waitForTimeout(1000);
  await open();
  assert.equal(await page.locator('[data-skill-id]').count(), 12);
  assert.equal(await page.locator('.tree-forest').evaluate((canvas) => canvas.getContext('2d').getImageData(10, 10, 1, 1).data[3]), 255, 'ARENA FOREST IS PAINTED');
  assert.equal(await node('speed').getAttribute('data-state'), 'poor');
  assert.ok(await page.getByRole('button', { name: 'KOIN BELUM CUKUP' }).isDisabled());
  await page.screenshot({ path: `${dir}/fresh-desktop.png` });
  await node('full_speed').click();
  assert.equal(await node('full_speed').getAttribute('data-state'), 'locked');
  assert.ok(await page.getByRole('button', { name: 'SELESAIKAN PRASYARAT' }).isDisabled());

  // Upgrade an actual legacy save through UI transactions.
  await page.evaluate(() => localStorage.setItem('perfectshot.ragdoll.meta.v1', JSON.stringify({ v: 1, coins: 2300, up: { hp: 2, reroll: 1 }, unlocked: ['bow:fire'] })));
  await page.reload(); await page.waitForTimeout(900); await open();
  assert.ok((await node('vitality').getAttribute('aria-label')).includes('LEVEL 2/5'));
  assert.equal(await node('reroll').getAttribute('data-state'), 'mastered');
  for (const [id, count] of [['speed', 5], ['reload', 3], ['draw', 3], ['full_speed', 1]]) {
    await node(id).click();
    for (let i = 0; i < count; i++) {
      const buy = page.getByRole('button', { name: /^(PELAJARI SKILL|NAIKKAN LEVEL)/ });
      await buy.click();
      assert.ok((await node(id).getAttribute('aria-label')).includes(`LEVEL ${i + 1}/${count}`));
    }
    assert.equal(await node(id).getAttribute('data-state'), 'mastered');
  }
  assert.ok(await page.getByRole('button', { name: 'LEVEL MAKSIMAL' }).isDisabled());
  let save = await page.evaluate(() => JSON.parse(localStorage.getItem('perfectshot.ragdoll.meta.v1')));
  assert.equal(save.coins, 660); assert.equal(save.tree.full_speed, 1); assert.equal(save.up.hp, 2);
  assert.ok(save.unlocked.includes('bow:fire'));
  await page.waitForTimeout(700);
  await page.screenshot({ path: `${dir}/mastered-desktop.png` });
  await page.reload(); await page.waitForTimeout(900); await open();
  assert.equal(await node('full_speed').getAttribute('data-state'), 'mastered');
  for (const tab of ['UNLOCK', 'STATISTIK', 'BUKU', 'HARIAN', 'ATUR', 'POHON SKILL']) {
    await page.getByRole('tab', { name: tab, exact: true }).click();
    assert.equal(await page.getByRole('tab', { name: tab, exact: true }).getAttribute('aria-selected'), 'true');
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await node('accuracy').click();
  const mobileFrame = await page.getByRole('dialog', { name: 'JALUR LEGENDA' }).boundingBox();
  assert.ok(mobileFrame && mobileFrame.x >= 0 && mobileFrame.x + mobileFrame.width <= 390, 'MODAL FITS PHONE WIDTH');
  const closeButton = await page.getByRole('button', { name: 'Tutup progres' }).boundingBox();
  assert.ok(closeButton && closeButton.x + closeButton.width <= 390, 'CLOSE CONTROL NOT CLIPPED');
  await page.screenshot({ path: `${dir}/mobile-accuracy.png` });
  const buy = page.getByRole('button', { name: 'PELAJARI SKILL +' });
  await buy.click();
  save = await page.evaluate(() => JSON.parse(localStorage.getItem('perfectshot.ragdoll.meta.v1')));
  assert.equal(save.tree.accuracy, 1); assert.equal(save.coins, 610);
  await node('full_accuracy').click();
  await page.screenshot({ path: `${dir}/mobile-locked.png` });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.setViewportSize({ width: 320, height: 740 });
  await node('speed').click();
  const smallFrame = await page.getByRole('dialog', { name: 'JALUR LEGENDA' }).boundingBox();
  assert.ok(smallFrame && smallFrame.x >= 0 && smallFrame.x + smallFrame.width <= 320, 'SMALL PHONE FRAME FITS');
  assert.equal(await node('speed').locator('.tree-node-level').evaluate((el) => getComputedStyle(el).color), 'rgb(20, 44, 55)', 'MAX LABEL HAS DARK INK');
  await page.getByRole('button', { name: 'LEVEL MAKSIMAL' }).scrollIntoViewIfNeeded();
  await page.screenshot({ path: `${dir}/small-phone.png` });
  await page.setViewportSize({ width: 740, height: 390 });
  await node('full_accuracy').click();
  await page.screenshot({ path: `${dir}/landscape.png` });
  assert.ok(await page.getByRole('button', { name: 'Tutup progres' }).isVisible());
  await page.keyboard.press('Escape');
  assert.equal(await page.getByRole('dialog', { name: 'JALUR LEGENDA' }).count(), 0);

  await page.setViewportSize({ width: 1280, height: 800 });
  await page.getByRole('button', { name: 'Mulai bermain', exact: true }).click({ force: true });
  await page.waitForTimeout(900);
  assert.ok(await page.getByLabel('Nyawa 106 dari 106', { exact: true }).isVisible());
  await page.getByRole('button', { name: 'Jeda & Menu Perlengkapan' }).click();
  await page.getByRole('button', { name: 'SKILL TREE / PROGRES PERMANEN' }).click();
  assert.ok(await page.getByText('UPGRADE BARU AKTIF DI RUN BERIKUTNYA.', { exact: true }).isVisible());
  await page.keyboard.press('Escape');
  assert.ok(await page.getByText('JEDA', { exact: true }).isVisible());

  // Finish the other paths through the same purchase controls, not direct rank injection.
  await page.evaluate(() => {
    const saved = JSON.parse(localStorage.getItem('perfectshot.ragdoll.meta.v1'));
    saved.coins = 7000;
    localStorage.setItem('perfectshot.ragdoll.meta.v1', JSON.stringify(saved));
  });
  await page.reload(); await page.waitForTimeout(900); await open();
  for (const [id, count] of [['accuracy', 4], ['trajectory', 3], ['spread', 3], ['full_accuracy', 1], ['vitality', 3], ['recovery', 3], ['full_vitality', 1]]) {
    await node(id).click();
    for (let i = 0; i < count; i++) await page.getByRole('button', { name: /^(PELAJARI SKILL|NAIKKAN LEVEL)/ }).click();
    assert.equal(await node(id).getAttribute('data-state'), 'mastered');
  }
  assert.equal(await page.locator('[data-skill-id][data-state="mastered"]').count(), 12);
  await node('full_accuracy').click(); await page.waitForTimeout(700);
  assert.ok(await page.getByText('-50%', { exact: true }).count() > 0);
  await page.screenshot({ path: `${dir}/all-mastered.png` });
  await page.getByRole('button', { name: 'Tutup progres' }).click();
  await page.getByRole('button', { name: 'Mulai bermain', exact: true }).click({ force: true });
  await page.waitForTimeout(900);
  assert.ok(await page.getByLabel('Nyawa 120 dari 120', { exact: true }).isVisible());
  assert.deepEqual(errors, []);
  writeFileSync(`${dir}/results.json`, JSON.stringify({ nodes: 12, forestRendered: true, smallPhoneContained: true, maxLabelsReadable: true, legacyMigration: true, prerequisites: true, allMasteriesPurchased: true, maxLevels: true, exactCosts: true, saveReload: true, mobilePurchase: true, liveHpBonus: true, pausePreserved: true, errors }, null, 2));
  console.log('TREE, PREREQUISITES, MAX LEVELS, LEGACY SAVE, PURCHASES, RELOAD, MOBILE, LIVE GAME: OK');
} finally {
  await browser.close();
}