// Runner tes tanpa dependensi baru: esbuild (sudah ada via Vite) mem-bundle *.test.ts → node --test.
// Pakai: node scripts/test.mjs
import { build } from 'esbuild';
import { mkdirSync, readdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const dir = 'src/game/ragdoll/__tests__';
const outDir = 'node_modules/.cache/ragdoll-tests';
mkdirSync(outDir, { recursive: true });
const outs = [];
for (const f of readdirSync(dir).filter((x) => x.endsWith('.test.ts'))) {
  const out = `${outDir}/${f.replace(/\.ts$/, '.mjs')}`;
  await build({ entryPoints: [`${dir}/${f}`], bundle: true, platform: 'node', format: 'esm', outfile: out, logLevel: 'error' });
  outs.push(out);
}
const r = spawnSync(process.execPath, ['--test', ...outs], { stdio: 'inherit' });
process.exit(r.status ?? 1);
