// Optional visual QA: npm install --prefix /tmp/ragdoll-visual @napi-rs/canvas
import { build } from 'esbuild';
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

const require = createRequire('/tmp/ragdoll-visual/package.json');
const { createCanvas } = require('@napi-rs/canvas');
const dir = 'node_modules/.cache/hair-preview';
mkdirSync(dir, { recursive: true });
await build({
  stdin: {
    contents: `export { paintSkinThumb, drawSkinFigure, settledFigure, stepSkinStage } from './src/SkinModal';
      export { impulse } from './src/game/ragdoll/stick';`,
    resolveDir: process.cwd(),
    loader: 'ts',
  },
  bundle: true, platform: 'node', format: 'esm', outfile: `${dir}/preview.mjs`,
});
const { paintSkinThumb, drawSkinFigure, settledFigure, stepSkinStage, impulse } = await import(pathToFileURL(resolve(`${dir}/preview.mjs`)).href);
const styles = process.argv.includes('--new')
  ? ['jinwoo', 'vergil', 'gojo_blue', 'rengoku']
  : ['saiyan', 'gojo', 'sasuke', 'levi'];
const W = 1120;
const H = 960;
const canvas = createCanvas(W, H);
const ctx = canvas.getContext('2d');
ctx.fillStyle = '#081c29'; ctx.fillRect(0, 0, W, H);
for (const [col, style] of styles.entries()) {
  const oldRandom = Math.random;
  Math.random = () => 0.42;
  ctx.save(); ctx.translate(col * 280 + 6, 32);
  ctx.beginPath(); ctx.rect(0, 0, 268, 268); ctx.clip();
  paintSkinThumb(ctx, 268, style); ctx.restore();
  const { k, hair } = settledFigure(style);
  const sim = { k, hair, cyc: 1, arrows: [], skin: style };
  for (let i = 0; i < 420; i++) {
    if (i === 100) impulse(k, 0, { x: -280, y: -50 });
    stepSkinStage(sim);
  }
  ctx.save();
  ctx.beginPath(); ctx.rect(col * 280, 320, 280, 460); ctx.clip();
  ctx.translate(col * 280 + 150 - k.p[0].x * 6, 530 - k.p[0].y * 6);
  ctx.scale(6, 6);
  drawSkinFigure(ctx, k, style, hair, 4.6, null);
  ctx.restore();
  ctx.save(); ctx.translate(col * 280 + 35, 824); ctx.beginPath(); ctx.rect(0, 0, 84, 84); ctx.clip(); paintSkinThumb(ctx, 84, style); ctx.restore();
  ctx.save(); ctx.translate(col * 280 + 235, 824); ctx.scale(-1, 1); ctx.beginPath(); ctx.rect(0, 0, 84, 84); ctx.clip(); paintSkinThumb(ctx, 84, style); ctx.restore();
  Math.random = oldRandom;
  ctx.font = 'bold 16px sans-serif'; ctx.fillStyle = '#d7e9f6';
  ctx.fillText(style.toUpperCase(), col * 280 + 15, 23);
}
const file = `${dir}/${process.argv[2] ?? 'current'}.png`;
writeFileSync(file, canvas.toBuffer('image/png'));
console.log(file);