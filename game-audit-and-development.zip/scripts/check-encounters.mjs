// Optional browser QA: npm install --prefix /tmp/ragdoll-visual playwright
import { createRequire } from 'node:module';
import { mkdirSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const require = createRequire('/tmp/ragdoll-visual/package.json');
const { chromium } = require('playwright');
const dir = 'node_modules/.cache/encounters';
mkdirSync(dir, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', (e) => errors.push(e.message));
await page.addInitScript(() => {
  localStorage.setItem('perfectshot.ragdoll.meta.v1', JSON.stringify({ v: 1, settings: { debug: true } }));
  window.__arenaTexts = [];
  const original = CanvasRenderingContext2D.prototype.fillText;
  CanvasRenderingContext2D.prototype.fillText = function (text, ...args) {
    if (this.canvas.getAttribute?.('aria-label') === 'Arena ragdoll archer') {
      if (!window.__arenaTexts.includes(String(text))) window.__arenaTexts.push(String(text));
    }
    return original.call(this, text, ...args);
  };
});
const arenaLevel = (level) => page.getByLabel(new RegExp(`^Level ${level}, \\d+ dari \\d+ musuh$`));
const jump = async (level) => {
  await page.getByRole('button', { name: 'DBG', exact: true }).click();
  await page.locator('input[type="number"]').fill(String(level));
  await page.getByRole('button', { name: 'LOMPAT LEVEL', exact: true }).click();
  await page.getByText('DEBUG', { exact: true }).locator('..').getByRole('button').click();
  await arenaLevel(level).waitFor({ state: 'visible' });
};

try {
  await page.goto(process.env.GAME_URL ?? 'http://localhost:5173');
  await page.waitForTimeout(1000);
  await page.getByRole('button', { name: 'Mulai bermain', exact: true }).click({ force: true });
  await arenaLevel(1).waitFor({ state: 'visible' });
  await page.waitForTimeout(2400);
  assert.equal(await page.getByText('BOS', { exact: true }).count(), 0);
  let texts = await page.evaluate(() => window.__arenaTexts);
  assert.ok(texts.some((t) => t.includes('LEVEL 1 / ARENA PEMANAH')));
  assert.ok(!texts.some((t) => t.startsWith('BOS BESAR:') || t.startsWith('MINI-BOS') || t === 'BOS NAGA MERAH!'));
  await page.screenshot({ path: `${dir}/level-1.png` });

  await jump(5);
  await page.getByText('BOS', { exact: true }).waitFor({ state: 'visible' });
  await page.waitForTimeout(3000);
  await page.screenshot({ path: `${dir}/level-5.png` });
  texts = await page.evaluate(() => window.__arenaTexts);
  assert.ok(texts.some((t) => t.startsWith('BOS BESAR:')));

  await jump(6); await page.waitForTimeout(1500);
  assert.equal(await page.getByText('BOS', { exact: true }).count(), 0);
  await page.screenshot({ path: `${dir}/level-6.png` });
  await jump(15); await page.waitForTimeout(3400);
  assert.ok(await page.getByText('BOS', { exact: true }).isVisible());
  texts = await page.evaluate(() => window.__arenaTexts);
  assert.ok(texts.includes('BOS NAGA MERAH!'));
  await page.screenshot({ path: `${dir}/level-15.png` });

  await page.reload(); await page.waitForTimeout(1000);
  await page.getByRole('button', { name: 'Kamus Musuh, Istana Kayu & 5 Bos' }).click();
  await page.getByRole('button', { name: /5 BOS$/ }).click();
  await page.getByRole('button', { name: /RAJA IBLIS MAGMA/ }).click();
  await page.getByRole('button', { name: /LAWAN BOS INI SEKARANG/ }).click();
  await arenaLevel(5).waitFor({ state: 'visible' });
  await page.waitForTimeout(3000);
  texts = await page.evaluate(() => window.__arenaTexts);
  assert.ok(texts.some((t) => t.startsWith('BOS BESAR:') && t.includes('RAJA IBLIS MAGMA')));
  await page.screenshot({ path: `${dir}/codex-practice-5.png` });
  assert.deepEqual(errors, []);
  writeFileSync(`${dir}/results.json`, JSON.stringify({ level1NoBoss: true, level5Boss: true, level6NoBoss: true, level15Dragon: true, chosenBossPracticeAt5: true, errors }, null, 2));
  console.log('LEVEL 1/5/6/15, HUD, INTRO, CODEX PRACTICE: OK');
} finally {
  await browser.close();
}