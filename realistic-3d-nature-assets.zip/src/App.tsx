import { useEffect, useRef, useState, useCallback } from 'react';
import {
  Trees,
  Mountain,
  Sprout,
  Layers,
  Route,
  Sun,
  Sunset,
  CloudFog,
  Cloud,
  Download,
  Camera,
  SlidersHorizontal,
  Eye,
  EyeOff,
  RotateCw,
  Sparkles,
  Wind,
  Compass,
  Check,
  Loader2,
  X,
} from 'lucide-react';
import {
  AssetMode,
  CameraPreset,
  EngineTelemetry,
  ForestStudioEngine,
  getMoodDefaults,
  LightingMood,
  SceneSettings,
  TreeVariant,
  ViewShadingMode,
} from './engine/sceneManager';

const INITIAL_SETTINGS: SceneSettings = {
  assetMode: 'full',
  treeVariant: 'broadleaf',
  lightingMood: 'midday',
  shadingMode: 'beauty',
  sunAzimuth: 142,
  sunElevation: 44,
  windStrength: 0.72,
  translucency: 1.0,
  exposure: 1.04,
  bloomStrength: 0.14,
  sunbeamsVisible: true,
  autoRotate: false,
};

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<ForestStudioEngine | null>(null);

  const [settings, setSettings] = useState<SceneSettings>(INITIAL_SETTINGS);
  const [telemetry, setTelemetry] = useState<EngineTelemetry>({
    fps: 60,
    triangles: 0,
    drawCalls: 0,
    instancedObjects: 0,
    assetName: 'Japanese Touge Forest & Mountain Asphalt Scene',
  });
  const [isReady, setIsReady] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 1180 : true
  );
  const [cinemaMode, setCinemaMode] = useState(false);
  const [activeCameraPreset, setActiveCameraPreset] = useState<CameraPreset>('reference');
  const [exportState, setExportState] = useState<'idle' | 'exporting' | 'done'>('idle');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 2800);
  }, []);

  // Initialize Three.js WebGL Forest Studio Engine once on mount
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    // Slight defer allows loader paint before procedural PBR canvas baking runs
    const timer = window.setTimeout(() => {
      const engine = new ForestStudioEngine(el, INITIAL_SETTINGS, (stats) => {
        setTelemetry(stats);
      });
      engineRef.current = engine;
      setIsReady(true);
    }, 40);

    return () => {
      window.clearTimeout(timer);
      if (engineRef.current) {
        engineRef.current.dispose();
        engineRef.current = null;
      }
    };
  }, []);

  // Keyboard shortcut: 'H' toggles Cinema Mode (hide all UI)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'h' || e.key === 'H') {
        setCinemaMode((v) => !v);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const handleAssetMode = (mode: AssetMode) => {
    setSettings((s) => ({ ...s, assetMode: mode }));
    if (mode === 'full') setActiveCameraPreset('reference');
    engineRef.current?.switchAssetMode(mode, settings.treeVariant, false);
  };

  const handleTreeVariant = (variant: TreeVariant) => {
    setSettings((s) => ({ ...s, assetMode: 'tree', treeVariant: variant }));
    engineRef.current?.switchAssetMode('tree', variant, false);
  };

  const handleMood = (mood: LightingMood) => {
    const defs = getMoodDefaults(mood);
    setSettings((s) => ({
      ...s,
      lightingMood: mood,
      sunAzimuth: defs.sunAzimuth,
      sunElevation: defs.sunElevation,
      exposure: defs.exposure,
      bloomStrength: defs.bloomStrength,
    }));
    engineRef.current?.applyLightingMood(mood, true);
  };

  const handleSunAzimuth = (val: number) => {
    setSettings((s) => ({ ...s, sunAzimuth: val }));
    engineRef.current?.updateSunPosition(val, settings.sunElevation, false);
  };

  const handleSunElevation = (val: number) => {
    setSettings((s) => ({ ...s, sunElevation: val }));
    engineRef.current?.updateSunPosition(settings.sunAzimuth, val, false);
  };

  const handleWind = (val: number) => {
    setSettings((s) => ({ ...s, windStrength: val }));
    engineRef.current?.setWindStrength(val);
  };

  const handleTranslucency = (val: number) => {
    setSettings((s) => ({ ...s, translucency: val }));
    engineRef.current?.setTranslucency(val);
  };

  const handleExposure = (val: number) => {
    setSettings((s) => ({ ...s, exposure: val }));
    engineRef.current?.setExposure(val);
  };

  const handleBloom = (val: number) => {
    setSettings((s) => ({ ...s, bloomStrength: val }));
    engineRef.current?.setBloomStrength(val);
  };

  const handleSunbeams = (checked: boolean) => {
    setSettings((s) => ({ ...s, sunbeamsVisible: checked }));
    engineRef.current?.setSunbeamsVisible(checked);
  };

  const handleAutoRotate = (checked: boolean) => {
    setSettings((s) => ({ ...s, autoRotate: checked }));
    engineRef.current?.setAutoRotate(checked);
  };

  const handleShadingMode = (mode: ViewShadingMode) => {
    setSettings((s) => ({ ...s, shadingMode: mode }));
    engineRef.current?.setShadingMode(mode);
  };

  const handleCameraPreset = (preset: CameraPreset) => {
    setActiveCameraPreset(preset);
    setSettings((s) => ({ ...s, assetMode: 'full' }));
    engineRef.current?.applyCameraPreset(preset);
  };

  const handleCapturePNG = () => {
    if (!engineRef.current) return;
    const dataUrl = engineRef.current.captureSnapshotPNG();
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `touge-forest-3d-${settings.assetMode}-hd.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast('HD Snapshot PNG berhasil disimpan!');
  };

  const handleExportGLB = async () => {
    if (!engineRef.current || exportState === 'exporting') return;
    setExportState('exporting');
    try {
      await engineRef.current.exportCurrentAssetGLB();
      setExportState('done');
      showToast('3D Asset (.GLB) siap untuk Blender / Unreal / Unity!');
      window.setTimeout(() => setExportState('idle'), 2200);
    } catch {
      setExportState('idle');
      showToast('Gagal mengekspor GLB.');
    }
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#0a0d0a]">
      {/* 100% Full-Bleed WebGL2 Photorealistic 3D Viewport */}
      <div
        ref={mountRef}
        className="h-full w-full cursor-grab active:cursor-grabbing"
      />

      {/* Sleek Loading Overlay while Procedural 2K/1K PBR Textures & Botanical Meshes Bake */}
      {!isReady && (
        <div className="pointer-events-none fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#0a0e0a] transition-opacity duration-500">
          <div className="flex flex-col items-center gap-4">
            <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl border border-[#a8e05f]/30 bg-[#131a12]">
              <Loader2 className="h-7 w-7 animate-spin text-[#a8e05f]" />
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold tracking-wider text-[#edf4ea] uppercase">
                Generating Procedural PBR Forest Assets
              </p>
              <p className="font-mono-tech mt-1 text-xs text-[#8ea088]">
                Baking Botanical Sprigs · Touge Asphalt · Forest Mulch · HDRI Sky · SSS Shaders
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Toast Feedback Notification */}
      {toastMsg && (
        <div className="pointer-events-none fixed top-20 left-1/2 z-40 -translate-x-1/2 rounded-full border border-[#a8e05f]/40 bg-[#101710]/90 px-4 py-2 text-xs font-medium text-[#d8f7a6] shadow-2xl backdrop-blur-md">
          {toastMsg}
        </div>
      )}

      {/* Cinema Mode Floating Restore Button */}
      {cinemaMode && (
        <button
          onClick={() => setCinemaMode(false)}
          className="fixed top-4 right-4 z-30 flex items-center gap-2 rounded-full border border-white/15 bg-black/55 px-3.5 py-2 text-xs font-medium text-white/90 backdrop-blur-md transition hover:border-[#a8e05f]/60 hover:bg-black/75"
        >
          <Eye className="h-3.5 w-3.5 text-[#a8e05f]" />
          <span>Tampilkan UI (H)</span>
        </button>
      )}

      {/* Main Studio HUD (Hidden cleanly in Cinema Mode) */}
      {!cinemaMode && (
        <>
          {/* TOP-LEFT: Compact Brand Badge & Real-Time Asset Telemetry */}
          <div className="pointer-events-none fixed top-4 left-4 z-20 flex flex-col gap-2">
            <div className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-white/12 bg-[#0d120d]/72 px-3.5 py-2.5 shadow-xl backdrop-blur-xl">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#a8e05f] to-[#4e8f24] text-[#0c1409] shadow-md shadow-[#a8e05f]/20">
                <Trees className="h-5 w-5 stroke-[2.2]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xs font-bold tracking-wider text-white uppercase">
                    Touge Forest 3D
                  </h1>
                  <span className="rounded bg-[#a8e05f]/18 px-1.5 py-0.5 font-mono-tech text-[10px] font-semibold text-[#b8f06a]">
                    ACES HDR
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-[#aebca8]">
                  {telemetry.assetName}
                </p>
              </div>
            </div>

            {/* Technical PBR Asset Readout Bar */}
            <div className="flex flex-wrap items-center gap-1.5">
              <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-[#0d120d]/62 px-2.5 py-1.5 font-mono-tech text-[10px] text-[#b8c6b3] backdrop-blur-md">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-[#a8e05f] shadow-[0_0_6px_#a8e05f]" />
                <span>{telemetry.fps} FPS</span>
                <span className="text-white/20">|</span>
                <span>{formatNumber(telemetry.triangles)} TRIS</span>
                {telemetry.instancedObjects > 0 && (
                  <>
                    <span className="text-white/20">|</span>
                    <span>{formatNumber(telemetry.instancedObjects)} INST</span>
                  </>
                )}
                <span className="text-white/20">|</span>
                <span className="text-[#c0f278]">PBR + SSS</span>
              </div>
            </div>
          </div>

          {/* TOP-RIGHT: Primary Studio Actions (Export GLB, HD Capture, Cinema, Inspector Toggle) */}
          <div className="fixed top-4 right-4 z-30 flex items-center gap-2">
            <button
              onClick={handleExportGLB}
              disabled={exportState === 'exporting'}
              title="Download 3D model (.GLB) untuk Blender / Unreal / Unity"
              className="flex items-center gap-2 rounded-xl border border-[#b4ef66]/50 bg-gradient-to-r from-[#87c934] to-[#68ab24] px-3.5 py-2 text-xs font-semibold text-[#0b1307] shadow-lg shadow-[#87c934]/20 transition hover:brightness-110 active:scale-[0.98] disabled:opacity-60"
            >
              {exportState === 'exporting' ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : exportState === 'done' ? (
                <Check className="h-3.5 w-3.5 stroke-[2.6]" />
              ) : (
                <Download className="h-3.5 w-3.5 stroke-[2.3]" />
              )}
              <span>
                {exportState === 'exporting'
                  ? 'Exporting...'
                  : exportState === 'done'
                    ? 'Saved .GLB'
                    : 'Export .GLB'}
              </span>
            </button>

            <button
              onClick={handleCapturePNG}
              title="Simpan Screenshot HD (.PNG)"
              className="flex items-center gap-1.5 rounded-xl border border-white/14 bg-[#0d120d]/72 px-3 py-2 text-xs font-medium text-[#e5eee2] backdrop-blur-xl transition hover:border-white/30 hover:bg-[#172017]/85"
            >
              <Camera className="h-3.5 w-3.5 text-[#a8e05f]" />
              <span className="hidden sm:inline">HD Photo</span>
            </button>

            <button
              onClick={() => setCinemaMode(true)}
              title="Mode Cinema - Sembunyikan UI (Tombol H)"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/14 bg-[#0d120d]/72 text-[#d2dfd0] backdrop-blur-xl transition hover:border-white/30 hover:text-white"
            >
              <EyeOff className="h-4 w-4" />
            </button>

            <button
              onClick={() => setDrawerOpen((v) => !v)}
              title="Lighting & PBR Studio Controls"
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-medium backdrop-blur-xl transition ${
                drawerOpen
                  ? 'border-[#a8e05f]/50 bg-[#1a2617]/88 text-[#d4f89e]'
                  : 'border-white/14 bg-[#0d120d]/72 text-[#e5eee2] hover:border-white/30'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Lighting</span>
            </button>
          </div>

          {/* RIGHT COLLAPSIBLE STUDIO DRAWER: Lighting Moods, Real-Time Sun/Wind/SSS, PBR View Modes */}
          {drawerOpen && (
            <aside className="studio-scroll fixed top-16 right-4 bottom-24 z-20 w-[280px] overflow-y-auto rounded-2xl border border-white/12 bg-[#0c110c]/78 p-4 shadow-2xl backdrop-blur-xl">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-[11px] font-semibold tracking-wider text-[#b7c7b2] uppercase">
                  HD Lighting & Shaders
                </span>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="rounded-lg p-1 text-white/50 hover:bg-white/10 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Lighting Mood Presets */}
              <div className="grid grid-cols-2 gap-1.5">
                {(
                  [
                    { id: 'midday', label: 'Ref Midday', icon: Sun },
                    { id: 'golden', label: 'Golden Hour', icon: Sunset },
                    { id: 'mist', label: 'Morning Mist', icon: CloudFog },
                    { id: 'overcast', label: 'Soft Overcast', icon: Cloud },
                  ] as const
                ).map(({ id, label, icon: Icon }) => {
                  const active = settings.lightingMood === id;
                  return (
                    <button
                      key={id}
                      onClick={() => handleMood(id)}
                      className={`flex items-center gap-2 rounded-xl border px-2.5 py-2 text-left text-[11px] font-medium transition ${
                        active
                          ? 'border-[#a8e05f]/65 bg-[#a8e05f]/16 text-[#dcf9ab]'
                          : 'border-white/8 bg-white/[0.03] text-[#bac7b6] hover:border-white/20 hover:bg-white/[0.07]'
                      }`}
                    >
                      <Icon
                        className={`h-3.5 w-3.5 shrink-0 ${
                          active ? 'text-[#b8f06a]' : 'text-[#8ea088]'
                        }`}
                      />
                      <span className="truncate">{label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="my-3.5 h-px bg-white/10" />

              {/* Real-time Sun Direction & Atmospheric Sliders */}
              <div className="space-y-3">
                <div>
                  <div className="mb-1 flex items-center justify-between text-[11px]">
                    <span className="flex items-center gap-1.5 text-[#c7d4c3]">
                      <Compass className="h-3 w-3 text-[#a8e05f]" />
                      Arah Matahari (Azimuth)
                    </span>
                    <span className="font-mono-tech text-[10px] text-[#9eb098]">
                      {Math.round(settings.sunAzimuth)}°
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={360}
                    step={1}
                    value={settings.sunAzimuth}
                    onChange={(e) => handleSunAzimuth(Number(e.target.value))}
                    className="studio-slider"
                  />
                </div>

                <div>
                  <div className="mb-1 flex items-center justify-between text-[11px]">
                    <span className="flex items-center gap-1.5 text-[#c7d4c3]">
                      <Sun className="h-3 w-3 text-[#a8e05f]" />
                      Tinggi Matahari (Elevation)
                    </span>
                    <span className="font-mono-tech text-[10px] text-[#9eb098]">
                      {Math.round(settings.sunElevation)}°
                    </span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={78}
                    step={1}
                    value={settings.sunElevation}
                    onChange={(e) => handleSunElevation(Number(e.target.value))}
                    className="studio-slider"
                  />
                </div>

                <div>
                  <div className="mb-1 flex items-center justify-between text-[11px]">
                    <span className="flex items-center gap-1.5 text-[#c7d4c3]">
                      <Sparkles className="h-3 w-3 text-[#a8e05f]" />
                      Backlight Daun (SSS)
                    </span>
                    <span className="font-mono-tech text-[10px] text-[#9eb098]">
                      {Math.round(settings.translucency * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={2}
                    step={0.05}
                    value={settings.translucency}
                    onChange={(e) => handleTranslucency(Number(e.target.value))}
                    className="studio-slider"
                  />
                </div>

                <div>
                  <div className="mb-1 flex items-center justify-between text-[11px]">
                    <span className="flex items-center gap-1.5 text-[#c7d4c3]">
                      <Wind className="h-3 w-3 text-[#a8e05f]" />
                      Angin Hutan (Wind)
                    </span>
                    <span className="font-mono-tech text-[10px] text-[#9eb098]">
                      {Math.round(settings.windStrength * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={2}
                    step={0.05}
                    value={settings.windStrength}
                    onChange={(e) => handleWind(Number(e.target.value))}
                    className="studio-slider"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <div className="mb-1 flex items-center justify-between text-[10px]">
                      <span className="text-[#b8c6b3]">Exposure</span>
                      <span className="font-mono-tech text-[#90a38b]">
                        {settings.exposure.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.65}
                      max={1.65}
                      step={0.02}
                      value={settings.exposure}
                      onChange={(e) => handleExposure(Number(e.target.value))}
                      className="studio-slider"
                    />
                  </div>
                  <div>
                    <div className="mb-1 flex items-center justify-between text-[10px]">
                      <span className="text-[#b8c6b3]">Sun Bloom</span>
                      <span className="font-mono-tech text-[#90a38b]">
                        {settings.bloomStrength.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={0.65}
                      step={0.02}
                      value={settings.bloomStrength}
                      onChange={(e) => handleBloom(Number(e.target.value))}
                      className="studio-slider"
                    />
                  </div>
                </div>
              </div>

              {/* Toggle Switches */}
              <div className="mt-3.5 grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => handleSunbeams(!settings.sunbeamsVisible)}
                  className={`flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11px] font-medium transition ${
                    settings.sunbeamsVisible
                      ? 'border-[#a8e05f]/50 bg-[#a8e05f]/14 text-[#d6f89f]'
                      : 'border-white/10 bg-white/[0.03] text-[#9eb098]'
                  }`}
                >
                  <Sparkles className="h-3 w-3" />
                  <span>Sunbeams</span>
                </button>
                <button
                  onClick={() => handleAutoRotate(!settings.autoRotate)}
                  className={`flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2 text-[11px] font-medium transition ${
                    settings.autoRotate
                      ? 'border-[#a8e05f]/50 bg-[#a8e05f]/14 text-[#d6f89f]'
                      : 'border-white/10 bg-white/[0.03] text-[#9eb098]'
                  }`}
                >
                  <RotateCw className="h-3 w-3" />
                  <span>Turntable</span>
                </button>
              </div>

              <div className="my-3.5 h-px bg-white/10" />

              {/* PBR Inspection Shading Mode */}
              <div>
                <p className="mb-2 text-[10px] font-semibold tracking-wider text-[#95a690] uppercase">
                  PBR Render Inspector
                </p>
                <div className="grid grid-cols-2 gap-1.5">
                  {(
                    [
                      { id: 'beauty', label: 'Beauty PBR' },
                      { id: 'wireframe', label: 'Wireframe' },
                      { id: 'clay', label: 'Clay Light' },
                      { id: 'normal', label: 'Normals' },
                    ] as const
                  ).map(({ id, label }) => (
                    <button
                      key={id}
                      onClick={() => handleShadingMode(id)}
                      className={`rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition ${
                        settings.shadingMode === id
                          ? 'border-[#a8e05f]/60 bg-[#a8e05f]/18 text-[#dbfa9f]'
                          : 'border-white/8 bg-white/[0.03] text-[#aebca8] hover:border-white/20'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </aside>
          )}

          {/* BOTTOM-LEFT: Camera Framing Presets (Full Scene Mode) */}
          {settings.assetMode === 'full' && (
            <div className="fixed bottom-20 left-4 z-20 hidden flex-col gap-1.5 md:flex">
              <div className="flex flex-wrap items-center gap-1 rounded-xl border border-white/10 bg-[#0d120d]/68 p-1 backdrop-blur-xl">
                {(
                  [
                    { id: 'reference', label: 'Ref Angle' },
                    { id: 'tougeRoad', label: 'Touge Aspal' },
                    { id: 'macroSoil', label: 'Macro Tanah & Daun' },
                    { id: 'canopyBacklight', label: 'Backlight Kanopi' },
                    { id: 'aerial', label: 'Aerial 3/4' },
                  ] as const
                ).map((cam) => (
                  <button
                    key={cam.id}
                    onClick={() => handleCameraPreset(cam.id)}
                    className={`rounded-lg px-2.5 py-1.5 text-[11px] font-medium transition ${
                      activeCameraPreset === cam.id
                        ? 'bg-[#a8e05f]/22 text-[#daf8a5]'
                        : 'text-[#a8b6a4] hover:bg-white/8 hover:text-white'
                    }`}
                  >
                    {cam.label}
                  </button>
                ))}
              </div>
              <span className="pl-1 font-mono-tech text-[10px] text-white/45">
                Drag: Orbit · Scroll: Zoom · Right-Drag: Pan
              </span>
            </div>
          )}

          {/* BOTTOM-CENTER: Floating 3D Asset Switcher Dock (Full Forest | Pohon | Tanah | Semak & Rumput) */}
          <div className="fixed bottom-4 left-1/2 z-30 flex -translate-x-1/2 flex-col items-center gap-2">
            {/* Sub-Variant Pills when inspecting isolated Tree Asset (All 7 Touge Tree Species!) */}
            {settings.assetMode === 'tree' && (
              <div className="flex max-w-[92vw] flex-wrap items-center justify-center gap-1 rounded-2xl border border-white/14 bg-[#0d130d]/86 p-1.5 shadow-xl backdrop-blur-xl sm:rounded-full">
                {(
                  [
                    { id: 'broadleaf', label: 'Momiji Maple' },
                    { id: 'zelkova', label: 'Keyaki Zelkova' },
                    { id: 'beech', label: 'Buna Beech' },
                    { id: 'redpine', label: 'Akamatsu Pine' },
                    { id: 'birch', label: 'Shirakaba Birch' },
                    { id: 'cedar', label: 'Sugi Cedar' },
                    { id: 'overhang', label: 'Overhang' },
                  ] as const
                ).map((v) => (
                  <button
                    key={v.id}
                    onClick={() => handleTreeVariant(v.id)}
                    className={`rounded-full px-2.5 py-1 text-[11px] font-medium whitespace-nowrap transition ${
                      settings.treeVariant === v.id
                        ? 'bg-[#a8e05f] text-[#0b1307] shadow-sm'
                        : 'text-[#b7c6b3] hover:bg-white/8 hover:text-white'
                    }`}
                  >
                    {v.label}
                  </button>
                ))}
              </div>
            )}

            {/* Main 5-Asset Selector Bar */}
            <div className="flex items-center gap-1 rounded-2xl border border-white/14 bg-[#0c110c]/82 p-1.5 shadow-2xl backdrop-blur-xl">
              {(
                [
                  { id: 'full', label: 'Full Touge', sub: '62m · 7 Pohon', icon: Layers },
                  { id: 'road', label: 'Aspal 3D', sub: '2× Long · Curb', icon: Route },
                  { id: 'tree', label: 'Pohon 3D', sub: '7 Species', icon: Trees },
                  { id: 'soil', label: 'Tanah 3D', sub: 'Soil & Mulch', icon: Mountain },
                  { id: 'shrub', label: 'Semak & Rumput', sub: 'Shrub & Grass', icon: Sprout },
                ] as const
              ).map(({ id, label, sub, icon: Icon }) => {
                const active = settings.assetMode === id;
                return (
                  <button
                    key={id}
                    onClick={() => handleAssetMode(id)}
                    className={`group flex items-center gap-2 rounded-xl px-3 py-2 transition sm:px-3.5 ${
                      active
                        ? 'bg-gradient-to-b from-[#a8e05f]/26 to-[#6ca828]/20 text-white ring-1 ring-[#a8e05f]/55'
                        : 'text-[#aebca8] hover:bg-white/[0.07] hover:text-white'
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        active ? 'text-[#b9f26b]' : 'text-[#84957e] group-hover:text-[#b4c6ae]'
                      }`}
                    />
                    <div className="text-left leading-tight">
                      <div className="text-xs font-semibold whitespace-nowrap">{label}</div>
                      <div className="hidden text-[10px] text-white/45 sm:block">{sub}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
