import * as THREE from 'three';
import { StudioMaterialLibrary } from '../materials';
import { createRng, fbm2D, randRange, ridgedNoise2D, smoothstep } from '../noise';
import {
  CURB_WIDTH,
  isInsideRoadCorridor,
  ROAD_HALF_WIDTH,
  roadOffsetPoint,
  sampleRoadCoords,
} from '../roadMath';

export type HeightSampler = (x: number, z: number) => number;

/**
 * Shared height function for the Full Japanese Mountain Forest + Curving Touge Asphalt Scene.
 * Seamlessly sculpted around `sampleRoadCoords(x, z)`:
 * - Under the asphalt corridor (|s| <= ROAD_HALF_WIDTH): graded cleanly just below tarmac
 * - Inner foreground embankment (s > ROAD_HALF_WIDTH + CURB_WIDTH): convex leaf-litter mound rising right behind the concrete curb!
 * - Outer forest shoulder & hillside (s < -ROAD_HALF_WIDTH): meets asphalt edge smoothly, then rises into the dense Japanese forest slope!
 */
export function sampleFullForestHeight(x: number, z: number): number {
  const road = sampleRoadCoords(x, z);
  const s = road.signedDist;

  // Organic forest floor mounding & micro-relief (damped cleanly to 0 right on the road surface)
  const macroUndulation = (fbm2D(x * 0.16 + 3.1, z * 0.16 + 1.7, 4, 2.0, 0.5, 101) - 0.5) * 0.65;
  const midClumps = (fbm2D(x * 0.52 + 9.2, z * 0.52 + 5.4, 3, 2.1, 0.5, 202) - 0.5) * 0.22;
  const microRelief = (ridgedNoise2D(x * 1.4, z * 1.4, 2, 303) - 0.5) * 0.075;
  const rawNoise = macroUndulation + midClumps + microRelief;

  // 1. Inside roadbed corridor: sit cleanly 6.5cm underneath the asphalt surface (zero z-fighting!)
  if (s >= -ROAD_HALF_WIDTH && s <= ROAD_HALF_WIDTH + CURB_WIDTH * 0.5) {
    return road.roadY - 0.065;
  }

  // 2. Inner foreground leaf-litter embankment (bottom & right foreground of reference photo!)
  if (s > ROAD_HALF_WIDTH + CURB_WIDTH * 0.5) {
    const distPastCurb = s - (ROAD_HALF_WIDTH + CURB_WIDTH * 0.5);
    const blend = smoothstep(0.0, 0.55, distPastCurb);
    // Natural convex mounding embankment rising above the concrete curb
    const moundRise = smoothstep(0.0, 4.8, distPastCurb) * 0.92;
    const bankY = road.roadY + 0.015 + moundRise + rawNoise * blend;
    return THREE.MathUtils.lerp(road.roadY - 0.06, bankY, smoothstep(0.0, 0.35, distPastCurb));
  }

  // 3. Outer forest shoulder & rising Japanese mountain woodland behind the asphalt (top half of photo!)
  const distPastOuter = -ROAD_HALF_WIDTH - s;
  const outerBlend = smoothstep(0.0, 0.55, distPastOuter);
  // Gentle shoulder flush with tarmac edge, climbing smoothly into lush mountain hillside
  const forestSlope =
    smoothstep(0.25, 12.0, distPastOuter) * 2.55 +
    smoothstep(1.0, 8.5, distPastOuter) * 0.32;
  const forestY = road.roadY - 0.015 + forestSlope + rawNoise * outerBlend;
  return THREE.MathUtils.lerp(road.roadY - 0.06, forestY, smoothstep(0.0, 0.32, distPastOuter));
}

/**
 * Height function for the isolated 4.6m x 4.6m Soil Asset Plinth Showcase
 */
export function sampleSoilPlinthHeight(x: number, z: number): number {
  const r = Math.sqrt(x * x + z * z);
  const mound = Math.max(0, 1 - (r / 3.4) * (r / 3.4)) * 0.42;
  const slope = (x * 0.08 + z * 0.05) * 0.5;
  const bumps = (fbm2D(x * 0.85 + 4.1, z * 0.85 + 2.3, 4, 2.0, 0.5, 515) - 0.5) * 0.24;
  const micro = (ridgedNoise2D(x * 2.4, z * 2.4, 2, 616) - 0.5) * 0.06;
  return mound + slope + bumps + micro;
}

/**
 * Computes analytical surface normal via central differences for accurate terrain-aligned scatter!
 */
export function sampleTerrainNormal(
  sampler: HeightSampler,
  x: number,
  z: number,
  eps = 0.08
): THREE.Vector3 {
  const hL = sampler(x - eps, z);
  const hR = sampler(x + eps, z);
  const hD = sampler(x, z - eps);
  const hU = sampler(x, z + eps);
  return new THREE.Vector3(hL - hR, 2 * eps, hD - hU).normalize();
}

/**
 * Builds a single realistic curled 3D fallen oak/beech leaf geometry (8 tris, curled upward at edges!)
 */
function createCurledDryLeafGeometry(): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(0.115, 0.068, 3, 2);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i); // -0.0575 .. 0.0575
    const z = pos.getZ(i); // -0.034 .. 0.034
    const nx = x / 0.0575;
    const nz = z / 0.034;
    // Organic dried leaf curl: edges lift slightly + slight lengthwise twist
    const curlY = (nz * nz) * 0.015 + (nx * nx) * 0.011 + nx * nz * 0.008;
    pos.setY(i, curlY + 0.004);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds a realistic 3D fanned cluster of dry pine needles / straw thatch (low-poly multi-strip bundle!)
 */
function createPineNeedleTuftGeometry(): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const rng = createRng(8842);

  const needles = 7;
  let vOffset = 0;

  for (let n = 0; n < needles; n++) {
    const angle = (n / needles) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const len = randRange(rng, 0.11, 0.2);
    const lift = randRange(rng, 0.012, 0.055);
    const w = 0.0055;
    const dx = Math.cos(angle);
    const dz = Math.sin(angle);
    const px = -dz * w;
    const pz = dx * w;

    // 3-segment arching dry straw/pine needle ribbon
    const pts = [
      { x: -dx * 0.01, y: 0.003, z: -dz * 0.01, scale: 1.0, v: 0 },
      { x: dx * len * 0.5, y: lift, z: dz * len * 0.5, scale: 0.72, v: 0.5 },
      { x: dx * len, y: lift * 0.38, z: dz * len, scale: 0.12, v: 1.0 },
    ];

    for (let s = 0; s < pts.length; s++) {
      const p = pts[s];
      positions.push(p.x - px * p.scale, p.y, p.z - pz * p.scale);
      positions.push(p.x + px * p.scale, p.y, p.z + pz * p.scale);
      normals.push(0, 1, 0, 0, 1, 0);
      uvs.push(0, p.v, 1, p.v);
    }

    indices.push(vOffset, vOffset + 1, vOffset + 2);
    indices.push(vOffset + 1, vOffset + 3, vOffset + 2);
    indices.push(vOffset + 2, vOffset + 3, vOffset + 4);
    indices.push(vOffset + 3, vOffset + 5, vOffset + 4);
    vOffset += 6;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds a slightly crooked, tapered 3D fallen weathered twig/stick geometry
 */
function createFallenTwigGeometry(): THREE.BufferGeometry {
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.24, 0.008, -0.012),
    new THREE.Vector3(-0.07, 0.018, 0.016),
    new THREE.Vector3(0.09, 0.011, -0.01),
    new THREE.Vector3(0.26, 0.022, 0.022),
  ]);
  const geo = new THREE.TubeGeometry(curve, 7, 0.012, 5, false);
  // Gently taper one end
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const t = (x + 0.25) / 0.52;
    const scale = 1.15 - t * 0.55;
    pos.setY(i, pos.getY(i) * scale);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Tiny bright green wild forest sprout / broadleaved seedling poking up through dry brown leaves!
 */
function createWildSproutGeometry(): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOff = 0;

  // Crossed 3-plane delicate miniature plant sprig
  for (let i = 0; i < 3; i++) {
    const ang = (i / 3) * Math.PI + 0.25;
    const c = Math.cos(ang);
    const s = Math.sin(ang);
    const w = 0.095;
    const h = 0.145;

    const verts = [
      [-w * c, -0.01, -w * s, 0, 0],
      [w * c, -0.01, w * s, 1, 0],
      [-w * c * 1.15, h, -w * s * 1.15, 0, 1],
      [w * c * 1.15, h, w * s * 1.15, 1, 1],
    ];
    for (const v of verts) {
      positions.push(v[0], v[1], v[2]);
      normals.push(0, 1, 0);
      uvs.push(v[3], v[4]);
    }
    indices.push(vOff, vOff + 1, vOff + 2, vOff + 1, vOff + 3, vOff + 2);
    vOff += 4;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  return geo;
}

/**
 * Generates an organic mossy forest boulder mesh
 */
function createMossyRockMesh(
  materials: StudioMaterialLibrary,
  radius: number,
  seed: number
): THREE.Mesh {
  const geo = new THREE.IcosahedronGeometry(radius, 3);
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    const dir = v.clone().normalize();
    // Angular natural granite rock displacement + flat base embed
    const n1 = fbm2D(dir.x * 2.2 + seed, dir.z * 2.2 + dir.y * 1.9, 3, 2.0, 0.5, seed);
    const n2 = ridgedNoise2D(dir.x * 4.5 + seed * 0.5, dir.z * 4.5 + dir.y * 3.8, 2, seed + 17);
    const scale = 0.72 + n1 * 0.42 + n2 * 0.16;
    v.multiplyScalar(scale);
    v.y *= 0.62; // naturally settled forest stone silhouette
    pos.setXYZ(i, v.x, v.y, v.z);
  }
  geo.computeVertexNormals();

  const mesh = new THREE.Mesh(geo, materials.mossyRock);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

/**
 * Helper to scatter thousands of physical 3D fallen leaves, pine-needle thatch tufts,
 * weathered fallen twigs, and emerging bright green forest sprouts onto ANY terrain!
 */
function populateGroundDetritus(
  group: THREE.Group,
  materials: StudioMaterialLibrary,
  sampler: HeightSampler,
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number; circularRadius?: number },
  counts: { leaves: number; needles: number; twigs: number; sprouts: number },
  seed: number,
  excludeFn?: (x: number, z: number) => boolean
) {
  const rng = createRng(seed);
  const up = new THREE.Vector3(0, 1, 0);
  const dummy = new THREE.Object3D();
  const qAlign = new THREE.Quaternion();
  const qSpin = new THREE.Quaternion();
  const color = new THREE.Color();

  const sampleValidPoint = (): { x: number; z: number } | null => {
    for (let tries = 0; tries < 10; tries++) {
      const x = randRange(rng, bounds.minX, bounds.maxX);
      const z = randRange(rng, bounds.minZ, bounds.maxZ);
      if (bounds.circularRadius && x * x + z * z > bounds.circularRadius * bounds.circularRadius) {
        continue;
      }
      if (excludeFn && excludeFn(x, z)) continue;
      return { x, z };
    }
    return null;
  };

  // 1. Physical 3D Curled Fallen Dry Leaves (InstancedMesh)
  const leafPalette = [
    '#cbb188', // pale sun-bleached tan (signature ref photo tone!)
    '#dcc7a1', // bright dry parchment leaf
    '#9a6a3b', // warm dry beech russet
    '#7a4e29', // deep chestnut brown
    '#b58d5c', // golden tan leaf
    '#5e3d21', // damp umber brown
    '#876742', // weathered khaki leaf
  ];
  const leafGeo = createCurledDryLeafGeometry();
  const leafInst = new THREE.InstancedMesh(leafGeo, materials.dryLeafScatter, counts.leaves);
  leafInst.name = 'Instanced_3D_Fallen_Dry_Leaves';
  leafInst.receiveShadow = true;
  leafInst.castShadow = false;

  let leafIdx = 0;
  for (let i = 0; i < counts.leaves; i++) {
    const pt = sampleValidPoint();
    if (!pt) continue;
    const y = sampler(pt.x, pt.z);
    const n = sampleTerrainNormal(sampler, pt.x, pt.z);

    qAlign.setFromUnitVectors(up, n);
    qSpin.setFromEuler(
      new THREE.Euler(
        randRange(rng, -0.32, 0.32),
        rng() * Math.PI * 2,
        randRange(rng, -0.32, 0.32)
      )
    );
    dummy.position.set(pt.x, y + randRange(rng, 0.004, 0.022), pt.z);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    const s = randRange(rng, 0.72, 1.65);
    dummy.scale.set(s, s * randRange(rng, 0.85, 1.3), s * randRange(rng, 0.8, 1.25));
    dummy.updateMatrix();
    leafInst.setMatrixAt(leafIdx, dummy.matrix);

    color.set(leafPalette[Math.floor(rng() * leafPalette.length)]);
    color.offsetHSL(randRange(rng, -0.02, 0.02), randRange(rng, -0.06, 0.06), randRange(rng, -0.06, 0.06));
    leafInst.setColorAt(leafIdx, color);
    leafIdx++;
  }
  leafInst.count = leafIdx;
  leafInst.instanceMatrix.needsUpdate = true;
  if (leafInst.instanceColor) leafInst.instanceColor.needsUpdate = true;
  group.add(leafInst);

  // 2. Physical 3D Pine Needle / Dry Grass Thatch Clusters (InstancedMesh)
  const needlePalette = ['#7d5935', '#997448', '#b09062', '#644528', '#8a6b42', '#523820'];
  const needleGeo = createPineNeedleTuftGeometry();
  const needleInst = new THREE.InstancedMesh(needleGeo, materials.pineNeedleThatch, counts.needles);
  needleInst.name = 'Instanced_3D_Pine_Needle_Thatch';
  needleInst.receiveShadow = true;

  let nIdx = 0;
  for (let i = 0; i < counts.needles; i++) {
    const pt = sampleValidPoint();
    if (!pt) continue;
    const y = sampler(pt.x, pt.z);
    const n = sampleTerrainNormal(sampler, pt.x, pt.z);
    qAlign.setFromUnitVectors(up, n);
    qSpin.setFromAxisAngle(up, rng() * Math.PI * 2);

    dummy.position.set(pt.x, y + 0.002, pt.z);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    const s = randRange(rng, 0.85, 1.9);
    dummy.scale.set(s, randRange(rng, 0.7, 1.45), s);
    dummy.updateMatrix();
    needleInst.setMatrixAt(nIdx, dummy.matrix);

    color.set(needlePalette[Math.floor(rng() * needlePalette.length)]);
    needleInst.setColorAt(nIdx, color);
    nIdx++;
  }
  needleInst.count = nIdx;
  needleInst.instanceMatrix.needsUpdate = true;
  if (needleInst.instanceColor) needleInst.instanceColor.needsUpdate = true;
  group.add(needleInst);

  // 3. Physical 3D Weathered Fallen Twigs & Dead Branches (InstancedMesh)
  const twigGeo = createFallenTwigGeometry();
  const twigInst = new THREE.InstancedMesh(twigGeo, materials.hardwoodBark, counts.twigs);
  twigInst.name = 'Instanced_3D_Fallen_Twigs';
  twigInst.castShadow = true;
  twigInst.receiveShadow = true;

  let tIdx = 0;
  for (let i = 0; i < counts.twigs; i++) {
    const pt = sampleValidPoint();
    if (!pt) continue;
    const y = sampler(pt.x, pt.z);
    const n = sampleTerrainNormal(sampler, pt.x, pt.z);
    qAlign.setFromUnitVectors(up, n);
    qSpin.setFromEuler(
      new THREE.Euler(randRange(rng, -0.14, 0.14), rng() * Math.PI * 2, randRange(rng, -0.14, 0.14))
    );

    dummy.position.set(pt.x, y + 0.008, pt.z);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    const lenScale = randRange(rng, 0.6, 2.3);
    const thickScale = randRange(rng, 0.65, 1.75);
    dummy.scale.set(lenScale, thickScale, thickScale);
    dummy.updateMatrix();
    twigInst.setMatrixAt(tIdx, dummy.matrix);

    // Subtle weathered grey-silver to dark damp brown wood variation
    const shade = randRange(rng, 0.72, 1.32);
    color.setRGB(shade, shade * 0.96, shade * 0.9);
    twigInst.setColorAt(tIdx, color);
    tIdx++;
  }
  twigInst.count = tIdx;
  twigInst.instanceMatrix.needsUpdate = true;
  if (twigInst.instanceColor) twigInst.instanceColor.needsUpdate = true;
  group.add(twigInst);

  // 4. Tiny Vivid Bright Green Wild Forest Sprouts emerging through dry brown leaf litter!
  const sproutGeo = createWildSproutGeometry();
  const sproutInst = new THREE.InstancedMesh(sproutGeo, materials.sproutLeaf, counts.sprouts);
  sproutInst.name = 'Instanced_3D_Forest_Sprouts';
  sproutInst.castShadow = true;
  sproutInst.receiveShadow = true;
  sproutInst.customDepthMaterial = materials.sproutLeaf.userData.customDepthMaterial;

  let sIdx = 0;
  for (let i = 0; i < counts.sprouts; i++) {
    const pt = sampleValidPoint();
    if (!pt) continue;
    const y = sampler(pt.x, pt.z);
    dummy.position.set(pt.x, y, pt.z);
    dummy.rotation.set(randRange(rng, -0.2, 0.2), rng() * Math.PI * 2, randRange(rng, -0.2, 0.2));
    const s = randRange(rng, 0.65, 1.65);
    dummy.scale.set(s, s * randRange(rng, 0.8, 1.35), s);
    dummy.updateMatrix();
    sproutInst.setMatrixAt(sIdx, dummy.matrix);
    sIdx++;
  }
  sproutInst.count = sIdx;
  sproutInst.instanceMatrix.needsUpdate = true;
  group.add(sproutInst);
}

/**
 * 1. FULL SCULPTED JAPANESE MOUNTAIN FOREST EMBANKMENT TERRAIN
 */
export function createFullForestTerrain(
  materials: StudioMaterialLibrary
): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Forest_Terrain_Embankment';

  const sizeX = 66;
  const sizeZ = 38;
  const segX = 240;
  const segZ = 148;

  const geo = new THREE.PlaneGeometry(sizeX, sizeZ, segX, segZ);
  geo.rotateX(-Math.PI / 2);

  // Preserve crisp physical 1:1 forest floor leaf-litter scale across the 2x-longer 66m terrain!
  const uvAttr = geo.attributes.uv;
  for (let i = 0; i < uvAttr.count; i++) {
    uvAttr.setXY(i, uvAttr.getX(i) * (sizeX / 30), uvAttr.getY(i) * (sizeZ / 26));
  }

  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const c = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = sampleFullForestHeight(x, z);
    pos.setY(i, y);

    const road = sampleRoadCoords(x, z);
    // Sunlit warm dry golden leaf-litter on foreground inner embankment (s > ROAD_HALF_WIDTH)
    // Richer dark damp mossy forest humus behind the far edge of the asphalt (s < -ROAD_HALF_WIDTH)
    const sunBank = smoothstep(ROAD_HALF_WIDTH, ROAD_HALF_WIDTH + 4.5, road.signedDist);
    const deepShade = smoothstep(-ROAD_HALF_WIDTH, -ROAD_HALF_WIDTH - 7.5, road.signedDist);
    const microMoss = fbm2D(x * 0.45 + 1.3, z * 0.45 + 7.1, 3, 2.0, 0.5, 909);

    const r = 0.94 + sunBank * 0.16 - deepShade * 0.22 - Math.max(0, microMoss - 0.6) * 0.22;
    const g = 0.92 + sunBank * 0.13 - deepShade * 0.18 + Math.max(0, microMoss - 0.6) * 0.08;
    const b = 0.87 + sunBank * 0.08 - deepShade * 0.22 - Math.max(0, microMoss - 0.6) * 0.22;

    c.setRGB(r, g, b);
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();

  const terrainMesh = new THREE.Mesh(geo, materials.forestFloor);
  terrainMesh.name = 'Forest_Floor_Mesh';
  terrainMesh.receiveShadow = true;
  group.add(terrainMesh);

  // Sculpted embedded mossy mountain forest stones strictly on the embankment & outer forest shoulder
  const rng = createRng(707);
  const rockOffsets = [
    // Foreground inner leaf-litter bank stones
    { spineX: -14.2, offset: ROAD_HALF_WIDTH + 2.1, r: 0.42 },
    { spineX: -7.5, offset: ROAD_HALF_WIDTH + 2.4, r: 0.34 },
    { spineX: 0.4, offset: ROAD_HALF_WIDTH + 2.6, r: 0.28 },
    { spineX: 4.8, offset: ROAD_HALF_WIDTH + 1.65, r: 0.36 },
    { spineX: 6.4, offset: ROAD_HALF_WIDTH + 3.8, r: 0.46 },
    { spineX: 15.2, offset: ROAD_HALF_WIDTH + 2.3, r: 0.48 },
    { spineX: 22.4, offset: ROAD_HALF_WIDTH + 1.9, r: 0.52 },
    // Far outer forest shoulder boulders across the 62m touge wall
    { spineX: -22.5, offset: -(ROAD_HALF_WIDTH + 1.5), r: 0.62 },
    { spineX: -14.8, offset: -(ROAD_HALF_WIDTH + 1.3), r: 0.54 },
    { spineX: -5.8, offset: -(ROAD_HALF_WIDTH + 1.4), r: 0.52 },
    { spineX: -1.6, offset: -(ROAD_HALF_WIDTH + 1.15), r: 0.44 },
    { spineX: 2.2, offset: -(ROAD_HALF_WIDTH + 1.7), r: 0.56 },
    { spineX: 6.2, offset: -(ROAD_HALF_WIDTH + 1.25), r: 0.48 },
    { spineX: 14.0, offset: -(ROAD_HALF_WIDTH + 1.5), r: 0.58 },
    { spineX: 21.5, offset: -(ROAD_HALF_WIDTH + 1.8), r: 0.66 },
    { spineX: -3.5, offset: -(ROAD_HALF_WIDTH + 3.6), r: 0.65 },
  ];
  rockOffsets.forEach((rp, idx) => {
    const pt = roadOffsetPoint(rp.spineX, rp.offset);
    const rock = createMossyRockMesh(materials, rp.r, 800 + idx * 19);
    const y = sampleFullForestHeight(pt.x, pt.z);
    rock.position.set(pt.x, y - rp.r * 0.22, pt.z);
    rock.rotation.set(randRange(rng, -0.25, 0.25), rng() * Math.PI * 2, randRange(rng, -0.25, 0.25));
    rock.name = `Mossy_Forest_Rock_${idx + 1}`;
    group.add(rock);
  });

  // Hero weathered pale fallen stick right on the foreground bank behind the curb (signature photo detail!)
  const bPt1 = roadOffsetPoint(0.2, ROAD_HALF_WIDTH + 1.15);
  const bPt2 = roadOffsetPoint(0.75, ROAD_HALF_WIDTH + 1.05);
  const bPt3 = roadOffsetPoint(1.3, ROAD_HALF_WIDTH + 1.18);
  const heroBranchCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(bPt1.x, sampleFullForestHeight(bPt1.x, bPt1.z) + 0.04, bPt1.z),
    new THREE.Vector3(bPt2.x, sampleFullForestHeight(bPt2.x, bPt2.z) + 0.055, bPt2.z),
    new THREE.Vector3(bPt3.x, sampleFullForestHeight(bPt3.x, bPt3.z) + 0.04, bPt3.z),
  ]);
  const heroBranch = new THREE.Mesh(
    new THREE.TubeGeometry(heroBranchCurve, 12, 0.038, 7, false),
    materials.hardwoodBark
  );
  heroBranch.name = 'Hero_Foreground_Fallen_Branch';
  heroBranch.castShadow = true;
  heroBranch.receiveShadow = true;
  group.add(heroBranch);

  // Exclude asphalt surface & inner concrete kerb crown from main forest-floor litter scatter
  const excludeRoad = (x: number, z: number) =>
    isInsideRoadCorridor(x, z, CURB_WIDTH * 0.52, 0.14);

  // Ultra-dense foreground embankment scatter (thick fallen leaves, pine needles, twigs & fresh green sprouts!)
  populateGroundDetritus(
    group,
    materials,
    sampleFullForestHeight,
    { minX: -5.5, maxX: 10.5, minZ: 0.5, maxZ: 11.2 },
    { leaves: 2800, needles: 1400, twigs: 195, sprouts: 125 },
    31415,
    excludeRoad
  );

  // Broad 62m touge corridor forest floor & roadside bank scatter
  populateGroundDetritus(
    group,
    materials,
    sampleFullForestHeight,
    { minX: -27.5, maxX: 27.5, minZ: -14.5, maxZ: 13.5 },
    { leaves: 2600, needles: 1150, twigs: 175, sprouts: 120 },
    27182,
    excludeRoad
  );

  return group;
}

/**
 * 2. ISOLATED MEGASCANS-STYLE 3D FOREST SOIL & LEAF LITTER ASSET PLINTH (4.6m x 4.6m)
 * Showcases the soil, 3D fallen leaves, pine needles, mossy stones, twigs, roots & tiny green sprouts!
 */
export function createIsolatedSoilAsset(materials: StudioMaterialLibrary): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Forest_Floor_Soil_Asset_Plinth';

  const size = 4.6;
  const segs = 96;
  const half = size * 0.5;

  // Sculpted high-resolution top soil surface
  const topGeo = new THREE.PlaneGeometry(size, size, segs, segs);
  topGeo.rotateX(-Math.PI / 2);

  // Scale UVs cleanly so texture density is crisp macro-HD
  const uv = topGeo.attributes.uv;
  for (let i = 0; i < uv.count; i++) {
    uv.setXY(i, uv.getX(i) * 1.45, uv.getY(i) * 1.45);
  }

  const pos = topGeo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const c = new THREE.Color();

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const y = sampleSoilPlinthHeight(x, z);
    pos.setY(i, y);

    const patch = fbm2D(x * 1.1 + 2.5, z * 1.1 + 4.2, 3, 2.0, 0.5, 412);
    c.setRGB(0.88 + patch * 0.24, 0.85 + patch * 0.22, 0.79 + patch * 0.18);
    colors[i * 3] = c.r;
    colors[i * 3 + 1] = c.g;
    colors[i * 3 + 2] = c.b;
  }
  topGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  topGeo.computeVertexNormals();

  const topMesh = new THREE.Mesh(topGeo, materials.forestFloor);
  topMesh.name = 'Soil_Surface_Displaced';
  topMesh.castShadow = true;
  topMesh.receiveShadow = true;
  group.add(topMesh);

  // Clean cross-section soil cutaway skirt along the 4 edges of the plinth
  const baseBottomY = -0.34;
  const skirtPositions: number[] = [];
  const skirtNormals: number[] = [];
  const skirtUvs: number[] = [];
  const skirtIndices: number[] = [];
  let vIdx = 0;

  const addSkirtSide = (
    p0x: number,
    p0z: number,
    p1x: number,
    p1z: number,
    nx: number,
    nz: number
  ) => {
    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      const x = THREE.MathUtils.lerp(p0x, p1x, t);
      const z = THREE.MathUtils.lerp(p0z, p1z, t);
      const yTop = sampleSoilPlinthHeight(x, z);

      skirtPositions.push(x, yTop, z);
      skirtPositions.push(x, baseBottomY, z);
      skirtNormals.push(nx, 0, nz, nx, 0, nz);
      skirtUvs.push(t * 2, 1, t * 2, 0);

      if (i < segs) {
        const a = vIdx + i * 2;
        const b = a + 1;
        const c2 = a + 2;
        const d = a + 3;
        skirtIndices.push(a, b, c2, b, d, c2);
      }
    }
    vIdx += (segs + 1) * 2;
  };

  addSkirtSide(-half, half, half, half, 0, 1);
  addSkirtSide(half, half, half, -half, 1, 0);
  addSkirtSide(half, -half, -half, -half, 0, -1);
  addSkirtSide(-half, -half, -half, half, -1, 0);

  const skirtGeo = new THREE.BufferGeometry();
  skirtGeo.setAttribute('position', new THREE.Float32BufferAttribute(skirtPositions, 3));
  skirtGeo.setAttribute('normal', new THREE.Float32BufferAttribute(skirtNormals, 3));
  skirtGeo.setAttribute('uv', new THREE.Float32BufferAttribute(skirtUvs, 2));
  skirtGeo.setIndex(skirtIndices);

  const skirtMesh = new THREE.Mesh(skirtGeo, materials.soilCutaway);
  skirtMesh.name = 'Soil_Cutaway_Profile';
  skirtMesh.castShadow = true;
  skirtMesh.receiveShadow = true;
  group.add(skirtMesh);

  // Embedded mossy stones & curving surface root on the soil asset tile
  const rocks = [
    { x: -1.05, z: -0.75, r: 0.34 },
    { x: 1.15, z: 0.62, r: 0.26 },
    { x: 0.32, z: -1.25, r: 0.22 },
    { x: -1.35, z: 0.95, r: 0.19 },
  ];
  rocks.forEach((rp, i) => {
    const rock = createMossyRockMesh(materials, rp.r, 920 + i * 31);
    rock.position.set(rp.x, sampleSoilPlinthHeight(rp.x, rp.z) - rp.r * 0.18, rp.z);
    rock.name = `Soil_Embedded_Stone_${i + 1}`;
    group.add(rock);
  });

  // Hero weathered dead forest branch across the soil tile
  const stickCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.9, sampleSoilPlinthHeight(-0.9, 0.7) + 0.04, 0.7),
    new THREE.Vector3(-0.1, sampleSoilPlinthHeight(-0.1, 0.42) + 0.055, 0.42),
    new THREE.Vector3(0.75, sampleSoilPlinthHeight(0.75, 0.18) + 0.038, 0.18),
  ]);
  const heroStick = new THREE.Mesh(
    new THREE.TubeGeometry(stickCurve, 12, 0.04, 7, false),
    materials.hardwoodBark
  );
  heroStick.name = 'Weathered_Fallen_Branch';
  heroStick.castShadow = true;
  heroStick.receiveShadow = true;
  group.add(heroStick);

  // Hyper-detailed 3D fallen leaves, pine needles, twigs & emerging green sprouts!
  populateGroundDetritus(
    group,
    materials,
    sampleSoilPlinthHeight,
    { minX: -half + 0.12, maxX: half - 0.12, minZ: -half + 0.12, maxZ: half - 0.12 },
    { leaves: 1550, needles: 780, twigs: 78, sprouts: 42 },
    65432
  );

  return group;
}
