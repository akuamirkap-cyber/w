import * as THREE from 'three';
import { StudioMaterialLibrary } from '../materials';
import { createRng, randRange } from '../noise';
import { HeightSampler, sampleTerrainNormal } from './terrain';

/**
 * Helper: Builds a gently arched multi-segment botanical leaf/frond card geometry
 */
function buildArchedCardIntoArrays(
  positions: number[],
  normals: number[],
  uvs: number[],
  indices: number[],
  vOffset: number,
  origin: THREE.Vector3,
  quaternion: THREE.Quaternion,
  width: number,
  length: number,
  archDrop: number,
  cup: number,
  centerForNormal: THREE.Vector3,
  segY = 4
): number {
  const segX = 2;
  const p = new THREE.Vector3();
  const n = new THREE.Vector3();
  const cDir = new THREE.Vector3();

  for (let iy = 0; iy <= segY; iy++) {
    const v = iy / segY;
    for (let ix = 0; ix <= segX; ix++) {
      const u = ix / segX;
      const xn = u * 2 - 1;

      const lx = xn * width * 0.5;
      const ly = v * length;
      const lz = -archDrop * v * v * length + cup * (1 - xn * xn) * width * 0.14;

      p.set(lx, ly, lz).applyQuaternion(quaternion).add(origin);
      n.set(-xn * 0.25, archDrop * v * 0.65, 1.0).normalize().applyQuaternion(quaternion);
      cDir.copy(p).sub(centerForNormal).add(new THREE.Vector3(0, 0.35, 0)).normalize();
      n.lerp(cDir, 0.58).normalize();

      positions.push(p.x, p.y, p.z);
      normals.push(n.x, n.y, n.z);
      uvs.push(u, v);
    }
  }

  const stride = segX + 1;
  for (let iy = 0; iy < segY; iy++) {
    for (let ix = 0; ix < segX; ix++) {
      const a = vOffset + iy * stride + ix;
      const b = vOffset + (iy + 1) * stride + ix;
      const c = vOffset + (iy + 1) * stride + (ix + 1);
      const d = vOffset + iy * stride + (ix + 1);
      indices.push(a, d, b, b, d, c);
    }
  }
  return vOffset + (segX + 1) * (segY + 1);
}

/**
 * 1. REALISTIC WOODY WILD FOREST SHRUB (Semak Hutan)
 * Multi-stemmed curving woody branches carrying layered arched broadleaved foliage sprays!
 */
export function createWildForestShrub(
  materials: StudioMaterialLibrary,
  opts: { seed: number; scale?: number; sunlit?: boolean }
): THREE.Group {
  const rng = createRng(opts.seed);
  const scale = opts.scale ?? 1.0;
  const sunlit = opts.sunlit ?? true;

  const group = new THREE.Group();
  group.name = `Wild_Forest_Shrub_${opts.seed}`;

  const stemGeos: THREE.BufferGeometry[] = [];
  const mainPos: number[] = [];
  const mainNorm: number[] = [];
  const mainUv: number[] = [];
  const mainIdx: number[] = [];
  let mainV = 0;

  const brightPos: number[] = [];
  const brightNorm: number[] = [];
  const brightUv: number[] = [];
  const brightIdx: number[] = [];
  let brightV = 0;

  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const shrubCore = new THREE.Vector3(0, 0.32 * scale, 0);

  const stemCount = Math.floor(randRange(rng, 6, 10));
  for (let s = 0; s < stemCount; s++) {
    const azim = (s / stemCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const spread = randRange(rng, 0.42, 0.92) * scale;
    const height = randRange(rng, 0.62, 1.25) * scale;

    const p0 = new THREE.Vector3(Math.cos(azim) * 0.04, -0.04, Math.sin(azim) * 0.04);
    const p1 = new THREE.Vector3(
      Math.cos(azim) * spread * 0.45,
      height * 0.55,
      Math.sin(azim) * spread * 0.45
    );
    const p2 = new THREE.Vector3(
      Math.cos(azim + randRange(rng, -0.25, 0.25)) * spread,
      height,
      Math.sin(azim + randRange(rng, -0.25, 0.25)) * spread
    );

    const curve = new THREE.CatmullRomCurve3([p0, p1, p2]);
    stemGeos.push(new THREE.TubeGeometry(curve, 5, 0.014 * scale, 4, false));

    // Attach 3–4 arched botanical leaf sprigs along upper half of each woody stem
    const cardSpots = [0.48, 0.74, 0.98];
    for (let k = 0; k < cardSpots.length; k++) {
      const origin = curve.getPointAt(cardSpots[k]);
      const cardsHere = k === 2 ? 2 : 1;
      for (let c = 0; c < cardsHere; c++) {
        const yaw = azim + randRange(rng, -0.9, 0.9);
        const pitch = randRange(rng, 0.52, 1.18);
        const roll = randRange(rng, -0.45, 0.45);
        e.set(pitch, yaw, roll, 'YXZ');
        q.setFromEuler(e);

        const cw = randRange(rng, 0.46, 0.78) * scale;
        const cl = randRange(rng, 0.54, 0.88) * scale;
        const useBright = sunlit && k === 2 && rng() > 0.38;

        if (useBright) {
          brightV = buildArchedCardIntoArrays(
            brightPos,
            brightNorm,
            brightUv,
            brightIdx,
            brightV,
            origin,
            q,
            cw,
            cl,
            randRange(rng, 0.22, 0.42),
            0.4,
            shrubCore,
            3
          );
        } else {
          mainV = buildArchedCardIntoArrays(
            mainPos,
            mainNorm,
            mainUv,
            mainIdx,
            mainV,
            origin,
            q,
            cw,
            cl,
            randRange(rng, 0.22, 0.44),
            0.4,
            shrubCore,
            3
          );
        }
      }
    }
  }

  // Merge woody shrub stems into a single geometry
  const mergedStems = mergeSimpleGeometries(stemGeos);
  stemGeos.forEach((g) => g.dispose());
  const stemMesh = new THREE.Mesh(mergedStems, materials.hardwoodBark);
  stemMesh.name = 'Shrub_Woody_Stems';
  stemMesh.castShadow = true;
  stemMesh.receiveShadow = true;
  group.add(stemMesh);

  if (mainV > 0) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(mainPos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(mainNorm, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(mainUv, 2));
    geo.setIndex(mainIdx);
    const mesh = new THREE.Mesh(geo, materials.shrubLeaf);
    mesh.name = 'Shrub_Main_Foliage';
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.customDepthMaterial = materials.shrubLeaf.userData.customDepthMaterial;
    group.add(mesh);
  }

  if (brightV > 0) {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(brightPos, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(brightNorm, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(brightUv, 2));
    geo.setIndex(brightIdx);
    const mesh = new THREE.Mesh(geo, materials.canopyBright);
    mesh.name = 'Shrub_Sunlit_Shoots';
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.customDepthMaterial = materials.canopyBright.userData.customDepthMaterial;
    group.add(mesh);
  }

  return group;
}

/**
 * 2. ARCHING WOODLAND FERN (Pakis Hutan)
 * 12-16 gracefully curving pinnate fronds radiating from a dark mossy forest crown!
 */
export function createWoodlandFern(
  materials: StudioMaterialLibrary,
  opts: { seed: number; scale?: number }
): THREE.Group {
  const rng = createRng(opts.seed);
  const scale = opts.scale ?? 1.0;

  const group = new THREE.Group();
  group.name = `Woodland_Fern_${opts.seed}`;

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOff = 0;

  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const origin = new THREE.Vector3(0, -0.02, 0);
  const center = new THREE.Vector3(0, 0.15 * scale, 0);

  // Outer mature drooping whorl + inner steeper fresh fronds
  const outerCount = 10;
  const innerCount = 6;

  for (let i = 0; i < outerCount; i++) {
    const yaw = (i / outerCount) * Math.PI * 2 + randRange(rng, -0.22, 0.22);
    const pitch = randRange(rng, 0.72, 1.08);
    e.set(pitch, yaw, randRange(rng, -0.15, 0.15), 'YXZ');
    q.setFromEuler(e);

    const len = randRange(rng, 0.78, 1.12) * scale;
    const wid = len * randRange(rng, 0.34, 0.44);
    vOff = buildArchedCardIntoArrays(
      positions,
      normals,
      uvs,
      indices,
      vOff,
      origin,
      q,
      wid,
      len,
      randRange(rng, 0.42, 0.62),
      0.35,
      center,
      5
    );
  }

  for (let i = 0; i < innerCount; i++) {
    const yaw = (i / innerCount) * Math.PI * 2 + 0.3 + randRange(rng, -0.25, 0.25);
    const pitch = randRange(rng, 0.28, 0.58);
    e.set(pitch, yaw, randRange(rng, -0.12, 0.12), 'YXZ');
    q.setFromEuler(e);

    const len = randRange(rng, 0.52, 0.76) * scale;
    const wid = len * 0.38;
    vOff = buildArchedCardIntoArrays(
      positions,
      normals,
      uvs,
      indices,
      vOff,
      origin,
      q,
      wid,
      len,
      randRange(rng, 0.26, 0.42),
      0.3,
      center,
      5
    );
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);

  const mesh = new THREE.Mesh(geo, materials.fernFrond);
  mesh.name = 'Fern_Fronds_Mesh';
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.customDepthMaterial = materials.fernFrond.userData.customDepthMaterial;
  group.add(mesh);

  return group;
}

/**
 * 3. YOUNG JAPANESE UNDERSTORY FOREST SAPLING (Anakan Pohon / Semak Tinggi)
 */
export function createForestSapling(
  materials: StudioMaterialLibrary,
  opts: { seed: number; height?: number }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 2.3;
  const group = new THREE.Group();
  group.name = `Forest_Sapling_${opts.seed}`;

  const stemGeos: THREE.BufferGeometry[] = [];
  const mainCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.05, 0),
    new THREE.Vector3(randRange(rng, -0.14, 0.14), height * 0.35, randRange(rng, -0.14, 0.14)),
    new THREE.Vector3(randRange(rng, -0.22, 0.22), height * 0.72, randRange(rng, -0.22, 0.22)),
    new THREE.Vector3(randRange(rng, -0.18, 0.18), height, randRange(rng, -0.18, 0.18)),
  ]);
  stemGeos.push(new THREE.TubeGeometry(mainCurve, 8, 0.026, 5, false));

  const leafPos: number[] = [];
  const leafNorm: number[] = [];
  const leafUv: number[] = [];
  const leafIdx: number[] = [];
  let vOff = 0;

  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const core = new THREE.Vector3(0, height * 0.65, 0);

  const twigs = 7;
  for (let i = 0; i < twigs; i++) {
    const t = 0.36 + (i / (twigs - 1)) * 0.62;
    const p = mainCurve.getPointAt(t);
    const yaw = i * 2.39996 + randRange(rng, -0.3, 0.3);
    const reach = (0.72 - t * 0.28) * (height * 0.45);
    const end = p
      .clone()
      .add(new THREE.Vector3(Math.cos(yaw) * reach, randRange(rng, 0.15, 0.36), Math.sin(yaw) * reach));

    stemGeos.push(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([p, end]), 4, 0.011, 4, false));

    for (let c = 0; c < 3; c++) {
      e.set(randRange(rng, 0.72, 1.25), yaw + (c - 1) * 0.72, randRange(rng, -0.35, 0.35), 'YXZ');
      q.setFromEuler(e);
      vOff = buildArchedCardIntoArrays(
        leafPos,
        leafNorm,
        leafUv,
        leafIdx,
        vOff,
        end,
        q,
        randRange(rng, 0.56, 0.85),
        randRange(rng, 0.68, 0.96),
        0.26,
        0.35,
        core,
        3
      );
    }
  }

  const mergedStems = mergeSimpleGeometries(stemGeos);
  stemGeos.forEach((g) => g.dispose());
  const stemMesh = new THREE.Mesh(mergedStems, materials.hardwoodBark);
  stemMesh.castShadow = true;
  stemMesh.receiveShadow = true;
  group.add(stemMesh);

  const leafGeo = new THREE.BufferGeometry();
  leafGeo.setAttribute('position', new THREE.Float32BufferAttribute(leafPos, 3));
  leafGeo.setAttribute('normal', new THREE.Float32BufferAttribute(leafNorm, 3));
  leafGeo.setAttribute('uv', new THREE.Float32BufferAttribute(leafUv, 2));
  leafGeo.setIndex(leafIdx);
  const leafMesh = new THREE.Mesh(leafGeo, materials.canopyBright);
  leafMesh.castShadow = true;
  leafMesh.receiveShadow = true;
  leafMesh.customDepthMaterial = materials.canopyBright.userData.customDepthMaterial;
  group.add(leafMesh);

  return group;
}

/**
 * 4. NATURAL MULTI-BLADE WILD FOREST GRASS TUFT GEOMETRY
 * 12 curved, gracefully tapering 4-segment blades fanning organically in every clump!
 */
export function createWildGrassTuftGeometry(seed = 1234): THREE.BufferGeometry {
  const rng = createRng(seed);
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOff = 0;

  const bladeCount = 12;
  const segs = 4;

  for (let b = 0; b < bladeCount; b++) {
    const azim = (b / bladeCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const rootDist = randRange(rng, 0.0, 0.085);
    const rx = Math.cos(azim) * rootDist;
    const rz = Math.sin(azim) * rootDist;

    const dirAngle = azim + randRange(rng, -0.45, 0.45);
    const dx = Math.cos(dirAngle);
    const dz = Math.sin(dirAngle);
    const px = -dz;
    const pz = dx;

    const bladeH = randRange(rng, 0.24, 0.56);
    const baseW = randRange(rng, 0.013, 0.024);
    const leanOut = randRange(rng, 0.14, 0.42) * bladeH;
    const droopTip = randRange(rng, 0.08, 0.28) * bladeH;

    for (let s = 0; s <= segs; s++) {
      const t = s / segs;
      const w = baseW * Math.pow(1 - t, 0.85);
      // Graceful parabolic natural grass arch
      const horiz = leanOut * Math.pow(t, 1.55);
      const y = bladeH * t - droopTip * t * t * t;
      const cx = rx + dx * horiz;
      const cz = rz + dz * horiz;

      // Slightly V-creased normals for realistic blade sheen
      const nx1 = -px * 0.35 + dx * 0.25;
      const nz1 = -pz * 0.35 + dz * 0.25;
      const nx2 = px * 0.35 + dx * 0.25;
      const nz2 = pz * 0.35 + dz * 0.25;

      if (s < segs) {
        positions.push(cx - px * w, y - 0.015, cz - pz * w);
        positions.push(cx + px * w, y - 0.015, cz + pz * w);
        normals.push(nx1, 0.88, nz1, nx2, 0.88, nz2);
        uvs.push(0, t, 1, t);
      } else {
        // Pointed razor-sharp grass tip vertex!
        positions.push(cx, y - 0.015, cz);
        normals.push(dx * 0.25, 0.92, dz * 0.25);
        uvs.push(0.5, 1.0);
      }
    }

    for (let s = 0; s < segs - 1; s++) {
      const a = vOff + s * 2;
      const b2 = a + 1;
      const c = a + 2;
      const d = a + 3;
      indices.push(a, b2, c, b2, d, c);
    }
    // Tip triangle
    const lastBase = vOff + (segs - 1) * 2;
    const tipIdx = lastBase + 2;
    indices.push(lastBase, lastBase + 1, tipIdx);

    vOff += segs * 2 + 1;
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeBoundingSphere();
  return geo;
}

/**
 * 5. SCATTERS REALISTIC CLUMPED WILD FOREST GRASS & DRY THATCH SEDGES ACROSS TERRAIN
 */
export function createInstancedForestGrass(
  materials: StudioMaterialLibrary,
  sampler: HeightSampler,
  placements: Array<{ x: number; z: number; scale: number; dryRatio: number }>,
  seed = 4567
): THREE.InstancedMesh {
  const rng = createRng(seed);
  const tuftGeo = createWildGrassTuftGeometry(seed + 99);
  const inst = new THREE.InstancedMesh(tuftGeo, materials.grassClump, placements.length);
  inst.name = 'Instanced_Wild_Forest_Grass';
  inst.castShadow = true;
  inst.receiveShadow = true;
  inst.customDepthMaterial = materials.grassClump.userData.customDepthMaterial;

  const dummy = new THREE.Object3D();
  const up = new THREE.Vector3(0, 1, 0);
  const qAlign = new THREE.Quaternion();
  const qSpin = new THREE.Quaternion();
  const color = new THREE.Color();

  // Natural mountain forest grass palette (vibrant spring greens + olive + dry golden straw thatch!)
  const greenColors = ['#588a24', '#6ea32b', '#44721d', '#82b832', '#3d661a', '#7aa935'];
  const dryColors = ['#9c7c48', '#b0915c', '#82653b', '#8d8045', '#c2a670'];

  for (let i = 0; i < placements.length; i++) {
    const p = placements[i];
    const y = sampler(p.x, p.z);
    const n = sampleTerrainNormal(sampler, p.x, p.z);

    // Partially align to terrain slope (real grass grows mostly vertically upward, slightly leaning out!)
    const blendedUp = up.clone().lerp(n, 0.35).normalize();
    qAlign.setFromUnitVectors(up, blendedUp);
    qSpin.setFromAxisAngle(up, rng() * Math.PI * 2);

    dummy.position.set(p.x, y - 0.01, p.z);
    dummy.quaternion.copy(qAlign).multiply(qSpin);
    dummy.scale.set(
      p.scale * randRange(rng, 0.85, 1.25),
      p.scale * randRange(rng, 0.78, 1.38),
      p.scale * randRange(rng, 0.85, 1.25)
    );
    dummy.updateMatrix();
    inst.setMatrixAt(i, dummy.matrix);

    const isDry = rng() < p.dryRatio;
    const palette = isDry ? dryColors : greenColors;
    color.set(palette[Math.floor(rng() * palette.length)]);
    color.offsetHSL(randRange(rng, -0.025, 0.025), randRange(rng, -0.06, 0.06), randRange(rng, -0.06, 0.06));
    inst.setColorAt(i, color);
  }

  inst.instanceMatrix.needsUpdate = true;
  if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
  return inst;
}

/**
 * 6. ISOLATED SHRUB, FERN, SAPLING & WILD GRASS SHOWCASE PACK
 */
export function createIsolatedShrubGrassAsset(materials: StudioMaterialLibrary): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Forest_Shrub_Grass_Asset_Kit';

  // Sculpted organic circular humus display disc
  const discGeo = new THREE.CylinderGeometry(2.55, 2.7, 0.24, 64, 4);
  const pos = discGeo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    if (y > 0.05) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const r = Math.sqrt(x * x + z * z);
      const mound = Math.max(0, 1 - (r / 2.65) * (r / 2.65)) * 0.14;
      pos.setY(i, y + mound);
    }
  }
  discGeo.computeVertexNormals();
  const discSampler: HeightSampler = (x, z) => {
    const r = Math.sqrt(x * x + z * z);
    return 0.12 + Math.max(0, 1 - (r / 2.65) * (r / 2.65)) * 0.14;
  };

  // Top faces forest floor material, clean plinth look
  const colors = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    colors[i * 3] = 0.88;
    colors[i * 3 + 1] = 0.86;
    colors[i * 3 + 2] = 0.82;
  }
  discGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const discMesh = new THREE.Mesh(discGeo, materials.forestFloor);
  discMesh.name = 'Botanical_Display_Base';
  discMesh.receiveShadow = true;
  discMesh.castShadow = true;
  group.add(discMesh);

  // 1. Hero Wild Woodland Shrub (back-left)
  const heroShrub = createWildForestShrub(materials, { seed: 4101, scale: 1.25, sunlit: true });
  heroShrub.position.set(-0.78, discSampler(-0.78, -0.45), -0.45);
  group.add(heroShrub);

  // 2. Young Broadleaf Mountain Sapling (back-right)
  const sapling = createForestSapling(materials, { seed: 4202, height: 2.35 });
  sapling.position.set(0.68, discSampler(0.68, -0.62), -0.62);
  group.add(sapling);

  // 3. Two Arching Woodland Ferns (mid-left & front-right)
  const fern1 = createWoodlandFern(materials, { seed: 4303, scale: 1.15 });
  fern1.position.set(0.85, discSampler(0.85, 0.55), 0.55);
  group.add(fern1);

  const fern2 = createWoodlandFern(materials, { seed: 4309, scale: 0.85 });
  fern2.position.set(-1.12, discSampler(-1.12, 0.65), 0.65);
  group.add(fern2);

  // 4. Secondary compact lower shrub
  const shrub2 = createWildForestShrub(materials, { seed: 4199, scale: 0.82, sunlit: false });
  shrub2.position.set(0.15, discSampler(0.15, -1.15), -1.15);
  group.add(shrub2);

  // 5. Dense natural wild forest grass + dry golden thatch sedge clusters in the foreground!
  const rng = createRng(4888);
  const grassSpots: Array<{ x: number; z: number; scale: number; dryRatio: number }> = [];
  for (let i = 0; i < 185; i++) {
    const r = Math.sqrt(rng()) * 2.15;
    const ang = rng() * Math.PI * 2;
    const x = Math.cos(ang) * r;
    const z = Math.sin(ang) * r;
    // Denser grass tufts along front & edges, mixing dry golden thatch with bright woodland green!
    grassSpots.push({
      x,
      z,
      scale: randRange(rng, 0.65, 1.48),
      dryRatio: z > 0.3 ? 0.36 : 0.22,
    });
  }
  const grassInst = createInstancedForestGrass(materials, discSampler, grassSpots, 4999);
  group.add(grassInst);

  return group;
}

/**
 * Clean helper to merge small non-indexed or indexed geometries with identical position/normal/uv attributes
 */
function mergeSimpleGeometries(geometries: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  let vOffset = 0;

  for (const g of geometries) {
    const pos = g.attributes.position;
    const norm = g.attributes.normal;
    const uv = g.attributes.uv;
    for (let i = 0; i < pos.count; i++) {
      positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
      normals.push(norm.getX(i), norm.getY(i), norm.getZ(i));
      uvs.push(uv ? uv.getX(i) : 0, uv ? uv.getY(i) : 0);
    }
    if (g.index) {
      for (let i = 0; i < g.index.count; i++) {
        indices.push(g.index.getX(i) + vOffset);
      }
    } else {
      for (let i = 0; i < pos.count; i++) {
        indices.push(i + vOffset);
      }
    }
    vOffset += pos.count;
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  out.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  out.setIndex(indices);
  return out;
}
