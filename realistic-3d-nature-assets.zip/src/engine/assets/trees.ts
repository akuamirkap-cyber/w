import * as THREE from 'three';
import { StudioMaterialLibrary } from '../materials';
import { createRng, randRange } from '../noise';

class GeometryBuilder {
  positions: number[] = [];
  normals: number[] = [];
  uvs: number[] = [];
  colors: number[] = [];
  indices: number[] = [];
  vertexCount = 0;

  toBufferGeometry(includeColors = false): THREE.BufferGeometry {
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(this.positions, 3));
    geo.setAttribute('normal', new THREE.Float32BufferAttribute(this.normals, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(this.uvs, 2));
    if (includeColors && this.colors.length === this.vertexCount * 3) {
      geo.setAttribute('color', new THREE.Float32BufferAttribute(this.colors, 3));
    }
    geo.setIndex(this.indices);
    geo.computeBoundingSphere();
    return geo;
  }
}

/**
 * Generates an organic tapered bark tube along a 3D CatmullRomCurve3 into GeometryBuilder.
 */
function appendBranchTube(
  builder: GeometryBuilder,
  points: THREE.Vector3[],
  radiusStart: number,
  radiusEnd: number,
  tubularSegments: number,
  radialSegments: number,
  uvVScale: number,
  rootFlare = false,
  flarePhase = 0
) {
  const curve = new THREE.CatmullRomCurve3(points);
  const frames = curve.computeFrenetFrames(tubularSegments, false);
  const baseVertex = builder.vertexCount;
  const totalLen = curve.getLength();
  const vRepeat = Math.max(0.45, totalLen * uvVScale);

  const P = new THREE.Vector3();
  const N = new THREE.Vector3();
  const B = new THREE.Vector3();
  const vert = new THREE.Vector3();
  const norm = new THREE.Vector3();

  for (let i = 0; i <= tubularSegments; i++) {
    const t = i / tubularSegments;
    curve.getPointAt(t, P);
    N.copy(frames.normals[i]);
    B.copy(frames.binormals[i]);

    const baseR = THREE.MathUtils.lerp(radiusStart, radiusEnd, Math.pow(t, 0.85));
    const flareWeight = rootFlare && t < 0.24 ? Math.pow(1 - t / 0.24, 2.15) : 0;

    for (let j = 0; j <= radialSegments; j++) {
      const u = j / radialSegments;
      const theta = u * Math.PI * 2;
      const cos = Math.cos(theta);
      const sin = Math.sin(theta);

      let r = baseR;
      if (flareWeight > 0) {
        const lobes = 0.62 + 0.38 * Math.cos(theta * 5 + flarePhase);
        r *= 1 + flareWeight * (0.42 + 0.36 * lobes);
      }
      r *= 1 + 0.042 * Math.sin(theta * 3 + t * 8.5);

      norm
        .set(0, 0, 0)
        .addScaledVector(N, cos)
        .addScaledVector(B, sin)
        .normalize();

      vert.copy(P).addScaledVector(norm, r);

      builder.positions.push(vert.x, vert.y, vert.z);
      builder.normals.push(norm.x, norm.y, norm.z);
      builder.uvs.push(u * Math.max(1, Math.round(radiusStart * 9)), t * vRepeat);
    }
  }

  const ringStride = radialSegments + 1;
  for (let i = 0; i < tubularSegments; i++) {
    for (let j = 0; j < radialSegments; j++) {
      const a = baseVertex + i * ringStride + j;
      const b = baseVertex + (i + 1) * ringStride + j;
      const c = baseVertex + (i + 1) * ringStride + (j + 1);
      const d = baseVertex + i * ringStride + (j + 1);
      builder.indices.push(a, b, d);
      builder.indices.push(b, c, d);
    }
  }

  builder.vertexCount += (tubularSegments + 1) * ringStride;
}

/**
 * Helper: Appends exposed surface root buttresses anchoring a trunk naturally into forest soil.
 */
function appendSurfaceRoots(
  builder: GeometryBuilder,
  trunkRadius: number,
  rootCount: number,
  rng: () => number,
  offsetX = 0,
  offsetZ = 0
) {
  for (let r = 0; r < rootCount; r++) {
    const ang = (r / rootCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const rootLen = trunkRadius * randRange(rng, 4.0, 6.4);
    const rootPts = [
      new THREE.Vector3(
        offsetX + Math.cos(ang) * trunkRadius * 0.45,
        0.34,
        offsetZ + Math.sin(ang) * trunkRadius * 0.45
      ),
      new THREE.Vector3(
        offsetX + Math.cos(ang) * rootLen * 0.48,
        0.09,
        offsetZ + Math.sin(ang) * rootLen * 0.48
      ),
      new THREE.Vector3(
        offsetX + Math.cos(ang + randRange(rng, -0.25, 0.25)) * rootLen,
        -0.28,
        offsetZ + Math.sin(ang + randRange(rng, -0.25, 0.25)) * rootLen
      ),
    ];
    appendBranchTube(builder, rootPts, trunkRadius * 0.36, trunkRadius * 0.08, 6, 5, 1.0);
  }
}

interface CrownAOProfile {
  center: THREE.Vector3;
  radiusXZ: number;
  minY: number;
  maxY: number;
}

const _worldUp = new THREE.Vector3(0, 1, 0);
const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _up = new THREE.Vector3();
const _bankQuat = new THREE.Quaternion();
const _localPos = new THREE.Vector3();
const _worldPos = new THREE.Vector3();
const _localNorm = new THREE.Vector3();
const _worldNorm = new THREE.Vector3();
const _canopyDir = new THREE.Vector3();

/**
 * CORE BOTANICAL FOLIAGE ENGINE (Fixed Natural Horizontal-Gravity Orientation!):
 * Builds an organically arched, sky-facing leaf spray directly along a branch growth vector `dir`:
 * - Stem (v=0) attaches firmly onto the twig; leaf tip (v=1) reaches OUTWARD along `dir`
 * - Leaf face points UP toward the sky (heliotropic phyllotaxy!) with natural gravity droop at tips
 * - ZERO vertical upright spike artifacts!
 * - Bakes smooth 3D canopy Ambient Occlusion + subtle organic tonal warmth into vertex colors!
 */
function appendBranchAlignedSprig(
  builder: GeometryBuilder,
  origin: THREE.Vector3,
  growDir: THREE.Vector3,
  width: number,
  length: number,
  droop: number,
  cup: number,
  bankAngleRad: number,
  aoProfile: CrownAOProfile,
  toneShift = 0.0
) {
  _fwd.copy(growDir);
  if (_fwd.lengthSq() < 1e-5) _fwd.set(1, 0, 0);
  _fwd.normalize();

  // Construct horizontal right axis so the flat leaf spray ALWAYS faces UP toward sunlight!
  if (Math.abs(_fwd.y) > 0.94) {
    _right.set(1, 0, 0).cross(_fwd).normalize();
  } else {
    _right.crossVectors(_fwd, _worldUp).normalize();
  }
  _up.crossVectors(_right, _fwd).normalize();

  // Apply gentle natural organic banking/roll around the twig stem axis
  if (Math.abs(bankAngleRad) > 1e-4) {
    _bankQuat.setFromAxisAngle(_fwd, bankAngleRad);
    _right.applyQuaternion(_bankQuat);
    _up.applyQuaternion(_bankQuat);
  }

  const segX = 2;
  const segY = 3;
  const baseVertex = builder.vertexCount;
  const heightSpan = Math.max(0.5, aoProfile.maxY - aoProfile.minY);

  for (let iy = 0; iy <= segY; iy++) {
    const v = iy / segY; // 0 = attached to woody branch, 1 = outer drooping tip
    for (let ix = 0; ix <= segX; ix++) {
      const u = ix / segX;
      const xNorm = u * 2 - 1; // -1..1

      // Local coordinates in branch-aligned basis:
      // Along _right = width, along _fwd = length, along _up = arch/gravity droop + gentle cross-cup!
      const sRight = xNorm * width * 0.5;
      // Start slightly behind origin (-0.06*length) so wooden twig visibly tucks right into leaves!
      const sFwd = (v - 0.06) * length;
      // Natural botanical arch: tiny upward rise near stem, graceful gravity droop toward tip!
      const archCurve = Math.sin(v * Math.PI) * length * 0.06 - droop * v * v * length;
      const crossCup = cup * (1 - xNorm * xNorm) * width * 0.13;
      const sUp = archCurve + crossCup;

      _worldPos
        .copy(origin)
        .addScaledVector(_right, sRight)
        .addScaledVector(_fwd, sFwd)
        .addScaledVector(_up, sUp);

      // Surface normal blended 65% outward/upward from canopy core (SpeedTree-grade soft daylight wrap!)
      _localNorm
        .set(0, 0, 0)
        .addScaledVector(_up, 1.0)
        .addScaledVector(_fwd, droop * v * 0.55)
        .addScaledVector(_right, -xNorm * 0.24)
        .normalize();

      _canopyDir
        .copy(_worldPos)
        .sub(aoProfile.center)
        .add(new THREE.Vector3(0, 0.85, 0))
        .normalize();
      _worldNorm.copy(_localNorm).lerp(_canopyDir, 0.65).normalize();

      // Baked 3D Canopy Ambient Occlusion (sculpts deep lush inner shadows & crisp outer sunlight!)
      const dx = _worldPos.x - aoProfile.center.x;
      const dz = _worldPos.z - aoProfile.center.z;
      const radial = Math.min(1.0, Math.hypot(dx, dz) / Math.max(0.6, aoProfile.radiusXZ));
      const heightT = Math.max(0, Math.min(1, (_worldPos.y - aoProfile.minY) / heightSpan));

      // Deep shaded interior core = ~0.46, outer sunlit top rim = ~1.02
      const ao = THREE.MathUtils.clamp(
        0.44 + radial * 0.30 + heightT * 0.24 + v * 0.08 + toneShift,
        0.38,
        1.04
      );
      // Slightly cooler emerald tint in interior shade, warmer sunlit green-gold on outer crown!
      const cr = ao * (0.94 + heightT * 0.09);
      const cg = ao * (0.98 + radial * 0.05);
      const cb = ao * (0.92 + (1 - heightT) * 0.07);

      builder.positions.push(_worldPos.x, _worldPos.y, _worldPos.z);
      builder.normals.push(_worldNorm.x, _worldNorm.y, _worldNorm.z);
      builder.uvs.push(u, v);
      builder.colors.push(cr, cg, cb);
    }
  }

  const stride = segX + 1;
  for (let iy = 0; iy < segY; iy++) {
    for (let ix = 0; ix < segX; ix++) {
      const a = baseVertex + iy * stride + ix;
      const b = baseVertex + (iy + 1) * stride + ix;
      const c = baseVertex + (iy + 1) * stride + (ix + 1);
      const d = baseVertex + iy * stride + (ix + 1);
      builder.indices.push(a, d, b);
      builder.indices.push(b, d, c);
    }
  }

  builder.vertexCount += (segX + 1) * (segY + 1);
  // Keep _localPos referenced cleanly if extended later
  void _localPos;
}

/**
 * Places a natural, horizontal-fanning multi-spray botanical foliage pad at a twig node!
 * Every spray fans outward from the branch direction, faces the sky, and gently droops under gravity.
 */
function appendNaturalFoliagePad(
  primaryBuilder: GeometryBuilder,
  shadeBuilder: GeometryBuilder,
  origin: THREE.Vector3,
  twigDir: THREE.Vector3,
  padScale: number,
  brightProbability: number,
  aoProfile: CrownAOProfile,
  rng: () => number,
  style: 'layered' | 'dome' | 'pinePad' | 'weeping' = 'layered',
  density = 4
) {
  // Base horizontal outward direction from twig
  const horiz = new THREE.Vector3(twigDir.x, 0, twigDir.z);
  if (horiz.lengthSq() < 1e-4) {
    const a = rng() * Math.PI * 2;
    horiz.set(Math.cos(a), 0, Math.sin(a));
  } else {
    horiz.normalize();
  }
  const baseYaw = Math.atan2(horiz.z, horiz.x);
  const toneShift = randRange(rng, -0.05, 0.05);

  const dir = new THREE.Vector3();
  const pos = new THREE.Vector3();

  for (let i = 0; i < density; i++) {
    // Spread sprays organically around the branch growth direction (forward + left/right wings!)
    const spreadSpan = style === 'pinePad' ? 1.85 : style === 'weeping' ? 1.4 : 1.55;
    const tFan = density === 1 ? 0 : (i / (density - 1)) * 2 - 1; // -1..+1
    const yaw = baseYaw + tFan * spreadSpan + randRange(rng, -0.25, 0.25);

    // Botanical pitch angle (vertical Y component of growth vector):
    // STRICTLY controlled horizontal-to-gently-drooping range — ZERO weird upright spikes!
    let slopeY: number;
    let droop: number;
    let bank: number;
    let wMult: number;
    let lMult: number;

    if (style === 'pinePad') {
      // Flat sculptural horizontal Japanese Akamatsu cloud pad!
      slopeY = randRange(rng, -0.08, 0.14);
      droop = randRange(rng, 0.08, 0.18);
      bank = randRange(rng, -0.22, 0.22);
      wMult = randRange(rng, 0.95, 1.25);
      lMult = randRange(rng, 0.9, 1.18);
    } else if (style === 'weeping') {
      // Graceful hanging Shirakaba White Birch branchlet curtain!
      slopeY = randRange(rng, -0.68, -0.18);
      droop = randRange(rng, 0.36, 0.56);
      bank = randRange(rng, -0.55, 0.55);
      wMult = randRange(rng, 0.72, 0.98);
      lMult = randRange(rng, 1.05, 1.42);
    } else if (style === 'dome') {
      // Rounded lush Zelkova / Beech woodland umbrella pad!
      slopeY = i === 0 ? randRange(rng, 0.06, 0.24) : randRange(rng, -0.22, 0.14);
      droop = randRange(rng, 0.22, 0.38);
      // Slight cross-roll on one companion card gives full 3D side-view volume without paper flatness!
      bank = i % 3 === 1 ? randRange(rng, 0.32, 0.52) * (rng() > 0.5 ? 1 : -1) : randRange(rng, -0.28, 0.28);
      wMult = randRange(rng, 0.9, 1.22);
      lMult = randRange(rng, 0.95, 1.28);
    } else {
      // Layered Japanese Maple (Momiji) horizontal feather shelves!
      slopeY = randRange(rng, -0.18, 0.16);
      droop = randRange(rng, 0.18, 0.34);
      bank = i % 3 === 2 ? randRange(rng, 0.28, 0.48) * (rng() > 0.5 ? 1 : -1) : randRange(rng, -0.24, 0.24);
      wMult = randRange(rng, 0.92, 1.24);
      lMult = randRange(rng, 0.96, 1.3);
    }

    dir.set(Math.cos(yaw), slopeY, Math.sin(yaw)).normalize();

    // Small local organic jitter around the twig node
    pos.copy(origin).add(
      new THREE.Vector3(
        randRange(rng, -0.14, 0.14) * padScale,
        randRange(rng, -0.09, 0.12) * padScale,
        randRange(rng, -0.14, 0.14) * padScale
      )
    );

    // Choose sunlit outer vs shaded interior material naturally based on height & probability
    const usePrimary = rng() < brightProbability;
    const target = usePrimary ? primaryBuilder : shadeBuilder;

    appendBranchAlignedSprig(
      target,
      pos,
      dir,
      padScale * wMult,
      padScale * lMult,
      droop,
      randRange(rng, 0.25, 0.55),
      bank,
      aoProfile,
      toneShift + randRange(rng, -0.03, 0.03)
    );
  }
}

/**
 * Helper to finalize & attach bark + foliage meshes to a tree group cleanly.
 */
function attachFoliageMesh(
  group: THREE.Group,
  builder: GeometryBuilder,
  mat: THREE.MeshStandardMaterial,
  name: string
) {
  if (builder.vertexCount === 0) return;
  const mesh = new THREE.Mesh(builder.toBufferGeometry(true), mat);
  mesh.name = name;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  if (mat.userData.customDepthMaterial) {
    mesh.customDepthMaterial = mat.userData.customDepthMaterial;
  }
  group.add(mesh);
}

export interface BroadleafTreeOptions {
  seed: number;
  height?: number;
  trunkRadius?: number;
  crownSpread?: number;
  sunlitRatio?: number;
  leanX?: number;
  leanZ?: number;
  detailLevel?: 'hero' | 'forest';
}

/* ============================================================================
 * 1. JAPANESE MOUNTAIN MAPLE (MOMIJI / Acer palmatum) — Refined & Fixed!
 * Signature layered horizontal chartreuse-lime & deep emerald spreading shelves
 * ============================================================================ */
export function createJapaneseBroadleafTree(
  materials: StudioMaterialLibrary,
  opts: BroadleafTreeOptions
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 7.8;
  const trunkRadius = opts.trunkRadius ?? 0.22;
  const crownSpread = opts.crownSpread ?? 3.8;
  const sunlitRatio = opts.sunlitRatio ?? 0.64;
  const isHero = (opts.detailLevel ?? 'hero') === 'hero';

  const group = new THREE.Group();
  group.name = `JapaneseMaple_Momiji_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const brightBuilder = new GeometryBuilder();
  const deepBuilder = new GeometryBuilder();

  const leanX = opts.leanX ?? randRange(rng, -0.45, 0.45);
  const leanZ = opts.leanZ ?? randRange(rng, -0.45, 0.45);

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(leanX * 0.55, height * 0.58, leanZ * 0.55),
    radiusXZ: crownSpread * 0.95,
    minY: height * 0.28,
    maxY: height * 1.05,
  };

  // Organic slightly sinuous trunk with root flare
  const trunkPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 6; i++) {
    const t = i / 6;
    const sx = Math.sin(t * Math.PI * 1.2 + opts.seed) * 0.22 * t + leanX * t * t;
    const sz = Math.cos(t * Math.PI * 1.1 + opts.seed * 0.7) * 0.22 * t + leanZ * t * t;
    trunkPts.push(new THREE.Vector3(sx, t * height * 0.78, sz));
  }
  const trunkCurve = new THREE.CatmullRomCurve3(trunkPts);
  appendBranchTube(
    barkBuilder,
    trunkPts,
    trunkRadius,
    trunkRadius * 0.24,
    isHero ? 15 : 10,
    isHero ? 10 : 7,
    0.55,
    true,
    rng() * 6.28
  );
  appendSurfaceRoots(barkBuilder, trunkRadius, isHero ? 5 : 3, rng);

  // Graceful spreading tiered limbs (primary -> crooked secondary -> fine tertiary twigs)
  const primaryCount = isHero ? 10 : 7;
  const golden = 2.3999632;

  for (let b = 0; b < primaryCount; b++) {
    const frac = b / Math.max(1, primaryCount - 1);
    const attachT = 0.34 + frac * 0.64;
    const origin = trunkCurve.getPointAt(attachT);
    const azim = b * golden + randRange(rng, -0.32, 0.32);
    const dx = Math.cos(azim);
    const dz = Math.sin(azim);

    const reach = crownSpread * (1.08 - frac * 0.44) * randRange(rng, 0.84, 1.16);
    const rise = height * (0.12 + frac * 0.16) * randRange(rng, 0.78, 1.15);

    // Organic crooked curve: climbs smoothly, then levels horizontally outward!
    const p1 = origin.clone();
    const p2 = origin
      .clone()
      .add(new THREE.Vector3(dx * reach * 0.36, rise * 0.56, dz * reach * 0.36));
    const p3 = origin
      .clone()
      .add(
        new THREE.Vector3(
          dx * reach * 0.72 + randRange(rng, -0.28, 0.28),
          rise * 0.9 + randRange(rng, -0.1, 0.14),
          dz * reach * 0.72 + randRange(rng, -0.28, 0.28)
        )
      );
    const p4 = origin
      .clone()
      .add(new THREE.Vector3(dx * reach, rise * 0.95 + randRange(rng, -0.16, 0.12), dz * reach));

    const boughCurve = new THREE.CatmullRomCurve3([p1, p2, p3, p4]);
    const rStart = trunkRadius * (0.42 - frac * 0.14);
    appendBranchTube(
      barkBuilder,
      [p1, p2, p3, p4],
      rStart,
      Math.max(0.014, rStart * 0.16),
      isHero ? 9 : 6,
      isHero ? 6 : 5,
      0.85
    );

    const boughDir = new THREE.Vector3(dx, 0.05, dz).normalize();
    const sunChance = THREE.MathUtils.clamp(sunlitRatio * (0.62 + frac * 0.56), 0.15, 0.92);

    // Foliage shelf along outer tip of primary bough
    appendNaturalFoliagePad(
      brightBuilder,
      deepBuilder,
      p4,
      boughDir,
      randRange(rng, 0.78, 1.08),
      sunChance,
      aoProfile,
      rng,
      'layered',
      isHero ? 5 : 4
    );

    // Secondary crooked horizontal branchlets fanning along the outer 65% of the bough
    const secCount = isHero ? 5 : 3;
    for (let s = 0; s < secCount; s++) {
      const st = 0.28 + (s / Math.max(1, secCount - 1)) * 0.62;
      const sOrigin = boughCurve.getPointAt(st);
      const side = s % 2 === 0 ? 1 : -1;
      const sAzim = azim + side * randRange(rng, 0.48, 1.05);
      const sReach = reach * randRange(rng, 0.34, 0.54) * (1.15 - st * 0.35);
      const sRise = randRange(rng, 0.08, 0.48);

      const sp1 = sOrigin.clone();
      const sp2 = sOrigin
        .clone()
        .add(new THREE.Vector3(Math.cos(sAzim) * sReach * 0.54, sRise * 0.65, Math.sin(sAzim) * sReach * 0.54));
      const sp3 = sOrigin
        .clone()
        .add(new THREE.Vector3(Math.cos(sAzim) * sReach, sRise * 0.92, Math.sin(sAzim) * sReach));

      appendBranchTube(barkBuilder, [sp1, sp2, sp3], rStart * 0.38, 0.01, 5, 4, 1.0);

      const secDir = new THREE.Vector3(Math.cos(sAzim), 0.04, Math.sin(sAzim)).normalize();
      const secSun = THREE.MathUtils.clamp(sunlitRatio * (0.48 + frac * 0.48 + st * 0.28), 0.12, 0.94);

      // Mid-twig foliage fill (eliminates awkward bare gaps along branches!)
      appendNaturalFoliagePad(
        brightBuilder,
        deepBuilder,
        sp2,
        secDir,
        randRange(rng, 0.66, 0.92),
        secSun * 0.65,
        aoProfile,
        rng,
        'layered',
        isHero ? 3 : 2
      );
      // Outer twig tip foliage shelf
      appendNaturalFoliagePad(
        brightBuilder,
        deepBuilder,
        sp3,
        secDir,
        randRange(rng, 0.74, 1.04),
        secSun,
        aoProfile,
        rng,
        'layered',
        isHero ? 4 : 3
      );
    }
  }

  // Crown apex spreading dome leaders
  const apexBase = trunkCurve.getPointAt(1.0);
  const leaderCount = isHero ? 5 : 4;
  for (let l = 0; l < leaderCount; l++) {
    const la = (l / leaderCount) * Math.PI * 2 + randRange(rng, -0.35, 0.35);
    const lReach = crownSpread * randRange(rng, 0.28, 0.52);
    const lRise = height * randRange(rng, 0.18, 0.28);
    const lp1 = apexBase.clone();
    const lp2 = apexBase
      .clone()
      .add(new THREE.Vector3(Math.cos(la) * lReach * 0.52, lRise * 0.68, Math.sin(la) * lReach * 0.52));
    const lp3 = apexBase
      .clone()
      .add(new THREE.Vector3(Math.cos(la) * lReach, lRise, Math.sin(la) * lReach));

    appendBranchTube(barkBuilder, [lp1, lp2, lp3], trunkRadius * 0.22, 0.012, 5, 4, 1.0);
    const lDir = new THREE.Vector3(Math.cos(la), 0.12, Math.sin(la)).normalize();

    appendNaturalFoliagePad(
      brightBuilder,
      deepBuilder,
      lp2,
      lDir,
      randRange(rng, 0.72, 0.96),
      Math.min(0.95, sunlitRatio + 0.12),
      aoProfile,
      rng,
      'layered',
      isHero ? 3 : 2
    );
    appendNaturalFoliagePad(
      brightBuilder,
      deepBuilder,
      lp3,
      lDir,
      randRange(rng, 0.82, 1.12),
      Math.min(0.96, sunlitRatio + 0.26),
      aoProfile,
      rng,
      'layered',
      isHero ? 5 : 4
    );
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.hardwoodBark);
  barkMesh.name = 'Momiji_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, brightBuilder, materials.treeCanopyBright, 'Momiji_Sunlit_Canopy');
  attachFoliageMesh(group, deepBuilder, materials.treeCanopyDeep, 'Momiji_Shade_Canopy');
  return group;
}

/* ============================================================================
 * 2. NEW TOUGE TREE #1: JAPANESE ZELKOVA (KEYAKI / Zelkova serrata)
 * Iconic sweeping vase/broom-shaped crown dividing low into gracefully arching leaders!
 * ============================================================================ */
export function createJapaneseZelkovaTree(
  materials: StudioMaterialLibrary,
  opts: { seed: number; height?: number; trunkRadius?: number; detailLevel?: 'hero' | 'forest' }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 9.2;
  const trunkRadius = opts.trunkRadius ?? 0.28;
  const isHero = (opts.detailLevel ?? 'hero') === 'hero';
  const crownSpread = height * 0.54;

  const group = new THREE.Group();
  group.name = `JapaneseZelkova_Keyaki_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const zelkovaBuilder = new GeometryBuilder();
  const shadeBuilder = new GeometryBuilder();

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(0, height * 0.66, 0),
    radiusXZ: crownSpread * 0.95,
    minY: height * 0.38,
    maxY: height * 1.06,
  };

  // Sturdy short flared lower trunk splitting at ~32% height into classic Keyaki vase silhouette!
  const splitY = height * 0.31;
  const basePts = [
    new THREE.Vector3(0, -0.1, 0),
    new THREE.Vector3(randRange(rng, -0.08, 0.08), splitY * 0.5, randRange(rng, -0.08, 0.08)),
    new THREE.Vector3(randRange(rng, -0.1, 0.1), splitY, randRange(rng, -0.1, 0.1)),
  ];
  const forkOrigin = basePts[2].clone();
  appendBranchTube(barkBuilder, basePts, trunkRadius, trunkRadius * 0.72, 8, isHero ? 10 : 7, 0.6, true, rng() * 6.28);
  appendSurfaceRoots(barkBuilder, trunkRadius, isHero ? 6 : 4, rng);

  // 6 sweeping upright-then-arching main vase limbs!
  const mainLimbs = isHero ? 7 : 5;
  for (let m = 0; m < mainLimbs; m++) {
    const azim = (m / mainLimbs) * Math.PI * 2 + randRange(rng, -0.25, 0.25);
    const dx = Math.cos(azim);
    const dz = Math.sin(azim);
    const reach = crownSpread * randRange(rng, 0.78, 1.12);
    const topY = height * randRange(rng, 0.86, 1.04);

    // Classic Zelkova vase S-curve: steep upward rise from fork, gracefully flaring outward at top!
    const p0 = forkOrigin.clone();
    const p1 = new THREE.Vector3(
      forkOrigin.x + dx * reach * 0.24,
      THREE.MathUtils.lerp(splitY, topY, 0.36),
      forkOrigin.z + dz * reach * 0.24
    );
    const p2 = new THREE.Vector3(
      forkOrigin.x + dx * reach * 0.62 + randRange(rng, -0.25, 0.25),
      THREE.MathUtils.lerp(splitY, topY, 0.76),
      forkOrigin.z + dz * reach * 0.62 + randRange(rng, -0.25, 0.25)
    );
    const p3 = new THREE.Vector3(
      forkOrigin.x + dx * reach,
      topY,
      forkOrigin.z + dz * reach
    );

    const limbCurve = new THREE.CatmullRomCurve3([p0, p1, p2, p3]);
    const limbR = trunkRadius * randRange(rng, 0.34, 0.44);
    appendBranchTube(barkBuilder, [p0, p1, p2, p3], limbR, 0.018, isHero ? 10 : 7, isHero ? 6 : 5, 0.75);

    // Tip umbrella foliage dome
    const tipDir = new THREE.Vector3(dx, 0.05, dz).normalize();
    appendNaturalFoliagePad(
      zelkovaBuilder,
      shadeBuilder,
      p3,
      tipDir,
      randRange(rng, 0.88, 1.18),
      0.84,
      aoProfile,
      rng,
      'dome',
      isHero ? 5 : 4
    );

    // Fine outward & inward arching secondary twigs along upper 60% of each vase limb
    const twigs = isHero ? 5 : 3;
    for (let k = 0; k < twigs; k++) {
      const kt = 0.38 + (k / Math.max(1, twigs - 1)) * 0.56;
      const tOrig = limbCurve.getPointAt(kt);
      const side = k % 2 === 0 ? 1 : -1;
      const tAzim = azim + side * randRange(rng, 0.35, 0.88);
      const tReach = reach * randRange(rng, 0.28, 0.46);
      const tRise = randRange(rng, 0.28, 0.85) * (1.1 - kt * 0.45);

      const tp1 = tOrig.clone();
      const tp2 = tOrig
        .clone()
        .add(new THREE.Vector3(Math.cos(tAzim) * tReach * 0.55, tRise * 0.75, Math.sin(tAzim) * tReach * 0.55));
      const tp3 = tOrig
        .clone()
        .add(new THREE.Vector3(Math.cos(tAzim) * tReach, tRise * 0.88, Math.sin(tAzim) * tReach));

      appendBranchTube(barkBuilder, [tp1, tp2, tp3], limbR * 0.4, 0.011, 5, 4, 1.0);
      const tDir = new THREE.Vector3(Math.cos(tAzim), 0.04, Math.sin(tAzim)).normalize();

      appendNaturalFoliagePad(
        zelkovaBuilder,
        shadeBuilder,
        tp2,
        tDir,
        randRange(rng, 0.72, 0.96),
        0.58 + kt * 0.25,
        aoProfile,
        rng,
        'dome',
        isHero ? 3 : 2
      );
      appendNaturalFoliagePad(
        zelkovaBuilder,
        shadeBuilder,
        tp3,
        tDir,
        randRange(rng, 0.82, 1.08),
        0.74 + kt * 0.2,
        aoProfile,
        rng,
        'dome',
        isHero ? 4 : 3
      );
    }
  }

  // Central inner crown filler leader to complete the lush Keyaki dome roof
  const centerTop = forkOrigin.clone().add(new THREE.Vector3(0, height * 0.7, 0));
  appendBranchTube(
    barkBuilder,
    [forkOrigin, forkOrigin.clone().add(new THREE.Vector3(0.12, height * 0.36, -0.1)), centerTop],
    trunkRadius * 0.34,
    0.02,
    7,
    5,
    0.8
  );
  for (let c = 0; c < 4; c++) {
    const a = (c / 4) * Math.PI * 2 + 0.4;
    appendNaturalFoliagePad(
      zelkovaBuilder,
      shadeBuilder,
      centerTop.clone().add(new THREE.Vector3(Math.cos(a) * 0.65, -0.15, Math.sin(a) * 0.65)),
      new THREE.Vector3(Math.cos(a), 0.08, Math.sin(a)),
      randRange(rng, 0.92, 1.2),
      0.86,
      aoProfile,
      rng,
      'dome',
      isHero ? 4 : 3
    );
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.hardwoodBark);
  barkMesh.name = 'Keyaki_Zelkova_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, zelkovaBuilder, materials.zelkovaLeaf, 'Keyaki_Main_Foliage');
  attachFoliageMesh(group, shadeBuilder, materials.treeCanopyDeep, 'Keyaki_Shade_Foliage');
  return group;
}

/* ============================================================================
 * 3. NEW TOUGE TREE #2: JAPANESE MOUNTAIN BEECH (BUNA / Fagus crenata)
 * Smooth silvery-ash mossy bark + wide sinuous muscular limbs & lush emerald dome!
 * ============================================================================ */
export function createJapaneseBeechTree(
  materials: StudioMaterialLibrary,
  opts: { seed: number; height?: number; trunkRadius?: number; detailLevel?: 'hero' | 'forest' }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 9.6;
  const trunkRadius = opts.trunkRadius ?? 0.3;
  const isHero = (opts.detailLevel ?? 'hero') === 'hero';
  const crownSpread = height * 0.5;

  const group = new THREE.Group();
  group.name = `JapaneseBeech_Buna_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const mainLeafBuilder = new GeometryBuilder();
  const brightLeafBuilder = new GeometryBuilder();

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(0, height * 0.6, 0),
    radiusXZ: crownSpread * 0.98,
    minY: height * 0.28,
    maxY: height * 1.05,
  };

  // Sturdy, gently undulating silvery beech trunk
  const trunkPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 6; i++) {
    const t = i / 6;
    trunkPts.push(
      new THREE.Vector3(
        Math.sin(t * 2.8 + opts.seed) * 0.24 * t,
        t * height * 0.84,
        Math.cos(t * 2.4 + opts.seed) * 0.24 * t
      )
    );
  }
  const trunkCurve = new THREE.CatmullRomCurve3(trunkPts);
  appendBranchTube(barkBuilder, trunkPts, trunkRadius, trunkRadius * 0.22, isHero ? 14 : 10, isHero ? 10 : 7, 0.55, true, rng() * 6.28);
  appendSurfaceRoots(barkBuilder, trunkRadius, isHero ? 6 : 4, rng);

  // Broad sweeping horizontal-undulating Buna mountain boughs
  const boughCount = isHero ? 11 : 8;
  const golden = 2.39996;
  for (let b = 0; b < boughCount; b++) {
    const frac = b / Math.max(1, boughCount - 1);
    const tAttach = 0.30 + frac * 0.68;
    const orig = trunkCurve.getPointAt(tAttach);
    const azim = b * golden + randRange(rng, -0.28, 0.28);
    const dx = Math.cos(azim);
    const dz = Math.sin(azim);

    // Classic beech broad lower-to-mid horizontal reach tapering softly toward crown dome
    const bellEnvelope = Math.sin(0.28 + (1 - frac) * 1.12);
    const reach = crownSpread * (0.48 + 0.62 * bellEnvelope) * randRange(rng, 0.85, 1.15);
    const rise = height * (0.04 + frac * 0.18) * randRange(rng, 0.8, 1.15);

    const p1 = orig.clone();
    const p2 = orig
      .clone()
      .add(new THREE.Vector3(dx * reach * 0.38, rise * 0.45 - 0.12 * (1 - frac), dz * reach * 0.38));
    const p3 = orig
      .clone()
      .add(
        new THREE.Vector3(
          dx * reach * 0.74 + randRange(rng, -0.26, 0.26),
          rise * 0.86,
          dz * reach * 0.74 + randRange(rng, -0.26, 0.26)
        )
      );
    const p4 = orig
      .clone()
      .add(new THREE.Vector3(dx * reach, rise * 0.96 - 0.12, dz * reach));

    const bCurve = new THREE.CatmullRomCurve3([p1, p2, p3, p4]);
    const r0 = trunkRadius * (0.44 - frac * 0.18);
    appendBranchTube(barkBuilder, [p1, p2, p3, p4], r0, 0.016, isHero ? 8 : 6, 5, 0.8);

    const bDir = new THREE.Vector3(dx, 0.02, dz).normalize();
    // Outer bright emerald-lime shoots on top of lush deep beech foliage
    const brightMix = THREE.MathUtils.clamp(0.18 + frac * 0.45, 0.15, 0.68);

    appendNaturalFoliagePad(
      brightLeafBuilder,
      mainLeafBuilder,
      p4,
      bDir,
      randRange(rng, 0.86, 1.16),
      brightMix,
      aoProfile,
      rng,
      'dome',
      isHero ? 5 : 4
    );

    const subCount = isHero ? 4 : 3;
    for (let s = 0; s < subCount; s++) {
      const st = 0.32 + (s / Math.max(1, subCount - 1)) * 0.56;
      const sOrig = bCurve.getPointAt(st);
      const side = s % 2 === 0 ? 1 : -1;
      const sAzim = azim + side * randRange(rng, 0.52, 1.08);
      const sReach = reach * randRange(rng, 0.34, 0.52);
      const sp2 = sOrig
        .clone()
        .add(new THREE.Vector3(Math.cos(sAzim) * sReach * 0.55, randRange(rng, 0.05, 0.32), Math.sin(sAzim) * sReach * 0.55));
      const sp3 = sOrig
        .clone()
        .add(new THREE.Vector3(Math.cos(sAzim) * sReach, randRange(rng, -0.05, 0.36), Math.sin(sAzim) * sReach));

      appendBranchTube(barkBuilder, [sOrig, sp2, sp3], r0 * 0.4, 0.011, 4, 4, 1.0);
      const sDir = new THREE.Vector3(Math.cos(sAzim), 0.0, Math.sin(sAzim)).normalize();

      appendNaturalFoliagePad(
        brightLeafBuilder,
        mainLeafBuilder,
        sp2,
        sDir,
        randRange(rng, 0.72, 0.96),
        brightMix * 0.6,
        aoProfile,
        rng,
        'dome',
        isHero ? 3 : 2
      );
      appendNaturalFoliagePad(
        brightLeafBuilder,
        mainLeafBuilder,
        sp3,
        sDir,
        randRange(rng, 0.82, 1.08),
        brightMix,
        aoProfile,
        rng,
        'dome',
        isHero ? 4 : 3
      );
    }
  }

  // Sunlit rounded beech crown roof
  const crownTop = trunkCurve.getPointAt(1.0);
  for (let c = 0; c < 4; c++) {
    const a = (c / 4) * Math.PI * 2 + randRange(rng, -0.3, 0.3);
    const tip = crownTop.clone().add(new THREE.Vector3(Math.cos(a) * 1.1, height * 0.14, Math.sin(a) * 1.1));
    appendBranchTube(barkBuilder, [crownTop, tip], trunkRadius * 0.18, 0.014, 4, 4, 0.9);
    appendNaturalFoliagePad(
      brightLeafBuilder,
      mainLeafBuilder,
      tip,
      new THREE.Vector3(Math.cos(a), 0.06, Math.sin(a)),
      randRange(rng, 0.92, 1.18),
      0.62,
      aoProfile,
      rng,
      'dome',
      isHero ? 5 : 4
    );
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.beechBark);
  barkMesh.name = 'Buna_Silvery_Beech_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, mainLeafBuilder, materials.zelkovaLeaf, 'Buna_Emerald_Canopy');
  attachFoliageMesh(group, brightLeafBuilder, materials.treeCanopyBright, 'Buna_Sunlit_Tips');
  return group;
}

/* ============================================================================
 * 4. NEW TOUGE TREE #3: JAPANESE RED PINE (AKAMATSU / Pinus densiflora)
 * Sculptural wind-swept crooked terracotta-bark cliff pine with flat cloud needle pads!
 * ============================================================================ */
export function createJapaneseRedPineTree(
  materials: StudioMaterialLibrary,
  opts: { seed: number; height?: number; trunkRadius?: number; detailLevel?: 'hero' | 'forest' }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 8.8;
  const trunkRadius = opts.trunkRadius ?? 0.25;
  const isHero = (opts.detailLevel ?? 'hero') === 'hero';

  const group = new THREE.Group();
  group.name = `JapaneseRedPine_Akamatsu_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const pinePadBuilder = new GeometryBuilder();

  const leanDir = randRange(rng, 0, Math.PI * 2);
  const lx = Math.cos(leanDir);
  const lz = Math.sin(leanDir);

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(lx * 0.8, height * 0.72, lz * 0.8),
    radiusXZ: height * 0.44,
    minY: height * 0.44,
    maxY: height * 1.05,
  };

  // Iconic dramatic crooked Japanese cliff pine S-curved trunk!
  const trunkPts = [
    new THREE.Vector3(0, -0.1, 0),
    new THREE.Vector3(lx * 0.35, height * 0.22, lz * 0.35),
    new THREE.Vector3(lx * 0.92 - lz * 0.22, height * 0.48, lz * 0.92 + lx * 0.22),
    new THREE.Vector3(lx * 0.62 + lz * 0.32, height * 0.74, lz * 0.62 - lx * 0.32),
    new THREE.Vector3(lx * 0.95, height * 0.95, lz * 0.95),
  ];
  const trunkCurve = new THREE.CatmullRomCurve3(trunkPts);
  appendBranchTube(
    barkBuilder,
    trunkPts,
    trunkRadius,
    trunkRadius * 0.22,
    isHero ? 16 : 11,
    isHero ? 9 : 7,
    0.55,
    true,
    rng() * 6.28
  );
  appendSurfaceRoots(barkBuilder, trunkRadius, isHero ? 5 : 3, rng);

  // Artistic weathered lower dead branch stubs (authentic Akamatsu character!)
  for (let d = 0; d < 3; d++) {
    const dt = randRange(rng, 0.26, 0.44);
    const dp = trunkCurve.getPointAt(dt);
    const da = rng() * Math.PI * 2;
    const dLen = randRange(rng, 0.45, 0.95);
    appendBranchTube(
      barkBuilder,
      [dp, dp.clone().add(new THREE.Vector3(Math.cos(da) * dLen, -0.18, Math.sin(da) * dLen))],
      0.042,
      0.012,
      4,
      4,
      1.0
    );
  }

  // Sculptural gnarled horizontal upper boughs terminating in flat horizontal cloud-like needle pads!
  const boughCount = isHero ? 8 : 6;
  const golden = 2.39996;
  for (let b = 0; b < boughCount; b++) {
    const frac = b / Math.max(1, boughCount - 1);
    const tAttach = 0.48 + frac * 0.48;
    const orig = trunkCurve.getPointAt(tAttach);
    const azim = b * golden + randRange(rng, -0.35, 0.35);
    const dx = Math.cos(azim);
    const dz = Math.sin(azim);
    const reach = (3.4 - frac * 1.45) * randRange(rng, 0.82, 1.18);

    // Gnarled pine limb: dips gracefully slightly downward then sweeps horizontally up at the tip!
    const bp1 = orig.clone();
    const bp2 = orig
      .clone()
      .add(new THREE.Vector3(dx * reach * 0.44, -0.22 * (1 - frac) + 0.08, dz * reach * 0.44));
    const bp3 = orig
      .clone()
      .add(
        new THREE.Vector3(
          dx * reach * 0.78 + randRange(rng, -0.25, 0.25),
          -0.06 + frac * 0.28,
          dz * reach * 0.78 + randRange(rng, -0.25, 0.25)
        )
      );
    const bp4 = orig
      .clone()
      .add(new THREE.Vector3(dx * reach, 0.16 + frac * 0.34, dz * reach));

    const bCurve = new THREE.CatmullRomCurve3([bp1, bp2, bp3, bp4]);
    const r0 = trunkRadius * (0.42 - frac * 0.16);
    appendBranchTube(barkBuilder, [bp1, bp2, bp3, bp4], r0, 0.02, 8, 5, 0.8);

    // Layered cloud needle pads perched horizontally on top of limb ends!
    const bDir = new THREE.Vector3(dx, 0.04, dz).normalize();
    appendNaturalFoliagePad(
      pinePadBuilder,
      pinePadBuilder,
      bp4.clone().add(new THREE.Vector3(0, 0.06, 0)),
      bDir,
      randRange(rng, 0.92, 1.24),
      1.0,
      aoProfile,
      rng,
      'pinePad',
      isHero ? 5 : 4
    );

    // Forked side pad sub-limbs (characteristic tiered pine silhouette!)
    const subPads = isHero ? 3 : 2;
    for (let s = 0; s < subPads; s++) {
      const st = 0.42 + (s / Math.max(1, subPads - 1)) * 0.44;
      const sOrig = bCurve.getPointAt(st);
      const side = s % 2 === 0 ? 1 : -1;
      const sAzim = azim + side * randRange(rng, 0.55, 1.05);
      const sReach = reach * randRange(rng, 0.34, 0.52);
      const spEnd = sOrig
        .clone()
        .add(new THREE.Vector3(Math.cos(sAzim) * sReach, randRange(rng, 0.08, 0.32), Math.sin(sAzim) * sReach));

      appendBranchTube(barkBuilder, [sOrig, spEnd], r0 * 0.45, 0.015, 4, 4, 1.0);
      appendNaturalFoliagePad(
        pinePadBuilder,
        pinePadBuilder,
        spEnd.clone().add(new THREE.Vector3(0, 0.05, 0)),
        new THREE.Vector3(Math.cos(sAzim), 0.03, Math.sin(sAzim)),
        randRange(rng, 0.82, 1.12),
        1.0,
        aoProfile,
        rng,
        'pinePad',
        isHero ? 4 : 3
      );
    }
  }

  // Flat iconic umbrella crown cloud pad at the apex
  const apex = trunkCurve.getPointAt(1.0);
  for (let c = 0; c < 4; c++) {
    const a = (c / 4) * Math.PI * 2 + 0.3;
    const tip = apex.clone().add(new THREE.Vector3(Math.cos(a) * 0.95, 0.34, Math.sin(a) * 0.95));
    appendBranchTube(barkBuilder, [apex, tip], trunkRadius * 0.16, 0.015, 4, 4, 1.0);
    appendNaturalFoliagePad(
      pinePadBuilder,
      pinePadBuilder,
      tip,
      new THREE.Vector3(Math.cos(a), 0.05, Math.sin(a)),
      randRange(rng, 0.96, 1.28),
      1.0,
      aoProfile,
      rng,
      'pinePad',
      isHero ? 5 : 4
    );
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.pineBark);
  barkMesh.name = 'Akamatsu_RedPine_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, pinePadBuilder, materials.pineNeedles, 'Akamatsu_Needle_CloudPads');
  return group;
}

/* ============================================================================
 * 5. NEW TOUGE TREE #4: JAPANESE WHITE BIRCH (SHIRAKABA / Betula platyphylla)
 * Striking papery white lenticel bark + slender ascending limbs & weeping feathery foliage!
 * ============================================================================ */
export function createJapaneseBirchTree(
  materials: StudioMaterialLibrary,
  opts: { seed: number; height?: number; trunkRadius?: number; twinStem?: boolean; detailLevel?: 'hero' | 'forest' }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 9.4;
  const trunkRadius = opts.trunkRadius ?? 0.16;
  const isHero = (opts.detailLevel ?? 'hero') === 'hero';
  const twinStem = opts.twinStem ?? rng() > 0.42;

  const group = new THREE.Group();
  group.name = `JapaneseBirch_Shirakaba_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const birchLeafBuilder = new GeometryBuilder();
  const shadeLeafBuilder = new GeometryBuilder();

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(0, height * 0.62, 0),
    radiusXZ: 2.9,
    minY: height * 0.3,
    maxY: height * 1.04,
  };

  const buildSingleBirchStem = (
    stemScale: number,
    leanAngle: number,
    leanAmount: number,
    seedOff: number
  ) => {
    const h = height * stemScale;
    const rBase = trunkRadius * stemScale;
    const lx = Math.cos(leanAngle) * leanAmount;
    const lz = Math.sin(leanAngle) * leanAmount;

    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 6; i++) {
      const t = i / 6;
      pts.push(
        new THREE.Vector3(
          lx * Math.pow(t, 1.25) + Math.sin(t * 3.4 + seedOff) * 0.12 * t,
          t * h * 0.94,
          lz * Math.pow(t, 1.25) + Math.cos(t * 3.0 + seedOff) * 0.12 * t
        )
      );
    }
    const stemCurve = new THREE.CatmullRomCurve3(pts);
    appendBranchTube(
      barkBuilder,
      pts,
      rBase,
      rBase * 0.14,
      isHero ? 14 : 9,
      isHero ? 8 : 6,
      0.65,
      true,
      rng() * 6.28
    );

    // Delicate ascending branches that arch gracefully outward & droop pendulously at the ends!
    const bCount = isHero ? 13 : 9;
    const golden = 2.39996;
    for (let b = 0; b < bCount; b++) {
      const frac = b / Math.max(1, bCount - 1);
      const tAttach = 0.34 + frac * 0.62;
      const orig = stemCurve.getPointAt(tAttach);
      const azim = b * golden + randRange(rng, -0.35, 0.35);
      const dx = Math.cos(azim);
      const dz = Math.sin(azim);
      const reach = (2.35 - frac * 1.15) * stemScale * randRange(rng, 0.8, 1.18);

      // Graceful upward departure, then soft pendulous weeping arc downward at twig end!
      const p1 = orig.clone();
      const p2 = orig
        .clone()
        .add(new THREE.Vector3(dx * reach * 0.45, 0.55 * (1 - frac * 0.35), dz * reach * 0.45));
      const p3 = orig
        .clone()
        .add(new THREE.Vector3(dx * reach * 0.86, 0.48 - 0.18 * (1 - frac), dz * reach * 0.86));
      const p4 = orig
        .clone()
        .add(new THREE.Vector3(dx * reach * 1.06, -0.05 + frac * 0.25, dz * reach * 1.06));

      const bCurve = new THREE.CatmullRomCurve3([p1, p2, p3, p4]);
      const br = Math.max(0.015, rBase * (0.34 - frac * 0.14));
      appendBranchTube(barkBuilder, [p1, p2, p3, p4], br, 0.008, 6, 4, 1.0);

      // Airy weeping birch leaf curtains draping along the arching outer half of each branch!
      const spots = [0.52, 0.78, 1.0];
      spots.forEach((st, idx) => {
        const sp = bCurve.getPointAt(st);
        const sideDir = new THREE.Vector3(
          dx + randRange(rng, -0.35, 0.35),
          -0.25,
          dz + randRange(rng, -0.35, 0.35)
        ).normalize();
        appendNaturalFoliagePad(
          birchLeafBuilder,
          shadeLeafBuilder,
          sp,
          sideDir,
          randRange(rng, 0.62, 0.88) * (1.05 - frac * 0.22),
          0.72 + frac * 0.22,
          aoProfile,
          rng,
          'weeping',
          isHero ? (idx === 2 ? 4 : 3) : 2
        );
      });
    }

    // Feathery airy apex tuft
    const top = stemCurve.getPointAt(1.0);
    appendNaturalFoliagePad(
      birchLeafBuilder,
      shadeLeafBuilder,
      top,
      new THREE.Vector3(lx, 0.05, lz).normalize(),
      0.86 * stemScale,
      0.9,
      aoProfile,
      rng,
      'dome',
      isHero ? 4 : 3
    );
  };

  const mainAngle = rng() * Math.PI * 2;
  buildSingleBirchStem(1.0, mainAngle, twinStem ? 0.62 : 0.28, opts.seed);
  if (twinStem) {
    // Classic Japanese highland Shirakaba twin-trunk clump curving gently apart!
    buildSingleBirchStem(0.84, mainAngle + Math.PI + randRange(rng, -0.45, 0.45), 0.75, opts.seed + 53);
  }
  appendSurfaceRoots(barkBuilder, trunkRadius * 1.15, isHero ? 5 : 3, rng);

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.birchBark);
  barkMesh.name = 'Shirakaba_WhiteBirch_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, birchLeafBuilder, materials.birchLeaf, 'Shirakaba_Weeping_Foliage');
  attachFoliageMesh(group, shadeLeafBuilder, materials.treeCanopyDeep, 'Shirakaba_Inner_Shade');
  return group;
}

/* ============================================================================
 * 6. TALL JAPANESE MOUNTAIN CEDAR (SUGI / Cryptomeria japonica) — Fixed Fronds!
 * ============================================================================ */
export function createJapaneseCedarTree(
  materials: StudioMaterialLibrary,
  opts: {
    seed: number;
    height?: number;
    trunkRadius?: number;
    detailLevel?: 'hero' | 'forest';
  }
): THREE.Group {
  const rng = createRng(opts.seed);
  const height = opts.height ?? 13.5;
  const trunkRadius = opts.trunkRadius ?? 0.22;
  const isHero = (opts.detailLevel ?? 'forest') === 'hero';

  const group = new THREE.Group();
  group.name = `JapaneseCedar_Sugi_${opts.seed}`;

  const barkBuilder = new GeometryBuilder();
  const frondBuilder = new GeometryBuilder();

  const leanX = randRange(rng, -0.32, 0.32);
  const leanZ = randRange(rng, -0.32, 0.32);

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(leanX * 0.6, height * 0.7, leanZ * 0.6),
    radiusXZ: height * 0.24,
    minY: height * 0.4,
    maxY: height * 1.02,
  };

  const trunkPts: THREE.Vector3[] = [];
  for (let i = 0; i <= 6; i++) {
    const t = i / 6;
    trunkPts.push(
      new THREE.Vector3(
        leanX * t + Math.sin(t * 4.2 + opts.seed) * 0.08,
        t * height,
        leanZ * t + Math.cos(t * 3.8 + opts.seed) * 0.08
      )
    );
  }
  const trunkCurve = new THREE.CatmullRomCurve3(trunkPts);
  appendBranchTube(
    barkBuilder,
    trunkPts,
    trunkRadius,
    trunkRadius * 0.08,
    isHero ? 14 : 9,
    isHero ? 8 : 6,
    0.55,
    true,
    rng() * 6.28
  );
  appendSurfaceRoots(barkBuilder, trunkRadius, isHero ? 5 : 3, rng);

  // Authentic weathered dead lower branch stubs along dark lower trunk
  const stubCount = isHero ? 7 : 4;
  for (let s = 0; s < stubCount; s++) {
    const t = randRange(rng, 0.16, 0.45);
    const p = trunkCurve.getPointAt(t);
    const ang = rng() * Math.PI * 2;
    const len = randRange(rng, 0.35, 0.85);
    appendBranchTube(
      barkBuilder,
      [p, p.clone().add(new THREE.Vector3(Math.cos(ang) * len, -0.18, Math.sin(ang) * len))],
      0.032,
      0.008,
      3,
      4,
      1.0
    );
  }

  // Conical layered evergreen whorls with naturally horizontal-sweeping drooping conifer fronds!
  const whorlCount = isHero ? 17 : 12;
  const golden = 2.39996;
  for (let w = 0; w < whorlCount; w++) {
    const frac = w / (whorlCount - 1);
    const t = 0.44 + frac * 0.54;
    const origin = trunkCurve.getPointAt(t);
    const branchesInWhorl = frac > 0.82 ? 3 : 4;
    const maxReach = (1.0 - frac * 0.74) * (height * 0.22);

    for (let k = 0; k < branchesInWhorl; k++) {
      const ang = w * golden + (k / branchesInWhorl) * Math.PI * 2 + randRange(rng, -0.24, 0.24);
      const dx = Math.cos(ang);
      const dz = Math.sin(ang);
      const reach = maxReach * randRange(rng, 0.8, 1.16);
      const droop = -reach * (0.24 - frac * 0.16);

      const bp1 = origin.clone();
      const bp2 = origin.clone().add(new THREE.Vector3(dx * reach * 0.54, droop * 0.72, dz * reach * 0.54));
      const bp3 = origin.clone().add(new THREE.Vector3(dx * reach, droop * 0.42 + 0.14, dz * reach));

      appendBranchTube(barkBuilder, [bp1, bp2, bp3], 0.044 * (1 - frac * 0.52), 0.01, 4, 4, 1.0);

      const bDir = new THREE.Vector3(dx, -0.12 + frac * 0.2, dz).normalize();
      const sz = (1.08 - frac * 0.44) * randRange(rng, 0.88, 1.18);

      appendNaturalFoliagePad(
        frondBuilder,
        frondBuilder,
        bp2,
        bDir,
        sz * 0.88,
        1.0,
        aoProfile,
        rng,
        'layered',
        isHero ? 3 : 2
      );
      appendNaturalFoliagePad(
        frondBuilder,
        frondBuilder,
        bp3,
        bDir,
        sz,
        1.0,
        aoProfile,
        rng,
        'layered',
        isHero ? 3 : 2
      );
    }
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.cedarBark);
  barkMesh.name = 'Sugi_Cedar_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, frondBuilder, materials.treeCedarFrond, 'Sugi_Conifer_Foliage');
  return group;
}

/* ============================================================================
 * 7. OVERHANGING ROADSIDE TOUGE BOUGH (Upper-Right Signature Framing Tree!)
 * ============================================================================ */
export function createOverhangTree(
  materials: StudioMaterialLibrary,
  seed: number
): THREE.Group {
  const rng = createRng(seed);
  const group = new THREE.Group();
  group.name = `OverhangFramingTree_${seed}`;

  const barkBuilder = new GeometryBuilder();
  const brightBuilder = new GeometryBuilder();
  const deepBuilder = new GeometryBuilder();

  const aoProfile: CrownAOProfile = {
    center: new THREE.Vector3(-3.4, 5.8, 0.25),
    radiusXZ: 4.5,
    minY: 3.4,
    maxY: 8.6,
  };

  // Sturdy leaning mountain-slope trunk arching dramatically across the upper-right roadside!
  const mainPts = [
    new THREE.Vector3(0, -0.2, 0),
    new THREE.Vector3(-0.4, 2.2, 0.15),
    new THREE.Vector3(-1.45, 4.4, 0.42),
    new THREE.Vector3(-3.2, 6.2, 0.56),
    new THREE.Vector3(-5.25, 7.15, 0.32),
    new THREE.Vector3(-6.9, 7.5, -0.14),
  ];
  const curve = new THREE.CatmullRomCurve3(mainPts);
  appendBranchTube(barkBuilder, mainPts, 0.24, 0.03, 16, 8, 0.6, true, 1.2);
  appendSurfaceRoots(barkBuilder, 0.24, 4, rng);

  // Delicate gravity-draped horizontal overhanging branchlets & naturally fanning leaf sprays
  for (let i = 0; i < 10; i++) {
    const t = 0.34 + (i / 9) * 0.64;
    const p = curve.getPointAt(t);
    const side = i % 2 === 0 ? 1 : -1;
    const dir = new THREE.Vector3(
      randRange(rng, -1.15, -0.35),
      randRange(rng, -0.14, 0.22),
      side * randRange(rng, 0.52, 1.28)
    ).normalize();
    const len = randRange(rng, 1.5, 3.0) * (1.14 - t * 0.34);

    const b1 = p.clone();
    const b2 = p.clone().addScaledVector(dir, len * 0.54).add(new THREE.Vector3(0, 0.14, 0));
    const b3 = p.clone().addScaledVector(dir, len).add(new THREE.Vector3(0, -0.14, 0));

    appendBranchTube(barkBuilder, [b1, b2, b3], 0.066 * (1 - t * 0.45), 0.01, 6, 5, 0.9);

    appendNaturalFoliagePad(
      brightBuilder,
      deepBuilder,
      b2,
      dir,
      randRange(rng, 0.72, 0.98),
      0.56,
      aoProfile,
      rng,
      'layered',
      3
    );
    appendNaturalFoliagePad(
      brightBuilder,
      deepBuilder,
      b3,
      dir,
      randRange(rng, 0.82, 1.12),
      0.74,
      aoProfile,
      rng,
      'layered',
      4
    );
  }

  const barkMesh = new THREE.Mesh(barkBuilder.toBufferGeometry(false), materials.hardwoodBark);
  barkMesh.name = 'Overhang_Bark';
  barkMesh.castShadow = true;
  barkMesh.receiveShadow = true;
  group.add(barkMesh);

  attachFoliageMesh(group, brightBuilder, materials.treeCanopyBright, 'Overhang_Foliage_Bright');
  attachFoliageMesh(group, deepBuilder, materials.treeCanopyDeep, 'Overhang_Foliage_Deep');
  return group;
}
