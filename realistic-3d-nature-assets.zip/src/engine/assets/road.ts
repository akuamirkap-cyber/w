import * as THREE from 'three';
import { StudioMaterialLibrary } from '../materials';
import { createRng, fbm2D, randRange } from '../noise';
import {
  CURB_WIDTH,
  ROAD_HALF_WIDTH,
  ROAD_MAX_X,
  ROAD_MIN_X,
  roadCenterDZDX,
  roadCenterZ,
  roadOffsetPoint,
  roadSurfaceElevation,
} from '../roadMath';

/**
 * Helper to create a small curled 3D dry leaf card for wind-blown road edge scatter
 */
function createStrayRoadLeafGeometry(): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(0.11, 0.064, 3, 2);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) / 0.055;
    const z = pos.getZ(i) / 0.032;
    pos.setY(i, (z * z) * 0.013 + (x * x) * 0.009 + 0.004);
  }
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds the continuous high-density curving Japanese mountain asphalt ribbon mesh
 * with world-scale aggregate UVs + `aRoadCoord` (cross-road 0..1 & arc length meters).
 */
function buildCurvedAsphaltGeometry(
  minX: number,
  maxX: number,
  lengthSegs: number,
  widthSegs: number,
  halfWidth: number
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const roadCoords: number[] = [];
  const indices: number[] = [];

  const spinePoints: Array<{
    x: number;
    z: number;
    nx: number;
    nz: number;
    arcLen: number;
  }> = [];

  let accumLen = 0;
  let prevX = 0;
  let prevZ = 0;

  for (let i = 0; i <= lengthSegs; i++) {
    const t = i / lengthSegs;
    const x = THREE.MathUtils.lerp(minX, maxX, t);
    const z = roadCenterZ(x);
    const df = roadCenterDZDX(x);
    const invLen = 1 / Math.sqrt(1 + df * df);
    const nx = -df * invLen; // points toward inner foreground bank (+z)
    const nz = invLen;

    if (i > 0) {
      accumLen += Math.hypot(x - prevX, z - prevZ);
    }
    prevX = x;
    prevZ = z;
    spinePoints.push({ x, z, nx, nz, arcLen: accumLen });
  }

  const skirtPad = 0.14;
  const totalHalf = halfWidth + skirtPad;
  const tileScale = 0.52;

  for (let i = 0; i <= lengthSegs; i++) {
    const sp = spinePoints[i];
    for (let j = 0; j <= widthSegs; j++) {
      const uRaw = j / widthSegs; // 0 = outer forest side, 1 = inner curb side
      const s = THREE.MathUtils.lerp(-totalHalf, totalHalf, uRaw);

      const px = sp.x + sp.nx * s;
      const pz = sp.z + sp.nz * s;

      const roadRipples = (fbm2D(px * 0.28 + 1.5, pz * 0.28 + 3.2, 2, 2.0, 0.5, 707) - 0.5) * 0.032;

      let edgeDrop = 0;
      if (Math.abs(s) > halfWidth) {
        const over = (Math.abs(s) - halfWidth) / skirtPad;
        edgeDrop = -over * over * 0.055;
      }

      const py = roadSurfaceElevation(sp.x, s) + roadRipples + edgeDrop;

      positions.push(px, py, pz);
      uvs.push((s + totalHalf) * tileScale, sp.arcLen * tileScale);
      const uNormalized = Math.max(0, Math.min(1, (s + halfWidth) / (2 * halfWidth)));
      roadCoords.push(uNormalized, sp.arcLen);
    }
  }

  const stride = widthSegs + 1;
  for (let i = 0; i < lengthSegs; i++) {
    for (let j = 0; j < widthSegs; j++) {
      const a = i * stride + j;
      const b = (i + 1) * stride + j;
      const c = (i + 1) * stride + (j + 1);
      const d = i * stride + (j + 1);
      indices.push(a, d, b, b, d, c);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute('aRoadCoord', new THREE.Float32BufferAttribute(roadCoords, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds the weathered concrete inner drainage curb hugging the inner curve between
 * the asphalt road and the foreground brown leaf-litter embankment!
 */
function buildConcreteInnerCurbGeometry(
  minX: number,
  maxX: number,
  lengthSegs: number,
  halfWidth: number,
  curbWidth: number
): THREE.BufferGeometry {
  const profile: Array<[number, number]> = [
    [-0.08, -0.055],
    [-0.02, 0.008],
    [0.08, 0.028],
    [curbWidth * 0.58, 0.042],
    [curbWidth * 0.96, 0.022],
    [curbWidth + 0.12, -0.09],
  ];
  const profLen = profile.length;

  const positions: number[] = [];
  const uvs: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];

  let arcLen = 0;
  let prevX = 0;
  let prevZ = 0;
  const col = new THREE.Color();

  for (let i = 0; i <= lengthSegs; i++) {
    const t = i / lengthSegs;
    const x = THREE.MathUtils.lerp(minX, maxX, t);
    const z = roadCenterZ(x);
    const df = roadCenterDZDX(x);
    const invLen = 1 / Math.sqrt(1 + df * df);
    const nx = -df * invLen;
    const nz = invLen;

    if (i > 0) arcLen += Math.hypot(x - prevX, z - prevZ);
    prevX = x;
    prevZ = z;

    const slabPhase = (arcLen % 1.45) / 1.45;
    const isJoint = slabPhase < 0.026 || slabPhase > 0.974;
    const jointDrop = isJoint ? -0.011 : 0;

    const mossNoise = fbm2D(x * 0.65 + 4.1, z * 0.65 + 2.7, 3, 2.0, 0.5, 521);

    for (let p = 0; p < profLen; p++) {
      const [localS, localY] = profile[p];
      const s = halfWidth + localS;
      const px = x + nx * s;
      const pz = z + nz * s;
      const baseY = roadSurfaceElevation(x, halfWidth);
      const chip = (fbm2D(px * 2.4, pz * 2.4, 2, 2.0, 0.5, 613) - 0.5) * 0.014;
      const py = baseY + localY + jointDrop + chip;

      positions.push(px, py, pz);
      uvs.push(p / (profLen - 1), arcLen * 0.65);

      const outerSoilTint = p >= 4 ? 0.68 : p === 3 ? 0.96 : 0.85;
      const jointShade = isJoint ? 0.48 : 1.0;
      const r = (0.94 + mossNoise * 0.14) * outerSoilTint * jointShade;
      const g = (0.95 + mossNoise * 0.16) * outerSoilTint * jointShade;
      const b = (0.88 + mossNoise * 0.08) * outerSoilTint * jointShade;
      col.setRGB(r, g, b);
      colors.push(col.r, col.g, col.b);
    }
  }

  for (let i = 0; i < lengthSegs; i++) {
    for (let p = 0; p < profLen - 1; p++) {
      const a = i * profLen + p;
      const b = (i + 1) * profLen + p;
      const c = (i + 1) * profLen + (p + 1);
      const d = i * profLen + (p + 1);
      indices.push(a, d, b, b, d, c);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * 1. FULL 62-METER (2X LONGER!) CURVING TOUGE MOUNTAIN ASPHALT ROAD + CONCRETE CURB
 */
export function createTougeAsphaltRoad(materials: StudioMaterialLibrary): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Touge_Mountain_Asphalt_Road_62m';

  const asphaltGeo = buildCurvedAsphaltGeometry(
    ROAD_MIN_X,
    ROAD_MAX_X,
    260,
    22,
    ROAD_HALF_WIDTH
  );
  const asphaltMesh = new THREE.Mesh(asphaltGeo, materials.tougeAsphalt);
  asphaltMesh.name = 'Touge_Asphalt_Surface';
  asphaltMesh.receiveShadow = true;
  group.add(asphaltMesh);

  const curbGeo = buildConcreteInnerCurbGeometry(
    ROAD_MIN_X,
    ROAD_MAX_X,
    280,
    ROAD_HALF_WIDTH,
    CURB_WIDTH
  );
  const curbMesh = new THREE.Mesh(curbGeo, materials.weatheredCurb);
  curbMesh.name = 'Weathered_Concrete_Drainage_Curb';
  curbMesh.castShadow = true;
  curbMesh.receiveShadow = true;
  group.add(curbMesh);

  // 840 wind-blown dry fallen leaves scattered along BOTH asphalt shoulders across the 62m pass!
  const rng = createRng(7744);
  const leafCount = 840;
  const leafGeo = createStrayRoadLeafGeometry();
  const leafInst = new THREE.InstancedMesh(leafGeo, materials.dryLeafScatter, leafCount);
  leafInst.name = 'Road_Shoulder_Windblown_Leaves';
  leafInst.receiveShadow = true;

  const dummy = new THREE.Object3D();
  const col = new THREE.Color();
  const leafPalette = ['#cbb188', '#a17344', '#855830', '#d6c19b', '#6d4726', '#947349'];

  for (let i = 0; i < leafCount; i++) {
    const rx = randRange(rng, ROAD_MIN_X + 1.5, ROAD_MAX_X - 1.5);
    const innerSide = rng() < 0.65;
    const edgePenetration = Math.pow(rng(), 2.2) * 1.18;
    const offset = innerSide
      ? ROAD_HALF_WIDTH + CURB_WIDTH * 0.55 - edgePenetration
      : -ROAD_HALF_WIDTH - 0.12 + edgePenetration;

    const pt = roadOffsetPoint(rx, offset);
    const curbLift = innerSide && offset > ROAD_HALF_WIDTH - 0.02 ? 0.036 : 0.008;

    dummy.position.set(pt.x, pt.y + curbLift, pt.z);
    dummy.rotation.set(
      randRange(rng, -0.14, 0.14),
      rng() * Math.PI * 2,
      randRange(rng, -0.14, 0.14)
    );
    const s = randRange(rng, 0.72, 1.45);
    dummy.scale.set(s, s, s);
    dummy.updateMatrix();
    leafInst.setMatrixAt(i, dummy.matrix);

    col.set(leafPalette[Math.floor(rng() * leafPalette.length)]);
    leafInst.setColorAt(i, col);
  }
  leafInst.instanceMatrix.needsUpdate = true;
  if (leafInst.instanceColor) leafInst.instanceColor.needsUpdate = true;
  group.add(leafInst);

  return group;
}

/**
 * 2. ISOLATED 2X LONGER (11.4m!) SWEEPING TOUGE ASPHALT ROAD & CONCRETE CURB SHOWCASE ASSET
 * Curved S-bend touge road section with curved architectural cutaway base, expansion-joint curb,
 * forest leaf-litter verge, mossy edge stones, twigs & 580+ wind-blown fallen leaves!
 */
export function createIsolatedAsphaltAsset(materials: StudioMaterialLibrary): THREE.Group {
  const group = new THREE.Group();
  group.name = 'Touge_Asphalt_Road_Asset_2x_Long';

  const lenX = 11.4; // >2x longer than original 5.4m slab!
  const halfLen = lenX * 0.5;
  const roadHalfW = 1.95; // 3.9m wide showcase lane ribbon
  const curbW = 0.42;
  const vergeW = 1.35; // sculpted brown leaf-litter shoulder embankment
  const segX = 112;
  const segZ = 24;

  // Sweeping S-bend showcase centerline z(x) & elevation y(x)
  const curveZ = (x: number) => 0.92 * Math.sin(x * 0.34) - 0.018 * x * x;
  const curveDZ = (x: number) => 0.92 * 0.34 * Math.cos(x * 0.34) - 0.036 * x;
  const curveElev = (x: number) => 0.20 + 0.08 * Math.sin(x * 0.28);

  // Precompute spine frames & arc length
  const spine: Array<{ x: number; z: number; nx: number; nz: number; y: number; arc: number }> = [];
  let arcAccum = 0;
  let pxPrev = 0;
  let pzPrev = 0;
  for (let i = 0; i <= segX; i++) {
    const x = THREE.MathUtils.lerp(-halfLen, halfLen, i / segX);
    const z = curveZ(x);
    const df = curveDZ(x);
    const inv = 1 / Math.sqrt(1 + df * df);
    const nx = -df * inv;
    const nz = inv;
    if (i > 0) arcAccum += Math.hypot(x - pxPrev, z - pzPrev);
    pxPrev = x;
    pzPrev = z;
    spine.push({ x, z, nx, nz, y: curveElev(x), arc: arcAccum });
  }

  // 1. Curved Asphalt Ribbon Surface
  const aPos: number[] = [];
  const aUv: number[] = [];
  const aRoad: number[] = [];
  const aIdx: number[] = [];

  for (let i = 0; i <= segX; i++) {
    const sp = spine[i];
    for (let j = 0; j <= segZ; j++) {
      const tz = j / segZ; // 0 = outer edge, 1 = inner curb edge
      const s = THREE.MathUtils.lerp(-roadHalfW, roadHalfW, tz);
      const px = sp.x + sp.nx * s;
      const pz = sp.z + sp.nz * s;
      const crown = 0.038 * Math.sin(tz * Math.PI);
      const ripple = (fbm2D(px * 0.4, pz * 0.4, 2, 2.0, 0.5, 311) - 0.5) * 0.018;
      const py = sp.y + crown + ripple;

      aPos.push(px, py, pz);
      aUv.push((s + roadHalfW) * 0.55, sp.arc * 0.55);
      aRoad.push(tz, sp.arc + 4.0);
    }
  }
  const aStride = segZ + 1;
  for (let i = 0; i < segX; i++) {
    for (let j = 0; j < segZ; j++) {
      const a = i * aStride + j;
      const b = (i + 1) * aStride + j;
      const c = (i + 1) * aStride + (j + 1);
      const d = i * aStride + (j + 1);
      aIdx.push(a, d, b, b, d, c);
    }
  }
  const asphaltGeo = new THREE.BufferGeometry();
  asphaltGeo.setAttribute('position', new THREE.Float32BufferAttribute(aPos, 3));
  asphaltGeo.setAttribute('uv', new THREE.Float32BufferAttribute(aUv, 2));
  asphaltGeo.setAttribute('aRoadCoord', new THREE.Float32BufferAttribute(aRoad, 2));
  asphaltGeo.setIndex(aIdx);
  asphaltGeo.computeVertexNormals();

  const asphaltMesh = new THREE.Mesh(asphaltGeo, materials.tougeAsphalt);
  asphaltMesh.name = 'Asphalt_2x_Surface_Showcase';
  asphaltMesh.castShadow = true;
  asphaltMesh.receiveShadow = true;
  group.add(asphaltMesh);

  // 2. Curved Beveled Concrete Kerb Block with Expansion Slab Joints
  const kProf: Array<[number, number]> = [
    [-0.03, -0.02],
    [0.02, 0.018],
    [curbW * 0.55, 0.038],
    [curbW, 0.022],
    [curbW + 0.06, -0.04],
  ];
  const kLen = kProf.length;
  const kPos: number[] = [];
  const kUv: number[] = [];
  const kCol: number[] = [];
  const kIdx: number[] = [];
  const tmpCol = new THREE.Color();

  for (let i = 0; i <= segX; i++) {
    const sp = spine[i];
    const slab = (sp.arc % 1.45) / 1.45;
    const isJoint = slab < 0.03 || slab > 0.97;
    const jDrop = isJoint ? -0.011 : 0;

    for (let p = 0; p < kLen; p++) {
      const [ls, ly] = kProf[p];
      const s = roadHalfW + ls;
      const px = sp.x + sp.nx * s;
      const pz = sp.z + sp.nz * s;
      kPos.push(px, sp.y + ly + jDrop, pz);
      kUv.push(p / (kLen - 1), sp.arc * 0.65);

      const shade = (isJoint ? 0.5 : 1.0) * (p === 2 ? 0.97 : 0.84);
      tmpCol.setRGB(shade, shade * 1.01, shade * 0.94);
      kCol.push(tmpCol.r, tmpCol.g, tmpCol.b);
    }
  }
  for (let i = 0; i < segX; i++) {
    for (let p = 0; p < kLen - 1; p++) {
      const a = i * kLen + p;
      const b = (i + 1) * kLen + p;
      const c = (i + 1) * kLen + (p + 1);
      const d = i * kLen + (p + 1);
      kIdx.push(a, d, b, b, d, c);
    }
  }
  const kerbGeo = new THREE.BufferGeometry();
  kerbGeo.setAttribute('position', new THREE.Float32BufferAttribute(kPos, 3));
  kerbGeo.setAttribute('uv', new THREE.Float32BufferAttribute(kUv, 2));
  kerbGeo.setAttribute('color', new THREE.Float32BufferAttribute(kCol, 3));
  kerbGeo.setIndex(kIdx);
  kerbGeo.computeVertexNormals();

  const kerbMesh = new THREE.Mesh(kerbGeo, materials.weatheredCurb);
  kerbMesh.name = 'Showcase_Concrete_Curb_2x';
  kerbMesh.castShadow = true;
  kerbMesh.receiveShadow = true;
  group.add(kerbMesh);

  // 3. Curved Sculpted Forest Leaf-Litter Shoulder Verge bordering the inner curb
  const vSegZ = 12;
  const vPos: number[] = [];
  const vUv: number[] = [];
  const vCol: number[] = [];
  const vIdx: number[] = [];

  for (let i = 0; i <= segX; i++) {
    const sp = spine[i];
    for (let j = 0; j <= vSegZ; j++) {
      const tv = j / vSegZ;
      const s = roadHalfW + curbW + tv * vergeW;
      const px = sp.x + sp.nx * s;
      const pz = sp.z + sp.nz * s;
      const bankRise = Math.pow(tv, 0.85) * 0.34;
      const bump = (fbm2D(px * 1.25, pz * 1.25, 3, 2.0, 0.5, 442) - 0.5) * 0.08 * tv;
      const py = sp.y + 0.015 + bankRise + bump;

      vPos.push(px, py, pz);
      vUv.push(tv * 0.72, sp.arc * 0.5);
      vCol.push(0.96, 0.92, 0.85);
    }
  }
  const vStride = vSegZ + 1;
  for (let i = 0; i < segX; i++) {
    for (let j = 0; j < vSegZ; j++) {
      const a = i * vStride + j;
      const b = (i + 1) * vStride + j;
      const c = (i + 1) * vStride + (j + 1);
      const d = i * vStride + (j + 1);
      vIdx.push(a, d, b, b, d, c);
    }
  }
  const vergeGeo = new THREE.BufferGeometry();
  vergeGeo.setAttribute('position', new THREE.Float32BufferAttribute(vPos, 3));
  vergeGeo.setAttribute('uv', new THREE.Float32BufferAttribute(vUv, 2));
  vergeGeo.setAttribute('color', new THREE.Float32BufferAttribute(vCol, 3));
  vergeGeo.setIndex(vIdx);
  vergeGeo.computeVertexNormals();

  const vergeMesh = new THREE.Mesh(vergeGeo, materials.forestFloor);
  vergeMesh.name = 'Roadside_Forest_Verge_2x';
  vergeMesh.castShadow = true;
  vergeMesh.receiveShadow = true;
  group.add(vergeMesh);

  // 4. Curved Geological Sub-Base Cutaway Skirt wrapping cleanly around the entire 11.4m S-curve!
  const baseBottomY = -0.24;
  const skirtPos: number[] = [];
  const skirtUv: number[] = [];
  const skirtIdx: number[] = [];
  let svOff = 0;

  const appendCurvedSkirt = (sideS: number, getTopY: (sp: typeof spine[0]) => number, flip: boolean) => {
    for (let i = 0; i <= segX; i++) {
      const sp = spine[i];
      const px = sp.x + sp.nx * sideS;
      const pz = sp.z + sp.nz * sideS;
      const ty = getTopY(sp);
      skirtPos.push(px, ty, pz, px, baseBottomY, pz);
      skirtUv.push(sp.arc * 0.5, 1, sp.arc * 0.5, 0);
      if (i < segX) {
        const a = svOff + i * 2;
        const b = a + 1;
        const c = a + 2;
        const d = a + 3;
        if (flip) {
          skirtIdx.push(a, c, b, b, c, d);
        } else {
          skirtIdx.push(a, b, c, b, d, c);
        }
      }
    }
    svOff += (segX + 1) * 2;
  };

  // Outer asphalt left/back wall
  appendCurvedSkirt(-roadHalfW, (sp) => sp.y, true);
  // Inner verge front wall
  appendCurvedSkirt(roadHalfW + curbW + vergeW, (sp) => sp.y + 0.355, false);

  // End-cap vertical walls at start (i=0) and finish (i=segX)
  const addEndCap = (sp: typeof spine[0], flip: boolean) => {
    const capSteps = 12;
    for (let k = 0; k <= capSteps; k++) {
      const tk = k / capSteps;
      const s = THREE.MathUtils.lerp(-roadHalfW, roadHalfW + curbW + vergeW, tk);
      const px = sp.x + sp.nx * s;
      const pz = sp.z + sp.nz * s;
      const ty =
        s <= roadHalfW
          ? sp.y + 0.03 * Math.sin(((s + roadHalfW) / (2 * roadHalfW)) * Math.PI)
          : s <= roadHalfW + curbW
            ? sp.y + 0.035
            : sp.y + 0.015 + Math.pow((s - roadHalfW - curbW) / vergeW, 0.85) * 0.34;
      skirtPos.push(px, ty, pz, px, baseBottomY, pz);
      skirtUv.push(tk * 2, 1, tk * 2, 0);
      if (k < capSteps) {
        const a = svOff + k * 2;
        const b = a + 1;
        const c = a + 2;
        const d = a + 3;
        if (flip) {
          skirtIdx.push(a, c, b, b, c, d);
        } else {
          skirtIdx.push(a, b, c, b, d, c);
        }
      }
    }
    svOff += (capSteps + 1) * 2;
  };
  addEndCap(spine[0], false);
  addEndCap(spine[segX], true);

  const skirtGeo = new THREE.BufferGeometry();
  skirtGeo.setAttribute('position', new THREE.Float32BufferAttribute(skirtPos, 3));
  skirtGeo.setAttribute('uv', new THREE.Float32BufferAttribute(skirtUv, 2));
  skirtGeo.setIndex(skirtIdx);
  skirtGeo.computeVertexNormals();

  const skirtMesh = new THREE.Mesh(skirtGeo, materials.soilCutaway);
  skirtMesh.name = 'Roadbed_Curved_Cutaway_Profile';
  skirtMesh.castShadow = true;
  skirtMesh.receiveShadow = true;
  group.add(skirtMesh);

  // 5. 580+ 3D Fallen Dry Leaves spilling from the leaf verge across the curb onto tarmac!
  const rng = createRng(9981);
  const strayCount = 580;
  const leafInst = new THREE.InstancedMesh(
    createStrayRoadLeafGeometry(),
    materials.dryLeafScatter,
    strayCount
  );
  leafInst.name = 'Showcase_Spilled_Road_Leaves_2x';
  leafInst.receiveShadow = true;

  const dummy = new THREE.Object3D();
  const pal = ['#cbb188', '#a17344', '#855830', '#d8c39d', '#6e4928'];
  for (let i = 0; i < strayCount; i++) {
    const spIdx = Math.floor(rng() * segX);
    const sp = spine[spIdx];
    const onVerge = rng() < 0.7;
    const s = onVerge
      ? roadHalfW + curbW + randRange(rng, 0.04, vergeW - 0.08)
      : roadHalfW + curbW * 0.5 - Math.pow(rng(), 2.0) * 1.1;
    const px = sp.x + sp.nx * s;
    const pz = sp.z + sp.nz * s;
    const py = onVerge
      ? sp.y + 0.025 + Math.pow((s - roadHalfW - curbW) / vergeW, 0.85) * 0.34
      : sp.y + (s > roadHalfW ? 0.042 : 0.015);

    dummy.position.set(px, py, pz);
    dummy.rotation.set(randRange(rng, -0.2, 0.2), rng() * Math.PI * 2, randRange(rng, -0.2, 0.2));
    const sc = randRange(rng, 0.72, 1.48);
    dummy.scale.set(sc, sc, sc);
    dummy.updateMatrix();
    leafInst.setMatrixAt(i, dummy.matrix);

    tmpCol.set(pal[Math.floor(rng() * pal.length)]);
    leafInst.setColorAt(i, tmpCol);
  }
  leafInst.instanceMatrix.needsUpdate = true;
  if (leafInst.instanceColor) leafInst.instanceColor.needsUpdate = true;
  group.add(leafInst);

  return group;
}
