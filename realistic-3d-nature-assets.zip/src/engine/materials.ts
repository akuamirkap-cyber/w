import * as THREE from 'three';
import { PBRTextureSet, StudioTextureLibrary } from './textures';

export interface ForestShaderUniforms {
  uTime: { value: number };
  uWindStrength: { value: number };
  uSunDirection: { value: THREE.Vector3 };
  uSunColor: { value: THREE.Color };
  uTranslucency: { value: number };
}

export interface StudioMaterialLibrary {
  uniforms: ForestShaderUniforms;
  forestFloor: THREE.MeshStandardMaterial;
  soilCutaway: THREE.MeshStandardMaterial;
  hardwoodBark: THREE.MeshStandardMaterial;
  cedarBark: THREE.MeshStandardMaterial;
  beechBark: THREE.MeshStandardMaterial;
  pineBark: THREE.MeshStandardMaterial;
  birchBark: THREE.MeshStandardMaterial;
  canopyBright: THREE.MeshStandardMaterial;
  treeCanopyBright: THREE.MeshStandardMaterial;
  treeCanopyDeep: THREE.MeshStandardMaterial;
  treeCedarFrond: THREE.MeshStandardMaterial;
  zelkovaLeaf: THREE.MeshStandardMaterial;
  pineNeedles: THREE.MeshStandardMaterial;
  birchLeaf: THREE.MeshStandardMaterial;
  shrubLeaf: THREE.MeshStandardMaterial;
  fernFrond: THREE.MeshStandardMaterial;
  dryLeafScatter: THREE.MeshStandardMaterial;
  pineNeedleThatch: THREE.MeshStandardMaterial;
  grassClump: THREE.MeshStandardMaterial;
  sproutLeaf: THREE.MeshStandardMaterial;
  mossyRock: THREE.MeshStandardMaterial;
  weatheredCurb: THREE.MeshStandardMaterial;
  tougeAsphalt: THREE.MeshStandardMaterial;
  sunbeam: THREE.ShaderMaterial;
  allStandardMaterials: THREE.MeshStandardMaterial[];
  dispose: () => void;
}

/**
 * Enhances a MeshStandardMaterial with real-time botanical wind animation &
 * physically-inspired backlit subsurface scattering (SSS) translucency!
 */
function attachBotanicalShader(
  mat: THREE.MeshStandardMaterial,
  uniforms: ForestShaderUniforms,
  options: {
    windAmp: number;
    windFreq: number;
    sssTint: THREE.Color;
    sssIntensity: number;
    rootAO?: boolean;
    key: string;
  }
): THREE.MeshDepthMaterial {
  const sssColorUniform = { value: options.sssTint.clone() };
  const sssStrengthUniform = { value: options.sssIntensity };
  const windAmpUniform = { value: options.windAmp };
  const windFreqUniform = { value: options.windFreq };

  mat.customProgramCacheKey = () => `botanical-pbr-${options.key}`;

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.uniforms.uSunDirection = uniforms.uSunDirection;
    shader.uniforms.uSunColor = uniforms.uSunColor;
    shader.uniforms.uTranslucency = uniforms.uTranslucency;
    shader.uniforms.uSssColor = sssColorUniform;
    shader.uniforms.uSssIntensity = sssStrengthUniform;
    shader.uniforms.uWindAmp = windAmpUniform;
    shader.uniforms.uWindFreq = windFreqUniform;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform float uWindStrength;
        uniform float uWindAmp;
        uniform float uWindFreq;
        varying vec3 vWorldPosCustom;
        varying float vTipFactor;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 worldPosBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipWeight = clamp(uv.y, 0.0, 1.0);
        tipWeight = tipWeight * tipWeight;
        vTipFactor = clamp(uv.y, 0.0, 1.0);

        float phase = worldPosBase.x * 0.42 + worldPosBase.z * 0.37 + worldPosBase.y * 0.25;
        float gust = sin(uTime * uWindFreq + phase) * 0.65 + sin(uTime * (uWindFreq * 2.35) + phase * 1.9) * 0.35;
        float flutter = sin(uTime * (uWindFreq * 4.7) + worldPosBase.x * 3.1 + worldPosBase.z * 2.7) * 0.22;
        float sway = (gust + flutter) * uWindAmp * uWindStrength * tipWeight;

        transformed.x += sway;
        transformed.z += sway * 0.62;
        transformed.y -= abs(sway) * 0.14;

        vec4 worldPosFinal = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosFinal = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        vWorldPosCustom = worldPosFinal.xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform vec3 uSunDirection;
        uniform vec3 uSunColor;
        uniform float uTranslucency;
        uniform vec3 uSssColor;
        uniform float uSssIntensity;
        varying vec3 vWorldPosCustom;
        varying float vTipFactor;
        `
      )
      .replace(
        '#include <opaque_fragment>',
        `
        // Physically calibrated backlit chlorophyll subsurface scattering (rich green-gold glow, ZERO white blowout!)
        vec3 viewDirW = normalize(cameraPosition - vWorldPosCustom);
        vec3 sunDirW = normalize(uSunDirection);

        // Forward light transmission when viewing foliage against sunlight
        float backScatter = pow(clamp(dot(viewDirW, -sunDirW), 0.0, 1.0), 3.0);
        // Soft overhead canopy sun-through-leaf chlorophyll warmth
        float upTrans = clamp(sunDirW.y * 0.65 + 0.25, 0.0, 1.0) * (0.28 + 0.72 * vTipFactor);
        float sssFactor = clamp((backScatter * 0.62 + upTrans * 0.20) * uSssIntensity * uTranslucency, 0.0, 0.78);

        // Energy-conserving chlorophyll transmission (stays deeply saturated green-lime, never chalky white!)
        vec3 sssContribution = diffuseColor.rgb * uSssColor * uSunColor * sssFactor;

        ${
          options.rootAO
            ? `
        // Natural soil-root occlusion gradient for grass & fern bases
        float rootOcclusion = mix(0.38, 1.05, smoothstep(0.0, 0.55, vTipFactor));
        outgoingLight *= rootOcclusion;
        sssContribution *= smoothstep(0.08, 0.75, vTipFactor);
        `
            : ''
        }

        // Soft highlight shoulder compression prevents bright foliage from clipping to flat white
        vec3 combinedLeaf = outgoingLight + sssContribution;
        outgoingLight = combinedLeaf / (vec3(1.0) + combinedLeaf * 0.22);
        #include <opaque_fragment>
        `
      );
  };

  // Matching alpha-tested + DoubleSide + wind-animated depth material so dappled leaf shadows are crisp!
  const depthMat = new THREE.MeshDepthMaterial({
    depthPacking: THREE.RGBADepthPacking,
    map: mat.map,
    alphaTest: mat.alphaTest,
    side: THREE.DoubleSide,
  });

  depthMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.uniforms.uWindAmp = windAmpUniform;
    shader.uniforms.uWindFreq = windFreqUniform;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform float uWindStrength;
        uniform float uWindAmp;
        uniform float uWindFreq;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 worldPosBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipWeight = clamp(uv.y, 0.0, 1.0);
        tipWeight = tipWeight * tipWeight;
        float phase = worldPosBase.x * 0.42 + worldPosBase.z * 0.37 + worldPosBase.y * 0.25;
        float gust = sin(uTime * uWindFreq + phase) * 0.65 + sin(uTime * (uWindFreq * 2.35) + phase * 1.9) * 0.35;
        float sway = gust * uWindAmp * uWindStrength * tipWeight;
        transformed.x += sway;
        transformed.z += sway * 0.62;
        `
      );
  };

  return depthMat;
}

/**
 * Enhances the forest floor material with seamless world-space macro moisture/moss breakup
 * so large embankments never look tiled!
 */
function createForestFloorMaterial(tex: PBRTextureSet): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.75, 1.75),
    roughnessMap: tex.roughnessMap,
    roughness: 0.96,
    metalness: 0.0,
    vertexColors: true,
    envMapIntensity: 0.72,
  });

  mat.customProgramCacheKey = () => 'forest-floor-macro-pbr';
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        `
      )
      .replace(
        '#include <worldpos_vertex>',
        `#include <worldpos_vertex>
        vFloorWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        float hashFloor(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float vNoiseFloor(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashFloor(i);
          float b = hashFloor(i + vec2(1.0, 0.0));
          float c = hashFloor(i + vec2(0.0, 1.0));
          float d = hashFloor(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        // Large-scale organic damp/dry forest soil variation to eliminate visible tiling
        float macro1 = vNoiseFloor(vFloorWorldPos.xz * 0.28);
        float macro2 = vNoiseFloor(vFloorWorldPos.xz * 0.85 + vec2(7.3, 4.1));
        float patchVar = macro1 * 0.65 + macro2 * 0.35;
        vec3 dampTint = vec3(0.76, 0.72, 0.68);
        vec3 dryLitTint = vec3(1.16, 1.11, 1.03);
        diffuseColor.rgb *= mix(dampTint, dryLitTint, smoothstep(0.22, 0.78, patchVar));
        `
      );
  };

  return mat;
}

/**
 * Photorealistic Japanese Touge Mountain Asphalt PBR material:
 * High-res crushed aggregate base + spline-aware rubber drift/tire wear tracks,
 * macro weathering patches, dusty forest-edge shoulders & satin tire-polish roughness!
 */
function createTougeAsphaltMaterial(tex: PBRTextureSet): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: tex.roughnessMap,
    roughness: 0.9,
    metalness: 0.03,
    envMapIntensity: 0.92,
  });

  mat.customProgramCacheKey = () => 'touge-asphalt-pbr-v1';
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute vec2 aRoadCoord;
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;
        `
      )
      .replace(
        '#include <worldpos_vertex>',
        `#include <worldpos_vertex>
        vRoadCoord = aRoadCoord;
        vAsphaltWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;

        float hashAsph(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noiseAsph(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashAsph(i);
          float b = hashAsph(i + vec2(1.0, 0.0));
          float c = hashAsph(i + vec2(0.0, 1.0));
          float d = hashAsph(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float u = vRoadCoord.x; // 0 = outer forest edge, 1 = inner curb edge
        float s = vRoadCoord.y; // longitudinal distance along road (meters)

        // World-space macro aggregate aging & subtle damp/sunlit blotches (zero tiling!)
        float macroW1 = noiseAsph(vAsphaltWorldPos.xz * 0.22);
        float macroW2 = noiseAsph(vAsphaltWorldPos.xz * 0.72 + vec2(4.7, 9.1));
        float macroWeather = macroW1 * 0.62 + macroW2 * 0.38;
        diffuseColor.rgb *= mix(0.86, 1.15, smoothstep(0.2, 0.82, macroWeather));

        // Subtle sweeping touge drift / rubber tire-wear arcs curving smoothly along the road!
        float driftShift = sin(s * 0.14 + 0.6) * 0.065;
        float track1 = exp(-pow((u - (0.30 + driftShift)) / 0.068, 2.0));
        float track2 = exp(-pow((u - (0.48 + driftShift * 0.85)) / 0.072, 2.0));
        float track3 = exp(-pow((u - (0.64 + driftShift * 0.7)) / 0.064, 2.0));
        float track4 = exp(-pow((u - (0.79 + driftShift * 0.5)) / 0.058, 2.0));
        float trackStreakNoise = 0.58 + 0.42 * noiseAsph(vec2(u * 26.0, s * 0.22));
        float tireMask = clamp((track1 * 0.65 + track2 * 0.85 + track3 * 0.9 + track4 * 0.75) * trackStreakNoise, 0.0, 1.0);

        // Dark charcoal rubber deposit along sweeping corner lines
        diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.68, 0.69, 0.71), tireMask * 0.56);

        // Dusty weathered grit & leaf-tannin staining along both roadside shoulders
        float edgeNoise = noiseAsph(vAsphaltWorldPos.xz * 1.45);
        float outerDust = smoothstep(0.15, 0.0, u + (edgeNoise - 0.5) * 0.055);
        float innerDust = smoothstep(0.86, 1.0, u + (edgeNoise - 0.5) * 0.055);
        float shoulderMask = clamp(outerDust + innerDust, 0.0, 1.0);
        vec3 shoulderGrit = vec3(0.36, 0.33, 0.28);
        diffuseColor.rgb = mix(diffuseColor.rgb, shoulderGrit, shoulderMask * 0.55);

        // Subtle pale dry rubber-dust sheen on sun-baked mid-lane
        float sunCrown = smoothstep(0.08, 0.45, u) * smoothstep(0.95, 0.55, u);
        diffuseColor.rgb *= (1.0 + sunCrown * 0.07);
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        `#include <roughnessmap_fragment>
        // Polished tire tracks catch subtle sunlit grazing sheen; dusty shoulders stay matte
        float rDriftShift = sin(vRoadCoord.y * 0.14 + 0.6) * 0.065;
        float rTrack = exp(-pow((vRoadCoord.x - (0.48 + rDriftShift * 0.85)) / 0.09, 2.0))
                     + exp(-pow((vRoadCoord.x - (0.64 + rDriftShift * 0.7)) / 0.09, 2.0));
        float rShoulder = smoothstep(0.14, 0.0, vRoadCoord.x) + smoothstep(0.87, 1.0, vRoadCoord.x);
        roughnessFactor = clamp(roughnessFactor - rTrack * 0.14 + rShoulder * 0.14, 0.48, 0.98);
        `
      );
  };

  return mat;
}

/**
 * Volumetric-style canopy sunbeams (crepuscular god-ray shafts)
 */
function createSunbeamShaderMaterial(uniforms: ForestShaderUniforms): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    uniforms: {
      uTime: uniforms.uTime,
      uSunColor: uniforms.uSunColor,
      uOpacity: { value: 0.075 },
    },
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vNormalW;
      varying vec3 vWorldPos;
      void main() {
        vUv = uv;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPos = wp.xyz;
        vNormalW = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 uSunColor;
      uniform float uOpacity;
      varying vec2 vUv;
      varying vec3 vNormalW;
      varying vec3 vWorldPos;

      void main() {
        vec3 viewDir = normalize(cameraPosition - vWorldPos);
        // Smooth grazing-angle Fresnel fade so cone edges are completely soft!
        float fresnel = pow(abs(dot(normalize(vNormalW), viewDir)), 1.75);
        // Smooth top and bottom longitudinal attenuation
        float verticalFade = smoothstep(0.0, 0.28, vUv.y) * smoothstep(1.0, 0.18, vUv.y);
        // Subtle animated dappled streaks simulating swaying tree leaves overhead
        float streaks = 0.72 + 0.28 * sin(vUv.x * 18.8495 + uTime * 0.35 + vWorldPos.x * 0.4);
        float alpha = fresnel * verticalFade * streaks * uOpacity;
        gl_FragColor = vec4(uSunColor * vec3(1.02, 1.04, 0.9), alpha);
      }
    `,
  });
}

export function createStudioMaterialLibrary(
  textures: StudioTextureLibrary
): StudioMaterialLibrary {
  const uniforms: ForestShaderUniforms = {
    uTime: { value: 0 },
    uWindStrength: { value: 0.72 },
    uSunDirection: { value: new THREE.Vector3(-0.48, 0.72, -0.5).normalize() },
    uSunColor: { value: new THREE.Color('#fff4d8') },
    uTranslucency: { value: 1.05 },
  };

  const forestFloor = createForestFloorMaterial(textures.forestFloor);

  const soilCutaway = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#35261a'),
    normalMap: textures.hardwoodBark.normalMap,
    normalScale: new THREE.Vector2(0.85, 0.85),
    roughness: 0.95,
    metalness: 0.0,
  });

  const hardwoodBark = new THREE.MeshStandardMaterial({
    map: textures.hardwoodBark.map,
    normalMap: textures.hardwoodBark.normalMap,
    normalScale: new THREE.Vector2(1.45, 1.45),
    roughnessMap: textures.hardwoodBark.roughnessMap,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.65,
  });

  const cedarBark = new THREE.MeshStandardMaterial({
    map: textures.cedarBark.map,
    normalMap: textures.cedarBark.normalMap,
    normalScale: new THREE.Vector2(1.6, 1.6),
    roughnessMap: textures.cedarBark.roughnessMap,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.65,
  });

  const beechBark = new THREE.MeshStandardMaterial({
    map: textures.beechBark.map,
    normalMap: textures.beechBark.normalMap,
    normalScale: new THREE.Vector2(1.05, 1.05),
    roughnessMap: textures.beechBark.roughnessMap,
    roughness: 0.88,
    metalness: 0.0,
    envMapIntensity: 0.68,
  });

  const pineBark = new THREE.MeshStandardMaterial({
    map: textures.pineBark.map,
    normalMap: textures.pineBark.normalMap,
    normalScale: new THREE.Vector2(1.75, 1.75),
    roughnessMap: textures.pineBark.roughnessMap,
    roughness: 0.94,
    metalness: 0.0,
    envMapIntensity: 0.62,
  });

  const birchBark = new THREE.MeshStandardMaterial({
    map: textures.birchBark.map,
    normalMap: textures.birchBark.normalMap,
    normalScale: new THREE.Vector2(1.15, 1.15),
    roughnessMap: textures.birchBark.roughnessMap,
    roughness: 0.86,
    metalness: 0.0,
    envMapIntensity: 0.66,
  });

  // 1a. Bright backlit spring chartreuse-lime (non-vertex-color version for shrubs & saplings)
  const canopyBright = new THREE.MeshStandardMaterial({
    map: textures.canopyBright.map,
    normalMap: textures.canopyBright.normalMap,
    normalScale: new THREE.Vector2(0.95, 0.95),
    roughnessMap: textures.canopyBright.roughnessMap,
    roughness: 0.66,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.62,
  });
  canopyBright.userData.customDepthMaterial = attachBotanicalShader(canopyBright, uniforms, {
    windAmp: 0.055,
    windFreq: 1.35,
    sssTint: new THREE.Color('#b6e83a'),
    sssIntensity: 0.72,
    key: 'canopy-bright-shrub',
  });

  // 1b. Tree Canopy Bright (with baked 3D canopy AO vertexColors!)
  const treeCanopyBright = new THREE.MeshStandardMaterial({
    map: textures.canopyBright.map,
    normalMap: textures.canopyBright.normalMap,
    normalScale: new THREE.Vector2(0.95, 0.95),
    roughnessMap: textures.canopyBright.roughnessMap,
    roughness: 0.68,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.58,
  });
  treeCanopyBright.userData.customDepthMaterial = attachBotanicalShader(treeCanopyBright, uniforms, {
    windAmp: 0.065,
    windFreq: 1.3,
    sssTint: new THREE.Color('#bce838'),
    sssIntensity: 0.76,
    key: 'tree-canopy-bright',
  });

  // 2. Tree Canopy Deep Emerald Shade (with baked 3D canopy AO vertexColors!)
  const treeCanopyDeep = new THREE.MeshStandardMaterial({
    map: textures.canopyDeep.map,
    normalMap: textures.canopyDeep.normalMap,
    normalScale: new THREE.Vector2(0.95, 0.95),
    roughnessMap: textures.canopyDeep.roughnessMap,
    roughness: 0.72,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.54,
  });
  treeCanopyDeep.userData.customDepthMaterial = attachBotanicalShader(treeCanopyDeep, uniforms, {
    windAmp: 0.055,
    windFreq: 1.2,
    sssTint: new THREE.Color('#7ec42c'),
    sssIntensity: 0.52,
    key: 'tree-canopy-deep',
  });

  // 3. Tall Japanese Sugi Cedar conifer foliage (with baked 3D canopy AO)
  const treeCedarFrond = new THREE.MeshStandardMaterial({
    map: textures.cedarFrond.map,
    normalMap: textures.cedarFrond.normalMap,
    normalScale: new THREE.Vector2(1.0, 1.0),
    roughnessMap: textures.cedarFrond.roughnessMap,
    roughness: 0.76,
    metalness: 0.0,
    alphaTest: 0.4,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.52,
  });
  treeCedarFrond.userData.customDepthMaterial = attachBotanicalShader(treeCedarFrond, uniforms, {
    windAmp: 0.045,
    windFreq: 1.05,
    sssTint: new THREE.Color('#66b02c'),
    sssIntensity: 0.38,
    key: 'tree-cedar-frond',
  });

  // 3b. Japanese Zelkova (Keyaki) & Beech (Buna) rich emerald-jade canopy foliage
  const zelkovaLeaf = new THREE.MeshStandardMaterial({
    map: textures.zelkovaLeaf.map,
    normalMap: textures.zelkovaLeaf.normalMap,
    normalScale: new THREE.Vector2(0.95, 0.95),
    roughnessMap: textures.zelkovaLeaf.roughnessMap,
    roughness: 0.68,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.56,
  });
  zelkovaLeaf.userData.customDepthMaterial = attachBotanicalShader(zelkovaLeaf, uniforms, {
    windAmp: 0.06,
    windFreq: 1.28,
    sssTint: new THREE.Color('#95d435'),
    sssIntensity: 0.62,
    key: 'tree-zelkova-leaf',
  });

  // 3c. Japanese Red Pine (Akamatsu) deep blue-green horizontal needle cloud pads
  const pineNeedles = new THREE.MeshStandardMaterial({
    map: textures.pineNeedles.map,
    normalMap: textures.pineNeedles.normalMap,
    normalScale: new THREE.Vector2(1.1, 1.1),
    roughnessMap: textures.pineNeedles.roughnessMap,
    roughness: 0.78,
    metalness: 0.0,
    alphaTest: 0.4,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.48,
  });
  pineNeedles.userData.customDepthMaterial = attachBotanicalShader(pineNeedles, uniforms, {
    windAmp: 0.038,
    windFreq: 1.0,
    sssTint: new THREE.Color('#5ca630'),
    sssIntensity: 0.35,
    key: 'tree-pine-needles',
  });

  // 3d. Japanese White Birch (Shirakaba) shimmering light highland birch foliage
  const birchLeaf = new THREE.MeshStandardMaterial({
    map: textures.birchLeaf.map,
    normalMap: textures.birchLeaf.normalMap,
    normalScale: new THREE.Vector2(0.9, 0.9),
    roughnessMap: textures.birchLeaf.roughnessMap,
    roughness: 0.62,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    vertexColors: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.6,
  });
  birchLeaf.userData.customDepthMaterial = attachBotanicalShader(birchLeaf, uniforms, {
    windAmp: 0.078,
    windFreq: 1.65,
    sssTint: new THREE.Color('#b4e645'),
    sssIntensity: 0.68,
    key: 'tree-birch-leaf',
  });

  // 4. Wild undergrowth forest shrubs & saplings
  const shrubLeaf = new THREE.MeshStandardMaterial({
    map: textures.shrubLeaf.map,
    normalMap: textures.shrubLeaf.normalMap,
    normalScale: new THREE.Vector2(0.9, 0.9),
    roughnessMap: textures.shrubLeaf.roughnessMap,
    roughness: 0.5,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.86,
  });
  const shrubLeafDepth = attachBotanicalShader(shrubLeaf, uniforms, {
    windAmp: 0.05,
    windFreq: 1.65,
    sssTint: new THREE.Color('#c7f54d'),
    sssIntensity: 0.78,
    key: 'shrub-leaf',
  });
  shrubLeaf.userData.customDepthMaterial = shrubLeafDepth;

  // 5. Woodland fern fronds
  const fernFrond = new THREE.MeshStandardMaterial({
    map: textures.fernFrond.map,
    normalMap: textures.fernFrond.normalMap,
    normalScale: new THREE.Vector2(0.85, 0.85),
    roughnessMap: textures.fernFrond.roughnessMap,
    roughness: 0.54,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.84,
  });
  const fernFrondDepth = attachBotanicalShader(fernFrond, uniforms, {
    windAmp: 0.065,
    windFreq: 1.75,
    sssTint: new THREE.Color('#b6ee4a'),
    sssIntensity: 0.84,
    rootAO: true,
    key: 'fern-frond',
  });
  fernFrond.userData.customDepthMaterial = fernFrondDepth;

  // 6. Physical 3D curled dry fallen leaves on soil (instanced)
  const dryLeafScatter = new THREE.MeshStandardMaterial({
    map: textures.dryLeafCard.map,
    normalMap: textures.dryLeafCard.normalMap,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughnessMap: textures.dryLeafCard.roughnessMap,
    roughness: 0.86,
    metalness: 0.0,
    alphaTest: 0.44,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.75,
  });

  // 6b. Physical 3D dry pine-needle / forest thatch clusters (instanced)
  const pineNeedleThatch = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    roughness: 0.88,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.7,
  });

  // 7. Wild forest grass clumps (instanced green & dry straw blades)
  const grassClump = new THREE.MeshStandardMaterial({
    map: textures.grassBlade.map,
    normalMap: textures.grassBlade.normalMap,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughnessMap: textures.grassBlade.roughnessMap,
    roughness: 0.62,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.8,
  });
  const grassDepth = attachBotanicalShader(grassClump, uniforms, {
    windAmp: 0.085,
    windFreq: 1.9,
    sssTint: new THREE.Color('#c8f25c'),
    sssIntensity: 0.66,
    rootAO: true,
    key: 'grass-clump',
  });
  grassClump.userData.customDepthMaterial = grassDepth;

  // 8. Tiny vivid bright green wild sprouts poking out of the foreground brown leaf litter!
  const sproutLeaf = new THREE.MeshStandardMaterial({
    map: textures.canopyBright.map,
    normalMap: textures.canopyBright.normalMap,
    roughness: 0.45,
    metalness: 0.0,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    envMapIntensity: 0.9,
  });
  const sproutDepth = attachBotanicalShader(sproutLeaf, uniforms, {
    windAmp: 0.025,
    windFreq: 2.1,
    sssTint: new THREE.Color('#dbff66'),
    sssIntensity: 0.95,
    rootAO: true,
    key: 'sprout-leaf',
  });
  sproutLeaf.userData.customDepthMaterial = sproutDepth;

  // 9. Mossy mountain stone & weathered concrete forest curb
  const mossyRock = new THREE.MeshStandardMaterial({
    map: textures.mossyRock.map,
    normalMap: textures.mossyRock.normalMap,
    normalScale: new THREE.Vector2(1.5, 1.5),
    roughnessMap: textures.mossyRock.roughnessMap,
    roughness: 0.92,
    metalness: 0.02,
    envMapIntensity: 0.7,
  });

  const weatheredCurb = new THREE.MeshStandardMaterial({
    map: textures.weatheredCurb.map,
    normalMap: textures.weatheredCurb.normalMap,
    normalScale: new THREE.Vector2(1.35, 1.35),
    roughnessMap: textures.weatheredCurb.roughnessMap,
    roughness: 0.89,
    metalness: 0.02,
    vertexColors: true,
    envMapIntensity: 0.72,
  });

  const tougeAsphalt = createTougeAsphaltMaterial(textures.asphalt);

  const sunbeam = createSunbeamShaderMaterial(uniforms);

  const allStandardMaterials = [
    forestFloor,
    soilCutaway,
    hardwoodBark,
    cedarBark,
    beechBark,
    pineBark,
    birchBark,
    canopyBright,
    treeCanopyBright,
    treeCanopyDeep,
    treeCedarFrond,
    zelkovaLeaf,
    pineNeedles,
    birchLeaf,
    shrubLeaf,
    fernFrond,
    dryLeafScatter,
    pineNeedleThatch,
    grassClump,
    sproutLeaf,
    mossyRock,
    weatheredCurb,
    tougeAsphalt,
  ];

  return {
    uniforms,
    forestFloor,
    soilCutaway,
    hardwoodBark,
    cedarBark,
    beechBark,
    pineBark,
    birchBark,
    canopyBright,
    treeCanopyBright,
    treeCanopyDeep,
    treeCedarFrond,
    zelkovaLeaf,
    pineNeedles,
    birchLeaf,
    shrubLeaf,
    fernFrond,
    dryLeafScatter,
    pineNeedleThatch,
    grassClump,
    sproutLeaf,
    mossyRock,
    weatheredCurb,
    tougeAsphalt,
    sunbeam,
    allStandardMaterials,
    dispose: () => {
      for (const m of allStandardMaterials) {
        if (m.userData.customDepthMaterial) {
          (m.userData.customDepthMaterial as THREE.Material).dispose();
        }
        m.dispose();
      }
      sunbeam.dispose();
    },
  };
}
