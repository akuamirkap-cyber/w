import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';

import {
  createForestSkyEquirectTexture,
  createStudioTextureLibrary,
  StudioTextureLibrary,
} from './textures';
import { createStudioMaterialLibrary, StudioMaterialLibrary } from './materials';
import {
  createJapaneseBeechTree,
  createJapaneseBirchTree,
  createJapaneseBroadleafTree,
  createJapaneseCedarTree,
  createJapaneseRedPineTree,
  createJapaneseZelkovaTree,
  createOverhangTree,
} from './assets/trees';
import {
  createFullForestTerrain,
  createIsolatedSoilAsset,
  sampleFullForestHeight,
} from './assets/terrain';
import {
  createIsolatedAsphaltAsset,
  createTougeAsphaltRoad,
} from './assets/road';
import {
  createForestSapling,
  createInstancedForestGrass,
  createIsolatedShrubGrassAsset,
  createWildForestShrub,
  createWoodlandFern,
} from './assets/foliage';
import { createRng, randRange } from './noise';
import {
  CURB_WIDTH,
  isInsideRoadCorridor,
  ROAD_HALF_WIDTH,
  roadOffsetPoint,
} from './roadMath';

export type AssetMode = 'full' | 'tree' | 'road' | 'soil' | 'shrub';
export type TreeVariant =
  | 'broadleaf'
  | 'zelkova'
  | 'beech'
  | 'redpine'
  | 'birch'
  | 'cedar'
  | 'overhang';
export type LightingMood = 'midday' | 'golden' | 'mist' | 'overcast';
export type ViewShadingMode = 'beauty' | 'wireframe' | 'clay' | 'normal';
export type CameraPreset = 'reference' | 'tougeRoad' | 'macroSoil' | 'canopyBacklight' | 'aerial';

export interface SceneSettings {
  assetMode: AssetMode;
  treeVariant: TreeVariant;
  lightingMood: LightingMood;
  shadingMode: ViewShadingMode;
  sunAzimuth: number; // degrees
  sunElevation: number; // degrees
  windStrength: number; // 0..2
  translucency: number; // 0..2
  exposure: number; // 0.6..1.8
  bloomStrength: number; // 0..0.7
  sunbeamsVisible: boolean;
  autoRotate: boolean;
}

export interface EngineTelemetry {
  fps: number;
  triangles: number;
  drawCalls: number;
  instancedObjects: number;
  assetName: string;
}

interface CameraGoal {
  pos: THREE.Vector3;
  target: THREE.Vector3;
  active: boolean;
}

const MOOD_CONFIGS: Record<
  LightingMood,
  {
    azimuth: number;
    elevation: number;
    sunColor: string;
    sunIntensity: number;
    hemiSky: string;
    hemiGround: string;
    hemiIntensity: number;
    bounceColor: string;
    bounceIntensity: number;
    fogColor: string;
    fogDensity: number;
    envIntensity: number;
    bloomStrength: number;
    sunbeamOpacity: number;
    exposure: number;
  }
> = {
  midday: {
    azimuth: 142,
    elevation: 44,
    sunColor: '#fff5dc',
    sunIntensity: 3.1,
    hemiSky: '#b4d4ec',
    hemiGround: '#3b311f',
    hemiIntensity: 0.92,
    bounceColor: '#7cb53b',
    bounceIntensity: 0.52,
    fogColor: '#bcc9c2',
    fogDensity: 0.017,
    envIntensity: 0.9,
    bloomStrength: 0.14,
    sunbeamOpacity: 0.072,
    exposure: 1.04,
  },
  golden: {
    azimuth: 124,
    elevation: 18,
    sunColor: '#ffba6e',
    sunIntensity: 3.55,
    hemiSky: '#8fa9cc',
    hemiGround: '#3d2815',
    hemiIntensity: 0.72,
    bounceColor: '#c2993e',
    bounceIntensity: 0.52,
    fogColor: '#c9b397',
    fogDensity: 0.019,
    envIntensity: 0.82,
    bloomStrength: 0.24,
    sunbeamOpacity: 0.115,
    exposure: 1.02,
  },
  mist: {
    azimuth: 158,
    elevation: 32,
    sunColor: '#e6f3ff',
    sunIntensity: 2.55,
    hemiSky: '#c4dbe4',
    hemiGround: '#2f3827',
    hemiIntensity: 1.08,
    bounceColor: '#76ab6e',
    bounceIntensity: 0.48,
    fogColor: '#c5d6d4',
    fogDensity: 0.028,
    envIntensity: 0.96,
    bloomStrength: 0.2,
    sunbeamOpacity: 0.12,
    exposure: 1.06,
  },
  overcast: {
    azimuth: 145,
    elevation: 58,
    sunColor: '#f2f5f7',
    sunIntensity: 1.7,
    hemiSky: '#d8e0e4',
    hemiGround: '#40382b',
    hemiIntensity: 1.32,
    bounceColor: '#82a062',
    bounceIntensity: 0.38,
    fogColor: '#c6cecc',
    fogDensity: 0.015,
    envIntensity: 1.08,
    bloomStrength: 0.08,
    sunbeamOpacity: 0.018,
    exposure: 1.04,
  },
};

export function getMoodDefaults(mood: LightingMood) {
  const m = MOOD_CONFIGS[mood];
  return {
    sunAzimuth: m.azimuth,
    sunElevation: m.elevation,
    exposure: m.exposure,
    bloomStrength: m.bloomStrength,
  };
}

export class ForestStudioEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private composer: EffectComposer;
  private bloomPass: UnrealBloomPass;
  private pmrem: THREE.PMREMGenerator;
  private currentEnvRT: THREE.WebGLRenderTarget | null = null;
  private currentSkyTex: THREE.Texture | null = null;

  private textures: StudioTextureLibrary;
  private materials: StudioMaterialLibrary;

  // Lighting rig
  private sunLight: THREE.DirectionalLight;
  private bounceLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;

  // Atmospheric elements (full scene)
  private sunbeamsGroup: THREE.Group;
  private pollenPoints: THREE.Points;

  // Asset containers (cached lazily for instant switching!)
  private activeRoot: THREE.Group;
  private fullSceneGroup: THREE.Group | null = null;
  private roadAssetGroup: THREE.Group | null = null;
  private soilAssetGroup: THREE.Group | null = null;
  private shrubAssetGroup: THREE.Group | null = null;
  private treeAssetGroups: Partial<Record<TreeVariant, THREE.Group>> = {};

  // Override materials for PBR inspection modes
  private clayMaterial: THREE.MeshStandardMaterial;
  private normalMaterial: THREE.MeshNormalMaterial;

  // State & Animation
  private settings: SceneSettings;
  private cameraGoal: CameraGoal = {
    pos: new THREE.Vector3(),
    target: new THREE.Vector3(),
    active: false,
  };
  private rafId = 0;
  private lastTime = 0;
  private elapsedTime = 0;
  private frameCounter = 0;
  private fpsAccum = 0;
  private currentFps = 60;
  private onTelemetry?: (t: EngineTelemetry) => void;
  private resizeObserver: ResizeObserver;
  private envRebuildTimer: number | null = null;
  private disposed = false;

  constructor(
    container: HTMLElement,
    initialSettings: SceneSettings,
    onTelemetry?: (t: EngineTelemetry) => void
  ) {
    this.container = container;
    this.settings = { ...initialSettings };
    this.onTelemetry = onTelemetry;

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);

    // 1. Renderer — Physically Correct HDR Filmic WebGL2 Pipeline
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = initialSettings.exposure;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    // 2. Scene & Atmospheric Forest Fog
    this.scene = new THREE.Scene();
    this.fog = new THREE.FogExp2('#bcc9c2', 0.022);
    this.scene.fog = this.fog;

    // 3. Camera & Smooth Damped Orbit Controls
    this.camera = new THREE.PerspectiveCamera(44, width / height, 0.08, 120);
    this.camera.position.set(1.55, 2.55, 9.4);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI * 0.495;
    this.controls.minDistance = 0.85;
    this.controls.maxDistance = 48;
    this.controls.target.set(-0.65, 2.3, -3.2);
    this.controls.addEventListener('start', () => {
      // Cancel smooth transition immediately when user grabs the viewport
      this.cameraGoal.active = false;
    });

    // 4. HDR Post-Processing Composer (HalfFloat HDR -> Subtle Optical Bloom -> ACES Output)
    const renderTarget = new THREE.WebGLRenderTarget(width, height, {
      type: THREE.HalfFloatType,
      samples: 4,
    });
    this.composer = new EffectComposer(this.renderer, renderTarget);
    this.composer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.composer.setSize(width, height);

    const renderPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(renderPass);

    // High bloom threshold (1.14) ensures ONLY true sky/sun highlights bloom — NEVER tree leaves!
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      initialSettings.bloomStrength,
      0.48,
      1.14
    );
    this.composer.addPass(this.bloomPass);

    const outputPass = new OutputPass();
    this.composer.addPass(outputPass);

    // 5. PBR Procedural Textures & Custom Shader Materials
    this.pmrem = new THREE.PMREMGenerator(this.renderer);
    this.pmrem.compileEquirectangularShader();

    this.textures = createStudioTextureLibrary(this.renderer.capabilities.getMaxAnisotropy());
    this.materials = createStudioMaterialLibrary(this.textures);

    this.clayMaterial = new THREE.MeshStandardMaterial({
      color: '#b8b6af',
      roughness: 0.86,
      metalness: 0.0,
    });
    this.normalMaterial = new THREE.MeshNormalMaterial({ side: THREE.DoubleSide });

    // 6. Photorealistic Forest Lighting Rig
    this.hemiLight = new THREE.HemisphereLight('#b8d7f0', '#3d3320', 1.05);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#fff6de', 3.65);
    this.sunLight.castShadow = true;
    const shadowRes = Math.min(4096, this.renderer.capabilities.maxTextureSize);
    this.sunLight.shadow.mapSize.set(shadowRes, shadowRes);
    this.sunLight.shadow.camera.near = 1.0;
    this.sunLight.shadow.camera.far = 48;
    this.sunLight.shadow.camera.left = -14;
    this.sunLight.shadow.camera.right = 14;
    this.sunLight.shadow.camera.top = 15;
    this.sunLight.shadow.camera.bottom = -12;
    this.sunLight.shadow.bias = -0.00035;
    this.sunLight.shadow.normalBias = 0.022;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    // Soft chlorophyll green canopy bounce fill light
    this.bounceLight = new THREE.DirectionalLight('#90c848', 0.75);
    this.bounceLight.position.set(8, 3.5, 9);
    this.scene.add(this.bounceLight);

    // 7. Volumetric Sunbeams & Sunlit Drifting Pollen Dust Motes
    this.sunbeamsGroup = this.createVolumetricSunbeams();
    this.scene.add(this.sunbeamsGroup);

    this.pollenPoints = this.createDriftingForestPollen();
    this.scene.add(this.pollenPoints);

    // 8. Root Group for Active 3D Asset Mode
    this.activeRoot = new THREE.Group();
    this.scene.add(this.activeRoot);

    // Build initial environment, lighting & full forest scene
    this.applyLightingMood(initialSettings.lightingMood, false);
    this.updateSunPosition(initialSettings.sunAzimuth, initialSettings.sunElevation, true);
    this.switchAssetMode(initialSettings.assetMode, initialSettings.treeVariant, true);

    // Responsive Resize Observer
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(container);

    // Start Real-Time Render Loop
    this.lastTime = performance.now();
    this.animate(this.lastTime);
  }

  /**
   * Builds soft crepuscular canopy god-ray shafts slanting down through gaps in the foliage
   */
  private createVolumetricSunbeams(): THREE.Group {
    const group = new THREE.Group();
    group.name = 'Volumetric_Canopy_Sunbeams';

    const beamSpecs = [
      { pos: [-3.2, 5.4, -2.4], topR: 0.78, botR: 2.45, h: 12.0 },
      { pos: [1.2, 5.8, -3.8], topR: 0.92, botR: 2.8, h: 12.4 },
      { pos: [-6.0, 6.0, -3.2], topR: 0.85, botR: 2.6, h: 12.8 },
      { pos: [4.6, 5.3, -2.8], topR: 0.7, botR: 2.2, h: 11.2 },
    ];

    beamSpecs.forEach((b, i) => {
      const geo = new THREE.CylinderGeometry(b.topR, b.botR, b.h, 20, 1, true);
      const mesh = new THREE.Mesh(geo, this.materials.sunbeam);
      mesh.position.set(b.pos[0], b.pos[1], b.pos[2]);
      mesh.name = `Canopy_Sunbeam_${i + 1}`;
      group.add(mesh);
    });

    return group;
  }

  /**
   * Subtle sunlit drifting forest pollen / airborne micro-motes catching light beams
   */
  private createDriftingForestPollen(): THREE.Points {
    const rng = createRng(9191);
    const count = 220;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = randRange(rng, -9.5, 9.5);
      positions[i * 3 + 1] = randRange(rng, 0.4, 7.5);
      positions[i * 3 + 2] = randRange(rng, -8.5, 7.5);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    // Soft circular glow sprite texture
    const c = document.createElement('canvas');
    c.width = 32;
    c.height = 32;
    const ctx = c.getContext('2d')!;
    const g = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    g.addColorStop(0, 'rgba(255, 252, 224, 0.95)');
    g.addColorStop(0.4, 'rgba(225, 245, 175, 0.45)');
    g.addColorStop(1, 'rgba(225, 245, 175, 0.0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 32, 32);
    const sprite = new THREE.CanvasTexture(c);

    const mat = new THREE.PointsMaterial({
      size: 0.095,
      map: sprite,
      transparent: true,
      opacity: 0.52,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      color: '#f2ffcf',
    });

    const pts = new THREE.Points(geo, mat);
    pts.name = 'Forest_Sunlit_Pollen';
    return pts;
  }

  /**
   * Builds the full photorealistic Japanese Touge Forest + Curving Mountain Asphalt Road Diorama
   * matching the reference photograph's exact layout (leaf bank -> curb -> asphalt -> forest wall) WITHOUT cars!
   */
  private getOrCreateFullForestScene(): THREE.Group {
    if (this.fullSceneGroup) return this.fullSceneGroup;

    const root = new THREE.Group();
    root.name = 'Japanese_Touge_Forest_Road_Diorama';
    const rng = createRng(2026);

    // 1. Sculpted Forest Embankment Terrain + 4,200+ 3D Fallen Leaves, Pine Needles, Twigs, Rocks & Sprouts
    const terrain = createFullForestTerrain(this.materials);
    root.add(terrain);

    // 2. Curving Touge Mountain Asphalt Road + Weathered Concrete Inner Curb + Wind-Blown Edge Leaves!
    const asphaltRoad = createTougeAsphaltRoad(this.materials);
    root.add(asphaltRoad);

    // 3. MIXED-SPECIES JAPANESE MOUNTAIN TOUGE TREE ECOSYSTEM (All 7 Species across the 62m Pass!)
    // 3a. Hero Luminous Japanese Mountain Maples (Momiji — focal chartreuse-lime canopies matching photo!)
    const mapleSpecs = [
      { spineX: -4.4, offset: -(ROAD_HALF_WIDTH + 1.9), h: 7.7, r: 0.22, spread: 4.1, sun: 0.78, leanX: 0.45, leanZ: 0.9, detail: 'hero' as const },
      { spineX: -0.8, offset: -(ROAD_HALF_WIDTH + 2.35), h: 8.1, r: 0.23, spread: 4.2, sun: 0.75, leanX: 0.15, leanZ: 0.85, detail: 'hero' as const },
      { spineX: 3.3, offset: -(ROAD_HALF_WIDTH + 2.15), h: 7.9, r: 0.22, spread: 4.0, sun: 0.72, leanX: -0.35, leanZ: 0.75, detail: 'hero' as const },
      { spineX: -14.8, offset: -(ROAD_HALF_WIDTH + 2.1), h: 8.2, r: 0.24, spread: 4.1, sun: 0.7, leanX: 0.4, leanZ: 0.65, detail: 'forest' as const },
      { spineX: 13.8, offset: -(ROAD_HALF_WIDTH + 2.2), h: 8.0, r: 0.23, spread: 4.0, sun: 0.68, leanX: -0.3, leanZ: 0.6, detail: 'forest' as const },
      { spineX: -22.5, offset: -(ROAD_HALF_WIDTH + 2.4), h: 8.5, r: 0.25, spread: 4.2, sun: 0.65, leanX: 0.3, leanZ: 0.5, detail: 'forest' as const },
      { spineX: 22.8, offset: -(ROAD_HALF_WIDTH + 2.5), h: 8.3, r: 0.24, spread: 4.1, sun: 0.64, leanX: -0.3, leanZ: 0.45, detail: 'forest' as const },
    ];
    mapleSpecs.forEach((sp, i) => {
      const pt = roadOffsetPoint(sp.spineX, sp.offset);
      const tree = createJapaneseBroadleafTree(this.materials, {
        seed: 1000 + i * 73,
        height: sp.h,
        trunkRadius: sp.r,
        crownSpread: sp.spread,
        sunlitRatio: sp.sun,
        leanX: sp.leanX,
        leanZ: sp.leanZ,
        detailLevel: sp.detail,
      });
      tree.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.16, pt.z);
      root.add(tree);
    });

    // 3b. NEW SPECIES #1: Japanese Zelkova (Keyaki — sweeping vase crown emerald giants!)
    const zelkovaSpecs = [
      { spineX: -8.8, offset: -(ROAD_HALF_WIDTH + 2.4), h: 9.4, r: 0.28 },
      { spineX: 7.9, offset: -(ROAD_HALF_WIDTH + 2.3), h: 9.2, r: 0.27 },
      { spineX: -18.5, offset: -(ROAD_HALF_WIDTH + 2.9), h: 9.6, r: 0.29 },
      { spineX: 18.2, offset: -(ROAD_HALF_WIDTH + 2.7), h: 9.5, r: 0.28 },
      { spineX: 15.6, offset: ROAD_HALF_WIDTH + 3.4, h: 9.1, r: 0.26 }, // frames far-right inner bend!
      { spineX: -17.4, offset: ROAD_HALF_WIDTH + 3.6, h: 9.2, r: 0.27 }, // frames far-left inner bend!
    ];
    zelkovaSpecs.forEach((sp, i) => {
      const pt = roadOffsetPoint(sp.spineX, sp.offset);
      const zelkova = createJapaneseZelkovaTree(this.materials, {
        seed: 4100 + i * 61,
        height: sp.h,
        trunkRadius: sp.r,
        detailLevel: i < 2 ? 'hero' : 'forest',
      });
      zelkova.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.18, pt.z);
      root.add(zelkova);
    });

    // 3c. NEW SPECIES #2: Japanese Mountain Beech (Buna — silvery-ash mossy trunks & wide mountain domes!)
    const beechSpecs = [
      { spineX: -11.6, offset: -(ROAD_HALF_WIDTH + 4.4), h: 9.8, r: 0.30 },
      { spineX: -2.6, offset: -(ROAD_HALF_WIDTH + 5.5), h: 10.2, r: 0.31 },
      { spineX: 4.8, offset: -(ROAD_HALF_WIDTH + 5.2), h: 9.9, r: 0.30 },
      { spineX: 11.4, offset: -(ROAD_HALF_WIDTH + 4.6), h: 9.7, r: 0.29 },
      { spineX: -24.5, offset: -(ROAD_HALF_WIDTH + 4.2), h: 10.0, r: 0.30 },
      { spineX: 25.2, offset: -(ROAD_HALF_WIDTH + 4.5), h: 9.8, r: 0.29 },
      { spineX: -22.0, offset: ROAD_HALF_WIDTH + 4.1, h: 9.4, r: 0.28 },
    ];
    beechSpecs.forEach((sp, i) => {
      const pt = roadOffsetPoint(sp.spineX, sp.offset);
      const beech = createJapaneseBeechTree(this.materials, {
        seed: 4500 + i * 67,
        height: sp.h,
        trunkRadius: sp.r,
        detailLevel: i < 2 ? 'hero' : 'forest',
      });
      beech.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.18, pt.z);
      root.add(beech);
    });

    // 3d. NEW SPECIES #3: Japanese Red Pine (Akamatsu — crooked terracotta-bark cliff pines with flat cloud pads!)
    const redPineSpecs = [
      { spineX: -6.4, offset: -(ROAD_HALF_WIDTH + 3.2), h: 9.0, r: 0.25 },
      { spineX: 6.1, offset: -(ROAD_HALF_WIDTH + 3.0), h: 8.8, r: 0.24 },
      { spineX: -16.2, offset: -(ROAD_HALF_WIDTH + 2.3), h: 9.2, r: 0.26 },
      { spineX: 16.4, offset: -(ROAD_HALF_WIDTH + 2.5), h: 9.1, r: 0.25 },
      { spineX: 21.6, offset: ROAD_HALF_WIDTH + 3.1, h: 8.6, r: 0.24 },
      { spineX: -13.2, offset: ROAD_HALF_WIDTH + 3.8, h: 8.9, r: 0.25 },
    ];
    redPineSpecs.forEach((sp, i) => {
      const pt = roadOffsetPoint(sp.spineX, sp.offset);
      const pine = createJapaneseRedPineTree(this.materials, {
        seed: 5100 + i * 79,
        height: sp.h,
        trunkRadius: sp.r,
        detailLevel: i < 2 ? 'hero' : 'forest',
      });
      pine.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.18, pt.z);
      root.add(pine);
    });

    // 3e. NEW SPECIES #4: Japanese White Birch (Shirakaba — striking papery-white highland stems & weeping foliage!)
    const birchSpecs = [
      { spineX: -3.2, offset: -(ROAD_HALF_WIDTH + 3.6), h: 9.5, twin: true },
      { spineX: 1.5, offset: -(ROAD_HALF_WIDTH + 3.9), h: 9.3, twin: false },
      { spineX: 9.8, offset: -(ROAD_HALF_WIDTH + 2.8), h: 9.6, twin: true },
      { spineX: -12.4, offset: -(ROAD_HALF_WIDTH + 2.7), h: 9.4, twin: true },
      { spineX: 20.4, offset: -(ROAD_HALF_WIDTH + 3.2), h: 9.5, twin: false },
      { spineX: -20.8, offset: -(ROAD_HALF_WIDTH + 3.4), h: 9.2, twin: true },
    ];
    birchSpecs.forEach((sp, i) => {
      const pt = roadOffsetPoint(sp.spineX, sp.offset);
      const birch = createJapaneseBirchTree(this.materials, {
        seed: 5600 + i * 83,
        height: sp.h,
        twinStem: sp.twin,
        detailLevel: i < 2 ? 'hero' : 'forest',
      });
      birch.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.16, pt.z);
      root.add(birch);
    });

    // 4. Signature Overhanging Dark Woody Limb arching in from Upper-Right Frame over the road & bank!
    const overhang = createOverhangTree(this.materials, 7777);
    const overPt = roadOffsetPoint(7.8, ROAD_HALF_WIDTH + 1.25);
    overhang.position.set(overPt.x, sampleFullForestHeight(overPt.x, overPt.z) - 0.2, overPt.z);
    root.add(overhang);

    // 5. Dense Vertical Wall of Slender Japanese Mountain Cedars (Sugi) spanning the full 62m pass!
    for (let i = 0; i < 38; i++) {
      const sx = THREE.MathUtils.lerp(-27.5, 27.5, i / 37) + randRange(rng, -0.7, 0.7);
      const off = -(ROAD_HALF_WIDTH + randRange(rng, 2.7, 7.6));
      const pt = roadOffsetPoint(sx, off);
      const cedar = createJapaneseCedarTree(this.materials, {
        seed: 2000 + i * 41,
        height: randRange(rng, 11.4, 15.8),
        trunkRadius: randRange(rng, 0.16, 0.26),
        detailLevel: 'forest',
      });
      cedar.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.25, pt.z);
      root.add(cedar);
    }

    // 5b. Dense Deep-Forest Background Trunk Wall (84 slender vertical trunks across full 62m pass!)
    const bgTrunkGeo = new THREE.CylinderGeometry(0.095, 0.21, 14.5, 7, 1);
    bgTrunkGeo.translate(0, 6.8, 0);
    const bgTrunks = new THREE.InstancedMesh(bgTrunkGeo, this.materials.cedarBark, 84);
    bgTrunks.name = 'Deep_Forest_Background_Trunks_62m';
    bgTrunks.receiveShadow = true;
    const bgDummy = new THREE.Object3D();
    for (let i = 0; i < 84; i++) {
      const sx = randRange(rng, -29.5, 29.5);
      const off = -(ROAD_HALF_WIDTH + randRange(rng, 4.5, 11.5));
      const pt = roadOffsetPoint(sx, off);
      const by = sampleFullForestHeight(pt.x, pt.z);
      bgDummy.position.set(pt.x, by - 0.35, pt.z);
      bgDummy.rotation.set(randRange(rng, -0.04, 0.04), rng() * Math.PI * 2, randRange(rng, -0.04, 0.04));
      const sr = randRange(rng, 0.62, 1.32);
      bgDummy.scale.set(sr, randRange(rng, 0.88, 1.32), sr);
      bgDummy.updateMatrix();
      bgTrunks.setMatrixAt(i, bgDummy.matrix);
    }
    bgTrunks.instanceMatrix.needsUpdate = true;
    root.add(bgTrunks);

    // 6. Lush Undergrowth Lining the Outer Shoulder across the 62m pass (Wild Shrubs, Saplings & Ferns)
    for (let i = 0; i < 24; i++) {
      const sx = THREE.MathUtils.lerp(-26.5, 26.5, i / 23) + randRange(rng, -0.6, 0.6);
      const isBackRow = i % 3 === 2;
      const off = -(ROAD_HALF_WIDTH + (isBackRow ? randRange(rng, 3.6, 4.6) : randRange(rng, 1.0, 1.5)));
      const pt = roadOffsetPoint(sx, off);
      const shrub = createWildForestShrub(this.materials, {
        seed: 3100 + i * 29,
        scale: isBackRow ? randRange(rng, 1.35, 1.65) : randRange(rng, 1.05, 1.32),
        sunlit: !isBackRow,
      });
      shrub.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.04, pt.z);
      root.add(shrub);
    }

    // Inner-wing far-left & far-right roadside shrubs framing the sweeping bends
    const innerEdgeShrubs = [-22.5, -16.2, -11.4, 8.8, 14.5, 20.8];
    innerEdgeShrubs.forEach((sx, i) => {
      const pt = roadOffsetPoint(sx, ROAD_HALF_WIDTH + randRange(rng, 2.3, 3.4));
      const shrub = createWildForestShrub(this.materials, {
        seed: 3290 + i * 19,
        scale: randRange(rng, 1.05, 1.35),
        sunlit: true,
      });
      shrub.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.04, pt.z);
      root.add(shrub);
    });

    // Young glowing backlit mountain saplings bridging the outer shoulder and upper canopy
    const saplingXList = [-21.5, -14.2, -6.1, -1.8, 1.6, 5.4, 11.2, 18.6, 24.0];
    saplingXList.forEach((sx, i) => {
      const pt = roadOffsetPoint(sx, -(ROAD_HALF_WIDTH + randRange(rng, 1.55, 1.95)));
      const sapling = createForestSapling(this.materials, {
        seed: 3600 + i * 37,
        height: randRange(rng, 2.3, 2.9),
      });
      sapling.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.05, pt.z);
      root.add(sapling);
    });

    // Woodland Ferns tucked along the 62m outer road shoulder & mossy bank rocks
    for (let i = 0; i < 18; i++) {
      const sx = THREE.MathUtils.lerp(-24.0, 24.0, i / 17) + randRange(rng, -0.5, 0.5);
      const pt = roadOffsetPoint(sx, -(ROAD_HALF_WIDTH + randRange(rng, 0.85, 1.15)));
      const fern = createWoodlandFern(this.materials, {
        seed: 3900 + i * 23,
        scale: randRange(rng, 0.92, 1.2),
      });
      fern.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.02, pt.z);
      root.add(fern);
    }
    [5.9, 7.3, 13.8, -11.6].forEach((sx, i) => {
      const pt = roadOffsetPoint(sx, ROAD_HALF_WIDTH + randRange(rng, 1.8, 3.0));
      const fern = createWoodlandFern(this.materials, { seed: 3980 + i * 17, scale: 0.92 });
      fern.position.set(pt.x, sampleFullForestHeight(pt.x, pt.z) - 0.02, pt.z);
      root.add(fern);
    });

    // 7. Clumped Wild Forest Grass & Dry Golden Thatch Sedges spanning the full 62m touge corridor!
    const grassPlacements: Array<{ x: number; z: number; scale: number; dryRatio: number }> = [];

    for (let i = 0; i < 680; i++) {
      const sx = randRange(rng, -28.5, 28.5);
      const off = -(ROAD_HALF_WIDTH + 0.32 + Math.pow(rng(), 1.35) * 4.8);
      const pt = roadOffsetPoint(sx, off);
      if (isInsideRoadCorridor(pt.x, pt.z, CURB_WIDTH, 0.25)) continue;
      grassPlacements.push({
        x: pt.x,
        z: pt.z,
        scale: randRange(rng, 0.56, 1.38),
        dryRatio: Math.abs(off) < ROAD_HALF_WIDTH + 1.15 ? 0.34 : 0.22,
      });
    }

    for (let i = 0; i < 310; i++) {
      const sx = randRange(rng, -25.0, 26.0);
      const off = ROAD_HALF_WIDTH + CURB_WIDTH + 0.22 + rng() * 5.0;
      const pt = roadOffsetPoint(sx, off);
      if (isInsideRoadCorridor(pt.x, pt.z, CURB_WIDTH + 0.16, 0.25)) continue;
      const isRightVerge = sx > 2.2 && off < ROAD_HALF_WIDTH + 2.4;
      grassPlacements.push({
        x: pt.x,
        z: pt.z,
        scale: isRightVerge ? randRange(rng, 0.55, 1.05) : randRange(rng, 0.44, 0.95),
        dryRatio: isRightVerge ? 0.32 : 0.58,
      });
    }

    const grassMesh = createInstancedForestGrass(
      this.materials,
      sampleFullForestHeight,
      grassPlacements,
      54321
    );
    root.add(grassMesh);

    this.fullSceneGroup = root;
    return root;
  }

  /**
   * Builds isolated Hero Tree Asset Showcase on a sculpted mossy root mound plinth
   */
  private getOrCreateTreeAsset(variant: TreeVariant): THREE.Group {
    if (this.treeAssetGroups[variant]) return this.treeAssetGroups[variant]!;

    const group = new THREE.Group();
    group.name = `Isolated_Tree_Asset_${variant}`;

    // Natural forest root-mound display plinth
    const plinthGeo = new THREE.CylinderGeometry(2.35, 2.55, 0.3, 56, 4);
    const pos = plinthGeo.attributes.position;
    const cols = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      if (y > 0.05) {
        const x = pos.getX(i);
        const z = pos.getZ(i);
        const r = Math.sqrt(x * x + z * z);
        pos.setY(i, y + Math.max(0, 1 - (r / 2.45) * (r / 2.45)) * 0.26);
      }
      cols[i * 3] = 0.88;
      cols[i * 3 + 1] = 0.86;
      cols[i * 3 + 2] = 0.8;
    }
    plinthGeo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
    plinthGeo.computeVertexNormals();
    const plinth = new THREE.Mesh(plinthGeo, this.materials.forestFloor);
    plinth.name = 'Tree_Root_Mound_Plinth';
    plinth.receiveShadow = true;
    plinth.castShadow = true;
    group.add(plinth);

    // Subtle decorative ferns & grass tufts around trunk roots
    const plinthHeight = (x: number, z: number) => {
      const r = Math.sqrt(x * x + z * z);
      return 0.15 + Math.max(0, 1 - (r / 2.45) * (r / 2.45)) * 0.26;
    };

    let tree: THREE.Group;
    if (variant === 'broadleaf') {
      tree = createJapaneseBroadleafTree(this.materials, {
        seed: 8801,
        height: 7.6,
        trunkRadius: 0.24,
        crownSpread: 3.9,
        sunlitRatio: 0.68,
        leanX: 0.22,
        leanZ: 0.14,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else if (variant === 'zelkova') {
      tree = createJapaneseZelkovaTree(this.materials, {
        seed: 8811,
        height: 9.2,
        trunkRadius: 0.28,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else if (variant === 'beech') {
      tree = createJapaneseBeechTree(this.materials, {
        seed: 8812,
        height: 9.6,
        trunkRadius: 0.3,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else if (variant === 'redpine') {
      tree = createJapaneseRedPineTree(this.materials, {
        seed: 8813,
        height: 8.8,
        trunkRadius: 0.25,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else if (variant === 'birch') {
      tree = createJapaneseBirchTree(this.materials, {
        seed: 8814,
        height: 9.4,
        trunkRadius: 0.17,
        twinStem: true,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else if (variant === 'cedar') {
      tree = createJapaneseCedarTree(this.materials, {
        seed: 8802,
        height: 11.4,
        trunkRadius: 0.24,
        detailLevel: 'hero',
      });
      tree.position.set(0, 0.28, 0);
    } else {
      tree = createOverhangTree(this.materials, 8803);
      tree.position.set(2.4, 0.22, 0);
    }
    group.add(tree);

    // Small base woodland ferns + tufts so roots blend organically
    const fern = createWoodlandFern(this.materials, { seed: 8850, scale: 0.75 });
    fern.position.set(0.85, plinthHeight(0.85, 0.7), 0.7);
    group.add(fern);

    const rng = createRng(8890);
    const tufts: Array<{ x: number; z: number; scale: number; dryRatio: number }> = [];
    for (let i = 0; i < 42; i++) {
      const r = randRange(rng, 0.55, 1.95);
      const a = rng() * Math.PI * 2;
      tufts.push({
        x: Math.cos(a) * r,
        z: Math.sin(a) * r,
        scale: randRange(rng, 0.55, 1.05),
        dryRatio: 0.35,
      });
    }
    group.add(createInstancedForestGrass(this.materials, plinthHeight, tufts, 8899));

    this.treeAssetGroups[variant] = group;
    return group;
  }

  private getOrCreateRoadAsset(): THREE.Group {
    if (!this.roadAssetGroup) {
      this.roadAssetGroup = createIsolatedAsphaltAsset(this.materials);
    }
    return this.roadAssetGroup;
  }

  private getOrCreateSoilAsset(): THREE.Group {
    if (!this.soilAssetGroup) {
      this.soilAssetGroup = createIsolatedSoilAsset(this.materials);
    }
    return this.soilAssetGroup;
  }

  private getOrCreateShrubAsset(): THREE.Group {
    if (!this.shrubAssetGroup) {
      this.shrubAssetGroup = createIsolatedShrubGrassAsset(this.materials);
    }
    return this.shrubAssetGroup;
  }

  /**
   * Switches between Full Forest Diorama, Isolated Tree, Soil Plinth, and Shrub/Grass Kit
   */
  public switchAssetMode(mode: AssetMode, treeVariant?: TreeVariant, instantCamera = false) {
    this.settings.assetMode = mode;
    if (treeVariant) this.settings.treeVariant = treeVariant;

    // Clear active root without disposing cached assets
    while (this.activeRoot.children.length > 0) {
      this.activeRoot.remove(this.activeRoot.children[0]);
    }

    let nextGroup: THREE.Group;
    if (mode === 'full') {
      nextGroup = this.getOrCreateFullForestScene();
    } else if (mode === 'tree') {
      nextGroup = this.getOrCreateTreeAsset(this.settings.treeVariant);
    } else if (mode === 'road') {
      nextGroup = this.getOrCreateRoadAsset();
    } else if (mode === 'soil') {
      nextGroup = this.getOrCreateSoilAsset();
    } else {
      nextGroup = this.getOrCreateShrubAsset();
    }

    this.activeRoot.add(nextGroup);

    // Adjust fog & sunbeams cleanly for isolated asset inspection vs full atmospheric forest!
    const moodCfg = MOOD_CONFIGS[this.settings.lightingMood];
    const isFull = mode === 'full';
    this.fog.density = isFull ? moodCfg.fogDensity : moodCfg.fogDensity * 0.45;
    this.sunbeamsGroup.visible = isFull && this.settings.sunbeamsVisible;
    this.pollenPoints.visible = isFull;

    // Tighten shadow camera for razor-sharp close-up shadows in isolated modes & wider frustum for 2x road!
    const shadowBound = isFull ? 22.0 : mode === 'tree' ? 8.5 : mode === 'road' ? 7.8 : 4.5;
    this.sunLight.shadow.camera.left = -shadowBound;
    this.sunLight.shadow.camera.right = shadowBound;
    this.sunLight.shadow.camera.top = shadowBound + (mode === 'tree' ? 6 : 2);
    this.sunLight.shadow.camera.bottom = -shadowBound;
    this.sunLight.shadow.camera.updateProjectionMatrix();

    // Reapply current shading inspection mode
    this.setShadingMode(this.settings.shadingMode);

    // Frame camera ideally for the selected 3D asset!
    if (mode === 'full') {
      this.setCameraTarget(
        new THREE.Vector3(2.2, 2.15, 9.1),
        new THREE.Vector3(-0.5, 2.05, -2.9),
        instantCamera
      );
    } else if (mode === 'tree') {
      const isTall =
        this.settings.treeVariant === 'cedar' ||
        this.settings.treeVariant === 'beech' ||
        this.settings.treeVariant === 'zelkova' ||
        this.settings.treeVariant === 'birch';
      this.setCameraTarget(
        new THREE.Vector3(isTall ? 8.0 : 6.8, isTall ? 5.2 : 4.2, isTall ? 9.6 : 8.2),
        new THREE.Vector3(0, isTall ? 4.8 : 3.8, 0),
        instantCamera
      );
    } else if (mode === 'road') {
      // Dramatic wide 3/4 showcase framing showing the entire 2x-longer 11.4m sweeping S-bend asphalt!
      this.setCameraTarget(
        new THREE.Vector3(6.8, 3.65, 8.6),
        new THREE.Vector3(0, 0.25, 0.45),
        instantCamera
      );
    } else if (mode === 'soil') {
      this.setCameraTarget(
        new THREE.Vector3(2.9, 2.35, 3.65),
        new THREE.Vector3(0, 0.24, 0),
        instantCamera
      );
    } else {
      this.setCameraTarget(
        new THREE.Vector3(2.75, 1.85, 3.85),
        new THREE.Vector3(0, 0.72, -0.1),
        instantCamera
      );
    }

    this.emitTelemetry();
  }

  public applyCameraPreset(preset: CameraPreset) {
    if (this.settings.assetMode !== 'full') {
      this.switchAssetMode('full', this.settings.treeVariant, false);
    }
    if (preset === 'reference') {
      this.setCameraTarget(
        new THREE.Vector3(2.2, 2.15, 9.1),
        new THREE.Vector3(-0.5, 2.05, -2.9),
        false
      );
    } else if (preset === 'tougeRoad') {
      // Sweeping low-angle touge highway view showcasing the full 2x-longer 62m curving mountain road!
      this.setCameraTarget(
        new THREE.Vector3(-12.5, 1.65, 4.9),
        new THREE.Vector3(7.5, 1.6, -1.6),
        false
      );
    } else if (preset === 'macroSoil') {
      this.setCameraTarget(
        new THREE.Vector3(2.15, 1.72, 6.7),
        new THREE.Vector3(0.45, 0.75, 4.45),
        false
      );
    } else if (preset === 'canopyBacklight') {
      this.setCameraTarget(
        new THREE.Vector3(-0.2, 1.9, 2.4),
        new THREE.Vector3(-3.2, 5.9, -4.8),
        false
      );
    } else if (preset === 'aerial') {
      this.setCameraTarget(
        new THREE.Vector3(10.5, 9.6, 12.2),
        new THREE.Vector3(-0.4, 1.6, -1.2),
        false
      );
    }
  }

  private setCameraTarget(pos: THREE.Vector3, target: THREE.Vector3, instant: boolean) {
    if (instant) {
      this.camera.position.copy(pos);
      this.controls.target.copy(target);
      this.controls.update();
      this.cameraGoal.active = false;
    } else {
      this.cameraGoal.pos.copy(pos);
      this.cameraGoal.target.copy(target);
      this.cameraGoal.active = true;
    }
  }

  /**
   * Updates Lighting Mood Preset + HDRI Sky Environment Map
   */
  public applyLightingMood(mood: LightingMood, rebuildEnv = true) {
    this.settings.lightingMood = mood;
    const cfg = MOOD_CONFIGS[mood];

    this.settings.sunAzimuth = cfg.azimuth;
    this.settings.sunElevation = cfg.elevation;
    this.settings.exposure = cfg.exposure;
    this.settings.bloomStrength = cfg.bloomStrength;

    this.sunLight.color.set(cfg.sunColor);
    this.sunLight.intensity = cfg.sunIntensity;
    this.materials.uniforms.uSunColor.value.set(cfg.sunColor);

    this.hemiLight.color.set(cfg.hemiSky);
    this.hemiLight.groundColor.set(cfg.hemiGround);
    this.hemiLight.intensity = cfg.hemiIntensity;

    this.bounceLight.color.set(cfg.bounceColor);
    this.bounceLight.intensity = cfg.bounceIntensity;

    this.fog.color.set(cfg.fogColor);
    this.fog.density =
      this.settings.assetMode === 'full' ? cfg.fogDensity : cfg.fogDensity * 0.45;

    this.renderer.toneMappingExposure = cfg.exposure;
    this.bloomPass.strength = cfg.bloomStrength;
    this.materials.sunbeam.uniforms.uOpacity.value = cfg.sunbeamOpacity;
    this.scene.environmentIntensity = cfg.envIntensity;

    this.updateSunPosition(cfg.azimuth, cfg.elevation, rebuildEnv);
  }

  /**
   * Updates live Sun Direction, Sunbeam tilt, Backlit SSS shader uniform, and debounced Sky HDRI!
   */
  public updateSunPosition(azimuthDeg: number, elevationDeg: number, rebuildEnvImmediate = false) {
    this.settings.sunAzimuth = azimuthDeg;
    this.settings.sunElevation = elevationDeg;

    const az = THREE.MathUtils.degToRad(azimuthDeg);
    const el = THREE.MathUtils.degToRad(elevationDeg);
    const dist = 24;

    const dir = new THREE.Vector3(
      Math.cos(el) * Math.sin(az),
      Math.sin(el),
      Math.cos(el) * Math.cos(az)
    ).normalize();

    this.sunLight.position.copy(dir).multiplyScalar(dist);
    this.sunLight.target.position.set(0, 1.5, -1.0);
    this.materials.uniforms.uSunDirection.value.copy(dir);

    // Orient volumetric god-ray sunbeams to physically match the live sun angle!
    const up = new THREE.Vector3(0, 1, 0);
    const beamQuat = new THREE.Quaternion().setFromUnitVectors(up, dir);
    this.sunbeamsGroup.children.forEach((child) => {
      child.quaternion.copy(beamQuat);
    });

    if (rebuildEnvImmediate) {
      this.rebuildSkyEnvironment();
    } else {
      if (this.envRebuildTimer !== null) window.clearTimeout(this.envRebuildTimer);
      this.envRebuildTimer = window.setTimeout(() => this.rebuildSkyEnvironment(), 140);
    }
  }

  private rebuildSkyEnvironment() {
    if (this.disposed) return;
    const skyTex = createForestSkyEquirectTexture(
      this.settings.lightingMood,
      this.settings.sunAzimuth,
      this.settings.sunElevation
    );
    const envRT = this.pmrem.fromEquirectangular(skyTex);

    if (this.currentEnvRT) this.currentEnvRT.dispose();
    if (this.currentSkyTex) this.currentSkyTex.dispose();

    this.currentEnvRT = envRT;
    this.currentSkyTex = skyTex;
    this.scene.environment = envRT.texture;
    this.scene.background = skyTex;
    this.scene.backgroundBlurriness = 0.08;
  }

  public setWindStrength(val: number) {
    this.settings.windStrength = val;
    this.materials.uniforms.uWindStrength.value = val;
  }

  public setTranslucency(val: number) {
    this.settings.translucency = val;
    this.materials.uniforms.uTranslucency.value = val;
  }

  public setExposure(val: number) {
    this.settings.exposure = val;
    this.renderer.toneMappingExposure = val;
  }

  public setBloomStrength(val: number) {
    this.settings.bloomStrength = val;
    this.bloomPass.strength = val;
  }

  public setSunbeamsVisible(visible: boolean) {
    this.settings.sunbeamsVisible = visible;
    this.sunbeamsGroup.visible = visible && this.settings.assetMode === 'full';
  }

  public setAutoRotate(enabled: boolean) {
    this.settings.autoRotate = enabled;
    this.controls.autoRotate = enabled;
    this.controls.autoRotateSpeed = 0.9;
  }

  /**
   * Switches PBR Asset Inspection View Mode (Beauty / Wireframe / Clay / Normal)
   */
  public setShadingMode(mode: ViewShadingMode) {
    this.settings.shadingMode = mode;

    // Reset scene override & wireframe flags
    this.scene.overrideMaterial = null;
    for (const mat of this.materials.allStandardMaterials) {
      mat.wireframe = mode === 'wireframe';
    }
    this.activeRoot.traverse((obj) => {
      if (obj instanceof THREE.Mesh && obj.material instanceof THREE.MeshStandardMaterial) {
        obj.material.wireframe = mode === 'wireframe';
      }
    });

    if (mode === 'clay') {
      this.scene.overrideMaterial = this.clayMaterial;
    } else if (mode === 'normal') {
      this.scene.overrideMaterial = this.normalMaterial;
    }
  }

  /**
   * Captures a clean HD PNG snapshot directly from the WebGL HDR composer
   */
  public captureSnapshotPNG(): string {
    this.composer.render();
    return this.renderer.domElement.toDataURL('image/png');
  }

  /**
   * Exports the currently viewed 3D Asset (Full Forest, Hero Tree, Soil Plinth, or Shrub/Grass Kit)
   * as a genuine binary `.glb` file ready for Blender, Unreal Engine 5, or Unity!
   */
  public async exportCurrentAssetGLB(): Promise<void> {
    const exporter = new GLTFExporter();
    const target = this.activeRoot;

    // Temporarily ensure beauty mode so exported materials retain full PBR maps!
    const prevMode = this.settings.shadingMode;
    if (prevMode !== 'beauty') this.setShadingMode('beauty');

    return new Promise((resolve, reject) => {
      exporter.parse(
        target,
        (result) => {
          if (prevMode !== 'beauty') this.setShadingMode(prevMode);
          if (result instanceof ArrayBuffer) {
            const blob = new Blob([result], { type: 'model/gltf-binary' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            const label =
              this.settings.assetMode === 'tree'
                ? `touge-tree-${this.settings.treeVariant}`
                : this.settings.assetMode === 'road'
                  ? 'touge-asphalt-road'
                  : `touge-forest-${this.settings.assetMode}`;
            a.href = url;
            a.download = `${label}-asset.glb`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 4000);
            resolve();
          } else {
            reject(new Error('Expected binary GLB output'));
          }
        },
        (err) => {
          if (prevMode !== 'beauty') this.setShadingMode(prevMode);
          reject(err);
        },
        { binary: true, maxTextureSize: 1024 }
      );
    });
  }

  private emitTelemetry() {
    if (!this.onTelemetry) return;

    let instancedObjects = 0;
    this.activeRoot.traverse((obj) => {
      if (obj instanceof THREE.InstancedMesh) {
        instancedObjects += obj.count;
      }
    });

    const treeVariantNames: Record<TreeVariant, string> = {
      broadleaf: 'Japanese Mountain Maple (Momiji · Acer palmatum)',
      zelkova: 'Japanese Zelkova (Keyaki · Zelkova serrata)',
      beech: 'Japanese Mountain Beech (Buna · Fagus crenata)',
      redpine: 'Japanese Red Pine (Akamatsu · Pinus densiflora)',
      birch: 'Japanese White Birch (Shirakaba · Betula platyphylla)',
      cedar: 'Japanese Mountain Cedar (Sugi · Cryptomeria japonica)',
      overhang: 'Overhanging Touge Roadside Hardwood Bough',
    };

    const assetNames: Record<AssetMode, string> = {
      full: 'Japanese Touge 62m Mountain Road & 7-Species Forest',
      tree: treeVariantNames[this.settings.treeVariant],
      road: '2× Sweeping Touge Asphalt Road & Concrete Curb (11.4m)',
      soil: 'Forest Floor Mulch & Fallen Leaves Tile',
      shrub: 'Woodland Shrub, Fern & Wild Grass Kit',
    };

    this.onTelemetry({
      fps: Math.round(this.currentFps),
      triangles: this.renderer.info.render.triangles,
      drawCalls: this.renderer.info.render.calls,
      instancedObjects,
      assetName: assetNames[this.settings.assetMode],
    });
  }

  private handleResize() {
    if (this.disposed) return;
    const width = Math.max(1, this.container.clientWidth);
    const height = Math.max(1, this.container.clientHeight);

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
    this.composer.setSize(width, height);
    this.bloomPass.setSize(width, height);
  }

  private animate = (now: number) => {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.animate);

    const dt = Math.min(0.05, (now - this.lastTime) / 1000);
    this.lastTime = now;
    this.elapsedTime += dt;

    // Update live wind & sunbeam shader clock
    this.materials.uniforms.uTime.value = this.elapsedTime;

    // Gentle buoyant forest pollen drift
    if (this.pollenPoints.visible) {
      this.pollenPoints.rotation.y = this.elapsedTime * 0.015;
      this.pollenPoints.position.y = Math.sin(this.elapsedTime * 0.45) * 0.14;
    }

    // Smooth exponential camera framing interpolation
    if (this.cameraGoal.active) {
      const alpha = 1 - Math.exp(-5.5 * dt);
      this.camera.position.lerp(this.cameraGoal.pos, alpha);
      this.controls.target.lerp(this.cameraGoal.target, alpha);
      if (
        this.camera.position.distanceTo(this.cameraGoal.pos) < 0.025 &&
        this.controls.target.distanceTo(this.cameraGoal.target) < 0.025
      ) {
        this.cameraGoal.active = false;
      }
    }

    this.controls.update();
    this.composer.render();

    // Update telemetry at ~2Hz
    this.frameCounter++;
    this.fpsAccum += dt;
    if (this.fpsAccum >= 0.5) {
      this.currentFps = this.frameCounter / this.fpsAccum;
      this.frameCounter = 0;
      this.fpsAccum = 0;
      this.emitTelemetry();
    }
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    if (this.envRebuildTimer !== null) window.clearTimeout(this.envRebuildTimer);
    this.resizeObserver.disconnect();
    this.controls.dispose();

    const disposeGroup = (g: THREE.Object3D | null | undefined) => {
      if (!g) return;
      g.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) {
          obj.geometry?.dispose();
        }
      });
    };
    disposeGroup(this.fullSceneGroup);
    disposeGroup(this.roadAssetGroup);
    disposeGroup(this.soilAssetGroup);
    disposeGroup(this.shrubAssetGroup);
    Object.values(this.treeAssetGroups).forEach((g) => disposeGroup(g));
    disposeGroup(this.sunbeamsGroup);
    disposeGroup(this.pollenPoints);

    this.clayMaterial.dispose();
    this.normalMaterial.dispose();
    this.materials.dispose();
    this.textures.dispose();
    if (this.currentEnvRT) this.currentEnvRT.dispose();
    if (this.currentSkyTex) this.currentSkyTex.dispose();
    this.pmrem.dispose();
    this.composer.dispose();
    this.renderer.dispose();

    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
