import * as THREE from 'three';
import { createRng, randRange, tileableFbm2D } from './noise';

export interface PBRTextureSet {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
}

export interface StudioTextureLibrary {
  forestFloor: PBRTextureSet;
  hardwoodBark: PBRTextureSet;
  cedarBark: PBRTextureSet;
  beechBark: PBRTextureSet;
  pineBark: PBRTextureSet;
  birchBark: PBRTextureSet;
  canopyBright: PBRTextureSet;
  canopyDeep: PBRTextureSet;
  zelkovaLeaf: PBRTextureSet;
  pineNeedles: PBRTextureSet;
  birchLeaf: PBRTextureSet;
  cedarFrond: PBRTextureSet;
  shrubLeaf: PBRTextureSet;
  fernFrond: PBRTextureSet;
  dryLeafCard: PBRTextureSet;
  grassBlade: PBRTextureSet;
  mossyRock: PBRTextureSet;
  weatheredCurb: PBRTextureSet;
  asphalt: PBRTextureSet;
  skyEnvEquirect: THREE.CanvasTexture;
  dispose: () => void;
}

function configureTexture(
  canvas: HTMLCanvasElement,
  isColor: boolean,
  repeat = false,
  anisotropy = 8
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  if (repeat) {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
  } else {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
  }
  tex.anisotropy = anisotropy;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Generates an OpenGL tangent-space Normal Map from a grayscale height canvas using Sobel filter.
 */
function heightToNormalCanvas(
  heightCanvas: HTMLCanvasElement,
  strength: number,
  wrap: boolean
): HTMLCanvasElement {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const srcCtx = heightCanvas.getContext('2d')!;
  const src = srcCtx.getImageData(0, 0, w, h).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = w;
  outCanvas.height = h;
  const outCtx = outCanvas.getContext('2d')!;
  const outImg = outCtx.createImageData(w, h);
  const dst = outImg.data;

  const sample = (x: number, y: number): number => {
    let sx = x;
    let sy = y;
    if (wrap) {
      sx = ((x % w) + w) % w;
      sy = ((y % h) + h) % h;
    } else {
      sx = Math.max(0, Math.min(w - 1, x));
      sy = Math.max(0, Math.min(h - 1, y));
    }
    return src[(sy * w + sx) * 4] / 255;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dx = (tr + 2 * r + br - (tl + 2 * l + bl)) * strength;
      const dy = (bl + 2 * b + br - (tl + 2 * t + tr)) * strength;
      const dz = 1.0;

      const invLen = 1.0 / Math.sqrt(dx * dx + dy * dy + dz * dz);
      const nx = -dx * invLen;
      const ny = -dy * invLen;
      const nz = dz * invLen;

      const idx = (y * w + x) * 4;
      dst[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }

  outCtx.putImageData(outImg, 0, 0);
  return outCanvas;
}

/**
 * Helper to draw a tiled shape seamlessly across a square canvas of size S.
 */
function drawWrapped(
  size: number,
  x: number,
  y: number,
  margin: number,
  drawFn: (ox: number, oy: number) => void
) {
  const oxList = [0];
  const oyList = [0];
  if (x < margin) oxList.push(size);
  if (x > size - margin) oxList.push(-size);
  if (y < margin) oyList.push(size);
  if (y > size - margin) oyList.push(-size);

  for (let i = 0; i < oxList.length; i++) {
    for (let j = 0; j < oyList.length; j++) {
      drawFn(x + oxList[i], y + oyList[j]);
    }
  }
}

/**
 * 1. PHOTOREALISTIC FOREST FLOOR MULCH, PINE NEEDLES & DRY FALLEN LEAVES (1024x1024 seamless PBR)
 * Carefully color-matched to the foreground roadside embankment in the reference photo!
 */
function createForestFloorPBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(202604);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  // Layer 1: Pixel-level humus dark loam topsoil with organic moisture variation
  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const macro = tileableFbm2D(u, v, 6, 4, 301);
      const micro = tileableFbm2D(u, v, 24, 3, 719);
      const grit = tileableFbm2D(u, v, 64, 2, 911);

      const val = macro * 0.55 + micro * 0.3 + grit * 0.15;
      const mossMask = Math.max(0, tileableFbm2D(u, v, 5, 3, 444) - 0.62) * 2.2;

      const idx = (y * size + x) * 4;
      // Deep damp dark-earth loam (#281d14 -> #4a3523)
      let r = 34 + val * 44;
      let g = 25 + val * 32;
      let b = 17 + val * 22;

      if (mossMask > 0) {
        r = r * (1 - mossMask * 0.35) + 46 * (mossMask * 0.35);
        g = g * (1 - mossMask * 0.35) + 60 * (mossMask * 0.35);
        b = b * (1 - mossMask * 0.35) + 25 * (mossMask * 0.35);
      }

      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(35 + val * 70);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      // Damp humus roughness (~0.74 - 0.90)
      const rVal = Math.round(188 + (1 - val) * 45);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  // Layer 2: Dense matted dry pine needles & straw thatch fibers (lower mat)
  const needlePalettes = [
    '#5c3e24',
    '#6e4b2c',
    '#7c5936',
    '#8c6b43',
    '#49321e',
    '#9d7e54',
    '#3d2918',
    '#a88c63',
  ];

  const drawNeedles = (count: number, minH: number, maxH: number) => {
    for (let i = 0; i < count; i++) {
      const x = rng() * size;
      const y = rng() * size;
      const len = randRange(rng, 18, 52);
      const angle = rng() * Math.PI * 2;
      const bend = randRange(rng, -8, 8);
      const width = randRange(rng, 0.9, 2.2);
      const col = needlePalettes[Math.floor(rng() * needlePalettes.length)];
      const hShade = Math.round(randRange(rng, minH, maxH));
      const rShade = Math.round(randRange(rng, 205, 240));

      drawWrapped(size, x, y, len + 8, (ox, oy) => {
        const ex = ox + Math.cos(angle) * len;
        const ey = oy + Math.sin(angle) * len;
        const cx = (ox + ex) * 0.5 - Math.sin(angle) * bend;
        const cy = (oy + ey) * 0.5 + Math.cos(angle) * bend;

        // Subtle dark contact AO shadow
        aCtx.strokeStyle = 'rgba(18, 11, 6, 0.35)';
        aCtx.lineWidth = width + 1.4;
        aCtx.lineCap = 'round';
        aCtx.beginPath();
        aCtx.moveTo(ox + 1.2, oy + 1.6);
        aCtx.quadraticCurveTo(cx + 1.2, cy + 1.6, ex + 1.2, ey + 1.6);
        aCtx.stroke();

        // Main pine needle color
        aCtx.strokeStyle = col;
        aCtx.lineWidth = width;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.quadraticCurveTo(cx, cy, ex, ey);
        aCtx.stroke();

        // Height fiber
        hCtx.strokeStyle = `rgb(${hShade},${hShade},${hShade})`;
        hCtx.lineWidth = width + 0.6;
        hCtx.lineCap = 'round';
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.quadraticCurveTo(cx, cy, ex, ey);
        hCtx.stroke();

        // Roughness
        rCtx.strokeStyle = `rgb(${rShade},${rShade},${rShade})`;
        rCtx.lineWidth = width + 0.5;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.quadraticCurveTo(cx, cy, ex, ey);
        rCtx.stroke();
      });
    }
  };

  drawNeedles(2600, 75, 130);

  // Layer 3: Hundreds of layered fallen dried oak/beech/maple leaves (exact reference look!)
  const leafColors = [
    { base: '#6f4827', edge: '#4d3018', vein: '#855c37' }, // rich chestnut brown
    { base: '#8a5d34', edge: '#5f3c1e', vein: '#a37548' }, // warm dry russet
    { base: '#b6976c', edge: '#896d49', vein: '#ccb088' }, // sun-bleached tan (signature ref tone!)
    { base: '#c9b28a', edge: '#967e59', vein: '#dfd0ae' }, // pale parchment dry leaf
    { base: '#573a21', edge: '#372312', vein: '#6c492b' }, // damp decomposed brown
    { base: '#9e7446', edge: '#6f4f2c', vein: '#b58b5c' }, // golden dry beech leaf
    { base: '#4a3523', edge: '#2b1d12', vein: '#5d442e' }, // deep forest umber
    { base: '#7d633d', edge: '#554126', vein: '#947950' }, // weathered olive-tan
  ];

  const drawDryLeafShape = (
    ctx: CanvasRenderingContext2D,
    len: number,
    wid: number,
    curl: number
  ) => {
    ctx.beginPath();
    ctx.moveTo(-len * 0.5, 0);
    ctx.bezierCurveTo(
      -len * 0.25,
      -wid * (0.95 + curl * 0.2),
      len * 0.22,
      -wid * (0.75 - curl * 0.15),
      len * 0.52,
      curl * wid * 0.25
    );
    ctx.bezierCurveTo(
      len * 0.22,
      wid * (0.85 + curl * 0.15),
      -len * 0.25,
      wid * (0.9 - curl * 0.2),
      -len * 0.5,
      0
    );
    ctx.closePath();
  };

  const leafCount = 1550;
  for (let i = 0; i < leafCount; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 16, 44);
    const wid = len * randRange(rng, 0.28, 0.52);
    const angle = rng() * Math.PI * 2;
    const curl = randRange(rng, -0.6, 0.6);
    const pal = leafColors[Math.floor(rng() * leafColors.length)];
    // Progressive layering height so top leaves stand crisply above lower leaves
    const progress = i / leafCount;
    const hBase = Math.round(95 + progress * 135);
    const rShade = Math.round(randRange(rng, 175, 232));

    drawWrapped(size, x, y, len + 12, (ox, oy) => {
      // Albedo pass
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(angle);

      // Soft contact AO shadow beneath leaf
      aCtx.save();
      aCtx.translate(2.0, 2.5);
      drawDryLeafShape(aCtx, len * 1.03, wid * 1.03, curl);
      aCtx.fillStyle = 'rgba(14, 9, 4, 0.42)';
      aCtx.fill();
      aCtx.restore();

      // Gradient fill across leaf for curled surface shading
      const grad = aCtx.createLinearGradient(0, -wid, 0, wid);
      grad.addColorStop(0, pal.edge);
      grad.addColorStop(0.45, pal.base);
      grad.addColorStop(0.8, pal.vein);
      grad.addColorStop(1, pal.edge);
      drawDryLeafShape(aCtx, len, wid, curl);
      aCtx.fillStyle = grad;
      aCtx.fill();

      // Dark crisp leaf border
      aCtx.strokeStyle = pal.edge;
      aCtx.lineWidth = 0.85;
      aCtx.stroke();

      // Midrib + delicate veins
      aCtx.strokeStyle = pal.vein;
      aCtx.lineWidth = 0.8;
      aCtx.beginPath();
      aCtx.moveTo(-len * 0.48, 0);
      aCtx.quadraticCurveTo(0, curl * wid * 0.15, len * 0.48, curl * wid * 0.22);
      aCtx.stroke();

      aCtx.restore();

      // Height pass (curled leaf ridge + raised edge for crisp Normal map!)
      hCtx.save();
      hCtx.translate(ox, oy);
      hCtx.rotate(angle);
      const hGrad = hCtx.createLinearGradient(0, -wid, 0, wid);
      const hLow = Math.max(20, hBase - 38);
      const hHigh = Math.min(255, hBase + 22);
      hGrad.addColorStop(0, `rgb(${hHigh},${hHigh},${hHigh})`);
      hGrad.addColorStop(0.45, `rgb(${hLow},${hLow},${hLow})`);
      hGrad.addColorStop(0.55, `rgb(${hBase},${hBase},${hBase})`);
      hGrad.addColorStop(1, `rgb(${hHigh},${hHigh},${hHigh})`);
      drawDryLeafShape(hCtx, len, wid, curl);
      hCtx.fillStyle = hGrad;
      hCtx.fill();
      hCtx.restore();

      // Roughness pass
      rCtx.save();
      rCtx.translate(ox, oy);
      rCtx.rotate(angle);
      drawDryLeafShape(rCtx, len, wid, curl);
      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fill();
      rCtx.restore();
    });

    // Interleave upper dry pine needles on top of leaves for natural matted look
    if (i === 950) {
      drawNeedles(1200, 145, 220);
    }
  }

  // Layer 4: Scattered fine broken twigs & weathered bark fragments
  for (let i = 0; i < 95; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const len = randRange(rng, 22, 75);
    const angle = rng() * Math.PI * 2;
    const thick = randRange(rng, 2.0, 4.8);
    const twigCol = rng() > 0.45 ? '#6e5c4a' : '#897a68';

    drawWrapped(size, x, y, len + 10, (ox, oy) => {
      const ex = ox + Math.cos(angle) * len;
      const ey = oy + Math.sin(angle) * len;
      const mx = (ox + ex) * 0.5 + randRange(rng, -5, 5);
      const my = (oy + ey) * 0.5 + randRange(rng, -5, 5);

      aCtx.strokeStyle = 'rgba(12, 8, 5, 0.5)';
      aCtx.lineWidth = thick + 2;
      aCtx.lineCap = 'round';
      aCtx.beginPath();
      aCtx.moveTo(ox + 2, oy + 2.5);
      aCtx.lineTo(mx + 2, my + 2.5);
      aCtx.lineTo(ex + 2, ey + 2.5);
      aCtx.stroke();

      aCtx.strokeStyle = twigCol;
      aCtx.lineWidth = thick;
      aCtx.beginPath();
      aCtx.moveTo(ox, oy);
      aCtx.lineTo(mx, my);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      hCtx.strokeStyle = 'rgb(245,245,245)';
      hCtx.lineWidth = thick + 1;
      hCtx.lineCap = 'round';
      hCtx.beginPath();
      hCtx.moveTo(ox, oy);
      hCtx.lineTo(mx, my);
      hCtx.lineTo(ex, ey);
      hCtx.stroke();
    });
  }

  // Subtle top scatter of tiny moss specks & pale dry highlights
  drawNeedles(650, 195, 248);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.8, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 2. PHOTOREALISTIC FURROWED TREE BARK PBR (Hardwood Oak/Maple & Japanese Cedar)
 */
function createBarkPBR(
  variant: 'hardwood' | 'cedar' | 'beech' | 'pine' | 'birch',
  anisotropy: number
): PBRTextureSet {
  const w = 512;
  const h = 1024;
  const seedMap = { hardwood: 505, cedar: 808, beech: 612, pine: 733, birch: 941 };
  const seed = seedMap[variant];

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = w;
  heightCanvas.height = h;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = w;
  roughCanvas.height = h;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(w, h);
  const hImg = hCtx.createImageData(w, h);
  const rImg = rCtx.createImageData(w, h);

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const u = x / w;
      const v = y / h;

      // Vertically stretched fissures + horizontal bark plate breaks
      const warp = (tileableFbm2D(u, v, 4, 3, seed + 13) - 0.5) * 0.08;
      const uWarped = (u + warp + 1) % 1;

      const verticalRibs = tileableFbm2D(
        uWarped,
        v * 0.25,
        variant === 'cedar' ? 22 : 14,
        4,
        seed
      );
      const ridge = 1.0 - Math.abs(verticalRibs * 2.0 - 1.0);
      const fissure = Math.pow(ridge, variant === 'cedar' ? 1.55 : 1.9);

      const plateBreaks = tileableFbm2D(u, v, 10, 3, seed + 77);
      const micro = tileableFbm2D(u, v, 36, 2, seed + 199);

      const height = Math.max(
        0,
        Math.min(1, fissure * 0.65 + plateBreaks * 0.22 + micro * 0.13)
      );

      // Subtle lichen and forest moss on bark
      const mossPatch = Math.max(
        0,
        tileableFbm2D(u, v, 6, 3, seed + 333) - 0.58
      ) * 2.4;
      const lichenPatch = Math.max(
        0,
        tileableFbm2D(u, v, 9, 2, seed + 444) - 0.68
      ) * 2.8;

      let r: number;
      let g: number;
      let b: number;

      if (variant === 'hardwood') {
        // Cool dark grey-brown mountain maple / zelkova bark with warm subtle inner lenticel flecks
        r = 38 + height * 56;
        g = 33 + height * 48;
        b = 28 + height * 41;
      } else if (variant === 'cedar') {
        // Warm deep reddish-brown Japanese sugi cedar fibrous bark
        r = 42 + height * 58;
        g = 28 + height * 40;
        b = 20 + height * 28;
      } else if (variant === 'beech') {
        // Smooth silvery-ash Japanese mountain beech (Buna / Fagus crenata) bark
        const horizRipple = tileableFbm2D(u * 0.5, v * 3.0, 12, 3, seed + 51);
        const smoothTone = 0.58 + horizRipple * 0.25 + micro * 0.17;
        r = 78 + smoothTone * 54;
        g = 80 + smoothTone * 53;
        b = 76 + smoothTone * 49;
      } else if (variant === 'pine') {
        // Iconic Japanese Red Pine (Akamatsu) scaly warm reddish-orange & dark fissured bark
        const plates = tileableFbm2D(uWarped, v * 0.45, 10, 3, seed + 29);
        const plateMask = Math.max(0, Math.min(1, (plates - 0.32) * 2.4));
        const darkCreviceR = 44 + height * 26;
        const darkCreviceG = 31 + height * 18;
        const darkCreviceB = 24 + height * 14;
        const redPlateR = 112 + height * 62;
        const redPlateG = 58 + height * 36;
        const redPlateB = 34 + height * 22;
        r = darkCreviceR * (1 - plateMask) + redPlateR * plateMask;
        g = darkCreviceG * (1 - plateMask) + redPlateG * plateMask;
        b = darkCreviceB * (1 - plateMask) + redPlateB * plateMask;
      } else {
        // Japanese White Birch (Shirakaba) papery cream-white bark with dark horizontal lenticels!
        const paperVar = tileableFbm2D(u, v, 8, 3, seed + 17);
        const lenticelBand = tileableFbm2D(u * 0.35, v * 5.5, 16, 3, seed + 88);
        const lenticelDash = tileableFbm2D(u * 2.2, v * 12.0, 14, 2, seed + 144);
        const isLenticel = lenticelBand > 0.67 && lenticelDash > 0.55;
        const darkKnot = tileableFbm2D(u, v, 6, 3, seed + 212) > 0.77;
        r = 166 + paperVar * 38;
        g = 161 + paperVar * 36;
        b = 150 + paperVar * 34;
        if (isLenticel) {
          r *= 0.32;
          g *= 0.3;
          b *= 0.28;
        } else if (darkKnot) {
          r *= 0.24;
          g *= 0.22;
          b *= 0.2;
        }
      }

      // Moss crevices (stronger on hardwood/beech/cedar, very light on birch)
      const mossScale = variant === 'birch' ? 0.22 : variant === 'beech' ? 0.78 : 0.65;
      if (mossPatch > 0) {
        const m = Math.min(mossScale, mossPatch * (1.1 - height * 0.45));
        r = r * (1 - m) + 46 * m;
        g = g * (1 - m) + 67 * m;
        b = b * (1 - m) + 27 * m;
      }
      // Subtle pale grey-green mountain lichen flecks on beech & hardwood ridges
      if (lichenPatch > 0 && height > 0.48 && variant !== 'birch') {
        const l = Math.min(variant === 'beech' ? 0.52 : 0.38, lichenPatch);
        r = r * (1 - l) + 122 * l;
        g = g * (1 - l) + 130 * l;
        b = b * (1 - l) + 110 * l;
      }

      const idx = (y * w + x) * 4;
      aImg.data[idx] = Math.min(255, Math.max(0, r));
      aImg.data[idx + 1] = Math.min(255, Math.max(0, g));
      aImg.data[idx + 2] = Math.min(255, Math.max(0, b));
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(height * 255);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      const rVal = Math.round(205 + (1 - height) * 45);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 3.6, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * Helper: Paints a single hyper-detailed botanical serrated/pointed leaf blade with midrib & veins
 */
function paintBotanicalLeaf(
  aCtx: CanvasRenderingContext2D,
  hCtx: CanvasRenderingContext2D,
  rCtx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  length: number,
  width: number,
  colorBase: string,
  colorTip: string,
  colorVein: string,
  lobed: boolean,
  heightLevel: number
) {
  const drawLeafOutline = (ctx: CanvasRenderingContext2D) => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    if (lobed) {
      // Japanese maple / broadleaved serrated 3-5 lobe inspired organic leaf
      ctx.bezierCurveTo(length * 0.15, -width * 0.55, length * 0.32, -width * 0.85, length * 0.48, -width * 0.48);
      ctx.bezierCurveTo(length * 0.62, -width * 0.65, length * 0.82, -width * 0.35, length, 0);
      ctx.bezierCurveTo(length * 0.82, width * 0.35, length * 0.62, width * 0.65, length * 0.48, width * 0.48);
      ctx.bezierCurveTo(length * 0.32, width * 0.85, length * 0.15, width * 0.55, 0, 0);
    } else {
      // Crisp pointed beech / zelkova serrated woodland leaf
      ctx.bezierCurveTo(length * 0.22, -width * 0.68, length * 0.66, -width * 0.58, length, 0);
      ctx.bezierCurveTo(length * 0.66, width * 0.58, length * 0.22, width * 0.68, 0, 0);
    }
    ctx.closePath();
  };

  // Albedo
  aCtx.save();
  aCtx.translate(x, y);
  aCtx.rotate(angle);

  const grad = aCtx.createLinearGradient(0, 0, length, 0);
  grad.addColorStop(0, colorBase);
  grad.addColorStop(0.58, colorTip);
  grad.addColorStop(1, colorTip);

  drawLeafOutline(aCtx);
  aCtx.fillStyle = grad;
  aCtx.fill();

  // Subtle top-half sunlight shading across midrib fold
  aCtx.save();
  aCtx.clip();
  aCtx.fillStyle = 'rgba(255, 255, 210, 0.11)';
  aCtx.fillRect(0, -width, length, width);
  aCtx.fillStyle = 'rgba(10, 28, 6, 0.12)';
  aCtx.fillRect(0, 0, length, width);
  aCtx.restore();

  // Central midrib + feather lateral veins
  aCtx.strokeStyle = colorVein;
  aCtx.lineWidth = Math.max(1.0, width * 0.045);
  aCtx.beginPath();
  aCtx.moveTo(0, 0);
  aCtx.lineTo(length * 0.94, 0);
  aCtx.stroke();

  aCtx.lineWidth = Math.max(0.65, width * 0.024);
  for (let v = 1; v <= 5; v++) {
    const t = v / 6.2;
    const vx = length * t;
    const span = width * (0.48 - Math.abs(t - 0.45) * 0.55);
    aCtx.beginPath();
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, -span);
    aCtx.moveTo(vx, 0);
    aCtx.lineTo(vx + length * 0.14, span);
    aCtx.stroke();
  }
  aCtx.restore();

  // Height (V-shaped midrib crease so every leaf catches directional light realistically!)
  hCtx.save();
  hCtx.translate(x, y);
  hCtx.rotate(angle);
  const hGrad = hCtx.createLinearGradient(0, -width * 0.7, 0, width * 0.7);
  const hHi = Math.min(255, heightLevel + 35);
  const hLo = Math.max(10, heightLevel - 28);
  hGrad.addColorStop(0, `rgb(${hHi},${hHi},${hHi})`);
  hGrad.addColorStop(0.5, `rgb(${hLo},${hLo},${hLo})`);
  hGrad.addColorStop(1, `rgb(${hHi},${hHi},${hHi})`);
  drawLeafOutline(hCtx);
  hCtx.fillStyle = hGrad;
  hCtx.fill();
  hCtx.restore();

  // Roughness (fresh waxy deciduous leaves ~ 0.38 - 0.58)
  rCtx.save();
  rCtx.translate(x, y);
  rCtx.rotate(angle);
  drawLeafOutline(rCtx);
  rCtx.fillStyle = 'rgb(122, 122, 122)';
  rCtx.fill();
  rCtx.restore();
}

/**
 * 3. BOTANICAL MULTI-LEAF TWIG SPRIG PBR CARD (1024x1024 alpha-cutout)
 * Creates lush layered branchlet sprays matching the exact Japanese spring forest canopy!
 */
function createBroadleafSprigPBR(
  style: 'bright' | 'deep' | 'shrub' | 'zelkova' | 'birch',
  anisotropy: number
): PBRTextureSet {
  const size = 1024;
  const seedMap = { bright: 1101, deep: 2202, shrub: 3303, zelkova: 4404, birch: 5505 };
  const rng = createRng(seedMap[style]);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(40,40,40)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(140,140,140)';
  rCtx.fillRect(0, 0, size, size);

  // Physically calibrated chlorophyll albedos — rich saturated Japanese mountain greens that NEVER blow out to chalky white!
  const palettes = {
    bright: [
      { base: '#326314', tip: '#68a620', vein: '#86bf35' },
      { base: '#3e7518', tip: '#7bb925', vein: '#98d13b' },
      { base: '#2b5712', tip: '#59921c', vein: '#76ad2f' },
      { base: '#45801a', tip: '#84c228', vein: '#a3da42' },
      { base: '#264d10', tip: '#4e831a', vein: '#699c2a' },
    ],
    deep: [
      { base: '#1a3810', tip: '#305c18', vein: '#467526' },
      { base: '#214513', tip: '#3c6e1d', vein: '#54882d' },
      { base: '#152d0d', tip: '#264a14', vein: '#3a6220' },
      { base: '#274f15', tip: '#4a7f21', vein: '#649a33' },
    ],
    shrub: [
      { base: '#234914', tip: '#487d1e', vein: '#649a31' },
      { base: '#2d5a17', tip: '#5d9623', vein: '#7cb239' },
      { base: '#1b3a10', tip: '#346319', vein: '#4d7c29' },
      { base: '#386b1a', tip: '#6ca828', vein: '#8bc33f' },
    ],
    zelkova: [
      // Rich lush Japanese Keyaki / Buna mountain emerald-jade foliage
      { base: '#1d4414', tip: '#3b7320', vein: '#569034' },
      { base: '#265318', tip: '#4c8824', vein: '#68a43a' },
      { base: '#173811', tip: '#31611b', vein: '#4a7b2c' },
      { base: '#2f631b', tip: '#5c9c29', vein: '#79b841' },
    ],
    birch: [
      // Airy fresh highland Shirakaba birch light-emerald & golden-green shimmering leaves
      { base: '#35691a', tip: '#6ca82b', vein: '#8cc446' },
      { base: '#417a1e', tip: '#7db832', vein: '#9cd24d' },
      { base: '#2b5816', tip: '#599224', vein: '#77ae3b' },
      { base: '#4c8522', tip: '#8ac238', vein: '#a8da54' },
    ],
  }[style];

  // Draw woody central stem + branching sub-twigs from bottom-center upward
  const drawBranchStem = (
    x0: number,
    y0: number,
    x1: number,
    y1: number,
    thick0: number,
    thick1: number
  ) => {
    const mx = (x0 + x1) * 0.5 + randRange(rng, -24, 24);
    const my = (y0 + y1) * 0.5 + randRange(rng, -18, 18);

    aCtx.strokeStyle = '#3d3022';
    aCtx.lineCap = 'round';
    aCtx.lineWidth = (thick0 + thick1) * 0.5;
    aCtx.beginPath();
    aCtx.moveTo(x0, y0);
    aCtx.quadraticCurveTo(mx, my, x1, y1);
    aCtx.stroke();

    hCtx.strokeStyle = 'rgb(140,140,140)';
    hCtx.lineCap = 'round';
    hCtx.lineWidth = (thick0 + thick1) * 0.5;
    hCtx.beginPath();
    hCtx.moveTo(x0, y0);
    hCtx.quadraticCurveTo(mx, my, x1, y1);
    hCtx.stroke();

    return { mx, my };
  };

  interface TwigAnchor {
    x: number;
    y: number;
    angle: number;
    scale: number;
  }

  const anchors: TwigAnchor[] = [];
  const mainBaseX = size * 0.5;
  const mainBaseY = size * 0.96;
  const mainTopX = size * 0.5 + randRange(rng, -45, 45);
  const mainTopY = size * 0.14;
  drawBranchStem(mainBaseX, mainBaseY, mainTopX, mainTopY, 13, 3.5);

  // Secondary radiating branchlets — high botanical density for lacy photorealistic Japanese canopy!
  const subBranches = style === 'shrub' ? 9 : 12;
  for (let b = 0; b < subBranches; b++) {
    const t = 0.12 + (b / (subBranches - 1)) * 0.76;
    const bx = mainBaseX + (mainTopX - mainBaseX) * t;
    const by = mainBaseY + (mainTopY - mainBaseY) * t;
    const side = b % 2 === 0 ? -1 : 1;
    const reach = size * randRange(rng, 0.26, 0.44) * (1.12 - Math.abs(t - 0.48) * 0.72);
    const branchAngle = -Math.PI * 0.5 + side * randRange(rng, 0.48, 1.24);
    const ex = Math.max(64, Math.min(size - 64, bx + Math.cos(branchAngle) * reach));
    const ey = Math.max(64, Math.min(size - 96, by + Math.sin(branchAngle) * reach));

    drawBranchStem(bx, by, ex, ey, 6.2 * (1 - t * 0.4), 1.9);

    const leavesPerTwig = style === 'bright' ? 9 : 8;
    for (let k = 0; k < leavesPerTwig; k++) {
      const lt = 0.16 + (k / (leavesPerTwig - 1)) * 0.88;
      const lx = bx + (ex - bx) * lt;
      const ly = by + (ey - by) * lt;
      const leafSide = k % 2 === 0 ? -1 : 1;
      const spreadAngle =
        branchAngle + (k === leavesPerTwig - 1 ? 0 : leafSide * randRange(rng, 0.42, 1.08));
      anchors.push({
        x: lx,
        y: ly,
        angle: spreadAngle,
        scale: randRange(rng, 0.62, 1.02) * (1.06 - lt * 0.26),
      });
    }
  }

  // Crown tip leaves
  for (let c = 0; c < 9; c++) {
    anchors.push({
      x: mainTopX + randRange(rng, -28, 28),
      y: mainTopY + randRange(rng, -14, 46),
      angle: -Math.PI * 0.5 + randRange(rng, -1.25, 1.25),
      scale: randRange(rng, 0.58, 0.92),
    });
  }

  // Paint crisp multi-layered botanical leaves (darker inner leaves first, bright outer sunlit shoots on top!)
  anchors.forEach((anc, idx) => {
    const pal = palettes[Math.floor(rng() * palettes.length)];
    const baseSize =
      style === 'birch'
        ? 106
        : style === 'zelkova'
          ? 114
          : style === 'shrub'
            ? 122
            : 128;
    const baseLen = baseSize * anc.scale;
    const baseWid =
      baseLen *
      (style === 'birch'
        ? randRange(rng, 0.52, 0.68)
        : style === 'zelkova'
          ? randRange(rng, 0.36, 0.48)
          : randRange(rng, 0.42, 0.56));
    const lobed = (style === 'bright' || style === 'deep') && rng() > 0.3;
    const hLvl = Math.round(85 + (idx / anchors.length) * 145);

    // Subtle soft ambient occlusion drop shadow beneath upper overlapping leaves
    if (idx > anchors.length * 0.35) {
      aCtx.save();
      aCtx.translate(anc.x + 4, anc.y + 5);
      aCtx.rotate(anc.angle);
      aCtx.fillStyle = 'rgba(10, 26, 5, 0.16)';
      aCtx.beginPath();
      aCtx.ellipse(baseLen * 0.45, 0, baseLen * 0.46, baseWid * 0.36, 0, 0, Math.PI * 2);
      aCtx.fill();
      aCtx.restore();
    }

    paintBotanicalLeaf(
      aCtx,
      hCtx,
      rCtx,
      anc.x,
      anc.y,
      anc.angle,
      baseLen,
      baseWid,
      pal.base,
      pal.tip,
      pal.vein,
      lobed,
      hLvl
    );

    // Secondary companion young shoot leaf for authentic feathery Japanese maple/beech density
    if (rng() > 0.2) {
      const pal2 = palettes[Math.floor(rng() * palettes.length)];
      paintBotanicalLeaf(
        aCtx,
        hCtx,
        rCtx,
        anc.x + randRange(rng, -12, 12),
        anc.y + randRange(rng, -12, 12),
        anc.angle + randRange(rng, -0.62, 0.62),
        baseLen * randRange(rng, 0.52, 0.78),
        baseWid * randRange(rng, 0.52, 0.8),
        pal2.base,
        pal2.tip,
        pal2.vein,
        lobed,
        Math.min(248, hLvl + 20)
      );
    }
  });

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.2, false);

  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 4. JAPANESE CEDAR (SUGI) CONIFER NEEDLE SPRAY (512x512 alpha-cutout)
 */
function createCedarFrondPBR(anisotropy: number): PBRTextureSet {
  const size = 512;
  const rng = createRng(9909);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(30,30,30)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(160,160,160)';
  rCtx.fillRect(0, 0, size, size);

  const needleColors = ['#1f3e17', '#294f1c', '#346322', '#447929', '#193312'];

  const drawNeedleShoot = (x: number, y: number, angle: number, len: number, depth: number) => {
    const ex = x + Math.cos(angle) * len;
    const ey = y + Math.sin(angle) * len;

    aCtx.strokeStyle = '#3d2d1d';
    aCtx.lineWidth = Math.max(1.5, 5 - depth * 1.4);
    aCtx.lineCap = 'round';
    aCtx.beginPath();
    aCtx.moveTo(x, y);
    aCtx.lineTo(ex, ey);
    aCtx.stroke();

    const steps = Math.floor(len / 4.2);
    for (let i = 0; i <= steps; i++) {
      const t = i / Math.max(1, steps);
      const px = x + (ex - x) * t;
      const py = y + (ey - y) * t;

      for (let s = -1; s <= 1; s += 2) {
        const na = angle + s * randRange(rng, 0.35, 0.72);
        const nl = randRange(rng, 14, 28) * (1.1 - t * 0.35);
        const col = needleColors[Math.floor(rng() * needleColors.length)];

        aCtx.strokeStyle = col;
        aCtx.lineWidth = randRange(rng, 2.2, 3.6);
        aCtx.beginPath();
        aCtx.moveTo(px, py);
        aCtx.lineTo(px + Math.cos(na) * nl, py + Math.sin(na) * nl);
        aCtx.stroke();

        const hv = Math.round(110 + t * 110);
        hCtx.strokeStyle = `rgb(${hv},${hv},${hv})`;
        hCtx.lineWidth = 3;
        hCtx.beginPath();
        hCtx.moveTo(px, py);
        hCtx.lineTo(px + Math.cos(na) * nl, py + Math.sin(na) * nl);
        hCtx.stroke();
      }
    }

    if (depth < 2) {
      const branches = depth === 0 ? 7 : 3;
      for (let b = 0; b < branches; b++) {
        const bt = 0.16 + (b / Math.max(1, branches - 1)) * 0.72;
        const bx = x + (ex - x) * bt;
        const by = y + (ey - y) * bt;
        const side = b % 2 === 0 ? -1 : 1;
        drawNeedleShoot(
          bx,
          by,
          angle + side * randRange(rng, 0.45, 0.85),
          len * randRange(rng, 0.38, 0.56) * (1.15 - bt * 0.4),
          depth + 1
        );
      }
    }
  };

  drawNeedleShoot(size * 0.5, size * 0.96, -Math.PI * 0.5, size * 0.84, 0);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.5, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 4b. JAPANESE RED PINE (AKAMATSU) CLOUD-PAD NEEDLE ROSETTE PBR (512x512 alpha-cutout)
 * Authentic radiating tufted clusters of slender deep blue-green pine needles!
 */
function createPineNeedlePadPBR(anisotropy: number): PBRTextureSet {
  const size = 512;
  const rng = createRng(6464);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(25,25,25)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(168,168,168)';
  rCtx.fillRect(0, 0, size, size);

  // Subtle reddish-brown woody twig skeleton radiating from bottom-center
  const hubs: Array<{ x: number; y: number; r: number }> = [
    { x: size * 0.5, y: size * 0.55, r: 105 },
    { x: size * 0.28, y: size * 0.62, r: 92 },
    { x: size * 0.72, y: size * 0.62, r: 92 },
    { x: size * 0.34, y: size * 0.36, r: 95 },
    { x: size * 0.66, y: size * 0.36, r: 95 },
    { x: size * 0.5, y: size * 0.25, r: 92 },
    { x: size * 0.2, y: size * 0.44, r: 78 },
    { x: size * 0.8, y: size * 0.44, r: 78 },
    { x: size * 0.5, y: size * 0.76, r: 80 },
  ];

  aCtx.strokeStyle = '#5c3c28';
  aCtx.lineCap = 'round';
  aCtx.lineWidth = 7;
  aCtx.beginPath();
  aCtx.moveTo(size * 0.5, size * 0.96);
  aCtx.lineTo(size * 0.5, size * 0.45);
  aCtx.stroke();

  hubs.forEach((hub) => {
    aCtx.strokeStyle = '#5c3c28';
    aCtx.lineWidth = 4;
    aCtx.beginPath();
    aCtx.moveTo(size * 0.5, size * 0.74);
    aCtx.lineTo(hub.x, hub.y);
    aCtx.stroke();
  });

  // Deep authentic Japanese Akamatsu pine-needle tones (forest blue-green & dark olive tips)
  const darkNeedles = ['#173018', '#1e3c1d', '#244720', '#132814'];
  const midNeedles = ['#2b5623', '#356628', '#264d21', '#3f742b'];
  const tipNeedles = ['#487e2f', '#588f35', '#3b6d27'];

  // Paint radiating tufted rosette bursts at each hub
  hubs.forEach((hub, hIdx) => {
    const needlesPerHub = 54;
    for (let i = 0; i < needlesPerHub; i++) {
      const ang = (i / needlesPerHub) * Math.PI * 2 + randRange(rng, -0.08, 0.08);
      const len = hub.r * randRange(rng, 0.58, 1.06);
      const startOff = randRange(rng, 2, 12);
      const sx = hub.x + Math.cos(ang) * startOff;
      const sy = hub.y + Math.sin(ang) * startOff;
      const ex = hub.x + Math.cos(ang) * len;
      const ey = hub.y + Math.sin(ang) * len;

      const tier = i % 3;
      const col =
        tier === 0
          ? darkNeedles[Math.floor(rng() * darkNeedles.length)]
          : tier === 1
            ? midNeedles[Math.floor(rng() * midNeedles.length)]
            : tipNeedles[Math.floor(rng() * tipNeedles.length)];

      aCtx.strokeStyle = col;
      aCtx.lineWidth = randRange(rng, 2.2, 3.6);
      aCtx.lineCap = 'round';
      aCtx.beginPath();
      aCtx.moveTo(sx, sy);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      const hv = Math.round(90 + (hIdx / hubs.length) * 95 + tier * 24);
      hCtx.strokeStyle = `rgb(${hv},${hv},${hv})`;
      hCtx.lineWidth = 3.2;
      hCtx.beginPath();
      hCtx.moveTo(sx, sy);
      hCtx.lineTo(ex, ey);
      hCtx.stroke();
    }
  });

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.4, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 5. WOODLAND FERN FROND PBR (512x1024 alpha-cutout)
 */
function createFernFrondPBR(anisotropy: number): PBRTextureSet {
  const w = 512;
  const h = 1024;
  const rng = createRng(7711);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = w;
  heightCanvas.height = h;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(20,20,20)';
  hCtx.fillRect(0, 0, w, h);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = w;
  roughCanvas.height = h;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(125,125,125)';
  rCtx.fillRect(0, 0, w, h);

  // Main arched dark-green fern stem (rachis)
  aCtx.strokeStyle = '#33531b';
  aCtx.lineWidth = 7;
  aCtx.lineCap = 'round';
  aCtx.beginPath();
  aCtx.moveTo(w * 0.5, h * 0.99);
  aCtx.lineTo(w * 0.5, h * 0.04);
  aCtx.stroke();

  const pairs = 25;
  for (let i = 0; i < pairs; i++) {
    const t = i / (pairs - 1);
    const y = h * (0.91 - t * 0.84);
    const envelope = Math.sin(Math.pow(t, 0.72) * Math.PI);
    const pinnaLen = w * (0.1 + envelope * 0.37);

    for (let side = -1; side <= 1; side += 2) {
      const ang = side * (Math.PI * 0.42 - t * 0.25) - Math.PI * 0.5;
      const sx = w * 0.5;
      const sy = y + (side === 1 ? -6 : 0);

      // Pinna sub-stem
      const ex = sx + Math.cos(ang) * pinnaLen;
      const ey = sy + Math.sin(ang) * pinnaLen;

      aCtx.strokeStyle = '#3e6a1e';
      aCtx.lineWidth = Math.max(1.5, 3.2 - t * 1.5);
      aCtx.beginPath();
      aCtx.moveTo(sx, sy);
      aCtx.lineTo(ex, ey);
      aCtx.stroke();

      // Tiny feathered pinnules along each pinna
      const subCount = Math.max(4, Math.floor(pinnaLen / 12));
      for (let j = 0; j < subCount; j++) {
        const st = (j + 0.3) / subCount;
        const px = sx + (ex - sx) * st;
        const py = sy + (ey - sy) * st;
        const pLen = (14 + (1 - st) * 16) * (0.75 + envelope * 0.4);
        const pWid = pLen * 0.38;

        for (let ps = -1; ps <= 1; ps += 2) {
          const pa = ang + ps * 0.85;
          paintBotanicalLeaf(
            aCtx,
            hCtx,
            rCtx,
            px,
            py,
            pa,
            pLen,
            pWid,
            t > 0.65 ? '#4c881f' : '#2d5c18',
            t > 0.65 ? '#87c930' : '#539024',
            '#73b038',
            false,
            Math.round(130 + randRange(rng, -20, 40))
          );
        }
      }
    }
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.0, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 6. SINGLE DRY FALLEN LEAF ALPHA CARD (256x256) for 3,500+ physical 3D ground scatter leaves!
 */
function createDryLeafCardPBR(anisotropy: number): PBRTextureSet {
  const size = 256;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;
  hCtx.fillStyle = 'rgb(30,30,30)';
  hCtx.fillRect(0, 0, size, size);

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;
  rCtx.fillStyle = 'rgb(210,210,210)';
  rCtx.fillRect(0, 0, size, size);

  // Neutral parchment base so vertex/instance color tints each leaf uniquely!
  paintBotanicalLeaf(
    aCtx,
    hCtx,
    rCtx,
    size * 0.08,
    size * 0.5,
    0,
    size * 0.84,
    size * 0.42,
    '#b8a384',
    '#e3d4b8',
    '#cbb796',
    true,
    170
  );

  // Petiole stem
  aCtx.strokeStyle = '#6e583f';
  aCtx.lineWidth = 4;
  aCtx.beginPath();
  aCtx.moveTo(size * 0.02, size * 0.5);
  aCtx.lineTo(size * 0.14, size * 0.5);
  aCtx.stroke();

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.4, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 7. FIBROUS GRASS BLADE PBR (128x512)
 */
function createGrassBladePBR(anisotropy: number): PBRTextureSet {
  const w = 128;
  const h = 512;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = w;
  albedoCanvas.height = h;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = w;
  heightCanvas.height = h;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = w;
  roughCanvas.height = h;
  const rCtx = roughCanvas.getContext('2d')!;

  // Vertical fibrous parallel veins + root-to-tip tonal fade
  const grad = aCtx.createLinearGradient(0, h, 0, 0);
  grad.addColorStop(0, '#5a6332'); // earthy base
  grad.addColorStop(0.25, '#89a342');
  grad.addColorStop(0.7, '#c2df63');
  grad.addColorStop(1, '#dcf285'); // sunlit tip (tinted further per instance!)
  aCtx.fillStyle = grad;
  aCtx.fillRect(0, 0, w, h);

  // Parallel longitudinal blade veins
  for (let x = 0; x < w; x += 6) {
    aCtx.fillStyle = x % 12 === 0 ? 'rgba(255,255,220,0.14)' : 'rgba(20,35,10,0.12)';
    aCtx.fillRect(x, 0, 2, h);

    const hv = 135 + Math.round(Math.sin((x / w) * Math.PI) * 90);
    hCtx.fillStyle = `rgb(${hv},${hv},${hv})`;
    hCtx.fillRect(x, 0, 6, h);
  }

  rCtx.fillStyle = 'rgb(138,138,138)';
  rCtx.fillRect(0, 0, w, h);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 1.8, false);
  return {
    map: configureTexture(albedoCanvas, true, false, anisotropy),
    normalMap: configureTexture(normalCanvas, false, false, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, false, anisotropy),
  };
}

/**
 * 8. MOSSY FOREST STONE & WEATHERED ROADSIDE CURB PBR (512x512 seamless)
 */
function createStonePBR(mode: 'rock' | 'curb', anisotropy: number): PBRTextureSet {
  const size = 512;
  const seed = mode === 'rock' ? 610 : 620;

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      const n1 = tileableFbm2D(u, v, 8, 4, seed);
      const n2 = tileableFbm2D(u, v, 24, 3, seed + 55);
      const val = n1 * 0.68 + n2 * 0.32;
      const moss = Math.max(0, tileableFbm2D(u, v, 5, 3, seed + 99) - (mode === 'rock' ? 0.48 : 0.62)) * 2.3;

      let r = mode === 'rock' ? 56 + val * 58 : 112 + val * 62;
      let g = mode === 'rock' ? 55 + val * 56 : 112 + val * 60;
      let b = mode === 'rock' ? 52 + val * 52 : 106 + val * 55;

      if (moss > 0) {
        const m = Math.min(0.75, moss);
        r = r * (1 - m) + 52 * m;
        g = g * (1 - m) + 74 * m;
        b = b * (1 - m) + 29 * m;
      }

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.min(255, r);
      aImg.data[idx + 1] = Math.min(255, g);
      aImg.data[idx + 2] = Math.min(255, b);
      aImg.data[idx + 3] = 255;

      const hv = Math.round(val * 255);
      hImg.data[idx] = hv;
      hImg.data[idx + 1] = hv;
      hImg.data[idx + 2] = hv;
      hImg.data[idx + 3] = 255;

      const rv = Math.round(190 + (1 - val) * 58);
      rImg.data[idx] = rv;
      rImg.data[idx + 1] = rv;
      rImg.data[idx + 2] = rv;
      rImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  const normalCanvas = heightToNormalCanvas(heightCanvas, 3.0, true);
  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 8b. PHOTOREALISTIC WEATHERED JAPANESE MOUNTAIN ASPHALT PBR (1024x1024 seamless)
 * Fine crushed basalt/granite aggregate, subtle hairline cracks, bitumen pores & mineral roughness.
 */
function createAsphaltPBR(anisotropy: number): PBRTextureSet {
  const size = 1024;
  const rng = createRng(8686);

  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const hImg = hCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);

  // Layer 1: Continuous multi-octave weathered bitumen binder & fine mineral grain
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;

      const macro = tileableFbm2D(u, v, 4, 4, 811);
      const med = tileableFbm2D(u, v, 18, 3, 823);
      const grain = tileableFbm2D(u, v, 96, 2, 839);
      const micro = tileableFbm2D(u, v, 210, 2, 853);

      // Sun-weathered cool medium-grey Japanese mountain asphalt (#5e6368 -> #8a9095)
      const val = macro * 0.34 + med * 0.24 + grain * 0.25 + micro * 0.17;
      const base = 76 + val * 62;

      const idx = (y * size + x) * 4;
      aImg.data[idx] = Math.min(255, base * 0.985);
      aImg.data[idx + 1] = Math.min(255, base * 1.0);
      aImg.data[idx + 2] = Math.min(255, base * 1.035); // subtle cool mineral grey cast
      aImg.data[idx + 3] = 255;

      const hVal = Math.round(70 + grain * 105 + micro * 55);
      hImg.data[idx] = hVal;
      hImg.data[idx + 1] = hVal;
      hImg.data[idx + 2] = hVal;
      hImg.data[idx + 3] = 255;

      // Coarse matte-satin asphalt roughness (~0.72 - 0.92)
      const rVal = Math.round(182 + (1 - grain) * 52);
      rImg.data[idx] = rVal;
      rImg.data[idx + 1] = rVal;
      rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;
    }
  }
  aCtx.putImageData(aImg, 0, 0);
  hCtx.putImageData(hImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);

  // Layer 2: Thousands of crushed basalt & bright granite stone aggregate chips (authentic tarmac texture!)
  const stoneTones = [
    '#9fa5aa', // pale granite chip
    '#878d92', // light grey aggregate
    '#b5babd', // bright quartz fleck
    '#52565a', // dark basalt stone
    '#3e4246', // deep tar pore / dark chip
    '#797e82', // mid stone chip
    '#8b877e', // warm tan-grey pebble
  ];

  for (let i = 0; i < 16500; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const rx = randRange(rng, 1.0, 3.2);
    const ry = randRange(rng, 0.9, 2.8);
    const rot = rng() * Math.PI;
    const col = stoneTones[Math.floor(rng() * stoneTones.length)];
    const isBright = col === '#b5babd' || col === '#9fa5aa';
    const isDark = col === '#3e4246' || col === '#52565a';
    const hShade = isDark
      ? Math.round(randRange(rng, 35, 85))
      : Math.round(randRange(rng, 170, 245));
    const rShade = isBright
      ? Math.round(randRange(rng, 138, 175)) // exposed crystalline aggregate catches crisp specular!
      : Math.round(randRange(rng, 196, 240));

    drawWrapped(size, x, y, 6, (ox, oy) => {
      aCtx.save();
      aCtx.translate(ox, oy);
      aCtx.rotate(rot);
      aCtx.fillStyle = col;
      aCtx.fillRect(-rx * 0.5, -ry * 0.5, rx, ry);
      aCtx.restore();

      hCtx.fillStyle = `rgb(${hShade},${hShade},${hShade})`;
      hCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);

      rCtx.fillStyle = `rgb(${rShade},${rShade},${rShade})`;
      rCtx.fillRect(ox - rx * 0.5, oy - ry * 0.5, rx, ry);
    });
  }

  // Layer 3: Subtle weathered mountain road hairline cracks & tar seal fissures
  for (let c = 0; c < 14; c++) {
    let cx = rng() * size;
    let cy = rng() * size;
    let ang = rng() * Math.PI * 2;
    const segs = Math.floor(randRange(rng, 12, 30));

    for (let s = 0; s < segs; s++) {
      const step = randRange(rng, 8, 22);
      ang += randRange(rng, -0.42, 0.42);
      const nx = cx + Math.cos(ang) * step;
      const ny = cy + Math.sin(ang) * step;
      const w = randRange(rng, 0.8, 2.0);

      drawWrapped(size, cx, cy, 30, (ox, oy) => {
        const dx = nx - cx;
        const dy = ny - cy;
        aCtx.strokeStyle = 'rgba(26, 28, 30, 0.52)';
        aCtx.lineWidth = w;
        aCtx.beginPath();
        aCtx.moveTo(ox, oy);
        aCtx.lineTo(ox + dx, oy + dy);
        aCtx.stroke();

        hCtx.strokeStyle = 'rgb(20, 20, 20)';
        hCtx.lineWidth = w + 0.8;
        hCtx.beginPath();
        hCtx.moveTo(ox, oy);
        hCtx.lineTo(ox + dx, oy + dy);
        hCtx.stroke();

        rCtx.strokeStyle = 'rgb(245, 245, 245)';
        rCtx.lineWidth = w + 1.0;
        rCtx.beginPath();
        rCtx.moveTo(ox, oy);
        rCtx.lineTo(ox + dx, oy + dy);
        rCtx.stroke();
      });

      cx = ((nx % size) + size) % size;
      cy = ((ny % size) + size) % size;
    }
  }

  const normalCanvas = heightToNormalCanvas(heightCanvas, 2.35, true);

  return {
    map: configureTexture(albedoCanvas, true, true, anisotropy),
    normalMap: configureTexture(normalCanvas, false, true, anisotropy),
    roughnessMap: configureTexture(roughCanvas, false, true, anisotropy),
  };
}

/**
 * 9. PROCEDURAL FOREST SKY EQUIRRECTANGULAR HDRI MAP (1024x512)
 * Produces natural physical sunlight skylight, green canopy horizon bounce, and earthy ground bounce.
 */
export function createForestSkyEquirectTexture(
  mood: 'midday' | 'golden' | 'mist' | 'overcast',
  sunAzimuthDeg: number,
  sunElevationDeg: number
): THREE.CanvasTexture {
  const w = 1024;
  const h = 512;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  // Vertical sky-to-forest-floor gradient
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  if (mood === 'midday') {
    grad.addColorStop(0.0, '#8fb8db'); // crisp mountain sky zenith
    grad.addColorStop(0.26, '#c7def0');
    grad.addColorStop(0.45, '#e7efe2'); // bright hazy forest skyline
    grad.addColorStop(0.51, '#6d8a4b'); // sunlit chlorophyll canopy bounce band!
    grad.addColorStop(0.62, '#3a4b25'); // shaded mid-canopy bounce
    grad.addColorStop(0.78, '#2b2218'); // forest mulch floor bounce
    grad.addColorStop(1.0, '#1a140e');
  } else if (mood === 'golden') {
    grad.addColorStop(0.0, '#4d73a3');
    grad.addColorStop(0.28, '#a4a6a6');
    grad.addColorStop(0.46, '#ffd296');
    grad.addColorStop(0.51, '#9c7d3b');
    grad.addColorStop(0.64, '#43381b');
    grad.addColorStop(0.82, '#291c11');
    grad.addColorStop(1.0, '#160f09');
  } else if (mood === 'mist') {
    grad.addColorStop(0.0, '#8da8b8');
    grad.addColorStop(0.32, '#c8dce2');
    grad.addColorStop(0.48, '#dde8e4');
    grad.addColorStop(0.54, '#60785a');
    grad.addColorStop(0.7, '#303c2a');
    grad.addColorStop(1.0, '#1a1a14');
  } else {
    // overcast soft studio
    grad.addColorStop(0.0, '#c2ccd1');
    grad.addColorStop(0.35, '#dce2e4');
    grad.addColorStop(0.5, '#95a58d');
    grad.addColorStop(0.65, '#46543a');
    grad.addColorStop(1.0, '#23201a');
  }

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Soft canopy dappled light mottling along upper hemisphere (simulates forest sky gaps!)
  const rng = createRng(404);
  for (let i = 0; i < 60; i++) {
    const cx = rng() * w;
    const cy = randRange(rng, h * 0.12, h * 0.48);
    const rad = randRange(rng, 25, 110);
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
    g.addColorStop(0, mood === 'golden' ? 'rgba(255,220,165,0.16)' : 'rgba(245,255,230,0.15)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, rad, 0, Math.PI * 2);
    ctx.fill();
  }

  // Intense solar glow disk in equirectangular coordinates
  const sunU = (((sunAzimuthDeg % 360) + 360) % 360) / 360;
  const sunV = 0.5 - (sunElevationDeg / 90) * 0.5;
  const sx = sunU * w;
  const sy = Math.max(15, Math.min(h * 0.49, sunV * h));
  const sunRad = mood === 'overcast' ? 160 : 120;

  const sunGrad = ctx.createRadialGradient(sx, sy, 2, sx, sy, sunRad);
  if (mood === 'golden') {
    sunGrad.addColorStop(0, 'rgba(255, 246, 215, 1.0)');
    sunGrad.addColorStop(0.2, 'rgba(255, 200, 120, 0.72)');
    sunGrad.addColorStop(0.6, 'rgba(255, 165, 85, 0.22)');
    sunGrad.addColorStop(1, 'rgba(255, 150, 70, 0)');
  } else if (mood === 'overcast') {
    sunGrad.addColorStop(0, 'rgba(255, 255, 252, 0.45)');
    sunGrad.addColorStop(1, 'rgba(255, 255, 252, 0)');
  } else {
    sunGrad.addColorStop(0, 'rgba(255, 255, 240, 1.0)');
    sunGrad.addColorStop(0.18, 'rgba(255, 250, 215, 0.65)');
    sunGrad.addColorStop(0.55, 'rgba(235, 248, 205, 0.18)');
    sunGrad.addColorStop(1, 'rgba(235, 248, 205, 0)');
  }

  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(sx, sy, sunRad, 0, Math.PI * 2);
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createStudioTextureLibrary(maxAnisotropy: number): StudioTextureLibrary {
  const aniso = Math.min(16, Math.max(4, maxAnisotropy));

  const forestFloor = createForestFloorPBR(aniso);
  forestFloor.map.repeat.set(4.5, 4.5);
  forestFloor.normalMap.repeat.set(4.5, 4.5);
  forestFloor.roughnessMap.repeat.set(4.5, 4.5);

  const hardwoodBark = createBarkPBR('hardwood', aniso);
  const cedarBark = createBarkPBR('cedar', aniso);
  const beechBark = createBarkPBR('beech', aniso);
  const pineBark = createBarkPBR('pine', aniso);
  const birchBark = createBarkPBR('birch', aniso);
  const canopyBright = createBroadleafSprigPBR('bright', aniso);
  const canopyDeep = createBroadleafSprigPBR('deep', aniso);
  const zelkovaLeaf = createBroadleafSprigPBR('zelkova', aniso);
  const pineNeedles = createPineNeedlePadPBR(aniso);
  const birchLeaf = createBroadleafSprigPBR('birch', aniso);
  const cedarFrond = createCedarFrondPBR(aniso);
  const shrubLeaf = createBroadleafSprigPBR('shrub', aniso);
  const fernFrond = createFernFrondPBR(aniso);
  const dryLeafCard = createDryLeafCardPBR(aniso);
  const grassBlade = createGrassBladePBR(aniso);
  const mossyRock = createStonePBR('rock', aniso);
  const weatheredCurb = createStonePBR('curb', aniso);
  const asphalt = createAsphaltPBR(aniso);
  const skyEnvEquirect = createForestSkyEquirectTexture('midday', 142, 46);

  const allSets = [
    forestFloor,
    hardwoodBark,
    cedarBark,
    beechBark,
    pineBark,
    birchBark,
    canopyBright,
    canopyDeep,
    zelkovaLeaf,
    pineNeedles,
    birchLeaf,
    cedarFrond,
    shrubLeaf,
    fernFrond,
    dryLeafCard,
    grassBlade,
    mossyRock,
    weatheredCurb,
    asphalt,
  ];

  return {
    forestFloor,
    hardwoodBark,
    cedarBark,
    beechBark,
    pineBark,
    birchBark,
    canopyBright,
    canopyDeep,
    zelkovaLeaf,
    pineNeedles,
    birchLeaf,
    cedarFrond,
    shrubLeaf,
    fernFrond,
    dryLeafCard,
    grassBlade,
    mossyRock,
    weatheredCurb,
    asphalt,
    skyEnvEquirect,
    dispose: () => {
      for (const s of allSets) {
        s.map.dispose();
        s.normalMap.dispose();
        s.roughnessMap.dispose();
      }
      skyEnvEquirect.dispose();
    },
  };
}
