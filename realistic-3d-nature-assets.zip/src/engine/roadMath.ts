import * as THREE from 'three';

export const ROAD_HALF_WIDTH = 3.55; // ~7.1m wide sweeping Japanese touge road
export const CURB_WIDTH = 0.46; // weathered concrete drainage curb along inner embankment edge
export const ROAD_MIN_X = -31.0; // 2x longer sweeping 62m mountain touge corridor!
export const ROAD_MAX_X = 31.0;

/**
 * Smooth bounded Japanese mountain touge S-curve spine z = f(x) across x in [-31, 31].
 * Near x = 0: matches the exact diagonal corner sweep of the reference photograph
 * (z(0) = 0.65, dz/dx = -0.36), then sweeps gracefully into deep mountain bends on both sides!
 */
export function roadCenterZ(x: number): number {
  return 0.65 - 4.4 * Math.sin(x * 0.082) + 1.25 * (1.0 - Math.cos(x * 0.068));
}

/**
 * Analytical first derivative dz/dx of roadCenterZ(x).
 */
export function roadCenterDZDX(x: number): number {
  return -4.4 * 0.082 * Math.cos(x * 0.082) + 1.25 * 0.068 * Math.sin(x * 0.068);
}

/**
 * Analytical second derivative d2z/dx2 of roadCenterZ(x) for fast exact Newton projection.
 */
function roadCenterD2ZDX2(x: number): number {
  return 4.4 * 0.082 * 0.082 * Math.sin(x * 0.082) + 1.25 * 0.068 * 0.068 * Math.cos(x * 0.068);
}

/**
 * Gentle longitudinal mountain pass elevation grade across the 62m touge corridor.
 */
export function roadBaseElevation(x: number): number {
  return 0.34 + 0.42 * Math.sin(x * 0.055) + x * 0.011;
}

/**
 * Exact surface height of the asphalt road given spline x and signed perpendicular offset s
 * (s > 0 = inner foreground embankment side, s < 0 = outer forest wall side).
 * Includes realistic slight drainage crown and gentle touge banking camber.
 */
export function roadSurfaceElevation(x: number, s: number): number {
  const base = roadBaseElevation(x);
  const t = Math.max(-1.25, Math.min(1.25, s / ROAD_HALF_WIDTH));
  const crown = 0.048 * Math.max(0, 1 - t * t);
  // Subtle dynamic banking following local curvature
  const curvature = roadCenterD2ZDX2(x);
  const camber = (-0.045 - curvature * 1.4) * t;
  return base + crown + camber;
}

export interface RoadSample {
  /** Closest spine X coordinate */
  spineX: number;
  /** Closest spine Z coordinate */
  spineZ: number;
  /** Signed perpendicular distance from road centerline (+ = inner foreground bank, - = outer forest wall) */
  signedDist: number;
  /** Unsigned distance to road centerline */
  absDist: number;
  /** Road surface elevation at this point */
  roadY: number;
  /** Unit tangent along road (+x direction) */
  tangentX: number;
  tangentZ: number;
  /** Unit normal pointing toward inner foreground embankment (+z side) */
  normalX: number;
  normalZ: number;
}

/**
 * Computes the exact closest point on the curving 62m touge road spine for any world (x, z)
 * using 4 fast Newton-Raphson iterations.
 */
export function sampleRoadCoords(x: number, z: number): RoadSample {
  let sx = Math.max(ROAD_MIN_X - 5, Math.min(ROAD_MAX_X + 5, x));

  for (let iter = 0; iter < 4; iter++) {
    const f = roadCenterZ(sx);
    const df = roadCenterDZDX(sx);
    const d2f = roadCenterD2ZDX2(sx);
    const dx = sx - x;
    const dz = f - z;
    const g = dx + dz * df;
    const dg = 1 + df * df + dz * d2f;
    if (Math.abs(dg) > 1e-5) {
      sx -= g / dg;
    }
  }

  const spineZ = roadCenterZ(sx);
  const df = roadCenterDZDX(sx);
  const invLen = 1 / Math.sqrt(1 + df * df);
  const tangentX = invLen;
  const tangentZ = df * invLen;

  // Normal pointing toward +z (inner foreground embankment side)
  const normalX = -tangentZ;
  const normalZ = tangentX;

  const rx = x - sx;
  const rz = z - spineZ;
  const signedDist = rx * normalX + rz * normalZ;

  return {
    spineX: sx,
    spineZ,
    signedDist,
    absDist: Math.abs(signedDist),
    roadY: roadSurfaceElevation(sx, signedDist),
    tangentX,
    tangentZ,
    normalX,
    normalZ,
  };
}

/**
 * Returns true if (x, z) falls inside the asphalt road + optional safety margin.
 */
export function isInsideRoadCorridor(
  x: number,
  z: number,
  extraInner = 0.48,
  extraOuter = 0.35
): boolean {
  const s = sampleRoadCoords(x, z).signedDist;
  return s > -(ROAD_HALF_WIDTH + extraOuter) && s < ROAD_HALF_WIDTH + extraInner;
}

/**
 * Convenience helper to compute a world position relative to the road curve:
 * x = spine X, signedOffset = signed perpendicular offset (+ foreground bank, - forest side).
 */
export function roadOffsetPoint(x: number, signedOffset: number): THREE.Vector3 {
  const z0 = roadCenterZ(x);
  const df = roadCenterDZDX(x);
  const invLen = 1 / Math.sqrt(1 + df * df);
  const nx = -df * invLen;
  const nz = invLen;
  const px = x + nx * signedOffset;
  const pz = z0 + nz * signedOffset;
  return new THREE.Vector3(px, roadSurfaceElevation(x, signedOffset), pz);
}
