import {
  Ctx, V, v, add, sub, mul, dist, lerp, lerpV, clamp, fromAngle, rot, seg, ease, ik,
  cap, capShade, limb, circle, shape, stroke, headPath,
} from './util';
import { BRACE, MAX_DRAW, drawArrow, drawBow } from './gear';

export type ArcherPhase = 'idle' | 'grab' | 'nock' | 'ready' | 'release' | 'recover' | 'win' | 'lose';
export const DUR: Record<string, number> = { grab: 1.25, nock: 1.5, recover: 0.45 };
/** how long the follow-through is held before the next arrow may be fetched */
export const RELEASE_HOLD = 0.25;
export const AIM_MIN = -1.05;
export const AIM_MAX = 0.36;
/** shooting stance: ankle offsets from the body centre, and ankle height above the floor */
export const STANCE = { back: -21, front: 23, ankle: 10 };

export interface ArcherState {
  x: number;
  ground: number;
  phase: ArcherPhase;
  t: number; // seconds spent in the current phase
  time: number; // global clock (breathing)
  aim: number; // smoothed aim angle
  pull: number; // px of string pull (spring simulated after release)
  vib: number; // string blur amount
  relAim: number; // snapshot taken at the release instant
  relPull: number;
  kick: number; // bow rolling in the hand (spring, rad) – lives across phases
  recoil: number; // torso recoil (spring, rad)
  quiver: number; // arrows currently available (incl. the one in hand)
  vx: number; // walking speed, only used for a touch of body lean
  footB: V; // ankles – planted in world space by the engine so steps never slide
  footF: V;
  rotB: number; // foot pitch while a step is in the air
  rotF: number;
  e0: number; // how far the bow had already been lowered (0..1) when the round ended
  duck: number; // px the hips are lowered (crouch / tuck)
  team: 0 | 1; // 1 = the duel opponent (different shirt and hair)
  gear?: number; // scale of bow and arrows (the mini-bow level)
}

const QA = 1.72; // quiver axis (nock -> tip): almost straight down, slightly back
const UA = 38;
const FA = 36;
const LEG_MAX = 95.3; // thigh + shin, minus a hair so the knee never locks
const C = {
  skin: '#e3b286', skinFar: '#cd9b70',
  hair: '#6b4a36', hairDark: '#523727',
  shirt: '#d8363c', guard: '#1b1c20',
  jeans: '#31566b', jeansFar: '#274657',
  shoe: '#3f76c8', shoeFar: '#3363ab', sole: '#eef1f4',
  quiver: '#1d1e23', quiverHi: '#3b3e47', belt: '#141518',
};

export function poseArcher(s: ArcherState) {
  const { x, ground: G, phase, t } = s;
  const gs = s.gear ?? 1;
  // a mini bow has its string much closer to the grip
  const nockPoint = (g0: V, ang: number, pull: number): V => sub(g0, fromAngle(ang, (BRACE + pull) * gs));
  const u = clamp(t / (DUR[phase] ?? 1), 0, 1);
  const breath = Math.sin(s.time * 2.1);
  const endE = ease.inOut(seg(t, 0, 0.55));
  const e0 = s.e0; // win / lose start from exactly the 'recover' pose at this progress
  // draw fraction: shoulders stay "loaded" for a moment after the release and are
  // fully relaxed again by the time the follow-through ends
  const f = clamp(
    phase === 'ready' ? s.pull / MAX_DRAW
      : phase === 'release' ? (s.relPull / MAX_DRAW) * Math.exp(-9 * t) * (1 - ease.inOut(seg(t, 0.1, RELEASE_HOLD)))
      : 0,
    0, 1,
  );

  // ---- body ---------------------------------------------------------------
  const ga = ease.inOut(seg(u, 0.06, 0.42)); // grab: reach in
  const gb = ease.inOut(seg(u, 0.54, 0.96)); // grab: stand back up
  let raise = 0;
  let lean = 0.02;
  let crouch = 0;
  let hipBack = 0;
  let look = 0;
  if (phase === 'grab') {
    const bell = ga * (1 - gb);
    lean += 0.5 * bell;
    crouch = 16 * bell;
    hipBack = -7 * bell;
    look = 0.14 * ease.sine(seg(u, 0, 0.12)) * (1 - gb) + 0.12 * bell;
  } else if (phase === 'nock') {
    raise = ease.inOut(seg(u, 0.78, 1));
    const toQuiver = ease.sine(seg(u, 0, 0.16)) * (1 - ease.sine(seg(u, 0.36, 0.56)));
    const toBow = ease.sine(seg(u, 0.44, 0.6)) * (1 - raise);
    look = 0.34 * toQuiver + 0.2 * toBow;
  } else if (phase === 'ready' || phase === 'release') raise = 1;
  else if (phase === 'recover') raise = 1 - ease.inOut(u);
  else if (phase === 'win' || phase === 'lose') raise = (1 - e0) * (1 - endE);
  const aim = s.aim;
  lean += raise * (aim * 0.3 - 0.03) - 0.035 * f + s.recoil + clamp(s.vx / 165, -1, 1) * 0.035 + s.duck * 0.007;

  // feet first: the hips ride as high as both legs allow, which gives the walk its bob
  const hop = phase === 'win' ? Math.abs(Math.sin(s.time * 9)) * 5 * endE : 0;
  const ankB = v(s.footB.x, s.footB.y - hop);
  const ankF = v(s.footF.x, s.footF.y - hop);
  const hipX = x + hipBack + lean * 8;
  const reach = (a: V) => a.y - Math.sqrt(Math.max(1, LEG_MAX * LEG_MAX - (a.x - hipX) * (a.x - hipX)));
  const hip = v(hipX, Math.max(G - 102 + crouch + s.duck + breath * 0.5 - hop, reach(ankB), reach(ankF)));
  const neck = add(hip, rot(v(0, -62), lean));
  const P = (lx: number, ly: number) => add(neck, rot(v(lx, ly), lean));
  const Sf = P(6 + 2 * f, 6 + breath * 0.4);
  const Sr = P(-6 - 5 * f, 7 + breath * 0.4 - f);
  const Pv = P(10, -9);
  const headC = P(3, -22);
  const headRot =
    lean * 0.4 + raise * aim * 0.3 + look + 0.04 * f +
    (phase === 'win' ? -0.2 * endE : phase === 'lose' ? 0.25 * endE : 0);

  // ---- bow arm ------------------------------------------------------------
  const hangF = v(Sf.x + 4, Sf.y + 70);
  const hangR = v(Sr.x - 3, Sr.y + 72);
  const standGrip = v(x + 82, G - 84);
  const standAng = 0.14;
  const lowBow = add(hip, v(40, -16));
  const lowAng = 0.52;
  const aimGrip = add(Pv, fromAngle(aim, 62 + 1.5 * f));

  let F = hangF;
  let bowAng = standAng;
  let held = phase !== 'idle';
  switch (phase) {
    case 'grab': {
      // hand travels in an arc, the lifted bow swings a little past its rest angle
      const arcIn = Math.sin(Math.PI * ga);
      const arcUp = Math.sin(Math.PI * gb);
      F = add(lerpV(lerpV(hangF, standGrip, ga), lowBow, gb), v(7 * arcIn + 6 * arcUp, -11 * arcIn - 9 * arcUp));
      bowAng = lerp(standAng, lowAng, ease.outBack(seg(u, 0.55, 1)));
      held = u >= 0.47;
      break;
    }
    case 'nock':
    case 'recover':
      F = lerpV(lowBow, aimGrip, raise);
      bowAng = lerp(lowAng, aim, raise);
      break;
    case 'ready':
    case 'release':
      F = aimGrip;
      bowAng = aim;
      break;
    case 'win':
      F = lerpV(lerpV(lowBow, aimGrip, 1 - e0), v(Sf.x + 30, Sf.y - 58), endE);
      bowAng = lerp(lerp(lowAng, aim, 1 - e0), -0.95, endE);
      break;
    case 'lose':
      F = lerpV(lerpV(lowBow, aimGrip, 1 - e0), lowBow, endE);
      bowAng = lerp(lerp(lowAng, aim, 1 - e0), lowAng, endE);
      break;
  }
  const fa = ik(Sf, F, UA, FA, 1);
  const grip = fa.end;
  const attach = phase === 'idle' ? 0 : phase === 'grab' ? seg(u, 0.42, 0.5) : 1;
  bowAng += s.kick * attach;
  const bowPos = lerpV(standGrip, grip, attach);

  // ---- draw arm -----------------------------------------------------------
  const bdir = fromAngle(bowAng);
  // the string gives a tiny bit when the nock clicks on
  const seat = phase === 'nock' ? Math.sin(Math.PI * seg(u, 0.77, 0.9)) * 2.2 : 0;
  const stringPull = phase === 'ready' ? s.pull : seat;
  const hold = sub(nockPoint(grip, bowAng, stringPull), mul(bdir, 5));
  const rdir = fromAngle(s.relAim);
  const gripAim = ik(Sf, aimGrip, UA, FA, 1).end;
  const hold0 = sub(nockPoint(gripAim, s.relAim, s.relPull), mul(rdir, 5));
  const follow = add(sub(hold0, mul(rdir, 15)), v(0, -2));

  const quiverM = add(hip, v(-8, 8));
  const qdir = fromAngle(QA);
  const grabPt = sub(quiverM, mul(qdir, 35));
  const outPt = add(hip, v(30, -84));

  let R = hangR;
  let bendR = 1;
  let fingers: 'relaxed' | 'pinch' | 'hook' | 'open' | 'fist' = 'relaxed';
  let fingerAng = Math.PI / 2;
  let r2 = 0;
  let r3 = 0;
  if (phase === 'grab') {
    const bell = ga * (1 - gb);
    R = add(hangR, v(-17 * bell, -9 * bell)); // counter-balance swing
  } else if (phase === 'nock') {
    const r1 = ease.inOut(seg(u, 0, 0.2));
    r2 = ease.inOut(seg(u, 0.24, 0.48));
    r3 = ease.inOut(seg(u, 0.48, 0.72));
    const r4 = ease.inOut(seg(u, 0.72, 0.8));
    const lay = add(hold, mul(bdir, 14)); // shaft on the rest, nock still in front of the string
    const lift = Math.sin(Math.PI * r3);
    R = lerpV(lerpV(lerpV(lerpV(hangR, grabPt, r1), outPt, r2), add(lay, v(4 * lift, -10 * lift)), r3), hold, r4);
    fingers = u < 0.21 ? 'relaxed' : u < 0.8 ? 'pinch' : 'hook';
  } else if (phase === 'ready') {
    R = hold;
    bendR = -1;
    fingers = 'hook';
  } else if (phase === 'release') {
    R = lerpV(hold0, follow, ease.out(seg(t, 0, 0.13)));
    bendR = -1;
    fingers = 'open';
  } else if (phase === 'recover') {
    const e = ease.inOut(u);
    R = lerpV(follow, hangR, e);
    bendR = lerp(-1, 1, e);
    fingers = u < 0.4 ? 'open' : 'relaxed';
  } else if (phase === 'win') {
    R = lerpV(lerpV(follow, hangR, e0), v(Sr.x - 8, Sr.y - 68), endE);
    bendR = lerp(lerp(-1, 1, e0), -1, endE);
    fingers = 'fist';
  } else if (phase === 'lose') {
    R = lerpV(lerpV(follow, hangR, e0), add(headC, rot(v(12, -2), headRot)), endE);
    bendR = lerp(lerp(-1, 1, e0), 1, endE);
  }
  // The draw elbow really travels in a level arc at shoulder height: forward, then towards
  // the camera, then back. From the side that reads as a foreshortened upper arm sweeping
  // from front to back under the chin – it never has to cross the face.
  const relF = s.relPull / MAX_DRAW;
  const after = Math.min(1.08, relF + 0.4); // follow-through carries the elbow further round
  const fDraw =
    phase === 'ready' ? clamp(s.pull / MAX_DRAW, 0, 1)
    : phase === 'release' ? lerp(relF, after, ease.out(seg(t, 0, 0.13)))
    : phase === 'nock' ? 0 : after;
  const wDraw =
    phase === 'nock' ? ease.inOut(seg(u, 0.78, 0.98))
    : phase === 'ready' || phase === 'release' ? 1
    : phase === 'recover' ? 1 - ease.inOut(u)
    : phase === 'win' || phase === 'lose' ? (1 - e0) * (1 - endE) : 0;
  const armIK = ik(Sr, R, UA, FA, bendR);
  let elbowR = armIK.mid;
  if (wDraw > 0 && gs >= 1) {
    const phi = lerp(0.42, 3.0, ease.sine(clamp(fDraw, 0, 1))) + 1.2 * clamp(fDraw - 1, 0, 0.08);
    let e = add(Sr, rot(v(UA * Math.cos(phi), -5 * clamp(fDraw, 0, 1)), lean));
    const dl = dist(e, armIK.end);
    if (dl > FA) e = add(armIK.end, mul(sub(e, armIK.end), FA / dl));
    elbowR = lerpV(armIK.mid, e, wDraw);
  }
  const ra = { mid: elbowR, end: armIK.end };

  // ---- arrow --------------------------------------------------------------
  const hasArrow = (phase === 'nock' && u >= 0.21) || phase === 'ready';
  let arrow: { nock: V; angle: number } | null = null;
  let arrowClip = false;
  if (hasArrow) {
    let ang = bowAng;
    if (phase === 'nock') {
      // while it leaves the quiver the shaft keeps sliding through the quiver mouth
      const outEnd = ik(Sr, outPt, UA, FA, 1).end;
      const through = (h: V) => Math.atan2(quiverM.y - h.y, quiverM.x - h.x);
      ang = r2 < 1 ? through(ra.end) : lerp(through(outEnd), bowAng, r3);
      arrowClip = r2 < 1;
    }
    arrow = { nock: add(ra.end, fromAngle(ang, 5)), angle: ang };
    fingerAng = ang;
  } else if (phase === 'release' || phase === 'recover') {
    fingerAng = lerp(s.relAim, Math.PI / 2, phase === 'recover' ? ease.inOut(u) : 0);
  } else if (phase === 'win' || phase === 'lose') {
    fingerAng = lerp(lerp(s.relAim, Math.PI / 2, e0), -Math.PI / 2, endE);
  }

  // ---- legs ---------------------------------------------------------------
  const legB = ik(hip, ankB, 48.5, 47, -1);
  const legF = ik(hip, ankF, 48.5, 47, -1);

  const expr = phase === 'win' ? 'happy' : phase === 'lose' ? 'shock' : phase === 'ready' || phase === 'release' ? 'focus' : 'neutral';
  return {
    s, hip, neck, lean, Sf, Sr, headC, headRot, fa, ra, legB, legF, ankB, ankF, held, arrow, arrowClip,
    fingers, fingerAng, quiverM, expr, f, rotB: s.rotB, rotF: s.rotF,
    // outside 'ready' s.pull is only the string's own ringing after a shot
    bow: { pos: bowPos, ang: bowAng, pull: phase === 'ready' ? s.pull : s.pull + seat, vib: s.vib },
    quiverCount: Math.max(0, s.quiver - (hasArrow ? 1 : 0)),
    slotStart: hasArrow ? 1 : 0,
  };
}
export type ArcherPose = ReturnType<typeof poseArcher>;

function sneaker(ctx: Ctx, a: V, far: boolean, pitch: number) {
  ctx.save();
  ctx.translate(a.x, a.y);
  ctx.rotate(pitch);
  shape(ctx, (p) => {
    p.moveTo(-9.5, -5);
    p.lineTo(7, -6);
    p.quadraticCurveTo(19, -1, 21.5, 6.5);
    p.lineTo(-10.5, 6.5);
    p.closePath();
  }, far ? C.shoeFar : C.shoe);
  shape(ctx, (p) => {
    p.moveTo(14.5, 0.6);
    p.quadraticCurveTo(20.5, 1.6, 21.5, 6.5);
    p.lineTo(13.5, 6.5);
    p.closePath();
  }, far ? '#d9dee4' : C.sole);
  shape(ctx, (p) => p.roundRect(-11, 5.6, 33, 4.4, 2), far ? '#d9dee4' : C.sole);
  stroke(ctx, [v(3.5, -3.6), v(7.5, -0.8)], '#ffffff', 1.4);
  stroke(ctx, [v(7.5, -2.2), v(11.5, 0.6)], '#ffffff', 1.4);
  ctx.restore();
}

function leg(ctx: Ctx, hip: V, knee: V, ank: V, far: boolean, pitch: number) {
  const c = far ? C.jeansFar : C.jeans;
  cap(ctx, hip, knee, 11.2, 9.4, c);
  cap(ctx, knee, ank, 9.4, 8.2, c);
  capShade(ctx, hip, knee, 11.2, 9.4, 0.2);
  capShade(ctx, knee, ank, 9.4, 8.2, 0.2);
  sneaker(ctx, ank, far, pitch);
}

function arm(ctx: Ctx, sh: V, el: V, hand: V, bracer: boolean) {
  cap(ctx, sh, el, 7.4, 6, C.skin);
  cap(ctx, el, hand, 5.9, 4.8, C.skin);
  capShade(ctx, sh, el, 7.4, 6, 0.18);
  capShade(ctx, el, hand, 5.9, 4.8, 0.18);
  limb(ctx, sh, lerpV(sh, el, 0.5), 8.8, 7.7, C.shirt, 0.2);
  if (bracer) limb(ctx, lerpV(el, hand, 0.22), lerpV(el, hand, 0.82), 6.2, 5.4, C.guard, 0);
}

export function drawArcher(ctx: Ctx, p: ArcherPose) {
  const t1 = p.s.team === 1;
  C.shirt = t1 ? '#7c3aed' : '#d8363c';
  C.hair = t1 ? '#26211f' : '#6b4a36';
  C.hairDark = t1 ? '#141110' : '#523727';
  const gs = p.s.gear ?? 1;
  const scaled = (c: V, fn: () => void) => {
    if (gs === 1) return fn();
    ctx.save();
    ctx.translate(c.x, c.y);
    ctx.scale(gs, gs);
    ctx.translate(-c.x, -c.y);
    fn();
    ctx.restore();
  };
  leg(ctx, p.hip, p.legB.mid, p.ankB, true, p.rotB);
  leg(ctx, p.hip, p.legF.mid, p.ankF, false, p.rotF);

  // torso
  ctx.save();
  ctx.translate(p.neck.x, p.neck.y);
  ctx.rotate(p.lean);
  shape(ctx, (q) => {
    q.moveTo(-12.6, 52); q.lineTo(12.6, 52); q.lineTo(13, 64);
    q.quadraticCurveTo(0, 73, -13, 64); q.closePath();
  }, C.jeans);
  limb(ctx, v(1, 2), v(2, -9), 5.2, 5, C.skin, 0.2);
  const torso = shape(ctx, (q) => {
    q.moveTo(-11.5, 0); q.quadraticCurveTo(0, -5, 11.5, 0);
    q.bezierCurveTo(17.5, 12, 16, 30, 12.6, 46); q.lineTo(12.2, 56); q.lineTo(-12.6, 56);
    q.bezierCurveTo(-13.6, 44, -17.6, 24, -11.5, 0); q.closePath();
  }, C.shirt);
  ctx.save();
  ctx.clip(torso);
  ctx.fillStyle = 'rgba(70,0,10,0.3)';
  ctx.fillRect(-20, -8, 10.5, 70);
  ctx.fillRect(-20, 49, 40, 8);
  // chest guard with its straps
  ctx.fillStyle = C.guard;
  ctx.beginPath();
  ctx.moveTo(1.5, -4); ctx.lineTo(20, -2); ctx.lineTo(20, 20); ctx.quadraticCurveTo(10, 31, 1, 19); ctx.closePath();
  ctx.fill();
  stroke(ctx, [v(2, 17), v(-18, 27)], C.guard, 2.6, 'butt');
  ctx.restore();
  ctx.fillStyle = C.belt;
  ctx.fillRect(-12.8, 52, 25.6, 4.2);
  ctx.restore();

  // head: short brown crop, no accessories
  ctx.save();
  ctx.translate(p.headC.x, p.headC.y);
  ctx.rotate(p.headRot);
  const face = shape(ctx, headPath, C.skin);
  ctx.save();
  ctx.clip(face);
  ctx.fillStyle = 'rgba(150,80,40,0.22)';
  ctx.beginPath(); ctx.ellipse(1, 16.5, 10, 4.2, -0.15, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  const hair = shape(ctx, (q) => {
    q.moveTo(-16.6, 1.5); q.bezierCurveTo(-21.5, -8, -17, -21.5, -2, -22);
    q.bezierCurveTo(7.5, -22, 14, -18, 15.4, -10.5); q.bezierCurveTo(10, -14, 5, -13, 1.6, -8);
    q.lineTo(0.6, -2.6); q.bezierCurveTo(-3, -4.6, -6.2, -2, -7, 3.4);
    q.bezierCurveTo(-10, 5, -14, 4.4, -16.6, 1.5); q.closePath();
  }, C.hair);
  ctx.save();
  ctx.clip(hair);
  ctx.fillStyle = C.hairDark;
  ctx.beginPath(); ctx.ellipse(-13, -3, 8, 15, 0.25, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  circle(ctx, v(-3.4, 1.6), 3.5, C.skinFar);
  const ex = p.expr;
  ctx.lineCap = 'round';
  if (ex === 'happy') {
    ctx.beginPath(); ctx.arc(10, -1.6, 2.7, Math.PI * 1.1, Math.PI * 1.9);
    ctx.lineWidth = 1.7; ctx.strokeStyle = '#2b1a12'; ctx.stroke();
  } else {
    ctx.fillStyle = '#2b1a12';
    ctx.beginPath();
    ctx.ellipse(10.4, -2.4, 1.6, ex === 'shock' ? 2.4 : ex === 'focus' ? 1.15 : 1.9, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  const brow = ex === 'focus' ? [v(6, -7.6), v(13.6, -5.2)] : ex === 'shock' ? [v(6.4, -8.6), v(13, -9)] : [v(6.2, -7), v(13.2, -6.4)];
  stroke(ctx, brow, C.hairDark, 1.9);
  ctx.beginPath();
  if (ex === 'happy') ctx.arc(11.5, 8.6, 3.8, 0.1, Math.PI * 0.75);
  else if (ex === 'shock') ctx.ellipse(13, 10.6, 1.9, 2.6, 0, 0, Math.PI * 2);
  else { ctx.moveTo(11.4, 10.7); ctx.lineTo(15.2, 10.3); }
  ctx.lineWidth = 1.5; ctx.strokeStyle = '#9a5a40'; ctx.stroke();
  ctx.restore();

  // hip quiver: spare arrows first, then the black tube over them
  for (let i = p.quiverCount - 1; i >= 0; i--) {
    const k = i + p.slotStart;
    const ang = QA + (k % 2 ? 1 : -1) * 0.04 * Math.ceil(k / 2);
    scaled(p.quiverM, () => drawArrow(ctx, sub(p.quiverM, fromAngle(ang, 30 - (k % 3) * 2 * Math.sign(k))), ang));
  }
  const qEnd = add(p.quiverM, fromAngle(QA, 60));
  stroke(ctx, [add(p.quiverM, fromAngle(QA, 4)), add(p.hip, v(-3, -7))], C.belt, 3.4);
  limb(ctx, p.quiverM, qEnd, 8.6, 7.4, C.quiver, 0);
  cap(ctx, add(p.quiverM, fromAngle(QA, 1)), add(p.quiverM, fromAngle(QA, 6)), 9.2, 9.2, C.quiverHi);
  cap(ctx, add(p.quiverM, fromAngle(QA, 22)), add(p.quiverM, fromAngle(QA, 40)), 4.6, 4.2, '#2c2e36');

  // bow arm, bow, gripping fingers
  arm(ctx, p.Sf, p.fa.mid, p.fa.end, true);
  circle(ctx, sub(p.fa.end, fromAngle(p.bow.ang, p.held ? 2.5 : 0)), 5.6, C.skin);
  scaled(p.bow.pos, () => drawBow(ctx, p.bow.pos, p.bow.ang, p.bow.pull, p.bow.vib));
  if (p.held) {
    ctx.save();
    ctx.translate(p.bow.pos.x, p.bow.pos.y);
    ctx.rotate(p.bow.ang);
    shape(ctx, (q) => q.roundRect(-0.5, -6.6, 7.4, 13.2, 3.4), C.skin);
    for (const y of [-3.2, 0, 3.2]) stroke(ctx, [v(2, y), v(6.2, y)], C.skinFar, 1);
    ctx.restore();
  }

  // arrow in hand / on the string
  if (p.arrow) {
    ctx.save();
    if (p.arrowClip) {
      ctx.translate(p.quiverM.x, p.quiverM.y);
      ctx.rotate(QA);
      ctx.beginPath();
      ctx.rect(-600, -600, 600, 1200);
      ctx.clip();
      ctx.rotate(-QA);
      ctx.translate(-p.quiverM.x, -p.quiverM.y);
    }
    const an = p.arrow;
    scaled(an.nock, () => drawArrow(ctx, an.nock, an.angle));
    ctx.restore();
  }

  // draw arm (nearest to the camera)
  arm(ctx, p.Sr, p.ra.mid, p.ra.end, false);
  const h = p.ra.end;
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.rotate(p.fingerAng);
  if (p.fingers === 'open') for (const a of [-0.75, -0.25, 0.25, 0.7]) stroke(ctx, [v(0, 0), fromAngle(a, 10.5)], C.skin, 3.6);
  circle(ctx, v(0, 0), p.fingers === 'fist' ? 6.4 : 5.5, C.skin);
  if (p.fingers === 'hook') {
    shape(ctx, (q) => q.roundRect(-1.5, -5.2, 9.5, 10.4, 3.2), C.guard);
    for (const y of [-2.6, 0.2, 3]) stroke(ctx, [v(4.5, y), v(8.4, y)], C.skin, 2.3);
  } else if (p.fingers === 'pinch') {
    shape(ctx, (q) => q.roundRect(0, -4.6, 8.5, 9.2, 3.4), C.skin);
    stroke(ctx, [v(3, -3.4), v(7.4, -1.2)], C.skinFar, 1);
  } else if (p.fingers === 'fist') for (const y of [-2.4, 0.4, 3.2]) stroke(ctx, [v(1.5, y), v(5.6, y)], C.skinFar, 1);
  else if (p.fingers === 'relaxed') shape(ctx, (q) => q.roundRect(1, -4, 8, 8, 3.4), C.skin);
  ctx.restore();
}
