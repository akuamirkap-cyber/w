const grad = () => ({ addColorStop() {} });
const ctxProxy: any = new Proxy({}, { get: (_t, prop) => {
  if (prop === 'createLinearGradient' || prop === 'createRadialGradient' || prop === 'createConicGradient' || prop === 'createPattern') return grad;
  if (prop === 'measureText') return () => ({ width: 42 });
  if (prop === 'getImageData') return (_x:number,_y:number,w:number,h:number) => ({ data: new Uint8ClampedArray(w*h*4), width: w, height: h });
  if (prop === 'createImageData' || prop === 'getContext') return (w:number,h:number) => ({ data: new Uint8ClampedArray(w*h*4), width: w, height: h });
  if (prop === 'canvas') return { width: 256, height: 256 };
  return () => {};
}, set: () => true });
(globalThis as any).document = { createElement: (tag: string) => tag === 'canvas' ? { width: 0, height: 0, getContext: () => ctxProxy, style: {} } : { style: {}, addEventListener(){}, removeEventListener(){} } };
(globalThis as any).window = { matchMedia: () => ({ matches: false }), devicePixelRatio: 1 };
import * as THREE from 'three';
import { createCityMaterials, createCity, type StreetTreeAsset } from './src/arenas/nyc-street/game/city';
import { createV3SurfaceTextures } from './src/arenas/rc-drift/pigeon/haruna-v3/textures';
import { createV2Textures } from './src/arenas/rc-drift/pigeon/haruna-v2/textures';
import { createLibrary } from './src/arenas/rc-drift/pigeon/haruna-v2/library';
const t0 = Date.now();
const aniso = 8;
const v3 = createV3SurfaceTextures(aniso);
const v2 = createV2Textures(aniso);
const lib = createLibrary(v2);
const maple = lib.find(d => d.id === 'maple')!;
console.log('maple asset built', Date.now() - t0, 'ms', 'leaves verts', maple.make(701).leaves.attributes.position.count);
const treeAsset: StreetTreeAsset = {
  templates: [maple.make(701), maple.make(1313), maple.make(2027)].map(t => ({ leaves: t.leaves, bark: t.bark })),
  leafMat: maple.leaf.mat, leafDepth: maple.leaf.depth, barkMat: maple.bark?.mat, barkDepth: maple.bark?.depth,
};
const scene = new THREE.Scene();
const mats = createCityMaterials(v3, aniso);
const city = createCity(scene, mats, treeAsset);
console.log('city built in', Date.now() - t0, 'ms');
const first = city.group.children[0];
first.children.forEach(c => { const mm = c as THREE.Mesh; if (mm.isMesh && mm.name.includes('V3')) console.log('chunk tree mesh:', mm.name, 'verts', mm.geometry.attributes.position.count, 'groups', mm.geometry.groups.length); });
city.dispose(); v3.dispose(); v2.dispose();
console.log('TREE-TEST OK');
