import { lazy, Suspense, useEffect, useState } from 'react';
import ProdriftMenu, { type MenuArenaId } from './menu/ProdriftMenu';

const NycStreetGame = lazy(() => import('./arenas/nyc-street/NycStreetGame'));
const RallyGame = lazy(() => import('./arenas/rc-drift/pigeon/RallyGame'));
const DriftSimGame = lazy(() => import('./arenas/drift-sim/DriftSimGame'));
const RmxGame = lazy(() => import('./arenas/rc-drift/RmxGame'));
const HarunaRoute33Game = lazy(() => import('./arenas/haruna-route33/HarunaRoute33Game'));
const HarunaDownhillGame = lazy(() => import('./arenas/haruna-downhill/HarunaDownhillGame'));

/**
 * Screen graph:
 *  - 'nyc'    → NYC Street Kings (main game: Manhattan traffic weaving, NOS 2x, Haruna V3 lighting)
 *  - 'menu'   → classic PRODRIFT launcher (garage, Mt. Haruna V3, rally, drift arenas)
 *  - others   → legacy arenas, reachable from the classic menu
 */
type Screen = 'nyc' | 'menu' | 'play' | 'studio' | MenuArenaId;

function Loading({ label }: { label: string }) {
  return (
    <div className="fixed inset-0 grid place-items-center bg-[#101828] text-[#f5f3ea]">
      <div className="flex flex-col items-center gap-3">
        <div className="h-7 w-7 animate-spin rounded-full border-2 border-white/25 border-t-[#ffae46]" />
        <span className="text-xs font-bold tracking-widest text-[#acb8cb] uppercase">{label}</span>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('nyc');

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'F2') {
        e.preventDefault();
        setScreen(s => (s === 'nyc' ? 'menu' : 'nyc'));
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  if (screen === 'menu') {
    return (
      <ProdriftMenu
        onPlay={() => setScreen('play')}
        onStudio={() => setScreen('studio')}
        onArena={(id) => setScreen(id)}
      />
    );
  }

  return (
    <Suspense fallback={<Loading label={screen === 'nyc' ? 'Memuat Manhattan...' : 'Memuat lintasan...'} />}>
      {screen === 'nyc' && <NycStreetGame onExit={() => setScreen('menu')} onGarage={() => setScreen('studio')} />}
      {screen === 'play' && <RallyGame onExit={() => setScreen('menu')} initialMode="drive" />}
      {screen === 'studio' && <RallyGame onExit={() => setScreen('nyc')} initialMode="garage" />}
      {screen === 'drift-sim' && <DriftSimGame onExit={() => setScreen('menu')} />}
      {screen === 'rc-arena' && <RmxGame onExit={() => setScreen('menu')} />}
      {screen === 'haruna-route33' && <HarunaRoute33Game onExit={() => setScreen('menu')} />}
      {screen === 'haruna-downhill' && <HarunaDownhillGame onExit={() => setScreen('menu')} />}
    </Suspense>
  );
}
