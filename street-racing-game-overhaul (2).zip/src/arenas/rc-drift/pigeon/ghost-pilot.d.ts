import type { DriverInput } from './drift-physics.js';
import type { RallyTrack, RoadRun } from './rally-road.js';
export type PaceLeg = { until?:number; entry?:number; pace?:number; offset?:number; width?:number };
export type PilotLeg = (PaceLeg&{until:number}) | {
  seconds:number; gas?:number; brake?:number; steer?:number; handbrake?:boolean; assist?:boolean;
};
export const pilotStep:number;
export function createPacePilot(track:RallyTrack):(run:RoadRun,leg?:PaceLeg)=>DriverInput;
export function createGhostPilot(track:RallyTrack,plan:readonly PilotLeg[]):(run:RoadRun)=>DriverInput;