import * as T from 'three';
import { createDriftScore } from './drift-score.js';
import { toKmh } from './speed-cues.js';
import type { DriftZone, HarunaDriveMode, RunMode, Telemetry } from './rally-course';
import { harunaRoute, pigeonRoute, type MountainSpec } from './pigeon-world/route';
import { buildMountainWorld } from './pigeon-world/world';
import { createPigeonLighting } from './pigeon-world/lighting';
import { createMountainCar, GroundKind, type GroundAt } from './pigeon-world/suspension';
import type { DriverInput } from './drift-physics.js';
import { COURSES } from './course-selection';
import { createPigeonAssets } from './pigeon-world/assets';
import { createHarunaArchiveRun } from './haruna-archive-run';
import { createHarunaV2Lighting, type HarunaV2Lighting } from './haruna-v2/lighting';
import { createV2Textures, type V2TextureSet } from './haruna-v2/textures';
import { buildHarunaV2World } from './haruna-v2/world';
import { createV3SurfaceTextures, type V3SurfaceTextureSet } from './haruna-v3/textures';
import { buildHarunaV3World } from './haruna-v3/world';

export function createMountainCourse(
  id: 'pigeon' | 'haruna' | 'haruna-v2' | 'haruna-v3',
  renderer: T.WebGLRenderer,
  assets = createPigeonAssets(),
  shadowResolution?: number,
  foliageShadows = true,
  v2Textures?: V2TextureSet,
  v3Textures?: V3SurfaceTextureSet,
) {
  const scene = new T.Scene();
  const isV2 = id === 'haruna-v2';
  const isV3 = id === 'haruna-v3';
  const isV2Style = isV2 || isV3;
  const spec = id === 'pigeon' ? pigeonRoute() : harunaRoute();
  const maxAniso = renderer.capabilities.getMaxAnisotropy();
  const worldOpts = {
    density: foliageShadows ? 0.85 : 0.6,
    grass: foliageShadows ? 0.8 : 0.45,
    shadowsOnBushes: foliageShadows,
  };
  const v3World = isV3
    ? buildHarunaV3World(
        scene,
        spec as ReturnType<typeof harunaRoute>,
        v2Textures ?? createV2Textures(maxAniso),
        v3Textures ?? createV3SurfaceTextures(maxAniso),
        worldOpts,
      )
    : null;
  const v2World = isV2
    ? buildHarunaV2World(scene, spec as ReturnType<typeof harunaRoute>, v2Textures ?? createV2Textures(maxAniso), worldOpts)
    : null;
  const pigeonWorld = !isV2Style ? buildMountainWorld(scene, spec, assets, { foliageShadows }) : null;
  const groundAt = v3World ? v3World.groundAt : v2World ? v2World.groundAt : pigeonWorld!.groundAt;
  const rawTick = v3World ? v3World.tick : v2World ? v2World.tick : pigeonWorld!.tick;
  const setOpenTerrain = v3World ? v3World.setOpenTerrain : v2World ? v2World.setOpenTerrain : pigeonWorld!.setOpenTerrain;
  const smokeBinding = v3World ? v3World.smokeBinding : v2World?.smokeBinding;
  const lighting = isV2Style
    ? createHarunaV2Lighting(scene, spec as ReturnType<typeof harunaRoute>, groundAt, renderer, shadowResolution ?? 4096, smokeBinding)
    : createPigeonLighting(scene, spec, groundAt, renderer, assets, shadowResolution);
  if (v3World) {
    v3World.syncSun(lighting.sunDirection, (lighting as HarunaV2Lighting).sunColor);
  }
  const tick = (dt: number) => {
    if (v3World) v3World.syncSun(lighting.sunDirection, (lighting as HarunaV2Lighting).sunColor);
    rawTick(dt);
  };
  const terrain = createTerrainRun(spec, groundAt);
  const archive = spec.id === 'haruna' ? createHarunaArchiveRun(spec.track) : null;
  const layout = archive ?? terrain;
  let harunaDrive: HarunaDriveMode = 'prodrift';
  const original = () => harunaDrive === 'prodrift' ? archive : null;
  const current = () => original() ?? terrain;

  function snapshot(): Telemetry {
    const info = current().snapshot();
    if (!archive) return info;
    if (harunaDrive === 'prodrift') {
      const { x, z } = archive.state;
      return { ...info, harunaDrive, elevation: archive.heightAt(x, z), grounded: true, surface: 'Aspal' };
    }
    const pin = archive.mapPosition(terrain.state.x, terrain.state.z);
    return { ...info, harunaDrive, mapX: pin.x, mapY: pin.y };
  }

  return {
    scene, route: layout.route, startMarker: layout.startMarker, length: layout.length, zones: layout.zones,
    track: null, botTrack: layout.botTrack, courseName: COURSES[id].name.toUpperCase(), lighting, snapshot, tickVisuals: tick,
    groundAt,
    isV2: isV2Style,
    dispose() {
      if ('dispose' in lighting && typeof lighting.dispose === 'function') lighting.dispose();
    },
    heightAt: (x: number, z: number) => groundAt(x, z).y,
    archivePoseAt: (x: number, z: number, yaw: number) => original()?.slopeAt(x, z, yaw),
    get harunaDrive() { return archive ? harunaDrive : undefined; },
    get state() { return current().state; },
    get pose() {
      const run = original();
      if (!run) return terrain.pose;
      return { y: run.heightAt(run.state.x, run.state.z), pitch: 0, roll: 0, grounded: true, kind: GroundKind.Asphalt };
    },
    step(dt: number, input: DriverInput) { current().step(dt, input); },
    reset(mode?: RunMode, driveMode?: HarunaDriveMode) {
      if (archive && driveMode) harunaDrive = driveMode;
      setOpenTerrain(!!archive && harunaDrive === 'terrain');
      current().reset(mode);
    },
    setFeintMode(enabled: boolean) { archive?.setFeintMode(enabled); terrain.setFeintMode(enabled); },
    get time() { return current().time; },
    get lap() { return current().lap; },
    get heading() { return current().heading; },
    get impact() { return current().impact; },
    get finished() { return current().finished; },
    get progress() { return current().progress; },
    get lane() { return current().lane; },
    get scoringZone() { return current().scoringZone; },
  };
}

function createTerrainRun(spec: MountainSpec, groundAt: GroundAt) {
  const { route, start, finish } = spec;
  const length = finish - start;
  const { x0, x1, z0, z1 } = route.bounds;
  const mapScale = Math.min(56 / Math.max(1, x1 - x0), 72 / Math.max(1, z1 - z0));
  const mapX = (x: number) => 50 - (x - (x0 + x1) * 0.5) * mapScale;
  const mapY = (z: number) => 49 - (z - (z0 + z1) * 0.5) * mapScale;
  const pathPoint = (s: number) => {
    const pos = route.at(start + s);
    return `${mapX(pos.x).toFixed(2)},${mapY(pos.z).toFixed(2)}`;
  };
  function path(from: number, to: number, stride: number) {
    const points = [];
    for (let s = from; s < to; s += stride) points.push(pathPoint(s));
    points.push(pathPoint(to));
    return `M${points.join(' ')}`;
  }
  const map = path(0, length, route.loop ? 4 : 10) + (route.loop ? ' Z' : '');
  const grid = route.at(start);
  const startMarker = { x: mapX(grid.x), y: mapY(grid.z) };
  const zones: DriftZone[] = [];
  let zoneStart = 0, zoneSide = 0;
  for (let s = 8; s <= length + 3; s += 3) {
    const k = route.at(start + s).curv;
    const side = s < length - 3 && Math.abs(k) > 0.012 ? -Math.sign(k) : 0;
    if (side === zoneSide) continue;
    if (zoneSide && s - zoneStart > 14) zones.push({ start: zoneStart, end: s, side: zoneSide, path: path(zoneStart, s, 5) });
    zoneStart = s; zoneSide = side;
  }

  const botTrack = { length, loop: route.loop, at(s: number) { return route.at(start + s); } };
  const drive = createMountainCar(groundAt);
  const { state, pose } = drive;
  const score = createDriftScore({ minAngle: 12 * Math.PI / 180, comboAngle: 0.175, maxAngle: 115 * Math.PI / 180,
    spinAngle: 118 * Math.PI / 180, minSlip: -1 });
  const bottom = route.rows.reduce((min, row) => Math.min(min, row.y), Infinity) - 66;

  let elapsed = 0, lap = 1, last: number | null = null, best: number | null = null;
  let progress = 0, previous = 0, furthest = 0, gate = 1;
  let started = false, finished = false, mode: RunMode = 'attack';
  let heading = 0, lane = 0, scoringZone = -1;

  function spawn() {
    heading = spec.id === 'haruna' ? spec.track.psi[Math.floor(spec.track.startS)] : Math.atan2(grid.tx, grid.tz);
    drive.reset(grid.x, grid.z, heading);
    lane = previous = 0;
  }

  function reset(next: RunMode = mode) {
    spawn();
    elapsed = progress = furthest = 0; gate = lap = 1;
    mode = next; started = finished = false; scoringZone = -1;
    score.reset();
  }

  function step(dt: number, input: DriverInput) {
    if (finished) return;
    drive.step(dt, input);
    if (pose.y < bottom || !Number.isFinite(pose.y)) { reset(); return; }
    const q = route.nearest(state.x, state.z);
    lane = -q.signed;
    heading = Math.atan2(q.tx, q.tz);
    const rel = route.loop ? T.MathUtils.euclideanModulo(q.s - start, length) : T.MathUtils.clamp(q.s - start, 0, length);
    const alignment = state.vx * q.tx + state.vz * q.tz;
    const onRoute = (pose.kind === GroundKind.Asphalt || pose.kind === GroundKind.Gutter) && pose.grounded && q.dist <= route.half + route.gutter + 0.5;
    const followsTrack = onRoute && alignment > 0.15;
    const target = length * gate * 0.25;
    if (followsTrack && gate < 4 && previous < target && rel >= target && rel - previous < 6) gate++;
    if (followsTrack && rel <= length * gate * 0.25 + 4 && rel - previous < 6) {
      furthest = Math.max(furthest, rel);
      progress = rel;
    }
    if (state.speed > 0.28) started = true;
    if (started) elapsed += dt;
    const zoneIndex = zones.findIndex(item => rel >= item.start && rel < item.end);
    const outer = zones[zoneIndex];
    const backwards = state.gear === 'R' || alignment < 0 || (rel < furthest - 12 && gate < 4);
    score.step(dt, { speed: pose.grounded ? state.speed : 0, beta: state.beta, forward: state.forwardSpeed,
      along: backwards || !onRoute ? 0 : alignment, pointsAlong: backwards || !onRoute ? 0 : alignment,
      slip: state.rearSlip, roughness: onRoute ? state.roughness : 1, impact: pose.impact, linking: state.driftPhase === 'link',
      outside: !!outer && onRoute && lane * outer.side > route.half * 0.46 && Math.sign(state.beta) === outer.side });
    scoringZone = score.inBonus ? zoneIndex : -1;
    const crossed = route.loop ? (previous > length - 5 && rel < 5) : (previous < length && rel >= length - 0.02);
    previous = rel;
    if (crossed && gate === 4 && followsTrack && started) {
      last = elapsed;
      best = best === null ? last : Math.min(last, best);
      if (mode === 'attack') { score.finish(); finished = true; furthest = progress = length; }
      else {
        lap++; elapsed = progress = furthest = 0; gate = 1;
        if (!route.loop) spawn();
      }
    }
  }

  function snapshot(): Telemetry {
    return { lap, best, last, time: elapsed, speed: toKmh(state.rcSpeed ?? state.speed), gear: state.gear, rev: state.rev,
      shifting: state.shifting, coasting: state.coasting, throttle: state.throttle, mapX: mapX(state.x), mapY: mapY(state.z), heading: state.yaw,
      distance: furthest, driftAngle: Math.round(T.MathUtils.radToDeg(Math.abs(state.beta))), controlPhase: state.driftPhase,
      drift: score.snapshot(), mode, finished, elevation: pose.y, grounded: pose.grounded,
      surface: !pose.grounded ? 'Udara' : pose.kind === GroundKind.Asphalt ? 'Aspal' : pose.kind === GroundKind.Gutter ? 'Bahu jalan' : 'Tanah',
    };
  }

  reset();
  return { route: map, startMarker, length, zones, botTrack, state, pose, step, snapshot, reset,
    setFeintMode: drive.setFeintMode,
    get time() { return elapsed; }, get lap() { return lap; }, get heading() { return heading; }, get impact() { return pose.impact; },
    get finished() { return finished; }, get progress() { return (lap - 1) * length + progress; },
    get lane() { return lane; }, get scoringZone() { return scoringZone; },
  };
}