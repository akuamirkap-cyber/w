import type { DriftZone, Telemetry } from './rally-course';
import type { GhostHudData } from './ghost-replay.js';
import { outsideMultiplier } from './drift-score.js';
import { COURSES } from './course-selection';

export type Route = { path: string; start: { x: number; y: number }; length: number; zones: DriftZone[]; name?: string };
export const formatScore = (value:number) => value.toLocaleString('id-ID');
export const bonusPercent=Math.round((outsideMultiplier-1)*100);

export function RallyMark() {
  return <svg width="24" height="24" viewBox="0 0 29 29" fill="currentColor" aria-hidden="true">
    <path d="M9 6h6l-2.6 5.7h-6L9 6Zm9.9 0h6l-2.6 5.7h-6L18.9 6Zm-7.2 5.7h6l-2.6 5.7h-6l2.6-5.7Zm-7.3 5.7h6l-2.6 5.6h-6l2.6-5.6Zm9.9 0h6l-2.6 5.6h-6l2.6-5.6Z"/>
  </svg>;
}

export function RaceBrand() {
  return <div className="race-brand" aria-label="PRODRIFT">
    <span className="race-mark"><RallyMark/></span><span className="race-name">PRO<span>DRIFT</span></span><span className="race-series">GROUP B</span>
  </div>;
}

export function clock(seconds: number) {
  const ms = Math.max(0, Math.floor(seconds * 1000 + .000001));
  const minutes = String(Math.floor(ms / 60000)).padStart(2, '0');
  const remainder = String(Math.floor(ms / 1000) % 60).padStart(2, '0');
  return `${minutes}:${remainder}.${String(ms % 1000).padStart(3, '0')}`;
}

export function LapReadout({ data, route, record, ghost }: { data: Telemetry; route: Route; record: number; ghost?:GhostHudData|null }) {
  const watching=ghost?.mode==='watch', pace=ghost?.paceDelta;
  const lapLabel = route.name === COURSES.haruna.name.toUpperCase() ? 'ETAPE' : 'PUTARAN';
  const modeLabel = data.harunaDrive === 'terrain' ? 'JELAJAH MEDAN' : data.mode === 'attack' ? 'DRIFT ATTACK' : 'LATIHAN BEBAS';
  return <div className={`lap-readout${watching?' watched-lap':''}`}>
    <div className="lap-label"><i aria-hidden="true"/><span>{watching?'KAMERA GHOST':modeLabel}</span><span>{watching?'QUALIFYING':data.harunaDrive==='terrain'?'BEBAS':data.mode==='attack'?`1 ${lapLabel}`:`${lapLabel} ${String(data.lap).padStart(2,'0')}`}</span></div>
    <output className="lap-time" aria-label="Waktu putaran" aria-live="off">{clock(data.time)}</output>
    <div className="lap-progress" role="progressbar" aria-label="Jarak putaran" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(data.distance / route.length * 100)}><i style={{ width: `${data.distance / route.length * 100}%` }}/></div>
    <div className="lap-distance"><span>JARAK</span><output aria-live="off">{(data.distance / 1000).toFixed(2)} <b>/</b> {(route.length / 1000).toFixed(2)} KM</output></div>
    {data.elevation !== undefined && <div className="terrain-readout" data-grounded={data.grounded}>
      <span>{data.surface}</span><output aria-label="Elevasi mobil" aria-live="off">{(Math.abs(data.elevation) < 0.05 ? 0 : data.elevation).toFixed(1)} m</output>
    </div>}
    <div className="score-tally">
      <div><span>{watching?'SKOR GHOST':'SKOR'}</span><output aria-label="Skor drift tersimpan" aria-live="off">{formatScore(data.drift.total)}</output></div>
      <div><span>{watching?'BONUS TERSIMPAN':data.mode==='practice'?'KOMBO TERBAIK':'REKOR'}</span><output aria-label={watching?'Poin tambahan zona bonus':undefined}>{formatScore(watching?data.drift.bonusPoints:data.mode==='practice'?data.drift.top:record)}</output></div>
    </div>
    {ghost&&<div className="ghost-pace"><span>ACUAN GHOST</span><output aria-label="Waktu acuan Ghost">{clock(ghost.lapTarget)}</output>
      {!watching&&pace!=null&&<b className={pace>0?'pace-behind':''} title="Selisih di jarak yang sama">{pace>0?'+':pace<0?'-':''}{Math.abs(pace).toLocaleString('id-ID',{minimumFractionDigits:2,maximumFractionDigits:2})} dtk</b>}</div>}
    {watching&&ghost&&<><div className="ghost-line-key" aria-label="Jejak di lintasan: hijau untuk gas, jingga untuk rem, emas untuk zona bonus"><span>JEJAK</span><span><i/> GAS</span><span><i/> REM</span><span><i/> BONUS</span></div>
      <div className="ghost-zone-count"><span>ZONA BONUS</span><output aria-label="Zona bonus yang dipakai Ghost">{ghost.bonusCoverage}/{ghost.zoneCount}</output></div></>}
  </div>;
}

export function SpeedReadout({ data, pedal=false }: { data: Telemetry; pedal?:boolean }) {
  const percent=Math.round(data.throttle*100);
  return <div className="speed-hud">
    <div className="speed-row">
      <div className="speed-value"><output aria-label="Kecepatan di lintasan" aria-live="off">{String(data.speed).padStart(2, '0')}</output><span>KM/J</span></div>
      <div className={`gear-value${data.shifting ? ' gear-shifting' : ''}`}><span>AUTO</span><output aria-label="Gigi saat ini" aria-live="off">{data.gear === 'R' ? 'R' : `D${data.gear}`}</output></div>
    </div>
    <div className="rev-meter" role="img" aria-label="Putaran mesin">
      {Array.from({length:14},(_,i)=><i key={i} className={`${i<Math.round(data.rev*14)?'rev-lit':''}${i>10?' rev-redline':''}`}/>)}
    </div>
    {pedal&&<div className={`throttle-strip${data.coasting?' is-coasting':''}`}>
      <span role="meter" className="throttle-fill" aria-label="Bukaan gas" aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}><i style={{transform:`scaleX(${data.throttle})`}}/></span>
      <span>{data.coasting?'MELUNCUR':`GAS ${percent}%`}</span>
    </div>}
  </div>;
}

const coachCopy={entry:'Atur gas, jaga sudut',slide:'Jaga sudut, koreksi setir',link:'Transisi drift',exit:'Luruskan setir, jaga momentum'};
export function DrivePrompt({ data }: { data:Telemetry }) {
  if(data.controlPhase==='grip'||data.speed<24)return null;
  return <div className={`drive-prompt prompt-${data.controlPhase}`}><i/>{coachCopy[data.controlPhase]}<i/></div>;
}

export function RouteMap({ data, route, companion, ghost=false }: { data: Telemetry; route: Route; companion?:Telemetry; ghost?:boolean }) {
  if (!route.path) return null;
  const angle = -data.heading * 180 / Math.PI;
  const courseTitle = route.name ?? 'SIRKUIT PINUS';
  return <div className="route-hud" aria-label={`Peta ${courseTitle}`} role="img">
    <svg viewBox="15 8 70 85" aria-hidden="true">
      <path className="route-shadow" d={route.path}/><path className="route-track" d={route.path}/>
      {route.zones.map(zone=><path key={zone.start} className={`route-zone${data.distance>=zone.start&&data.distance<zone.end?' zone-current':''}`} d={zone.path}/>)}
      <path className="route-start" d={`M${route.start.x - 4} ${route.start.y}h8`}/>
      {companion&&<path className="route-needle ghost-needle" d="M0 -4.6 3.3 3.7 0 2.3 -3.3 3.7Z" transform={`translate(${companion.mapX} ${companion.mapY}) rotate(${-companion.heading*180/Math.PI})`}/>}
      <path className={`route-needle${ghost?' ghost-needle':''}`} d="M0 -4.5 3.1 3.7 0 2.3 -3.1 3.7Z" transform={`translate(${data.mapX} ${data.mapY}) rotate(${angle})`}/>
    </svg>
    <span>{courseTitle}</span>
  </div>;
}

export function DriftReadout({ data }: { data: Telemetry }) {
  const score=data.drift, {phase}=score;
  if (phase==='idle'||!score.points) return null;
  const result=phase==='banked'||phase==='lost';
  const title=phase==='banked'?'KOMBO TERSIMPAN':phase==='lost'?'KOMBO PUTUS':phase==='carry'?'SAMBUNG DRIFT':score.links?'DRIFT BERANTAI':'DRIFT';
  return <div className={`drift-readout drift-${phase}`} data-chain={score.links} aria-label="Kombo drift" key={result?phase:'active'}>
    <span className="drift-heading"><i/> {title} <i/></span>
    <div className="drift-count"><strong>{phase==='banked'?'+':''}{formatScore(score.points)}</strong>{!result&&<span>x{score.multiplier.toFixed(1)}</span>}</div>
    {phase==='lost'?<span className="drift-angle">{score.cause}</span>:result?<span className="drift-angle">{score.links?`${score.links} SAMBUNGAN`:'DRIFT BERSIH'}</span>:<>
      <span className="drift-detail"><span>{score.links?`${score.links} SAMBUNGAN`:`${data.driftAngle}\u00b0 SUDUT`}</span>{score.outer&&<b>ZONA LUAR +{bonusPercent}%</b>}</span>
      <span className="drift-window" aria-hidden="true"><i style={{transform:`scaleX(${score.grace})`}}/></span>
    </>}
  </div>;
}