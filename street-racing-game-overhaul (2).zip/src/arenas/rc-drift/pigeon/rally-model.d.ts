import type * as Three from 'three';
import type { RallyBuild } from './rally-config';
import type { DriftState } from './drift-physics.js';

type ModelOptions = Partial<RallyBuild> & {
  build?: Partial<RallyBuild>;
  THREE?: typeof Three;
  headlights?: boolean;
  cockpit?: boolean;
  canvasFactory?: (width: number, height: number) => HTMLCanvasElement;
};

type DriveFrame = {
  speed: number;
  steer: number;
  gear?: string;
  rev?: number;
  handbrake?: boolean;
  serviceBrake?: boolean;
  displayKmh?: number;
  inspectGear?: boolean;
  animateCabin?: boolean;
  wheels?: DriftState['wheels'];
  accelLong?: number;
  accelLat?: number;
  steerAngle?: number;
  roughness?: number;
};

export type RallyModel = Three.Group & { userData: {
  tick: (dt: number, state: DriveFrame) => void;
  setHeadlights: (enabled: boolean) => void;
  updateGlow: (eye: Three.Vector3) => void;
  setCockpitView: (enabled: boolean, preservePose?: boolean) => void;
  setMirrorTexture: (texture: Three.Texture | null) => void;
  resetDriver: (gear?: string) => void;
  driverAction: { mode: 'wheel' | 'brake' | 'gear'; reach: number; contact: boolean };
  sockets: { driverEye: Three.Object3D };
  build: RallyBuild;
  setBuild: (patch: Partial<RallyBuild>) => RallyBuild;
} };

export const DEFAULT_RALLY_BUILD: Readonly<RallyBuild>;
export function configureRallyThree(three: typeof Three): void;
export function createRallyCarModel(options?: ModelOptions): RallyModel;