import * as THREE from 'three';
import { globalUniforms } from '../haruna-v2/materials';
import type { V2TextureSet } from '../haruna-v2/textures';
import type { PBRTextureSet, V3SurfaceTextureSet } from './textures';

export interface V3FoliageUniforms {
  uTime: { value: number };
  uWindStrength: { value: number };
  uSunDirection: { value: THREE.Vector3 };
  uSunColor: { value: THREE.Color };
  uTranslucency: { value: number };
}

export const v3FoliageUniforms: V3FoliageUniforms = {
  uTime: globalUniforms.uTime,
  uWindStrength: globalUniforms.uWind,
  uSunDirection: { value: new THREE.Vector3(0.45, 0.72, 0.52).normalize() },
  uSunColor: { value: new THREE.Color('#fff2d6') },
  uTranslucency: globalUniforms.uTransl,
};

function attachBotanicalShader(
  mat: THREE.MeshStandardMaterial,
  uniforms: V3FoliageUniforms,
  options: {
    windAmp: number;
    windFreq: number;
    sssTint: THREE.Color;
    sssIntensity: number;
    rootAO?: boolean;
    key: string;
  }
): THREE.MeshDepthMaterial {
  const sssColorUniform = { value: options.sssTint.clone() };
  const sssStrengthUniform = { value: options.sssIntensity };
  const windAmpUniform = { value: options.windAmp };
  const windFreqUniform = { value: options.windFreq };

  mat.customProgramCacheKey = () => `v3-botanical-pbr-${options.key}`;

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.uniforms.uSunDirection = uniforms.uSunDirection;
    shader.uniforms.uSunColor = uniforms.uSunColor;
    shader.uniforms.uTranslucency = uniforms.uTranslucency;
    shader.uniforms.uSssColor = sssColorUniform;
    shader.uniforms.uSssIntensity = sssStrengthUniform;
    shader.uniforms.uWindAmp = windAmpUniform;
    shader.uniforms.uWindFreq = windFreqUniform;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform float uWindStrength;
        uniform float uWindAmp;
        uniform float uWindFreq;
        varying vec3 vWorldPosCustom;
        varying float vTipFactor;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 worldPosBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipWeight = clamp(uv.y, 0.0, 1.0);
        tipWeight = tipWeight * tipWeight;
        vTipFactor = clamp(uv.y, 0.0, 1.0);

        float phase = worldPosBase.x * 0.42 + worldPosBase.z * 0.37 + worldPosBase.y * 0.25;
        float gust = sin(uTime * uWindFreq + phase) * 0.65 + sin(uTime * (uWindFreq * 2.35) + phase * 1.9) * 0.35;
        float flutter = sin(uTime * (uWindFreq * 4.7) + worldPosBase.x * 3.1 + worldPosBase.z * 2.7) * 0.22;
        float sway = (gust + flutter) * uWindAmp * uWindStrength * tipWeight;

        transformed.x += sway;
        transformed.z += sway * 0.62;
        transformed.y -= abs(sway) * 0.14;

        vec4 worldPosFinal = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosFinal = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        vWorldPosCustom = worldPosFinal.xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform vec3 uSunDirection;
        uniform vec3 uSunColor;
        uniform float uTranslucency;
        uniform vec3 uSssColor;
        uniform float uSssIntensity;
        varying vec3 vWorldPosCustom;
        varying float vTipFactor;
        `
      )
      .replace(
        '#include <opaque_fragment>',
        `
        vec3 viewDirW = normalize(cameraPosition - vWorldPosCustom);
        vec3 sunDirW = normalize(uSunDirection);

        float backScatter = pow(clamp(dot(viewDirW, -sunDirW), 0.0, 1.0), 3.0);
        float upTrans = clamp(sunDirW.y * 0.65 + 0.25, 0.0, 1.0) * (0.28 + 0.72 * vTipFactor);
        float sssFactor = clamp((backScatter * 0.62 + upTrans * 0.20) * uSssIntensity * uTranslucency, 0.0, 0.78);

        vec3 sssContribution = diffuseColor.rgb * uSssColor * uSunColor * sssFactor;

        ${
          options.rootAO
            ? `
        float rootOcclusion = mix(0.40, 1.05, smoothstep(0.0, 0.55, vTipFactor));
        outgoingLight *= rootOcclusion;
        sssContribution *= smoothstep(0.08, 0.75, vTipFactor);
        `
            : ''
        }

        vec3 combinedLeaf = outgoingLight + sssContribution;
        outgoingLight = combinedLeaf / (vec3(1.0) + combinedLeaf * 0.22);
        #include <opaque_fragment>
        `
      );
  };

  const depthMat = new THREE.MeshDepthMaterial({
    depthPacking: THREE.RGBADepthPacking,
    map: mat.map,
    alphaTest: mat.alphaTest,
    side: THREE.DoubleSide,
  });

  depthMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.uniforms.uWindAmp = windAmpUniform;
    shader.uniforms.uWindFreq = windFreqUniform;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform float uWindStrength;
        uniform float uWindAmp;
        uniform float uWindFreq;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 worldPosBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          worldPosBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipWeight = clamp(uv.y, 0.0, 1.0);
        tipWeight = tipWeight * tipWeight;
        float phase = worldPosBase.x * 0.42 + worldPosBase.z * 0.37 + worldPosBase.y * 0.25;
        float gust = sin(uTime * uWindFreq + phase) * 0.65 + sin(uTime * (uWindFreq * 2.35) + phase * 1.9) * 0.35;
        float sway = gust * uWindAmp * uWindStrength * tipWeight;
        transformed.x += sway;
        transformed.z += sway * 0.62;
        `
      );
  };

  return depthMat;
}

/**
 * Forest floor dead-leaf mulch material (100% from realistic-3d-nature-assets.zip)
 * with seamless world-space macro moisture/dryness breakup so embankments never look tiled.
 */
export function createV3ForestFloorMaterial(
  tex: PBRTextureSet,
  opts?: { farSkyline?: boolean; doubleSide?: boolean }
): THREE.MeshStandardMaterial {
  const farSkyline = Boolean(opts?.farSkyline);
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.75, 1.75),
    roughnessMap: tex.roughnessMap,
    roughness: 0.96,
    metalness: 0.0,
    vertexColors: true,
    envMapIntensity: 0.72,
    side: opts?.doubleSide ? THREE.DoubleSide : THREE.FrontSide,
  });

  mat.customProgramCacheKey = () => `v3-forest-floor-macro-pbr-${farSkyline ? 1 : 0}-${opts?.doubleSide ? 1 : 0}`;
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vFloorWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    let frag = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec3 vFloorWorldPos;
        float hashFloor(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float vNoiseFloor(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashFloor(i);
          float b = hashFloor(i + vec2(1.0, 0.0));
          float c = hashFloor(i + vec2(0.0, 1.0));
          float d = hashFloor(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float macro1 = vNoiseFloor(vFloorWorldPos.xz * 0.28);
        float macro2 = vNoiseFloor(vFloorWorldPos.xz * 0.85 + vec2(7.3, 4.1));
        float patchVar = macro1 * 0.65 + macro2 * 0.35;
        vec3 dampTint = vec3(0.76, 0.72, 0.68);
        vec3 dryLitTint = vec3(1.16, 1.11, 1.03);
        diffuseColor.rgb *= mix(dampTint, dryLitTint, smoothstep(0.22, 0.78, patchVar));
        `
      );

    if (farSkyline) {
      frag = frag.replace('#include <fog_fragment>', `
        #ifdef USE_FOG
          #ifdef FOG_EXP2
            float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
          #else
            float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
          #endif
          fogFactor = min(fogFactor, 0.84);
          gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
        #endif
      `);
    }

    shader.fragmentShader = frag;
  };

  return mat;
}

/**
 * Photorealistic Japanese Touge Mountain Asphalt PBR material (from realistic-3d-nature-assets.zip):
 * Crushed basalt aggregate + spline-aware rubber tire tracks, weathering, and soft earthy shoulder edges.
 */
export function createV3TougeAsphaltMaterial(tex: PBRTextureSet): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    normalMap: tex.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: tex.roughnessMap,
    roughness: 0.9,
    metalness: 0.03,
    envMapIntensity: 0.92,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });

  mat.customProgramCacheKey = () => 'v3-touge-asphalt-pbr-v1';
  mat.onBeforeCompile = (shader) => {
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute vec2 aRoadCoord;
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vRoadCoord = aRoadCoord;
        vAsphaltWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        varying vec2 vRoadCoord;
        varying vec3 vAsphaltWorldPos;

        float hashAsph(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
        }
        float noiseAsph(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = hashAsph(i);
          float b = hashAsph(i + vec2(1.0, 0.0));
          float c = hashAsph(i + vec2(0.0, 1.0));
          float d = hashAsph(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        `
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float u = vRoadCoord.x;
        float s = vRoadCoord.y;

        float macroW1 = noiseAsph(vAsphaltWorldPos.xz * 0.22);
        float macroW2 = noiseAsph(vAsphaltWorldPos.xz * 0.72 + vec2(4.7, 9.1));
        float macroWeather = macroW1 * 0.62 + macroW2 * 0.38;
        diffuseColor.rgb *= mix(0.86, 1.15, smoothstep(0.2, 0.82, macroWeather));

        float driftShift = sin(s * 0.14 + 0.6) * 0.065;
        float track1 = exp(-pow((u - (0.30 + driftShift)) / 0.068, 2.0));
        float track2 = exp(-pow((u - (0.48 + driftShift * 0.85)) / 0.072, 2.0));
        float track3 = exp(-pow((u - (0.64 + driftShift * 0.7)) / 0.064, 2.0));
        float track4 = exp(-pow((u - (0.79 + driftShift * 0.5)) / 0.058, 2.0));
        float trackStreakNoise = 0.58 + 0.42 * noiseAsph(vec2(u * 26.0, s * 0.22));
        float tireMask = clamp((track1 * 0.65 + track2 * 0.85 + track3 * 0.9 + track4 * 0.75) * trackStreakNoise, 0.0, 1.0);

        diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.68, 0.69, 0.71), tireMask * 0.56);

        float edgeNoise = noiseAsph(vAsphaltWorldPos.xz * 1.45);
        float outerDust = smoothstep(0.15, 0.0, u + (edgeNoise - 0.5) * 0.055);
        float innerDust = smoothstep(0.86, 1.0, u + (edgeNoise - 0.5) * 0.055);
        float shoulderMask = clamp(outerDust + innerDust, 0.0, 1.0);
        vec3 shoulderGrit = vec3(0.36, 0.33, 0.28);
        diffuseColor.rgb = mix(diffuseColor.rgb, shoulderGrit, shoulderMask * 0.58);

        float sunCrown = smoothstep(0.08, 0.45, u) * smoothstep(0.95, 0.55, u);
        diffuseColor.rgb *= (1.0 + sunCrown * 0.07);
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        `#include <roughnessmap_fragment>
        float rDriftShift = sin(vRoadCoord.y * 0.14 + 0.6) * 0.065;
        float rTrack = exp(-pow((vRoadCoord.x - (0.48 + rDriftShift * 0.85)) / 0.09, 2.0))
                     + exp(-pow((vRoadCoord.x - (0.64 + rDriftShift * 0.7)) / 0.09, 2.0));
        float rShoulder = smoothstep(0.14, 0.0, vRoadCoord.x) + smoothstep(0.87, 1.0, vRoadCoord.x);
        roughnessFactor = clamp(roughnessFactor - rTrack * 0.14 + rShoulder * 0.14, 0.48, 0.98);
        `
      );
  };

  return mat;
}

function createBBGrassMaterial(uniforms: V3FoliageUniforms): THREE.MeshStandardMaterial {
  const bbGrass = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    vertexColors: true,
    roughness: 0.56,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.72,
  });
  bbGrass.customProgramCacheKey = () => 'v3-bb-3d-grass-blade-pbr';
  bbGrass.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.uniforms.uSunDirection = uniforms.uSunDirection;
    shader.uniforms.uSunColor = uniforms.uSunColor;
    shader.uniforms.uTranslucency = uniforms.uTranslucency;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute float aAO;
        uniform float uTime;
        uniform float uWindStrength;
        varying vec3 vWorldPosBB;
        varying float vBBTip;
        varying float vBBAO;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 wBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          wBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipH = clamp(uv.y, 0.0, 1.0);
        vBBTip = tipH;
        vBBAO = aAO;
        float swayWeight = tipH * tipH;
        float phase = wBase.x * 0.48 + wBase.z * 0.41;
        float gust = sin(uTime * 1.95 + phase) * 0.65 + sin(uTime * 4.2 + phase * 1.8) * 0.35;
        float sway = gust * 0.09 * uWindStrength * swayWeight;
        transformed.x += sway;
        transformed.z += sway * 0.64;
        transformed.y -= abs(sway) * 0.16;

        vec4 wFinal = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          wFinal = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        vWorldPosBB = wFinal.xyz;
        `
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform vec3 uSunDirection;
        uniform vec3 uSunColor;
        uniform float uTranslucency;
        varying vec3 vWorldPosBB;
        varying float vBBTip;
        varying float vBBAO;
        `
      )
      .replace(
        '#include <opaque_fragment>',
        `
        vec3 vDirBB = normalize(cameraPosition - vWorldPosBB);
        vec3 sDirBB = normalize(uSunDirection);
        float backBB = pow(clamp(dot(vDirBB, -sDirBB), 0.0, 1.0), 2.8);
        float upBB = clamp(sDirBB.y * 0.6 + 0.25, 0.0, 1.0) * (0.25 + 0.75 * vBBTip);
        float sssBB = clamp((backBB * 0.58 + upBB * 0.22) * 0.78 * uTranslucency, 0.0, 0.72);
        vec3 sssGlowBB = diffuseColor.rgb * vec3(0.75, 0.96, 0.34) * uSunColor * sssBB * smoothstep(0.08, 0.75, vBBTip);

        float aoTerm = mix(0.42, 1.06, clamp(vBBAO, 0.0, 1.0));
        vec3 finalBB = outgoingLight * aoTerm + sssGlowBB;
        outgoingLight = finalBB / (vec3(1.0) + finalBB * 0.22);
        #include <opaque_fragment>
        `
      );
  };

  const bbGrassDepth = new THREE.MeshDepthMaterial({
    depthPacking: THREE.RGBADepthPacking,
    side: THREE.DoubleSide,
  });
  bbGrassDepth.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.uniforms.uWindStrength = uniforms.uWindStrength;
    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform float uWindStrength;
        `
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vec4 wBase = modelMatrix * vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          wBase = modelMatrix * instanceMatrix * vec4(transformed, 1.0);
        #endif
        float tipH = clamp(uv.y, 0.0, 1.0);
        float phase = wBase.x * 0.48 + wBase.z * 0.41;
        float gust = sin(uTime * 1.95 + phase) * 0.65 + sin(uTime * 4.2 + phase * 1.8) * 0.35;
        float sway = gust * 0.09 * uWindStrength * (tipH * tipH);
        transformed.x += sway;
        transformed.z += sway * 0.64;
        `
      );
  };
  bbGrass.userData.customDepthMaterial = bbGrassDepth;
  return bbGrass;
}

export function createV3SurfaceMaterials(tex: V3SurfaceTextureSet, v2Tex: V2TextureSet) {
  const forestFloor = createV3ForestFloorMaterial(tex.forestFloor);
  const forestFloorFar = createV3ForestFloorMaterial(tex.forestFloor, { farSkyline: true });
  const forestFloorShoulder = createV3ForestFloorMaterial(tex.forestFloor, { doubleSide: true });
  const tougeAsphalt = createV3TougeAsphaltMaterial(tex.asphalt);

  const dryLeafScatter = new THREE.MeshStandardMaterial({
    map: tex.dryLeafCard.map,
    normalMap: tex.dryLeafCard.normalMap,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughnessMap: tex.dryLeafCard.roughnessMap,
    roughness: 0.86,
    metalness: 0.0,
    alphaTest: 0.44,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.75,
  });

  const pineNeedleThatch = new THREE.MeshStandardMaterial({
    color: '#ffffff',
    roughness: 0.88,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.7,
  });

  const mossyRock = new THREE.MeshStandardMaterial({
    map: tex.mossyRock.map,
    normalMap: tex.mossyRock.normalMap,
    normalScale: new THREE.Vector2(1.5, 1.5),
    roughnessMap: tex.mossyRock.roughnessMap,
    roughness: 0.92,
    metalness: 0.02,
    envMapIntensity: 0.7,
  });

  const wildStems = new THREE.MeshStandardMaterial({
    map: v2Tex.barkBroad.map,
    normalMap: v2Tex.barkBroad.normal,
    normalScale: new THREE.Vector2(1.2, 1.2),
    roughness: 0.92,
    metalness: 0.0,
    envMapIntensity: 0.55,
  });

  const wildShrubLeaf = new THREE.MeshStandardMaterial({
    map: tex.shrubLeaf.map,
    normalMap: tex.shrubLeaf.normalMap,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughnessMap: tex.shrubLeaf.roughnessMap,
    roughness: 0.56,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.82,
  });
  wildShrubLeaf.userData.customDepthMaterial = attachBotanicalShader(wildShrubLeaf, v3FoliageUniforms, {
    windAmp: 0.055,
    windFreq: 1.55,
    sssTint: new THREE.Color('#b6ec44'),
    sssIntensity: 0.76,
    key: 'wild-shrub',
  });

  const wildShrubBright = new THREE.MeshStandardMaterial({
    color: '#d9f0a8',
    map: tex.shrubLeaf.map,
    normalMap: tex.shrubLeaf.normalMap,
    normalScale: new THREE.Vector2(0.8, 0.8),
    roughnessMap: tex.shrubLeaf.roughnessMap,
    roughness: 0.5,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.86,
  });
  wildShrubBright.userData.customDepthMaterial = attachBotanicalShader(wildShrubBright, v3FoliageUniforms, {
    windAmp: 0.068,
    windFreq: 1.75,
    sssTint: new THREE.Color('#c8f44c'),
    sssIntensity: 0.88,
    key: 'wild-shrub-bright',
  });

  const wildFernFrond = new THREE.MeshStandardMaterial({
    map: tex.fernFrond.map,
    normalMap: tex.fernFrond.normalMap,
    normalScale: new THREE.Vector2(0.9, 0.9),
    roughnessMap: tex.fernFrond.roughnessMap,
    roughness: 0.5,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.85,
  });
  wildFernFrond.userData.customDepthMaterial = attachBotanicalShader(wildFernFrond, v3FoliageUniforms, {
    windAmp: 0.075,
    windFreq: 1.5,
    sssTint: new THREE.Color('#beef4a'),
    sssIntensity: 0.82,
    rootAO: true,
    key: 'wild-fern',
  });

  const wildGrassClump = new THREE.MeshStandardMaterial({
    map: tex.grassBlade.map,
    normalMap: tex.grassBlade.normalMap,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughnessMap: tex.grassBlade.roughnessMap,
    roughness: 0.6,
    metalness: 0.0,
    side: THREE.DoubleSide,
    envMapIntensity: 0.8,
  });
  wildGrassClump.userData.customDepthMaterial = attachBotanicalShader(wildGrassClump, v3FoliageUniforms, {
    windAmp: 0.085,
    windFreq: 1.9,
    sssTint: new THREE.Color('#c8f25c'),
    sssIntensity: 0.68,
    rootAO: true,
    key: 'wild-grass',
  });

  const sasaLeaf = new THREE.MeshStandardMaterial({
    map: tex.sasaLeaf.map,
    normalMap: tex.sasaLeaf.normalMap,
    normalScale: new THREE.Vector2(0.85, 0.85),
    roughnessMap: tex.sasaLeaf.roughnessMap,
    roughness: 0.48,
    metalness: 0.0,
    alphaTest: 0.42,
    alphaToCoverage: true,
    side: THREE.DoubleSide,
    envMapIntensity: 0.84,
  });
  sasaLeaf.userData.customDepthMaterial = attachBotanicalShader(sasaLeaf, v3FoliageUniforms, {
    windAmp: 0.055,
    windFreq: 1.7,
    sssTint: new THREE.Color('#b6ec4c'),
    sssIntensity: 0.78,
    rootAO: true,
    key: 'bb-sasa',
  });

  const bbGrass = createBBGrassMaterial(v3FoliageUniforms);

  return {
    forestFloor,
    forestFloorFar,
    forestFloorShoulder,
    tougeAsphalt,
    dryLeafScatter,
    pineNeedleThatch,
    mossyRock,
    wildStems,
    wildShrubLeaf,
    wildShrubBright,
    wildFernFrond,
    wildGrassClump,
    sasaLeaf,
    bbGrass,
  };
}
