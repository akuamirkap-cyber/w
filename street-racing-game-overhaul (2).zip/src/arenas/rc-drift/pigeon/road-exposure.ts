import type * as Three from 'three';
import { roadExposure, roadFlow } from './speed-cues.js';

export function createRoadExposure(T: typeof Three) {
  const screen=new T.Scene(),camera=new T.Camera(),zero=new T.Vector2();
  let pixels:Three.FramebufferTexture|null=null;
  const uniforms={
    image:{value:null as Three.Texture|null},projection:{value:new T.Matrix4()},inverseLens:{value:new T.Matrix4()},
    upView:{value:new T.Vector3()},shutter:{value:new T.Vector3()},height:{value:2},amount:{value:0},side:{value:.3},
  };
  const material=new T.ShaderMaterial({uniforms,depthTest:false,depthWrite:false,toneMapped:false,blending:T.NoBlending,
    vertexShader:`varying vec2 pixel;
      void main(){pixel=uv;gl_Position=vec4(position.xy,0.0,1.0);}`,
    fragmentShader:`uniform sampler2D image;
      uniform mat4 projection, inverseLens;
      uniform vec3 upView, shutter;
      uniform float height, amount, side;
      varying vec2 pixel;
      void main() {
        vec4 clearColor=texture2D(image,pixel);
        vec2 xy=pixel*2.0-1.0;
        float peripheral=smoothstep(side,min(.97,side+.49),abs(xy.x));
        // Reconstruct a ray to the road and project it back by one physical exposure.
        vec4 point=inverseLens*vec4(xy,0.0,1.0);
        vec3 ray=normalize(point.xyz/point.w);
        float fall=-dot(ray,upView);
        if(peripheral<.01||fall<.021){gl_FragColor=clearColor;return;}
        float mixBy=amount*peripheral*smoothstep(.026,.16,fall);
        vec3 hit=ray*height/max(fall,.02);
        vec4 previous=projection*vec4(hit+shutter,1.0);
        if(previous.w<.06){gl_FragColor=clearColor;return;}
        vec2 direction=(xy-previous.xy/previous.w)*.5;
        direction*=min(1.0,.072/max(length(direction),.0001));
        vec2 d=direction*peripheral;
        vec4 exposure=clearColor*.30;
        exposure+=texture2D(image,clamp(pixel-d*.34,0.001,0.999))*.20;
        exposure+=texture2D(image,clamp(pixel+d*.34,0.001,0.999))*.20;
        exposure+=texture2D(image,clamp(pixel-d*.76,0.001,0.999))*.15;
        exposure+=texture2D(image,clamp(pixel+d*.76,0.001,0.999))*.15;
        gl_FragColor=mix(clearColor,exposure,mixBy);
      }`,
  });
  const plane=new T.PlaneGeometry(2,2),quad=new T.Mesh(plane,material);
  quad.frustumCulled=false;screen.add(quad);

  function render(renderer:Three.WebGLRenderer,lens:Three.PerspectiveCamera,vx:number,vz:number,bumper:boolean) {
    const speed=Math.hypot(vx,vz),weight=roadFlow(speed);
    const width=renderer.domElement.width,height=renderer.domElement.height;
    if(weight<.045||!width||!height)return;
    if(!pixels||pixels.image.width!==width||pixels.image.height!==height) {
      pixels?.dispose();pixels=new T.FramebufferTexture(width,height);
      pixels.magFilter=pixels.minFilter=T.LinearFilter;
      uniforms.image.value=pixels;
    }
    uniforms.upView.value.set(0,1,0).transformDirection(lens.matrixWorldInverse);
    uniforms.shutter.value.set(vx,0,vz).transformDirection(lens.matrixWorldInverse).multiplyScalar(roadExposure(speed));
    uniforms.projection.value.copy(lens.projectionMatrix);
    uniforms.inverseLens.value.copy(lens.projectionMatrixInverse);
    uniforms.height.value=lens.position.y+.013;
    uniforms.amount.value=weight*(bumper?.87:.70);
    uniforms.side.value=bumper?.12:T.MathUtils.lerp(.52,.28,T.MathUtils.smoothstep(lens.aspect,.62,1.58));

    // Copy the already tone-mapped frame, so bypassing the pass never changes its colors.
    renderer.copyFramebufferToTexture(pixels,zero);
    const clear=renderer.autoClear;
    renderer.autoClear=false;
    try {renderer.render(screen,camera);} finally {renderer.autoClear=clear;}
  }

  return {render,dispose(){pixels?.dispose();plane.dispose();material.dispose();}};
}