import type { MeshStandardMaterial } from 'three';
import { baseHeight } from '../../../haruna-downhill/game/terrain';
import type { Bounds } from './route';

export const HARUNA_NEAR_CELL = 4;
const HARUNA_FAR_CELL = 48;

export function harunaNearBounds({ x0, x1, z0, z1 }: Bounds): Bounds {
  const cell = HARUNA_NEAR_CELL, margin = 185;
  return { x0: Math.floor((x0 - margin) / cell) * cell, x1: Math.ceil((x1 + margin) / cell) * cell,
    z0: Math.floor((z0 - margin - 40) / cell) * cell, z1: Math.ceil((z1 + margin + 60) / cell) * cell };
}

export function makeReliefGrid(bounds: Bounds, cell: number, sample: (x: number, z: number) => number,
  alternating: boolean, skip?: (x0: number, z0: number, x1: number, z1: number) => boolean) {
  const { x0, z0 } = bounds;
  const nx = Math.round((bounds.x1 - x0) / cell), nz = Math.round((bounds.z1 - z0) / cell);
  const width = nx + 1, heights = new Float32Array(width * (nz + 1));
  for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) heights[i + j * width] = sample(x0 + i * cell, z0 + j * cell);

  const alternate = (i: number, j: number) => alternating && ((i + j) & 1) === 1;
  function filled(i: number, j: number) {
    return !skip?.(x0 + i * cell, z0 + j * cell, x0 + (i + 1) * cell, z0 + (j + 1) * cell);
  }

  function heightAt(x: number, z: number) {
    const u = (x - x0) / cell, v = (z - z0) / cell;
    if (u < 0 || v < 0 || u > nx || v > nz) return -Infinity;
    const i = Math.min(nx - 1, Math.floor(u)), j = Math.min(nz - 1, Math.floor(v));
    if (!filled(i, j)) return -Infinity;
    const p = i + j * width, fx = u - i, fz = v - j;
    const a = heights[p], b = heights[p + 1], c = heights[p + width], d = heights[p + width + 1];
    if (alternate(i, j)) {
      return fz >= fx ? a * (1 - fz) + c * (fz - fx) + d * fx : a * (1 - fx) + b * (fx - fz) + d * fz;
    }
    return fx + fz <= 1 ? a * (1 - fx - fz) + b * fx + c * fz : d * (fx + fz - 1) + c * (1 - fx) + b * (1 - fz);
  }

  return { bounds, cell, nx, nz, width, heights, alternate, filled, heightAt };
}

export type ReliefGrid = ReturnType<typeof makeReliefGrid>;

export function makeHarunaFarGrid(near: Bounds) {
  return makeReliefGrid({ x0: -4800, x1: 4800, z0: -3000, z1: 8200 }, HARUNA_FAR_CELL,
    (x, z) => Math.fround(baseHeight(x, z)) - 0.5, true,
    (x0, z0, x1, z1) => x0 >= near.x0 && z0 >= near.z0 && x1 <= near.x1 && z1 <= near.z1);
}

export function retainHarunaSkyline(material: MeshStandardMaterial) {
  // Leave PIGEON lighting and foreground fog alone; keep some contrast on kilometre-scale relief.
  material.onBeforeCompile = shader => {
    shader.fragmentShader = shader.fragmentShader.replace('#include <fog_fragment>', `
      #if defined(USE_FOG) && !defined(FOG_EXP2)
        float fogFactor = 1.0 - smoothstep(fogNear, fogFar, vFogDepth);
        float upperAir = max(0.0, 1.0 - fogFactor);
        float forestHaze = (1.0 - fogFactor) + 0.18 * (1.0 - exp(-4.0 * upperAir));
        float reliefFog = 1.0 - exp(-(forestHaze * forestHaze + 0.04 * upperAir));
        gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor, reliefFog);
      #else
        #include <fog_fragment>
      #endif
    `);
  };
}