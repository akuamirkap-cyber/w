import { MathUtils, Vector3 } from 'three';
import { curve, TRACK_LENGTH, ROAD_WIDTH, GUTTER_WIDTH, bankProfile, wildHeight } from './donor-track';
import { lerp, smoothstep } from './noise';
import { buildTrack } from '../../../haruna-downhill/game/trackLayout';
import { baseHeight, OX, OZ, RoadField, ROAD_HALF } from '../../../haruna-downhill/game/terrain';
import { roadFrame } from '../../../haruna-downhill/game/roadMesh';
import { harunaNearBounds, HARUNA_NEAR_CELL } from './haruna-relief';

export type Frame = { x: number; y: number; z: number; tx: number; tz: number; curv: number; s: number };
export type Nearest = Frame & { signed: number; dist: number };
export type Bounds = { x0: number; x1: number; z0: number; z1: number };
export type MountainSpec = ReturnType<typeof pigeonRoute> | ReturnType<typeof harunaRoute>;

function createRoute(rows: Frame[], loop: boolean, half: number, gutter: number) {
  const length = rows[rows.length - 1].s;
  const count = rows.length - 1;
  const spacing = length / count;
  const tiles = new Map<number, number[]>();
  const cell = 24;
  const key = (x: number, z: number) => x * 65536 + z;
  for (let i = 0; i < count; i++) {
    const a = rows[i], b = rows[i + 1];
    for (let x = Math.floor(Math.min(a.x, b.x) / cell); x <= Math.floor(Math.max(a.x, b.x) / cell); x++) {
      for (let z = Math.floor(Math.min(a.z, b.z) / cell); z <= Math.floor(Math.max(a.z, b.z) / cell); z++) {
        const tile = key(x, z);
        const items = tiles.get(tile);
        if (items) items.push(i); else tiles.set(tile, [i]);
      }
    }
  }

  function at(distance: number): Frame {
    const s = loop ? MathUtils.euclideanModulo(distance, length) : MathUtils.clamp(distance, 0, length);
    const i = Math.min(count - 1, Math.floor(s / spacing));
    const a = rows[i], b = rows[i + 1], t = (s - a.s) / spacing;
    const tx = MathUtils.lerp(a.tx, b.tx, t), tz = MathUtils.lerp(a.tz, b.tz, t);
    const norm = Math.hypot(tx, tz) || 1;
    return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), z: lerp(a.z, b.z, t), tx: tx / norm, tz: tz / norm, curv: lerp(a.curv, b.curv, t), s };
  }

  function nearest(x: number, z: number): Nearest {
    const cx = Math.floor(x / cell), cz = Math.floor(z / cell);
    let best = Infinity, index = 0, fraction = 0;
    function check(i: number) {
      const a = rows[i], b = rows[i + 1];
      const dx = b.x - a.x, dz = b.z - a.z;
      const u = MathUtils.clamp(((x - a.x) * dx + (z - a.z) * dz) / (dx * dx + dz * dz || 1), 0, 1);
      const ex = x - a.x - dx * u, ez = z - a.z - dz * u;
      const d2 = ex * ex + ez * ez;
      if (d2 < best) { best = d2; index = i; fraction = u; }
    }
    for (let radius = 0; radius <= 2; radius++) {
      for (let ix = cx - radius; ix <= cx + radius; ix++) {
        for (let iz = cz - radius; iz <= cz + radius; iz++) {
          if (Math.max(Math.abs(ix - cx), Math.abs(iz - cz)) !== radius) continue;
          const tile = tiles.get(key(ix, iz));
          if (tile) for (const i of tile) check(i);
        }
      }
      const outside = Math.min(x - (cx - radius) * cell, (cx + radius + 1) * cell - x, z - (cz - radius) * cell, (cz + radius + 1) * cell - z);
      if (best <= outside * outside) break;
      if (radius === 2) {
        for (let i = 0; i < count; i += 10) check(i);
        check(count - 1);
        const around = index;
        for (let i = around - 12; i <= around + 12; i++) {
          if (loop || (i >= 0 && i < count)) check(MathUtils.euclideanModulo(i, count));
        }
      }
    }
    const f = at(rows[index].s + fraction * spacing);
    return { ...f, dist: Math.sqrt(best), signed: (z - f.z) * f.tx - (x - f.x) * f.tz };
  }

  const bounds = rows.reduce<Bounds>((b, f) => ({ x0: Math.min(b.x0, f.x), x1: Math.max(b.x1, f.x), z0: Math.min(b.z0, f.z), z1: Math.max(b.z1, f.z) }),
    { x0: Infinity, x1: -Infinity, z0: Infinity, z1: -Infinity });
  return { rows, at, nearest, length, loop, half, gutter, bounds };
}

export function pigeonRoute() {
  const count = Math.ceil(TRACK_LENGTH / 0.65);
  const points = curve.getSpacedPoints(count);
  const rows = points.map((p, i): Frame => {
    const t = curve.getTangentAt(i / count, new Vector3()).setY(0).normalize();
    const a = curve.getTangentAt(MathUtils.euclideanModulo((i - 3) / count, 1)).setY(0).normalize();
    const b = curve.getTangentAt(MathUtils.euclideanModulo((i + 3) / count, 1)).setY(0).normalize();
    return { x: p.x, y: p.y, z: p.z, tx: t.x, tz: t.z, s: i * TRACK_LENGTH / count,
      curv: Math.atan2(a.z * b.x - a.x * b.z, a.dot(b)) / (6 * TRACK_LENGTH / count) };
  });
  const route = createRoute(rows, true, ROAD_WIDTH / 2, GUTTER_WIDTH);
  const terrain = (x: number, z: number, q = route.nearest(x, z)) => {
    const near = q.y + bankProfile(q.dist - route.half - route.gutter, q.signed > 0, x, z);
    const t = smoothstep(20, 60, q.dist);
    return t > 0 ? lerp(near, wildHeight(x, z) + q.y + (q.signed > 0 ? 14 : -10), t) : near;
  };
  return {
    id: 'pigeon' as const, route, terrain, corridor: 14, cell: 2,
    bounds: { x0: -248, x1: 232, z0: -198, z1: 282 },
    start: 2, finish: route.length + 2,
  };
}

export function harunaRoute() {
  const track = buildTrack(baseHeight, OX, OZ);
  const rows = Array.from(track.x, (x, i): Frame => ({
    x, y: track.y[i], z: track.z[i], tx: Math.sin(track.psi[i]), tz: Math.cos(track.psi[i]), s: i * track.ds, curv: track.kappa[i],
  }));
  const route = createRoute(rows, false, ROAD_HALF, GUTTER_WIDTH);
  const lot = roadFrame(track, Math.floor(track.startS) - 36, 31);
  const exit = roadFrame(track, track.n - 1);
  const startLot = { x: lot.x, z: lot.z, r: 22, y: lot.y };
  const finishPlaza = { x: exit.x + exit.f.x * 44, z: exit.z + exit.f.z * 44, r: 46, y: exit.y - 0.2 };
  const field = new RoadField(track, [startLot, finishPlaza], 3);
  return {
    id: 'haruna' as const, route, track, field, startLot, finishPlaza, terrain: (x: number, z: number) => field.height(x, z),
    cell: HARUNA_NEAR_CELL, bounds: harunaNearBounds(route.bounds),
    start: track.startS, finish: track.finishS,
  };
}