import * as THREE from 'three';
import { buildRoad } from '../../../haruna-downhill/game/roadMesh';
import { buildHarunaLandmarks } from '../../../haruna-downhill/game/scenery';
import { buildLake, LAKE } from '../../../haruna-downhill/game/terrain';
import { makeHarunaFarGrid, makeReliefGrid, type ReliefGrid } from '../pigeon-world/haruna-relief';
import type { harunaRoute } from '../pigeon-world/route';
import { createRoadContact } from '../pigeon-world/road-contact';
import { GroundKind, type GroundAt } from '../pigeon-world/suspension';
import { createLibrary, type AssetDef } from './library';
import { createGroundMaterial, globalUniforms, grassMaterial } from './materials';
import { createNoise2D, fbm, mulberry32, rand, smoothstep } from './noise';
import type { V2TextureSet } from './textures';
import { makeGrassTuft } from './trees';

const V = THREE.Vector3;

export interface HarunaV2WorldOptions {
  density: number;
  grass: number;
  shadowsOnBushes: boolean;
}

export function buildHarunaV2World(
  scene: THREE.Scene,
  spec: ReturnType<typeof harunaRoute>,
  tex: V2TextureSet,
  opts: HarunaV2WorldOptions,
) {
  const group = new THREE.Group();
  group.name = 'Mt. Haruna V2 world';
  scene.add(group);

  const { route, track, field, startLot, finishPlaza, bounds, cell } = spec;
  const noise = createNoise2D(7);
  const noise2 = createNoise2D(19);

  // ---------------- 1. HARUNA MOUNTAIN RELIEF WITH V2 LITTER/MOSS GROUND ----------------
  const nearGrid = makeReliefGrid(bounds, cell, (x, z) => spec.terrain(x, z), true);
  const farGrid = makeHarunaFarGrid(bounds);

  const nearGroundMat = createGroundMaterial(tex);
  nearGroundMat.color.set('#c8b8a6');
  const farGroundMat = createGroundMaterial(tex, { farSkyline: true });
  farGroundMat.color.set('#c8b8a6');

  const mossAt = (x: number, z: number, dist: number) => {
    const n = fbm(noise2, x * 0.04, z * 0.04, 3) * 0.5 + 0.5;
    return Math.min(1, smoothstep(6, 20, dist) * (0.25 + n * 0.9));
  };
  const aoAt = (dist: number) => 0.75 + 0.25 * smoothstep(4, 12, dist);

  const nearGroup = renderV2Relief(
    nearGrid,
    128 / cell,
    nearGroundMat,
    (x, z) => route.nearest(x, z).dist,
    mossAt,
    aoAt,
    true,
  );
  nearGroup.name = 'Mt. Haruna V2 hills (4 m) — V2 litter & moss';
  group.add(nearGroup);

  const farGroup = renderV2Relief(
    farGrid,
    16,
    farGroundMat,
    () => 120,
    mossAt,
    aoAt,
    false,
  );
  farGroup.name = 'Mt. Haruna V2 mountain ranges (48 m)';
  const lake = buildLake();
  lake.name = 'Mt. Haruna caldera lake';
  group.add(farGroup, lake);

  // ---------------- 2. HARUNA ROAD CONTOUR, GUARDRAILS, SIGNS & LANDMARKS + V2 ASPHALT ----------------
  const contact = createRoadContact();
  const original = buildRoad(track, field, { skipEdgeWhiteLines: true });
  original.group.name = 'Mt. Haruna V2 roadway, guardrails, signs & landmarks';
  original.markings.material.color.set(0xd5d2c8);

  // Enable full shadows on Haruna guardrails & sign posts for V2 directional sunlight
  original.guardrails.traverse(obj => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
  });

  // Build V2 asphalt ribbon along exact Haruna centerline & width (9.2m = [-4.6, +4.6])
  const across = 10;
  const rows = track.n;
  const roadW = route.half * 2; // 9.2m
  const rPos: number[] = [];
  const rUv: number[] = [];
  const rIdx: number[] = [];
  for (let i = 0; i < rows; i++) {
    const cos = Math.cos(track.psi[i]);
    const sin = Math.sin(track.psi[i]);
    for (let j = 0; j <= across; j++) {
      const u = j / across;
      const lat = (u - 0.5) * roadW;
      const crown = 0.06 * (1 - Math.pow(2 * u - 1, 2));
      rPos.push(
        track.x[i] + lat * cos,
        track.y[i] + crown + 0.015,
        track.z[i] - lat * sin,
      );
      rUv.push(u, i / 14);
    }
  }
  for (let i = 0; i < rows - 1; i++) {
    for (let j = 0; j < across; j++) {
      const a = i * (across + 1) + j;
      const b = a + across + 1;
      rIdx.push(a, b, a + 1, a + 1, b, b + 1);
    }
  }
  const rGeo = new THREE.BufferGeometry();
  rGeo.setAttribute('position', new THREE.Float32BufferAttribute(rPos, 3));
  rGeo.setAttribute('uv', new THREE.Float32BufferAttribute(rUv, 2));
  rGeo.setIndex(rIdx);
  rGeo.computeVertexNormals();

  const rMat = new THREE.MeshStandardMaterial({
    map: tex.asphalt.map,
    normalMap: tex.asphalt.normal,
    normalScale: new THREE.Vector2(0.9, 0.9),
    roughnessMap: tex.asphalt.rough,
    roughness: 1,
    metalness: 0,
    envMapIntensity: 0.8,
    color: '#d8d8d8',
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const asphalt = new THREE.Mesh(rGeo, rMat);
  asphalt.name = 'Mt. Haruna V2 crowned asphalt';
  asphalt.receiveShadow = true;
  original.group.add(asphalt);
  contact.add(asphalt, GroundKind.Asphalt);

  // Separate Haruna curbs/U-drains (V2 mossy concrete) and earth verges (V2 litter/moss ground)
  const positions = original.shoulders.geometry.getAttribute('position');
  const packed = [0, 1].map(() => ({
    pos: [] as number[],
    uv: [] as number[],
    moss: [] as number[],
    ao: [] as number[],
  }));
  for (let i = 0; i < positions.count; i += 3) {
    const part = packed[original.shoulderConcrete[i / 3]];
    for (let j = i; j < i + 3; j++) {
      const x = positions.getX(j);
      const y = positions.getY(j);
      const z = positions.getZ(j);
      part.pos.push(x, y, z);
      part.uv.push(x / 4, z / 4);
      if (part === packed[0]) {
        const d = route.nearest(x, z).dist;
        part.moss.push(mossAt(x, z, d));
        part.ao.push(aoAt(d));
      }
    }
  }
  const gutterMat = new THREE.MeshStandardMaterial({
    color: '#c9c6bc',
    roughness: 0.95,
    map: tex.moss.map,
    normalMap: tex.asphalt.normal,
    side: THREE.DoubleSide,
  });
  const shoulderGroundMat = createGroundMaterial(tex, { doubleSide: true });
  shoulderGroundMat.color.set('#c8b8a6');

  packed.forEach(({ pos, uv, moss, ao }, part) => {
    if (!pos.length) return;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    if (!part) {
      geometry.setAttribute('aMoss', new THREE.Float32BufferAttribute(moss, 1));
      geometry.setAttribute('aAO', new THREE.Float32BufferAttribute(ao, 1));
    }
    geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry, part ? gutterMat : shoulderGroundMat);
    mesh.name = part ? 'Haruna V2 curbs & U-drains' : 'Haruna V2 earth shoulders';
    mesh.receiveShadow = true;
    original.group.add(mesh);
    contact.add(mesh, part ? GroundKind.Gutter : GroundKind.Earth);
  });

  original.baseAsphalt.removeFromParent();
  original.shoulders.removeFromParent();
  original.baseAsphalt.geometry.dispose();
  original.shoulders.geometry.dispose();
  original.baseAsphalt.material.dispose();

  // Haruna start parking lot & finish plaza landmarks (torii, banners, gas station, parked cars)
  const landmarks = buildHarunaLandmarks(track, startLot, finishPlaza);
  const padAsphaltMat = new THREE.MeshStandardMaterial({
    map: tex.asphalt.map,
    normalMap: tex.asphalt.normal,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughnessMap: tex.asphalt.rough,
    roughness: 1,
    color: '#a8a8a8',
  });
  for (const surface of landmarks.surfaces) {
    const oldMat = surface.material;
    surface.material = padAsphaltMat;
    if (Array.isArray(oldMat)) oldMat.forEach(m => m.dispose());
    else oldMat.dispose();
    contact.add(surface, GroundKind.Asphalt);
  }
  original.group.add(landmarks.group);
  group.add(original.group);

  // ---------------- 3. UNIFIED COLLISION GROUND PROBE ----------------
  const scratch = { y: 0, kind: GroundKind.Void };
  const groundAt: GroundAt = (x, z, out = scratch) => {
    out.y = Math.max(nearGrid.heightAt(x, z), farGrid.heightAt(x, z));
    out.kind = Number.isFinite(out.y) ? GroundKind.Earth : GroundKind.Void;
    contact.sample(x, z, out);
    if (out.kind === GroundKind.Void) out.y = -200;
    return out;
  };

  // ---------------- 4. V2 VEGETATION & ROCK PLACEMENT ALONG HARUNA ROUTE ----------------
  const lib = createLibrary(tex);
  const defMap = new Map<string, AssetDef>(lib.map(d => [d.id, d]));
  const rng = mulberry32(2024);

  // Coarse 24m spatial corridor lookup (~165m from track) so grid sweeps stay blazingly fast
  const CORRIDOR_CELL = 24;
  const corridorKey = (cx: number, cz: number) => cx * 65536 + cz;
  const nearCorridor = new Set<number>();
  const rCells = Math.ceil(165 / CORRIDOR_CELL);
  for (let i = 0; i < route.rows.length; i += 4) {
    const row = route.rows[i];
    const cx = Math.floor(row.x / CORRIDOR_CELL);
    const cz = Math.floor(row.z / CORRIDOR_CELL);
    for (let dz = -rCells; dz <= rCells; dz++) {
      for (let dx = -rCells; dx <= rCells; dx++) {
        nearCorridor.add(corridorKey(cx + dx, cz + dz));
      }
    }
  }
  const inCorridor = (x: number, z: number) =>
    nearCorridor.has(corridorKey(Math.floor(x / CORRIDOR_CELL), Math.floor(z / CORRIDOR_CELL)));

  const gates = [route.at(spec.start), route.at(spec.finish)];
  const inside = (x: number, z: number) => {
    if (x < bounds.x0 + 6 || x > bounds.x1 - 6 || z < bounds.z0 + 6 || z > bounds.z1 - 6) return false;
    if (!inCorridor(x, z)) return false;
    if (field.platformDist(x, z) < 1.8) return false;
    if ((x - LAKE.x) ** 2 + (z - LAKE.z) ** 2 < (LAKE.r + 4) ** 2) return false;
    for (const gate of gates) {
      const dx = x - gate.x;
      const dz = z - gate.z;
      if (Math.abs(dx * gate.tx + dz * gate.tz) < 5.8 && Math.abs(dx * gate.tz - dz * gate.tx) < 11.4) return false;
    }
    return true;
  };

  type Inst = { m: THREE.Matrix4; c: THREE.Color };
  // Group instances into 60m x 60m frustum-culled tiles per (defId|variant|tx,tz)
  const buckets = new Map<string, Inst[]>();
  const push = (defId: string, v: number, x: number, z: number, inst: Inst) => {
    const tx = Math.floor(x / 60);
    const tz = Math.floor(z / 60);
    const k = `${defId}|${v}|${tx},${tz}`;
    let list = buckets.get(k);
    if (!list) {
      list = [];
      buckets.set(k, list);
    }
    list.push(inst);
  };

  const pick = (w: [string, number][]) => {
    const tot = w.reduce((s, x) => s + x[1], 0);
    let t = rng() * tot;
    for (const [id, p] of w) {
      if ((t -= p) <= 0) return id;
    }
    return w[0][0];
  };

  const q = new THREE.Quaternion();
  const sc = new V();
  const pos = new V();
  const e = new THREE.Euler();
  const qLean = new THREE.Quaternion();
  const UP = new V(0, 1, 0);

  const place = (
    id: string,
    x: number,
    z: number,
    y: number,
    signed: number,
    tx: number,
    tz: number,
    scale: number,
    tilt = 0.04,
    lean = 0,
  ) => {
    const def = defMap.get(id)!;
    const v = Math.floor(rng() * def.variants);
    pos.set(x, y - 0.06, z);
    e.set(rand(rng, -tilt, tilt), rand(rng, 0, Math.PI * 2), rand(rng, -tilt, tilt));
    q.setFromEuler(e);
    if (lean > 0) {
      // Lean toward the road so maple/beech canopy closes over the asphalt like TREE AND ASPAL DAN GRASS
      const toRoad = new V(-tz, 0, tx).multiplyScalar(-Math.sign(signed) || 1);
      const axis = UP.clone().cross(toRoad).normalize();
      if (axis.lengthSq() > 0.001) {
        qLean.setFromAxisAngle(axis, lean);
        q.premultiply(qLean);
      }
    }
    sc.setScalar(scale);
    const m = new THREE.Matrix4().compose(pos, q, sc);
    const c = new THREE.Color(rand(rng, 0.86, 1.06), rand(rng, 0.9, 1.08), rand(rng, 0.8, 1.0));
    push(id, v, x, z, { m, c });
  };

  const roadHalf = route.half; // 4.6m
  const terrainProbe = { y: 0, kind: GroundKind.Void };

  // 4A. Canopy trees (5.6m grid inside [roadHalf + 2.2, 64m])
  const cellT = 5.6 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cellT) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cellT) {
      const px = x + rand(rng, 0, cellT);
      const pz = z - rand(rng, 0, cellT);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 2.2 || a > 64) continue;
      if (rng() > (a > 40 ? 0.6 : 0.78)) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      const n = noise(px * 0.018, pz * 0.018);
      let id: string;
      if (a < 15) id = pick([['maple', 0.26 + n * 0.1], ['sapling', 0.18], ['beech', 0.14], ['cedar', 0.24], ['pole', 0.18]]);
      else if (n > 0.35) id = pick([['beech', 0.35], ['maple', 0.25], ['cedar', 0.25], ['cypress', 0.15]]);
      else id = pick([['cedar', 0.4], ['pole', 0.32], ['cypress', 0.16], ['beech', 0.06], ['maple', 0.06]]);
      place(id, px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.82, 1.15), 0.04, a < 12 ? rand(rng, 0.02, 0.07) : 0);
    }
  }

  // 4B. Roadside canopy row: big broadleaf trees hugging both edges, leaning in over the asphalt
  const rowStep = Math.max(4.5, 8.2 / Math.sqrt(opts.density));
  for (let s = 4; s < route.length - 4; s += rowStep) {
    for (const side of [-1, 1]) {
      if (rng() < 0.18) continue;
      const a = roadHalf + rand(rng, 2.3, 5.6);
      const f = route.at(s + rand(rng, 0, rowStep * 0.45));
      const px = f.x - f.tz * side * a;
      const pz = f.z + f.tx * side * a;
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      if (info.dist < roadHalf + 2.2) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      const id = pick([['maple', 0.38], ['beech', 0.42], ['sapling', 0.2]]);
      place(id, px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.95, 1.3), 0.03, rand(rng, 0.04, 0.13));
    }
  }

  // 4C. Far band: sparse conifers on distant slopes (64m..150m)
  const cellF = 9.0 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cellF) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cellF) {
      const px = x + rand(rng, 0, cellF);
      const pz = z - rand(rng, 0, cellF);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a <= 64 || a > 150 || rng() > 0.72) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      place(pick([['cedar', 0.5], ['pole', 0.3], ['cypress', 0.2]]), px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.9, 1.2));
    }
  }

  // 4D. Understory saplings near road (roadHalf + 2.0 .. 26m)
  const cell2 = 7.0 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cell2) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cell2) {
      const px = x + rand(rng, 0, cell2);
      const pz = z - rand(rng, 0, cell2);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 2.0 || a > 26 || rng() > 0.55) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      place(rng() < 0.6 ? 'sapling' : 'maple', px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.6, 1.0), 0.08);
    }
  }

  // 4E. Bushes (sasa, shrub, fern)
  const cell3 = 2.6 / Math.sqrt(opts.density);
  for (let z = bounds.z1 - 6; z > bounds.z0 + 6; z -= cell3) {
    for (let x = bounds.x0 + 6; x < bounds.x1 - 6; x += cell3) {
      const px = x + rand(rng, 0, cell3);
      const pz = z - rand(rng, 0, cell3);
      if (!inside(px, pz)) continue;
      const info = route.nearest(px, pz);
      const a = info.dist;
      if (a < roadHalf + 1.55 || a > 50) continue;
      const pr = a < 9.5 ? 0.4 : 0.26;
      if (rng() > pr) continue;
      const g = groundAt(px, pz, terrainProbe);
      if (g.kind === GroundKind.Void) continue;
      const n = noise2(px * 0.05, pz * 0.05);
      const id = n > 0.2 ? pick([['sasa', 0.7], ['fern', 0.3]]) : pick([['sasa', 0.35], ['shrub', 0.35], ['fern', 0.3]]);
      place(id, px, pz, g.y, info.signed, info.tx, info.tz, rand(rng, 0.7, 1.3), 0.12);
    }
  }

  // Build frustum-culled instanced meshes for all trees & bushes
  const geoCache = new Map<string, ReturnType<AssetDef['make']>>();
  const getAsset = (def: AssetDef, v: number) => {
    const k = `${def.id}|${v}`;
    if (!geoCache.has(k)) geoCache.set(k, def.make(1000 + v * 97 + def.id.length * 13));
    return geoCache.get(k)!;
  };
  let treeCount = 0;
  for (const [key, list] of buckets) {
    const [id, vs] = key.split('|');
    const def = defMap.get(id)!;
    const asset = getAsset(def, Number(vs));
    const isBush = def.category === 'Semak & Tanaman Bawah';
    if (!isBush) treeCount += list.length;
    const lm = new THREE.InstancedMesh(asset.leaves, def.leaf.mat, list.length);
    lm.customDepthMaterial = def.leaf.depth;
    lm.castShadow = !isBush || (opts.shadowsOnBushes && id !== 'fern');
    lm.receiveShadow = true;
    list.forEach((it, i) => {
      lm.setMatrixAt(i, it.m);
      lm.setColorAt(i, it.c);
    });
    lm.computeBoundingSphere();
    if (lm.boundingSphere) lm.boundingSphere.radius += 3;
    group.add(lm);
    if (asset.bark && def.bark) {
      const bm = new THREE.InstancedMesh(asset.bark, def.bark.mat, list.length);
      bm.customDepthMaterial = def.bark.depth;
      bm.castShadow = true;
      bm.receiveShadow = true;
      list.forEach((it, i) => bm.setMatrixAt(i, it.m));
      bm.computeBoundingSphere();
      if (bm.boundingSphere) bm.boundingSphere.radius += 2;
      group.add(bm);
    }
  }

  // ---------------- 5. GRASS TUFTS (100% V2 grass design, frustum-tiled along Haruna) ----------------
  const tuft = makeGrassTuft();
  const gm = grassMaterial(tex.grass);
  const grassTiles = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  const grassN = Math.floor(72000 * opts.grass);
  for (let k = 0; k < grassN; k++) {
    const s = rng() * route.length;
    const f = route.at(s);
    const side = rng() < 0.5 ? -1 : 1;
    const a = roadHalf + 1.2 + Math.pow(rng(), 2.2) * 22;
    const along = rand(rng, -0.6, 0.6);
    const px = f.x - f.tz * a * side + f.tx * along;
    const pz = f.z + f.tx * a * side + f.tz * along;
    if (!inside(px, pz)) continue;
    const info = route.nearest(px, pz);
    if (info.dist < roadHalf + 1.15) continue;
    const n = noise2(px * 0.08, pz * 0.08);
    if (info.dist > 10 && n < -0.15) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;
    pos.set(px, g.y - 0.04, pz);
    e.set(rand(rng, -0.15, 0.15), rand(rng, 0, 6.28), rand(rng, -0.15, 0.15));
    q.setFromEuler(e);
    const sVal = rand(rng, 0.45, 1.0) * (info.dist < 7.5 ? 0.75 : 1);
    sc.set(sVal, sVal * rand(rng, 0.7, 1.4), sVal);
    const tileKey = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let bucket = grassTiles.get(tileKey);
    if (!bucket) {
      bucket = { mats: [], cols: [] };
      grassTiles.set(tileKey, bucket);
    }
    bucket.mats.push(new THREE.Matrix4().compose(pos, q, sc));
    bucket.cols.push(new THREE.Color().setRGB(rand(rng, 0.62, 0.9), rand(rng, 0.7, 0.95), rand(rng, 0.5, 0.75)));
  }
  for (const bucket of grassTiles.values()) {
    const im = new THREE.InstancedMesh(tuft, gm, bucket.mats.length);
    for (let i = 0; i < bucket.mats.length; i++) {
      im.setMatrixAt(i, bucket.mats[i]);
      im.setColorAt(i, bucket.cols[i]);
    }
    im.receiveShadow = true;
    im.computeBoundingSphere();
    group.add(im);
  }

  // ---------------- 6. ROCKS ----------------
  const rockGeo = new THREE.IcosahedronGeometry(1, 3);
  {
    const p = rockGeo.attributes.position as THREE.BufferAttribute;
    const rn = createNoise2D(3);
    for (let i = 0; i < p.count; i++) {
      const v = new V(p.getX(i), p.getY(i), p.getZ(i));
      const d = 1 + rn(v.x * 1.7 + v.z, v.y * 1.7) * 0.22 + rn(v.x * 4, v.z * 4 + v.y) * 0.06;
      v.multiplyScalar(d);
      v.y *= 0.6;
      p.setXYZ(i, v.x, v.y, v.z);
    }
    rockGeo.computeVertexNormals();
    const uv = new Float32Array(p.count * 2);
    for (let i = 0; i < p.count; i++) {
      uv[i * 2] = p.getX(i) * 0.5 + p.getZ(i) * 0.3;
      uv[i * 2 + 1] = p.getY(i) * 0.5;
    }
    rockGeo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  }
  const rockMat = new THREE.MeshStandardMaterial({
    color: '#8a877d',
    map: tex.barkBroad.map,
    normalMap: tex.barkBroad.normal,
    roughness: 0.92,
  });
  const rockTiles = new Map<string, THREE.Matrix4[]>();
  for (let k = 0; k < 950; k++) {
    const s = rng() * route.length;
    const f = route.at(s);
    const side = rng() < 0.7 ? 1 : -1;
    const a = roadHalf + 1.8 + rng() * 22;
    const px = f.x - f.tz * a * side;
    const pz = f.z + f.tx * a * side;
    if (!inside(px, pz)) continue;
    const info = route.nearest(px, pz);
    if (info.dist < roadHalf + 1.7) continue;
    const g = groundAt(px, pz, terrainProbe);
    if (g.kind === GroundKind.Void || g.kind === GroundKind.Asphalt) continue;
    const sVal = rand(rng, 0.15, 0.7) * (rng() < 0.08 ? 2.2 : 1);
    pos.set(px, g.y - sVal * 0.2, pz);
    e.set(rand(rng, -0.4, 0.4), rand(rng, 0, 6.28), rand(rng, -0.4, 0.4));
    q.setFromEuler(e);
    sc.set(sVal * rand(rng, 0.8, 1.4), sVal, sVal * rand(rng, 0.8, 1.3));
    const tileKey = `${Math.floor(px / 60)},${Math.floor(pz / 60)}`;
    let list = rockTiles.get(tileKey);
    if (!list) {
      list = [];
      rockTiles.set(tileKey, list);
    }
    list.push(new THREE.Matrix4().compose(pos, q, sc));
  }
  for (const list of rockTiles.values()) {
    const rocks = new THREE.InstancedMesh(rockGeo, rockMat, list.length);
    list.forEach((m, i) => rocks.setMatrixAt(i, m));
    rocks.castShadow = true;
    rocks.receiveShadow = true;
    rocks.computeBoundingSphere();
    group.add(rocks);
  }

  // ---------------- 7. DRIFT SMOKE / ROAD HAZE ----------------
  const smokeUniforms = {
    uTime: globalUniforms.uTime,
    uMap: { value: tex.smoke },
    uSun: { value: new THREE.Color(1, 0.95, 0.85) },
    uAmb: { value: new THREE.Color(0.62, 0.7, 0.72) },
    uFogColor: { value: new THREE.Color('#a6bab2') },
    uFogDensity: { value: 0.0029 },
    uOpacity: { value: 1 },
  };
  const smokeMat = new THREE.ShaderMaterial({
    uniforms: smokeUniforms,
    transparent: true,
    depthWrite: false,
    vertexShader: /* glsl */ `
      attribute vec4 aData;
      uniform float uTime;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      void main() {
        vec3 c = (instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        float life = fract(uTime * aData.y + aData.x);
        float ang = aData.w * 6.2831;
        c += vec3(cos(ang) * life * 3.5 + life * 2.5, life * life * 3.5 + 0.3, sin(ang) * life * 3.5);
        float size = aData.z * (0.6 + life * 2.2);
        vec4 mv = viewMatrix * vec4(c, 1.0);
        float rot = aData.w * 6.28 + uTime * 0.08 * (aData.w - 0.5);
        vec2 p = mat2(cos(rot), -sin(rot), sin(rot), cos(rot)) * position.xy;
        mv.xy += p * size;
        vAlpha = smoothstep(0.0, 0.12, life) * pow(1.0 - life, 1.4);
        vUv = uv;
        vFogDepth = -mv.z;
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uMap;
      uniform vec3 uSun;
      uniform vec3 uAmb;
      uniform vec3 uFogColor;
      uniform float uFogDensity;
      uniform float uOpacity;
      varying vec2 vUv;
      varying float vAlpha;
      varying float vFogDepth;
      void main() {
        vec4 t = texture2D(uMap, vUv);
        vec3 col = mix(uAmb, uSun, 0.35 + 0.3 * vUv.y) * 1.05;
        float f = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
        col = mix(col, uFogColor, f * 0.6);
        gl_FragColor = vec4(col, t.a * vAlpha * 0.2 * uOpacity);
        #include <colorspace_fragment>
      }`,
  });
  const plane = new THREE.PlaneGeometry(1, 1);
  const smokeSpots = [
    { s: spec.start + 135, spread: 45, count: 55 },
    { s: spec.start + 520, spread: 50, count: 55 },
    { s: spec.start + 1150, spread: 60, count: 60 },
  ];
  const smokeTotal = smokeSpots.reduce((acc, x) => acc + x.count, 0);
  const smoke = new THREE.InstancedMesh(plane, smokeMat, smokeTotal);
  const aData = new Float32Array(smokeTotal * 4);
  let si = 0;
  for (const sp of smokeSpots) {
    for (let k = 0; k < sp.count; k++) {
      const f = route.at(sp.s + rand(rng, 0, sp.spread));
      const off = rand(rng, -3.4, 3.4);
      pos.set(f.x - f.tz * off, f.y + 0.25, f.z + f.tx * off);
      smoke.setMatrixAt(si, new THREE.Matrix4().makeTranslation(pos.x, pos.y, pos.z));
      aData.set([rng(), rand(rng, 0.025, 0.05), rand(rng, 2.2, 4.2), rng()], si * 4);
      si++;
    }
  }
  plane.setAttribute('aData', new THREE.InstancedBufferAttribute(aData, 4));
  smoke.frustumCulled = false;
  smoke.renderOrder = 10;
  smoke.visible = false;
  group.add(smoke);

  // ---------------- 8. SUNLIT DUST MOTES ----------------
  const dustN = 5200;
  const dPos = new Float32Array(dustN * 3);
  for (let k = 0; k < dustN; k++) {
    const f = route.at(rng() * route.length);
    const off = rand(rng, -16, 16);
    dPos.set([f.x - f.tz * off, f.y + rand(rng, 0.3, 9), f.z + f.tx * off], k * 3);
  }
  const dGeo = new THREE.BufferGeometry();
  dGeo.setAttribute('position', new THREE.BufferAttribute(dPos, 3));
  const dustMat = new THREE.ShaderMaterial({
    uniforms: { uTime: globalUniforms.uTime },
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    vertexShader: `
      uniform float uTime;
      varying float vA;
      void main() {
        vec3 p = position;
        float s = fract(sin(dot(p.xz, vec2(12.9, 78.2))) * 437.5);
        p += vec3(sin(uTime * 0.3 + s * 20.0) * 0.6, sin(uTime * 0.21 + s * 9.0) * 0.4, cos(uTime * 0.27 + s * 14.0) * 0.6);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = clamp(26.0 / -mv.z, 1.0, 5.0);
        vA = (0.4 + 0.6 * sin(uTime * 1.5 + s * 30.0)) * smoothstep(40.0, 4.0, -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vA;
      void main() {
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vA * 0.35;
        gl_FragColor = vec4(vec3(1.0, 0.95, 0.8) * a, a);
      }`,
  });
  const dust = new THREE.Points(dGeo, dustMat);
  dust.frustumCulled = false;
  group.add(dust);

  let elapsed = 0;
  function tick(dt: number) {
    elapsed += dt;
    globalUniforms.uTime.value = elapsed;
  }

  return {
    groundAt,
    tick,
    treeCount,
    smokeBinding: { smoke, smokeUniforms },
    setOpenTerrain(enabled: boolean) {
      original.guardrails.visible = !enabled;
    },
  };
}

function renderV2Relief(
  grid: ReliefGrid,
  stride: number,
  material: THREE.Material,
  distAt: (x: number, z: number) => number,
  mossAt: (x: number, z: number, dist: number) => number,
  aoAt: (dist: number) => number,
  shadow: boolean,
) {
  const { bounds, cell, nx, nz, width, heights } = grid;
  const group = new THREE.Group();
  for (let iz = 0; iz < nz; iz += stride) {
    for (let ix = 0; ix < nx; ix += stride) {
      const w = Math.min(stride, nx - ix);
      const h = Math.min(stride, nz - iz);
      const positions: number[] = [];
      const uv: number[] = [];
      const moss: number[] = [];
      const ao: number[] = [];
      const indices: number[] = [];
      for (let z = 0; z <= h; z++) {
        for (let x = 0; x <= w; x++) {
          const gx = ix + x;
          const gz = iz + z;
          const index = gx + gz * width;
          const wx = bounds.x0 + gx * cell;
          const wz = bounds.z0 + gz * cell;
          const y = heights[index];
          const d = distAt(wx, wz);
          positions.push(wx, y, wz);
          uv.push(wx / 4, wz / 4);
          moss.push(mossAt(wx, wz, d));
          ao.push(aoAt(d));
          if (x < w && z < h && grid.filled(gx, gz)) {
            const a = x + z * (w + 1);
            const b = a + w + 1;
            if (grid.alternate(gx, gz)) indices.push(a, b, b + 1, a, b + 1, a + 1);
            else indices.push(a, b, a + 1, a + 1, b, b + 1);
          }
        }
      }
      if (indices.length) {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
        geo.setAttribute('aMoss', new THREE.Float32BufferAttribute(moss, 1));
        geo.setAttribute('aAO', new THREE.Float32BufferAttribute(ao, 1));
        geo.setIndex(indices);
        geo.computeVertexNormals();
        const mesh = new THREE.Mesh(geo, material);
        mesh.receiveShadow = shadow;
        group.add(mesh);
      }
    }
  }
  return group;
}
