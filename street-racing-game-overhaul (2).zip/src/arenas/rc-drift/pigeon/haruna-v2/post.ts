import * as THREE from 'three';
import {
  BloomEffect, BrightnessContrastEffect, Effect, EffectComposer, EffectPass, GodRaysEffect,
  HueSaturationEffect, KernelSize, RenderPass, SMAAEffect, ToneMappingEffect, ToneMappingMode,
} from 'postprocessing';
import type { HarunaV2Lighting } from './lighting';
import type { GroundAt } from '../pigeon-world/suspension';
import { VolumetricLightEffect } from './volumetric';

class MicroSharpenEffect extends Effect {
  constructor(amount = 0.28) {
    super(
      'MicroSharpenEffect',
      /* glsl */ `
        uniform float uAmount;
        void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
          vec2 px = texelSize;
          vec3 cN = texture2D(inputBuffer, uv + vec2(0.0, px.y)).rgb;
          vec3 cS = texture2D(inputBuffer, uv - vec2(0.0, px.y)).rgb;
          vec3 cE = texture2D(inputBuffer, uv + vec2(px.x, 0.0)).rgb;
          vec3 cW = texture2D(inputBuffer, uv - vec2(px.x, 0.0)).rgb;
          vec3 blur = (cN + cS + cE + cW) * 0.25;
          vec3 diff = inputColor.rgb - blur;
          float contrast = max(max(abs(diff.r), abs(diff.g)), abs(diff.b));
          float weight = uAmount * smoothstep(0.004, 0.06, contrast) * (1.0 - smoothstep(0.28, 0.65, contrast));
          outputColor = vec4(max(vec3(0.0), inputColor.rgb + diff * weight), inputColor.a);
        }
      `,
      { uniforms: new Map([['uAmount', new THREE.Uniform(amount)]]) },
    );
  }
}

export function createHarunaV2Post(
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
  camera: THREE.Camera,
  lighting: HarunaV2Lighting,
  groundAt: GroundAt,
  lowPower: boolean,
  hdCrisp = false,
) {
  const hdr = renderer.extensions.has('EXT_color_buffer_float');
  const initialAutoClear = renderer.autoClear;
  const msaa = hdr && !lowPower ? Math.min(4, renderer.capabilities.maxSamples) : 0;
  const composer = new EffectComposer(renderer, {
    frameBufferType: hdr ? THREE.HalfFloatType : THREE.UnsignedByteType,
    multisampling: msaa,
  });
  renderer.autoClear = initialAutoClear;

  const renderPass = new RenderPass(scene, camera);
  composer.addPass(renderPass);

  const vol = new VolumetricLightEffect();
  const volPass = new EffectPass(camera, vol);
  let activePersp = camera as THREE.PerspectiveCamera;
  let activeElapsed = 0;
  const origVolRender = volPass.render.bind(volPass);
  volPass.render = (r, inputBuffer, outputBuffer, deltaTime, stencilTest) => {
    vol.sync(activePersp, lighting.dir, lighting.sunDirection, activeElapsed);
    origVolRender(r, inputBuffer, outputBuffer, deltaTime, stencilTest);
  };
  composer.addPass(volPass);

  const godRays = new GodRaysEffect(camera, lighting.sunMesh, {
    height: hdCrisp ? 600 : 480,
    kernelSize: KernelSize.SMALL,
    density: 0.97,
    decay: 0.93,
    weight: 0.42,
    exposure: 0.62,
    samples: 72,
    clampMax: 1,
    blur: true,
  });
  composer.addPass(new EffectPass(camera, godRays));

  const bloom = new BloomEffect({
    intensity: hdCrisp ? 0.34 : 0.7,
    luminanceThreshold: hdCrisp ? 0.88 : 0.82,
    luminanceSmoothing: 0.25,
    mipmapBlur: true,
    radius: hdCrisp ? 0.44 : 0.72,
  });
  composer.addPass(new EffectPass(camera, bloom));

  const tone = new ToneMappingEffect({ mode: ToneMappingMode.ACES_FILMIC });
  const hue = new HueSaturationEffect({ saturation: 0.24, hue: 0 });
  const bc = new BrightnessContrastEffect({ brightness: 0.01, contrast: 0.12 });
  if (hdCrisp) {
    composer.addPass(new EffectPass(camera, tone, hue, bc, new MicroSharpenEffect(0.32)));
  } else {
    composer.addPass(new EffectPass(camera, tone, hue, bc));
  }

  if (!msaa) {
    composer.addPass(new EffectPass(camera, new SMAAEffect()));
  }

  let mainScene = scene;
  let mainCamera = camera;
  const size = new THREE.Vector2();
  const cssSize = new THREE.Vector2();
  const lastSize = new THREE.Vector2();

  return {
    render(nextScene: THREE.Scene, nextCamera: THREE.Camera, dt: number, elapsedTime: number) {
      if (mainScene !== nextScene) composer.setMainScene((mainScene = nextScene));
      if (mainCamera !== nextCamera) composer.setMainCamera((mainCamera = nextCamera));

      renderer.getDrawingBufferSize(size);
      if (!size.equals(lastSize)) {
        renderer.getSize(cssSize);
        composer.setSize(cssSize.x, cssSize.y, false);
        lastSize.copy(size);
      }

      const persp = nextCamera as THREE.PerspectiveCamera;
      activePersp = persp;
      activeElapsed = elapsedTime;
      vol.sync(persp, lighting.dir, lighting.sunDirection, elapsedTime);
      vol.uniforms.get('uIntensity')!.value = lighting.godRaysStrength;
      vol.uniforms.get('uDensity')!.value = lighting.volDensity;
      (vol.uniforms.get('uSunColor')!.value as THREE.Color).copy(lighting.sunColor).multiplyScalar(0.95);
      vol.uniforms.get('uExposure')!.value = lighting.exposure;
      (vol.uniforms.get('uAmbient')!.value as THREE.Color).copy(lighting.fog.color);
      const ground = groundAt(nextCamera.position.x, nextCamera.position.z);
      vol.uniforms.get('uGroundY')!.value = Number.isFinite(ground.y) && ground.y > -150 ? ground.y : nextCamera.position.y - 2;
      vol.uniforms.get('uMaxDist')!.value = 110;

      godRays.godRaysMaterial.uniforms.weight.value = 0.42 * lighting.godRaysStrength;

      const toneMapping = renderer.toneMapping;
      const autoClear = renderer.autoClear;
      const previousTarget = renderer.getRenderTarget();
      renderer.toneMapping = THREE.NoToneMapping;
      renderer.autoClear = true;
      try {
        composer.render(dt);
      } finally {
        renderer.toneMapping = toneMapping;
        renderer.autoClear = autoClear;
        renderer.setRenderTarget(previousTarget);
      }
    },
    dispose() {
      composer.dispose();
    },
  };
}
