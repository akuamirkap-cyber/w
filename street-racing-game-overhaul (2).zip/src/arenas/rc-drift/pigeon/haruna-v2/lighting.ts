import * as THREE from 'three';
import { DEFAULT_ATMOSPHERE, DEFAULT_LIGHTING, type AtmosphereState, type LightingMood, type LightingState } from '../drive-lighting';
import type { harunaRoute } from '../pigeon-world/route';
import type { GroundAt } from '../pigeon-world/suspension';
import { globalUniforms } from './materials';
import { smoothstep } from './noise';

export interface V2LightingSettings {
  sunElevation: number;
  sunAzimuth: number;
  godRays: number;
  fog: number;
  wind: number;
  exposure: number;
  smoke: boolean;
}

export const DEFAULT_V2_LIGHTING: V2LightingSettings = {
  sunElevation: 42,
  sunAzimuth: 28,
  godRays: 1,
  fog: 1,
  wind: 1,
  exposure: 1,
  smoke: false,
};

const V2_SETTINGS_KEY = 'prodrift.haruna-v2.lighting.v1';

export function normalizeV2Lighting(raw: Partial<V2LightingSettings> = {}): V2LightingSettings {
  const num = (v: unknown, min: number, max: number, fb: number) =>
    typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fb;
  return {
    sunElevation: num(raw.sunElevation, 6, 80, DEFAULT_V2_LIGHTING.sunElevation),
    sunAzimuth: num(raw.sunAzimuth, -180, 180, DEFAULT_V2_LIGHTING.sunAzimuth),
    godRays: num(raw.godRays, 0, 2.5, DEFAULT_V2_LIGHTING.godRays),
    fog: num(raw.fog, 0.2, 2.5, DEFAULT_V2_LIGHTING.fog),
    wind: num(raw.wind, 0, 3, DEFAULT_V2_LIGHTING.wind),
    exposure: num(raw.exposure, 0.4, 2, DEFAULT_V2_LIGHTING.exposure),
    smoke: typeof raw.smoke === 'boolean' ? raw.smoke : DEFAULT_V2_LIGHTING.smoke,
  };
}

export function readV2Lighting(): V2LightingSettings {
  try {
    return normalizeV2Lighting(JSON.parse(localStorage.getItem(V2_SETTINGS_KEY) ?? '{}'));
  } catch {
    return { ...DEFAULT_V2_LIGHTING };
  }
}

export function saveV2Lighting(next: V2LightingSettings) {
  try {
    localStorage.setItem(V2_SETTINGS_KEY, JSON.stringify(next));
  } catch { /* Storage is optional. */ }
}

function skyMaterial() {
  return new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uZenith: { value: new THREE.Color('#5d8fc4') },
      uHorizon: { value: new THREE.Color('#c9dbdc') },
      uSunColor: { value: new THREE.Color(1, 0.93, 0.8) },
    },
    vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
    fragmentShader: `
      uniform vec3 uSunDir; uniform vec3 uZenith; uniform vec3 uHorizon; uniform vec3 uSunColor;
      varying vec3 vDir;
      void main(){
        vec3 d = normalize(vDir);
        float h = max(d.y, 0.0);
        vec3 col = mix(uHorizon, uZenith, pow(h, 0.5));
        float s = max(dot(d, uSunDir), 0.0);
        col += uSunColor * (pow(s, 1800.0) * 60.0 + pow(s, 60.0) * 1.2 + pow(s, 8.0) * 0.35);
        if (d.y < 0.0) col = mix(uHorizon, uHorizon * 0.6, min(-d.y * 3.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
}

export interface SmokeBinding {
  smoke: THREE.InstancedMesh;
  smokeUniforms: {
    uFogColor: { value: THREE.Color };
    uFogDensity: { value: number };
    uSun: { value: THREE.Color };
  };
}

export function createHarunaV2Lighting(
  scene: THREE.Scene,
  spec: ReturnType<typeof harunaRoute>,
  _groundAt: GroundAt,
  renderer: THREE.WebGLRenderer,
  shadowSize = 4096,
  smokeBinding?: SmokeBinding,
) {
  let state: LightingState = { ...DEFAULT_LIGHTING };
  let atmosphere: AtmosphereState = { ...DEFAULT_ATMOSPHERE };
  let mood: LightingMood = 'day';
  let v2 = readV2Lighting();

  const skyMat = skyMaterial();
  const sky = new THREE.Mesh(new THREE.SphereGeometry(1000, 48, 24), skyMat);
  sky.name = 'Haruna V2 sky dome';
  sky.frustumCulled = false;
  sky.renderOrder = -1;
  scene.add(sky);

  const baseFog = 0.0029;
  const fog = new THREE.FogExp2('#a6bab2', baseFog);
  scene.fog = fog;
  const background = new THREE.Color('#a6bab2');
  scene.background = background;

  const sun = new THREE.DirectionalLight(0xfff1dc, 3.4);
  sun.castShadow = true;
  const clampedShadow = Math.min(renderer.capabilities.maxTextureSize, shadowSize);
  sun.shadow.mapSize.set(clampedShadow, clampedShadow);
  const c = sun.shadow.camera;
  c.left = c.bottom = -70;
  c.right = c.top = 70;
  c.near = 1;
  c.far = 520;
  c.updateProjectionMatrix();
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.05;
  sun.shadow.radius = 2;
  scene.add(sun, sun.target);

  const hemi = new THREE.HemisphereLight(0xc3d6e2, 0x4a3b28, 0.75);
  scene.add(hemi);

  const sunMesh = new THREE.Mesh(
    new THREE.SphereGeometry(18, 24, 12),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.94, 0.82), transparent: true, depthWrite: false, fog: false }),
  );
  sunMesh.frustumCulled = false;
  sunMesh.layers.enable(2);

  const sunDir = new THREE.Vector3(0, 1, 0);
  const sunCol = new THREE.Color(1, 0.93, 0.8);
  const startGrid = spec.route.at(spec.start);
  const startFwd = new THREE.Vector3(startGrid.tx, 0, startGrid.tz).normalize();
  const startRight = new THREE.Vector3(-startFwd.z, 0, startFwd.x).normalize();

  let effectiveGodRays = v2.godRays;
  let effectiveVolDensity = 0.0065;
  let effectiveExposure = v2.exposure;

  function sync() {
    const fillScale = state.hemiOn ? state.hemi / 100 : 0;
    const directScale = state.dirOn ? state.dir / 100 : 0;
    const elDeg = mood === 'night' ? 24 : v2.sunElevation;
    const el = THREE.MathUtils.degToRad(elDeg);
    const az = THREE.MathUtils.degToRad(v2.sunAzimuth);

    // Orient sun azimuth=0 along Haruna's opening downhill straight so god rays shine through the canopy ahead
    sunDir
      .copy(startFwd).multiplyScalar(Math.cos(az) * Math.cos(el))
      .addScaledVector(startRight, Math.sin(az) * Math.cos(el))
      .add(new THREE.Vector3(0, Math.sin(el), 0))
      .normalize();

    const warm = smoothstep(4, 40, elDeg);
    const zen = new THREE.Color('#3f6fae').lerp(new THREE.Color('#5d8fc4'), warm);
    const hor = new THREE.Color('#e9c9a2').lerp(new THREE.Color('#c9dbdc'), warm);
    sunCol.setRGB(1, 0.62 + 0.33 * warm, 0.38 + 0.47 * warm);

    let sunIntensity = 4.4 * (0.35 + 0.65 * smoothstep(-2, 25, elDeg)) * directScale;
    let hemiIntensity = (0.42 + 0.18 * warm) * fillScale;
    const fogCol = new THREE.Color('#8aa59d').lerp(hor, 0.15);
    let fogScale = v2.fog;
    let raysScale = v2.godRays * directScale;

    if (mood === 'rain') {
      sunCol.set('#c9dbef');
      zen.set('#6e7c84');
      hor.set('#aab5b8');
      fogCol.set('#96a3a2');
      sunIntensity *= 0.28;
      hemiIntensity = 0.72 * fillScale;
      fogScale *= 1.45;
      raysScale *= 0.15;
    } else if (mood === 'night') {
      sunCol.set('#b6cdf7');
      zen.set('#0e1a2e');
      hor.set('#222e3d');
      fogCol.set('#1b2634');
      sunIntensity = 0.9 * directScale;
      hemiIntensity = 0.35 * fillScale;
      fogScale *= 1.1;
      raysScale *= 0.22;
    }

    sun.color.copy(sunCol);
    sun.intensity = sunIntensity;
    if ('intensity' in sun.shadow) sun.shadow.intensity = state.shadow / 100;
    hemi.intensity = hemiIntensity;

    skyMat.uniforms.uSunDir.value.copy(sunDir);
    skyMat.uniforms.uSunColor.value.copy(sunCol);
    skyMat.uniforms.uZenith.value.copy(zen);
    skyMat.uniforms.uHorizon.value.copy(hor);

    fog.density = baseFog * fogScale;
    fog.color.copy(fogCol);
    background.copy(fogCol);

    globalUniforms.uWind.value = v2.wind;
    effectiveGodRays = raysScale;
    effectiveVolDensity = 0.0065 * (0.3 + 0.7 * fogScale);
    effectiveExposure = v2.exposure;

    (sunMesh.material as THREE.MeshBasicMaterial).color.copy(sunCol);
    if (smokeBinding) {
      smokeBinding.smoke.visible = v2.smoke;
      smokeBinding.smokeUniforms.uFogColor.value.copy(fog.color);
      smokeBinding.smokeUniforms.uFogDensity.value = fog.density;
      smokeBinding.smokeUniforms.uSun.value.copy(sunCol);
    }
  }

  // Generate sky PMREM environment map (exactly like Engine.ts)
  const pm = new THREE.PMREMGenerator(renderer);
  const envScene = new THREE.Scene();
  const envSky = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), skyMat);
  envScene.add(envSky);
  sync();
  const envRT = pm.fromScene(envScene, 0.04);
  scene.environment = envRT.texture;
  scene.environmentIntensity = 0.42;
  envSky.geometry.dispose();
  pm.dispose();

  const fwdVec = new THREE.Vector3();
  const centreVec = new THREE.Vector3();
  const lzVec = new THREE.Vector3();
  const lxVec = new THREE.Vector3();
  const lyVec = new THREE.Vector3();
  const snappedVec = new THREE.Vector3();
  const worldUp = new THREE.Vector3(0, 1, 0);

  function update(carPos: THREE.Vector3, viewPos: THREE.Vector3, yaw: number, _now: number, _seconds: number, viewDir?: THREE.Vector3) {
    sky.position.copy(viewPos);
    sunMesh.position.copy(viewPos).addScaledVector(sunDir, 800);
    sunMesh.updateMatrixWorld(true);

    if (viewDir) {
      fwdVec.copy(viewDir);
    } else {
      fwdVec.subVectors(carPos, viewPos);
      if (fwdVec.lengthSq() < 0.25) fwdVec.set(Math.sin(yaw), 0, Math.cos(yaw));
    }
    fwdVec.y = 0;
    if (fwdVec.lengthSq() < 1e-4) fwdVec.set(Math.sin(yaw), 0, Math.cos(yaw));
    fwdVec.normalize();

    centreVec.copy(viewPos).addScaledVector(fwdVec, 38);
    const cam = sun.shadow.camera;
    const span = cam.right - cam.left;
    const texel = span / sun.shadow.mapSize.x;
    lzVec.copy(sunDir);
    lxVec.crossVectors(worldUp, lzVec).normalize();
    lyVec.crossVectors(lzVec, lxVec).normalize();
    const px = Math.round(centreVec.dot(lxVec) / texel) * texel;
    const py = Math.round(centreVec.dot(lyVec) / texel) * texel;
    const pz = centreVec.dot(lzVec);
    snappedVec.copy(lxVec).multiplyScalar(px).addScaledVector(lyVec, py).addScaledVector(lzVec, pz);
    sun.target.position.copy(snappedVec);
    sun.position.copy(snappedVec).addScaledVector(sunDir, 250);
    sun.target.updateMatrixWorld();
    renderer.shadowMap.needsUpdate = true;
  }

  return {
    scene,
    hemi,
    dir: sun,
    dome: sky,
    background,
    fog,
    sunMesh,
    sunDirection: sunDir,
    hasDaylightAtmosphere: true,
    get sunGain() { return (state.dirOn ? state.dir / 100 : 0) * (mood === 'day' ? 1 : 0.2); },
    get state() { return state; },
    get mood() { return mood; },
    get v2Settings() { return v2; },
    get godRaysStrength() { return effectiveGodRays; },
    get volDensity() { return effectiveVolDensity; },
    get exposure() { return effectiveExposure; },
    get sunColor() { return sunCol; },
    setMood(next: LightingMood) { mood = next; sync(); },
    setLook() { /* Mt. Haruna V2 always uses the 100% V2 lighting & shadow model */ },
    apply(next: Partial<LightingState>) { state = { ...state, ...next }; sync(); return state; },
    applyV2(next: Partial<V2LightingSettings>) {
      v2 = normalizeV2Lighting({ ...v2, ...next });
      saveV2Lighting(v2);
      sync();
      return v2;
    },
    applyAtmosphere(next: AtmosphereState) {
      atmosphere = next;
      // Map global fogThickness slider gently if changed while still keeping V2 fog as primary
      void atmosphere;
      sync();
    },
    update,
    dispose() {
      scene.environment = null;
      envRT.dispose();
      (sunMesh.material as THREE.Material).dispose();
      sunMesh.geometry.dispose();
    },
  };
}

export type HarunaV2Lighting = ReturnType<typeof createHarunaV2Lighting>;
