import * as THREE from 'three';
import { mulberry32, rand, type RNG } from './noise';

// ---------- helpers ----------
function makeCanvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  return { c, ctx };
}

// periodic value noise (tileable) ---------------------------------
function hash2(ix: number, iy: number, seed: number) {
  let h = (ix * 374761393 + iy * 668265263 + seed * 2147483647) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h = h ^ (h >>> 16);
  return (h >>> 0) / 4294967295;
}
function pnoise(x: number, y: number, px: number, py: number, seed: number) {
  const ix = Math.floor(x), iy = Math.floor(y);
  const fx = x - ix, fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  const m = (a: number, p: number) => ((a % p) + p) % p;
  const x0 = m(ix, px), x1 = m(ix + 1, px), y0 = m(iy, py), y1 = m(iy + 1, py);
  const a = hash2(x0, y0, seed), b = hash2(x1, y0, seed), c = hash2(x0, y1, seed), d = hash2(x1, y1, seed);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy; // 0..1
}
function pfbm(u: number, v: number, fx: number, fy: number, oct: number, seed: number) {
  let s = 0, a = 1, n = 0, f = 1;
  for (let i = 0; i < oct; i++) {
    s += a * pnoise(u * fx * f, v * fy * f, fx * f, fy * f, seed + i * 17);
    n += a;
    a *= 0.5;
    f *= 2;
  }
  return s / n;
}

function wrapDraw(w: number, h: number, x: number, y: number, r: number, fn: (x: number, y: number) => void) {
  for (const dx of [-w, 0, w]) {
    for (const dy of [-h, 0, h]) {
      const nx = x + dx, ny = y + dy;
      if (nx + r < 0 || nx - r > w || ny + r < 0 || ny - r > h) continue;
      fn(nx, ny);
    }
  }
}

function finishColor(c: HTMLCanvasElement, repeat = true) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}
function finishLinear(c: HTMLCanvasElement) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.NoColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

/** Alpha texture: avoids black fringes in mipmaps by filling transparent texels with a base color. */
function finishAlpha(c: HTMLCanvasElement, fill: [number, number, number]) {
  const ctx = c.getContext('2d')!;
  const img = ctx.getImageData(0, 0, c.width, c.height);
  const src = img.data;
  const w = c.width, h = c.height;
  const out = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) {
    const sy = h - 1 - y; // flip so canvas top == v=1
    for (let x = 0; x < w; x++) {
      const si = (sy * w + x) * 4, di = (y * w + x) * 4;
      const a = src[si + 3];
      if (a < 8) {
        out[di] = fill[0]; out[di + 1] = fill[1]; out[di + 2] = fill[2]; out[di + 3] = 0;
      } else {
        out[di] = src[si]; out[di + 1] = src[si + 1]; out[di + 2] = src[si + 2]; out[di + 3] = a;
      }
    }
  }
  const t = new THREE.DataTexture(out, w, h, THREE.RGBAFormat);
  t.colorSpace = THREE.SRGBColorSpace;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

function normalFromHeight(hc: HTMLCanvasElement, strength: number) {
  const w = hc.width, h = hc.height;
  const src = hc.getContext('2d')!.getImageData(0, 0, w, h).data;
  const { c, ctx } = makeCanvas(w, h);
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const H = (x: number, y: number) => src[((((y + h) % h) * w + ((x + w) % w)) * 4)] / 255;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const dx = (H(x + 1, y) - H(x - 1, y)) * strength;
      const dy = (H(x, y + 1) - H(x, y - 1)) * strength;
      let nx = -dx, ny = dy, nz = 1;
      const l = Math.hypot(nx, ny, nz);
      nx /= l; ny /= l; nz /= l;
      const i = (y * w + x) * 4;
      d[i] = (nx * 0.5 + 0.5) * 255;
      d[i + 1] = (ny * 0.5 + 0.5) * 255;
      d[i + 2] = (nz * 0.5 + 0.5) * 255;
      d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return finishLinear(c);
}

const hsl = (h: number, s: number, l: number, a = 1) => `hsla(${h},${s}%,${l}%,${a})`;

// ---------- ASPHALT ----------
export function createAsphalt() {
  const W = 1024, H = 2048;
  const col = makeCanvas(W, H), hei = makeCanvas(W, H), rou = makeCanvas(W, H);
  const r = mulberry32(11);
  const ci = col.ctx.createImageData(W, H), hi = hei.ctx.createImageData(W, H), ri = rou.ctx.createImageData(W, H);
  for (let y = 0; y < H; y++) {
    const v = y / H;
    for (let x = 0; x < W; x++) {
      const u = x / W;
      const big = pfbm(u, v, 3, 6, 4, 3);
      const mid = pfbm(u, v, 24, 48, 3, 9);
      const grain = r();
      // wheel paths (slightly darker + smoother from rubber/oil)
      const wp = Math.exp(-Math.pow((u - 0.3) / 0.07, 2)) + Math.exp(-Math.pow((u - 0.7) / 0.07, 2));
      let l = 76 + (big - 0.5) * 22 + (mid - 0.5) * 14 + (grain - 0.5) * 30 - wp * 9;
      // aggregate stones
      let hgt = 110 + (mid - 0.5) * 60 + (grain - 0.5) * 70;
      if (grain > 0.965) { l += 45; hgt += 80; }
      else if (grain < 0.04) { l -= 25; hgt -= 60; }
      // dirty margins
      const edge = Math.min(u, 1 - u);
      const dirt = Math.max(0, 1 - edge / 0.06) * (0.6 + big * 0.6);
      const i = (y * W + x) * 4;
      const rr = l + dirt * 22, gg = l + dirt * 12 + 1, bb = l + 3 - dirt * 4;
      ci.data[i] = rr; ci.data[i + 1] = gg; ci.data[i + 2] = bb; ci.data[i + 3] = 255;
      hi.data[i] = hi.data[i + 1] = hi.data[i + 2] = Math.max(0, Math.min(255, hgt)); hi.data[i + 3] = 255;
      const ro = 238 - wp * 30 - (grain > 0.965 ? 25 : 0);
      ri.data[i] = ri.data[i + 1] = ri.data[i + 2] = ro; ri.data[i + 3] = 255;
    }
  }
  col.ctx.putImageData(ci, 0, 0);
  hei.ctx.putImageData(hi, 0, 0);
  rou.ctx.putImageData(ri, 0, 0);

  const C = col.ctx, Hh = hei.ctx, R = rou.ctx;
  // repair patches
  for (let k = 0; k < 5; k++) {
    const x = rand(r, 80, W - 300), y = rand(r, 0, H), w = rand(r, 120, 320), h = rand(r, 150, 500);
    wrapDraw(W, H, x + w / 2, y + h / 2, Math.max(w, h), (cx, cy) => {
      C.fillStyle = `rgba(20,21,23,${rand(r, 0.18, 0.32)})`;
      C.fillRect(cx - w / 2, cy - h / 2, w, h);
      C.strokeStyle = 'rgba(12,12,12,0.55)';
      C.lineWidth = 3;
      C.strokeRect(cx - w / 2, cy - h / 2, w, h);
      Hh.strokeStyle = 'rgba(0,0,0,0.6)';
      Hh.lineWidth = 3;
      Hh.strokeRect(cx - w / 2, cy - h / 2, w, h);
    });
  }
  // cracks
  const crack = (x: number, y: number, len: number, dir: number, wdt: number) => {
    let px = x, py = y, a = dir;
    for (let s = 0; s < len; s++) {
      a += rand(r, -0.45, 0.45);
      const nx = px + Math.cos(a) * 6, ny = py + Math.sin(a) * 6;
      wrapDraw(W, H, px, py, 10, (ox, oy) => {
        const dx = ox - px, dy = oy - py;
        for (const [ctx, st] of [[C, 'rgba(14,14,14,0.85)'], [Hh, 'rgba(0,0,0,1)']] as const) {
          ctx.strokeStyle = st;
          ctx.lineWidth = wdt;
          ctx.beginPath();
          ctx.moveTo(px + dx, py + dy);
          ctx.lineTo(nx + dx, ny + dy);
          ctx.stroke();
        }
      });
      px = nx; py = ny;
      if (r() < 0.05) crack(px, py, len * 0.4, a + rand(r, -1.4, 1.4), wdt * 0.7);
      if (px < 0 || px > W) break;
      if (py < 0) py += H;
      if (py > H) py -= H;
    }
  };
  crack(W * 0.5, rand(r, 0, H), 300, Math.PI / 2, 2.2);
  for (let k = 0; k < 18; k++) crack(rand(r, 60, W - 60), rand(r, 0, H), rand(r, 10, 60), rand(r, 0, 6.28), rand(r, 1, 2));
  // alligator cracking near edges
  for (let k = 0; k < 40; k++) crack(rand(r, 10, 140) + (r() < 0.5 ? 0 : W - 150), rand(r, 0, H), rand(r, 4, 14), rand(r, 0, 6.28), 1.4);

  // tire marks (drift) - tileable along v via sin with period
  for (let k = 0; k < 6; k++) {
    const base = rand(r, 0.22, 0.78) * W, amp = rand(r, 30, 160), ph = rand(r, 0, 6.28);
    const freq = (Math.floor(rand(r, 1, 3)) * Math.PI * 2) / H;
    const alpha = rand(r, 0.04, 0.12);
    for (let pair = 0; pair < 2; pair++) {
      C.strokeStyle = `rgba(8,8,8,${alpha})`;
      C.lineWidth = rand(r, 18, 30);
      C.beginPath();
      for (let y = -10; y <= H + 10; y += 8) {
        const x = base + pair * 62 + Math.sin(y * freq + ph) * amp;
        if (y === -10) C.moveTo(x, y); else C.lineTo(x, y);
      }
      C.stroke();
    }
    R.strokeStyle = 'rgba(150,150,150,0.25)';
    R.lineWidth = 24;
    R.beginPath();
    for (let y = -10; y <= H + 10; y += 8) {
      const x = base + Math.sin(y * freq + ph) * amp;
      if (y === -10) R.moveTo(x, y); else R.lineTo(x, y);
    }
    R.stroke();
  }

  // edge lines (white, worn)
  const lineW = 22;
  for (const lx of [0.075 * W, 0.925 * W]) {
    for (let y = 0; y < H; y += 2) {
      const wear = pfbm(lx / W, y / H, 4, 40, 3, 77);
      const a = 0.72 + 0.28 * Math.max(0, Math.min(1, (wear - 0.2) * 3));
      C.fillStyle = `rgba(222,222,212,${0.88 * a})`;
      C.fillRect(lx - lineW / 2, y, lineW, 2);
      Hh.fillStyle = `rgba(255,255,255,${0.5 * a})`;
      Hh.fillRect(lx - lineW / 2, y, lineW, 2);
      R.fillStyle = `rgba(150,150,150,${a})`;
      R.fillRect(lx - lineW / 2, y, lineW, 2);
    }
    // speckle wear on line
    for (let k = 0; k < 900; k++) {
      C.fillStyle = `rgba(70,70,72,${rand(r, 0.2, 0.6)})`;
      C.fillRect(lx - lineW / 2 + rand(r, 0, lineW), rand(r, 0, H), rand(r, 1, 3), rand(r, 1, 3));
    }
  }
  // debris on margins: small leaves + needles
  for (let k = 0; k < 1400; k++) {
    const side = r() < 0.5;
    const x = side ? Math.pow(r(), 2) * 70 : W - Math.pow(r(), 2) * 70;
    const y = rand(r, 0, H);
    wrapDraw(W, H, x, y, 12, (px, py) => {
      C.save();
      C.translate(px, py);
      C.rotate(rand(r, 0, 6.28));
      C.fillStyle = hsl(rand(r, 18, 38), rand(r, 35, 60), rand(r, 18, 36), 0.9);
      C.beginPath();
      C.ellipse(0, 0, rand(r, 3, 8), rand(r, 1.2, 3), 0, 0, Math.PI * 2);
      C.fill();
      C.restore();
    });
  }

  return {
    map: finishColor(col.c),
    normal: normalFromHeight(hei.c, 2.2),
    rough: finishLinear(rou.c),
  };
}

// ---------- LEAF LITTER GROUND ----------
function drawLitterLeaf(ctx: CanvasRenderingContext2D, x: number, y: number, len: number, wid: number, rot: number, color: string, stem = true) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(-len, 0);
  ctx.bezierCurveTo(-len * 0.4, -wid * 1.3, len * 0.4, -wid * 1.1, len, 0);
  ctx.bezierCurveTo(len * 0.4, wid * 1.1, -len * 0.4, wid * 1.3, -len, 0);
  ctx.fill();
  if (stem) {
    ctx.strokeStyle = 'rgba(30,18,10,0.45)';
    ctx.lineWidth = Math.max(0.6, wid * 0.12);
    ctx.beginPath();
    ctx.moveTo(-len * 1.25, 0);
    ctx.lineTo(len * 0.9, 0);
    ctx.stroke();
  }
  ctx.restore();
}

export function createLitter() {
  const S = 1024;
  const col = makeCanvas(S, S), hei = makeCanvas(S, S);
  const r = mulberry32(21);
  const ci = col.ctx.createImageData(S, S), hi = hei.ctx.createImageData(S, S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const n = pfbm(x / S, y / S, 8, 8, 5, 5);
    const g = r();
    const i = (y * S + x) * 4;
    const l = 22 + n * 26 + g * 10;
    ci.data[i] = l * 1.45; ci.data[i + 1] = l * 1.05; ci.data[i + 2] = l * 0.7; ci.data[i + 3] = 255;
    hi.data[i] = hi.data[i + 1] = hi.data[i + 2] = 40 + n * 50; hi.data[i + 3] = 255;
  }
  col.ctx.putImageData(ci, 0, 0);
  hei.ctx.putImageData(hi, 0, 0);
  const C = col.ctx, H = hei.ctx;
  const palette = () => {
    const t = r();
    if (t < 0.35) return [rand(r, 20, 32), rand(r, 45, 65), rand(r, 22, 34)]; // brown
    if (t < 0.6) return [rand(r, 22, 34), rand(r, 55, 75), rand(r, 32, 46)]; // orange-tan
    if (t < 0.8) return [rand(r, 30, 40), rand(r, 30, 48), rand(r, 40, 56)]; // pale tan
    if (t < 0.92) return [rand(r, 14, 22), rand(r, 40, 55), rand(r, 14, 22)]; // dark rotten
    return [rand(r, 8, 18), rand(r, 50, 65), rand(r, 25, 35)]; // reddish cedar
  };
  const N = 5200;
  for (let k = 0; k < N; k++) {
    const layer = k / N;
    const x = rand(r, 0, S), y = rand(r, 0, S);
    const len = rand(r, 6, 20), wid = len * rand(r, 0.3, 0.55), rot = rand(r, 0, 6.28);
    const [hh, ss, ll] = palette();
    wrapDraw(S, S, x, y, len * 1.4, (px, py) => {
      drawLitterLeaf(C, px + 1.5, py + 2, len, wid, rot, 'rgba(0,0,0,0.35)', false);
      drawLitterLeaf(C, px, py, len, wid, rot, hsl(hh, ss, ll * (0.75 + layer * 0.35)));
      const hv = Math.floor(70 + layer * 170);
      drawLitterLeaf(H, px, py, len, wid, rot, `rgb(${hv},${hv},${hv})`, false);
    });
  }
  // cedar needles/twigs
  for (let k = 0; k < 900; k++) {
    const x = rand(r, 0, S), y = rand(r, 0, S), a = rand(r, 0, 6.28), L = rand(r, 10, 40);
    wrapDraw(S, S, x, y, L, (px, py) => {
      for (const [ctx, st, lw] of [[C, hsl(rand(r, 15, 28), 45, rand(r, 18, 32)), rand(r, 1, 2.4)], [H, 'rgb(255,255,255)', 1.5]] as const) {
        ctx.strokeStyle = st;
        ctx.lineWidth = lw;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.quadraticCurveTo(px + Math.cos(a + 0.4) * L * 0.5, py + Math.sin(a + 0.4) * L * 0.5, px + Math.cos(a) * L, py + Math.sin(a) * L);
        ctx.stroke();
      }
    });
  }
  return { map: finishColor(col.c), normal: normalFromHeight(hei.c, 3.5) };
}

// ---------- MOSS / FOREST FLOOR ----------
export function createMoss() {
  const S = 1024;
  const col = makeCanvas(S, S), hei = makeCanvas(S, S);
  const r = mulberry32(31);
  const ci = col.ctx.createImageData(S, S), hi = hei.ctx.createImageData(S, S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const n = pfbm(x / S, y / S, 6, 6, 5, 41);
    const f = pfbm(x / S, y / S, 64, 64, 2, 43);
    const g = r();
    const i = (y * S + x) * 4;
    const l = 0.55 + n * 0.6 + (f - 0.5) * 0.5 + (g - 0.5) * 0.25;
    ci.data[i] = 34 * l + 10; ci.data[i + 1] = 52 * l + 12; ci.data[i + 2] = 18 * l + 6; ci.data[i + 3] = 255;
    hi.data[i] = hi.data[i + 1] = hi.data[i + 2] = Math.min(255, 60 + f * 140 + g * 40); hi.data[i + 3] = 255;
  }
  col.ctx.putImageData(ci, 0, 0);
  hei.ctx.putImageData(hi, 0, 0);
  const C = col.ctx, H = hei.ctx;
  // tiny sprouts
  for (let k = 0; k < 7000; k++) {
    const x = rand(r, 0, S), y = rand(r, 0, S);
    wrapDraw(S, S, x, y, 4, (px, py) => {
      C.fillStyle = hsl(rand(r, 70, 105), rand(r, 35, 60), rand(r, 18, 38), 0.9);
      C.beginPath();
      C.arc(px, py, rand(r, 0.8, 2.4), 0, Math.PI * 2);
      C.fill();
      H.fillStyle = 'rgba(255,255,255,0.6)';
      H.fillRect(px, py, 2, 2);
    });
  }
  // sparse litter
  for (let k = 0; k < 700; k++) {
    const x = rand(r, 0, S), y = rand(r, 0, S), len = rand(r, 6, 16), rot = rand(r, 0, 6.28);
    wrapDraw(S, S, x, y, len * 1.5, (px, py) => {
      drawLitterLeaf(C, px, py, len, len * 0.4, rot, hsl(rand(r, 20, 36), rand(r, 40, 60), rand(r, 18, 34), 0.95));
      drawLitterLeaf(H, px, py, len, len * 0.4, rot, 'rgb(220,220,220)', false);
    });
  }
  return { map: finishColor(col.c), normal: normalFromHeight(hei.c, 3) };
}

// ---------- BARK ----------
export function createBarkCedar() {
  const W = 512, H = 1024;
  const col = makeCanvas(W, H), hei = makeCanvas(W, H);
  const ci = col.ctx.createImageData(W, H), hi = hei.ctx.createImageData(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const u = x / W, v = y / H;
    const warp = pfbm(u, v, 4, 2, 3, 61) * 0.08;
    const strands = pfbm(u + warp, v, 48, 3, 4, 63);
    const fine = pfbm(u + warp, v, 160, 10, 2, 67);
    const patch = pfbm(u, v, 3, 4, 4, 69);
    const ridge = 1 - Math.abs(strands - 0.5) * 2;
    const h = ridge * 0.7 + fine * 0.3;
    const i = (y * W + x) * 4;
    // reddish brown in grooves, greyish on ridges
    const grey = Math.min(1, Math.max(0, (patch - 0.35) * 2.2)) * ridge;
    const base = [88 + h * 50, 52 + h * 34, 36 + h * 22];
    const gr = [118 + h * 30, 108 + h * 28, 96 + h * 24];
    const lich = patch > 0.66 && fine > 0.55 ? 1 : 0;
    let rr = base[0] * (1 - grey) + gr[0] * grey;
    let gg = base[1] * (1 - grey) + gr[1] * grey;
    let bb = base[2] * (1 - grey) + gr[2] * grey;
    if (lich) { rr = rr * 0.5 + 70; gg = gg * 0.5 + 82; bb = bb * 0.5 + 58; }
    const dark = 0.55 + h * 0.55;
    ci.data[i] = rr * dark; ci.data[i + 1] = gg * dark; ci.data[i + 2] = bb * dark; ci.data[i + 3] = 255;
    hi.data[i] = hi.data[i + 1] = hi.data[i + 2] = h * 255; hi.data[i + 3] = 255;
  }
  col.ctx.putImageData(ci, 0, 0);
  hei.ctx.putImageData(hi, 0, 0);
  return { map: finishColor(col.c), normal: normalFromHeight(hei.c, 5) };
}

export function createBarkBroad() {
  const W = 512, H = 512;
  const col = makeCanvas(W, H), hei = makeCanvas(W, H);
  const r = mulberry32(71);
  const ci = col.ctx.createImageData(W, H), hi = hei.ctx.createImageData(W, H);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const u = x / W, v = y / H;
    const n = pfbm(u, v, 6, 6, 5, 73);
    const fine = pfbm(u, v, 40, 80, 3, 79);
    const lich = pfbm(u, v, 10, 10, 4, 81);
    const i = (y * W + x) * 4;
    const l = 0.75 + n * 0.45 + (fine - 0.5) * 0.25;
    let rr = 105 * l, gg = 102 * l, bb = 94 * l;
    if (lich > 0.58) { const t = Math.min(1, (lich - 0.58) * 6); rr = rr * (1 - t) + 150 * t; gg = gg * (1 - t) + 160 * t; bb = bb * (1 - t) + 135 * t; }
    if (lich < 0.32) { const t = Math.min(1, (0.32 - lich) * 6); rr = rr * (1 - t) + 55 * t; gg = gg * (1 - t) + 72 * t; bb = bb * (1 - t) + 35 * t; }
    ci.data[i] = rr; ci.data[i + 1] = gg; ci.data[i + 2] = bb; ci.data[i + 3] = 255;
    hi.data[i] = hi.data[i + 1] = hi.data[i + 2] = 90 + n * 80 + fine * 60; hi.data[i + 3] = 255;
  }
  col.ctx.putImageData(ci, 0, 0);
  hei.ctx.putImageData(hi, 0, 0);
  // lenticels
  for (let k = 0; k < 900; k++) {
    const x = rand(r, 0, W), y = rand(r, 0, H), w = rand(r, 4, 14);
    wrapDraw(W, H, x, y, w, (px, py) => {
      col.ctx.fillStyle = 'rgba(40,36,32,0.55)';
      col.ctx.fillRect(px - w / 2, py, w, 1.5);
      hei.ctx.fillStyle = 'rgba(0,0,0,0.7)';
      hei.ctx.fillRect(px - w / 2, py, w, 1.5);
    });
  }
  return { map: finishColor(col.c), normal: normalFromHeight(hei.c, 3) };
}

// ---------- FOLIAGE ATLASES (alpha) ----------
function needleRope(ctx: CanvasRenderingContext2D, r: RNG, pts: [number, number][], thick: number, hue: number, light: number) {
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i], [x1, y1] = pts[i + 1];
    const seg = Math.hypot(x1 - x0, y1 - y0);
    const ang = Math.atan2(y1 - y0, x1 - x0);
    const t = i / (pts.length - 1);
    const steps = Math.ceil(seg / 1.6);
    for (let s = 0; s < steps; s++) {
      const f = s / steps;
      const x = x0 + (x1 - x0) * f, y = y0 + (y1 - y0) * f;
      const th = thick * (1 - t * 0.55);
      for (const side of [-1, 1]) {
        const a = ang + side * rand(r, 0.5, 1.1);
        const L = th * rand(r, 0.7, 1.25);
        const tip = t > 0.8 ? 10 : 0;
        ctx.strokeStyle = hsl(hue + rand(r, -6, 8) + tip * 0.5, rand(r, 40, 60), light + rand(r, -6, 8) + tip + t * 6);
        ctx.lineWidth = rand(r, 1.2, 2.4);
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L);
        ctx.stroke();
      }
    }
  }
}

function curvePts(r: RNG, x: number, y: number, ang: number, len: number, bend: number, n = 10) {
  const pts: [number, number][] = [];
  let a = ang;
  for (let i = 0; i <= n; i++) {
    pts.push([x, y]);
    a += bend + rand(r, -0.08, 0.08);
    x += Math.cos(a) * (len / n);
    y += Math.sin(a) * (len / n);
  }
  return pts;
}

export function createCedarFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(101);
  ctx.lineCap = 'round';
  const shoots = 9;
  for (let i = 0; i < shoots; i++) {
    const ang = -Math.PI / 2 + rand(r, -0.95, 0.95);
    const len = rand(r, 520, 820);
    const pts = curvePts(r, S / 2 + rand(r, -30, 30), S - 20, ang, len, rand(r, -0.03, 0.03), 14);
    ctx.strokeStyle = '#4a3523';
    ctx.lineWidth = 4;
    ctx.beginPath();
    pts.forEach(([x, y], k) => (k ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.stroke();
    for (let k = 3; k < pts.length - 1; k++) {
      const [px, py] = pts[k];
      const [qx, qy] = pts[k + 1];
      const base = Math.atan2(qy - py, qx - px);
      for (const side of [-1, 1]) {
        if (r() < 0.25) continue;
        const sp = curvePts(r, px, py, base + side * rand(r, 0.6, 1.1), rand(r, 80, 170), -side * 0.04, 7);
        needleRope(ctx, r, sp, rand(r, 9, 14), rand(r, 88, 102), rand(r, 18, 26));
        for (let m = 2; m < sp.length - 1; m += 2) {
          const sub = curvePts(r, sp[m][0], sp[m][1], base + side * rand(r, 1.0, 1.6), rand(r, 30, 70), 0, 5);
          needleRope(ctx, r, sub, rand(r, 7, 10), rand(r, 86, 100), rand(r, 20, 30));
        }
      }
    }
    needleRope(ctx, r, pts.slice(3), 15, 92, 22);
  }
  return finishAlpha(c, [45, 62, 30]);
}

export function createCypressFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(111);
  ctx.lineCap = 'round';
  const frond = (x: number, y: number, ang: number, len: number, w: number, depth: number) => {
    const pts = curvePts(r, x, y, ang, len, rand(r, -0.04, 0.04), 10);
    for (let k = 0; k < pts.length - 1; k++) {
      const [px, py] = pts[k];
      const t = k / pts.length;
      const sc = w * (1 - t * 0.7);
      ctx.fillStyle = hsl(rand(r, 92, 108), rand(r, 45, 60), rand(r, 20, 30) + t * 10);
      ctx.beginPath();
      ctx.ellipse(px, py, sc, sc * 0.55, ang, 0, Math.PI * 2);
      ctx.fill();
      if (depth > 0 && k % 2 === 1 && k < pts.length - 2) {
        for (const side of [-1, 1]) frond(px, py, ang + side * rand(r, 0.7, 1.0), len * rand(r, 0.32, 0.45), w * 0.75, depth - 1);
      }
    }
  };
  for (let i = 0; i < 6; i++) frond(S / 2 + rand(r, -40, 40), S - 30, -Math.PI / 2 + rand(r, -0.8, 0.8), rand(r, 600, 820), 22, 2);
  return finishAlpha(c, [40, 70, 32]);
}

function palmateLeaf(ctx: CanvasRenderingContext2D, x: number, y: number, R: number, rot: number, fill: string, vein: string, lobes = 7) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.fillStyle = fill;
  ctx.beginPath();
  const spread = 2.3;
  for (let i = 0; i <= lobes; i++) {
    const a = -Math.PI / 2 - spread + (i / lobes) * spread * 2;
    if (i === lobes) break;
    const am = a + spread / lobes;
    const tip = R * (i === 0 || i === lobes - 1 ? 0.6 : 1) * (Math.abs(i - (lobes - 1) / 2) < 1 ? 1 : 0.88);
    const tx = Math.cos(am) * tip, ty = Math.sin(am) * tip;
    const vx = Math.cos(a) * R * 0.32, vy = Math.sin(a) * R * 0.32;
    if (i === 0) ctx.moveTo(vx, vy); else ctx.lineTo(vx, vy);
    ctx.quadraticCurveTo(Math.cos(am - 0.18) * tip * 0.7, Math.sin(am - 0.18) * tip * 0.7, tx, ty);
    const na = a + (2 * spread) / lobes;
    ctx.quadraticCurveTo(Math.cos(am + 0.18) * tip * 0.7, Math.sin(am + 0.18) * tip * 0.7, Math.cos(na) * R * 0.32, Math.sin(na) * R * 0.32);
  }
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = vein;
  ctx.lineWidth = Math.max(0.8, R * 0.035);
  for (let i = 0; i < lobes; i++) {
    const am = -Math.PI / 2 - spread + (i / lobes) * spread * 2 + spread / lobes;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(am) * R * 0.8, Math.sin(am) * R * 0.8);
    ctx.stroke();
  }
  ctx.restore();
}

function ovateLeaf(ctx: CanvasRenderingContext2D, x: number, y: number, L: number, rot: number, fill: string, vein: string, wr = 0.42) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  const W = L * wr;
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  const n = 14;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const w = Math.sin(Math.PI * Math.pow(t, 0.8)) * W * (i % 2 ? 1 : 0.92);
    ctx.lineTo(w, -t * L);
  }
  for (let i = n; i >= 0; i--) {
    const t = i / n;
    const w = Math.sin(Math.PI * Math.pow(t, 0.8)) * W * (i % 2 ? 1 : 0.92);
    ctx.lineTo(-w, -t * L);
  }
  ctx.fill();
  ctx.strokeStyle = vein;
  ctx.lineWidth = Math.max(0.7, L * 0.025);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -L * 0.95);
  for (let i = 1; i < 7; i++) {
    const t = i / 7;
    ctx.moveTo(0, -t * L * 0.9);
    ctx.lineTo(W * 0.8 * Math.sin(Math.PI * t), -t * L * 0.9 - L * 0.12);
    ctx.moveTo(0, -t * L * 0.9);
    ctx.lineTo(-W * 0.8 * Math.sin(Math.PI * t), -t * L * 0.9 - L * 0.12);
  }
  ctx.stroke();
  ctx.restore();
}

function twigCluster(
  r: RNG, ctx: CanvasRenderingContext2D, S: number,
  leaf: (x: number, y: number, rot: number, layer: number) => void,
  twigs = 7, leavesPer = 14,
) {
  ctx.lineCap = 'round';
  const all: { x: number; y: number; rot: number; layer: number }[] = [];
  for (let i = 0; i < twigs; i++) {
    const ang = -Math.PI / 2 + rand(r, -1.2, 1.2);
    const pts = curvePts(r, S / 2 + rand(r, -50, 50), S - 10, ang, rand(r, 420, 760), rand(r, -0.05, 0.05), 12);
    ctx.strokeStyle = '#5a4630';
    ctx.lineWidth = 3;
    ctx.beginPath();
    pts.forEach(([x, y], k) => (k ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.stroke();
    for (let k = 0; k < leavesPer; k++) {
      const t = 0.25 + (k / leavesPer) * 0.75;
      const idx = Math.min(pts.length - 1, Math.floor(t * (pts.length - 1)));
      const [px, py] = pts[idx];
      const side = k % 2 ? 1 : -1;
      const rot = ang + Math.PI / 2 + side * rand(r, 0.5, 1.3);
      const pl = rand(r, 18, 40);
      const lx = px + Math.cos(rot - Math.PI / 2) * pl, ly = py + Math.sin(rot - Math.PI / 2) * pl;
      ctx.strokeStyle = '#6b7a35';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(lx, ly);
      ctx.stroke();
      all.push({ x: lx, y: ly, rot, layer: r() });
    }
  }
  all.sort((a, b) => a.layer - b.layer);
  for (const l of all) leaf(l.x, l.y, l.rot, l.layer);
}

export function createMapleFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(121);
  twigCluster(r, ctx, S, (x, y, rot, layer) => {
    const R = rand(r, 50, 78);
    const h = rand(r, 72, 92), s = rand(r, 55, 72), l = 30 + layer * 22 + rand(r, -3, 3);
    palmateLeaf(ctx, x, y, R, rot, hsl(h, s, l), hsl(h + 4, s - 10, l + 10, 0.6), r() < 0.6 ? 7 : 5);
  }, 8, 13);
  return finishAlpha(c, [96, 140, 40]);
}

export function createBeechFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(131);
  twigCluster(r, ctx, S, (x, y, rot, layer) => {
    const L = rand(r, 70, 110);
    const h = rand(r, 78, 98), s = rand(r, 45, 62), l = 26 + layer * 22 + rand(r, -3, 3);
    ovateLeaf(ctx, x, y, L, rot, hsl(h, s, l), hsl(h + 6, s - 15, l + 9, 0.55));
  }, 8, 16);
  return finishAlpha(c, [80, 120, 40]);
}

export function createSasaFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(141);
  ctx.lineCap = 'round';
  const leaves: { x: number; y: number; a: number; L: number; layer: number }[] = [];
  for (let i = 0; i < 16; i++) {
    const ang = -Math.PI / 2 + rand(r, -0.9, 0.9);
    const pts = curvePts(r, S / 2 + rand(r, -260, 260), S, ang, rand(r, 400, 820), rand(r, -0.04, 0.04), 8);
    ctx.strokeStyle = hsl(70, 30, 28);
    ctx.lineWidth = 3;
    ctx.beginPath();
    pts.forEach(([x, y], k) => (k ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.stroke();
    for (let k = 4; k < pts.length; k += 1) {
      const [px, py] = pts[k];
      const cnt = k === pts.length - 1 ? 4 : 2;
      for (let m = 0; m < cnt; m++) leaves.push({ x: px, y: py, a: ang + rand(r, -1.4, 1.4), L: rand(r, 140, 230), layer: r() });
    }
  }
  leaves.sort((a, b) => a.layer - b.layer);
  for (const l of leaves) {
    const h = rand(r, 82, 100), s = rand(r, 40, 58), lt = 22 + l.layer * 20;
    ctx.save();
    ctx.translate(l.x, l.y);
    ctx.rotate(l.a + Math.PI / 2);
    const W = l.L * 0.13;
    ctx.fillStyle = hsl(h, s, lt);
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(W * 1.4, -l.L * 0.35, 0, -l.L);
    ctx.quadraticCurveTo(-W * 1.4, -l.L * 0.35, 0, 0);
    ctx.fill();
    if (r() < 0.45) {
      ctx.strokeStyle = hsl(50, 30, 70, 0.7);
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    ctx.strokeStyle = hsl(h, s - 10, lt + 12, 0.7);
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -l.L * 0.95);
    ctx.stroke();
    ctx.restore();
  }
  return finishAlpha(c, [60, 90, 32]);
}

export function createShrubFoliage() {
  const S = 512;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(151);
  const all: { x: number; y: number; rot: number; layer: number }[] = [];
  for (let i = 0; i < 520; i++) {
    const a = rand(r, 0, Math.PI * 2), d = Math.sqrt(r()) * S * 0.46;
    all.push({ x: S / 2 + Math.cos(a) * d, y: S / 2 + Math.sin(a) * d, rot: rand(r, 0, 6.28), layer: 1 - d / (S * 0.46) * 0.6 + r() * 0.3 });
  }
  all.sort((a, b) => a.layer - b.layer);
  for (const l of all) {
    ovateLeaf(ctx, l.x, l.y, rand(r, 22, 36), l.rot, hsl(rand(r, 85, 110), rand(r, 35, 55), 16 + l.layer * 24), 'rgba(160,190,110,0.35)', 0.5);
  }
  return finishAlpha(c, [50, 80, 32]);
}

export function createFernFoliage() {
  const S = 1024;
  const { c, ctx } = makeCanvas(S, S);
  const r = mulberry32(161);
  ctx.lineCap = 'round';
  for (let f = 0; f < 7; f++) {
    const ang = -Math.PI / 2 + rand(r, -1.1, 1.1);
    const pts = curvePts(r, S / 2 + rand(r, -40, 40), S, ang, rand(r, 650, 900), (ang + Math.PI / 2) * 0.05, 30);
    const h = rand(r, 85, 100), lt = rand(r, 24, 34);
    ctx.strokeStyle = hsl(h, 40, lt - 6);
    ctx.lineWidth = 3;
    ctx.beginPath();
    pts.forEach(([x, y], k) => (k ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.stroke();
    for (let k = 3; k < pts.length - 1; k++) {
      const t = k / pts.length;
      const [px, py] = pts[k], [qx, qy] = pts[k + 1];
      const a = Math.atan2(qy - py, qx - px);
      const L = Math.sin(Math.PI * Math.min(1, t * 1.1)) * 110 + 10;
      for (const side of [-1, 1]) {
        const pa = a + side * 1.2;
        ctx.strokeStyle = hsl(h + rand(r, -4, 4), 50, lt + rand(r, -3, 5));
        ctx.lineWidth = 7 * (1 - t * 0.6);
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.quadraticCurveTo(px + Math.cos(pa) * L * 0.5, py + Math.sin(pa) * L * 0.5 - 6, px + Math.cos(pa + side * 0.2) * L, py + Math.sin(pa + side * 0.2) * L);
        ctx.stroke();
      }
    }
  }
  return finishAlpha(c, [55, 88, 32]);
}

export function createGrass() {
  const W = 512, H = 512;
  const { c, ctx } = makeCanvas(W, H);
  const r = mulberry32(171);
  ctx.lineCap = 'round';
  for (let i = 0; i < 110; i++) {
    const x0 = rand(r, 40, W - 40);
    const h = rand(r, 0.45, 1) * H * 0.95;
    const lean = rand(r, -0.5, 0.5) * h * 0.5;
    const w = rand(r, 5, 10);
    const hue = rand(r, 62, 100), sat = rand(r, 35, 60), l = rand(r, 22, 44);
    const g = ctx.createLinearGradient(0, H, 0, H - h);
    g.addColorStop(0, hsl(hue, sat, l * 0.45));
    g.addColorStop(0.6, hsl(hue, sat, l));
    g.addColorStop(1, hsl(hue - 12, sat - 10, l + 14));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x0 - w / 2, H);
    ctx.quadraticCurveTo(x0 - w / 2 + lean * 0.3, H - h * 0.6, x0 + lean, H - h);
    ctx.quadraticCurveTo(x0 + w / 2 + lean * 0.3, H - h * 0.6, x0 + w / 2, H);
    ctx.fill();
  }
  return finishAlpha(c, [70, 95, 40]);
}

export function createSmoke() {
  const S = 256;
  const { c, ctx } = makeCanvas(S, S);
  const img = ctx.createImageData(S, S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const dx = x / S - 0.5, dy = y / S - 0.5;
    const d = Math.sqrt(dx * dx + dy * dy) * 2;
    const n = pfbm(x / S, y / S, 4, 4, 5, 191);
    const a = Math.max(0, 1 - d) ** 1.6 * (0.35 + n * 0.9);
    const i = (y * S + x) * 4;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = 255;
    img.data[i + 3] = Math.min(255, a * 255);
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function createV2Textures(maxAniso = 12) {
  const asphalt = createAsphalt();
  const litter = createLitter();
  const moss = createMoss();
  const barkCedar = createBarkCedar();
  const barkBroad = createBarkBroad();
  const cedar = createCedarFoliage();
  const cypress = createCypressFoliage();
  const maple = createMapleFoliage();
  const beech = createBeechFoliage();
  const sasa = createSasaFoliage();
  const shrub = createShrubFoliage();
  const fern = createFernFoliage();
  const grass = createGrass();
  const smoke = createSmoke();

  const textures = new Set<THREE.Texture>();
  const register = (t: THREE.Texture, aniso: number) => {
    t.anisotropy = Math.min(maxAniso, aniso);
    textures.add(t);
  };
  Object.values(asphalt).forEach(t => register(t, 12));
  Object.values(litter).forEach(t => register(t, 12));
  Object.values(moss).forEach(t => register(t, 12));
  Object.values(barkCedar).forEach(t => register(t, 12));
  Object.values(barkBroad).forEach(t => register(t, 12));
  [cedar, cypress, maple, beech, sasa, shrub, fern, grass, smoke].forEach(t => register(t, 8));

  return {
    asphalt,
    litter,
    moss,
    barkCedar,
    barkBroad,
    cedar,
    cypress,
    maple,
    beech,
    sasa,
    shrub,
    fern,
    grass,
    smoke,
    textures,
    dispose() {
      for (const t of textures) t.dispose();
    },
  };
}

export type V2TextureSet = ReturnType<typeof createV2Textures>;
