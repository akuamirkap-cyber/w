import * as THREE from 'three';
import type { SurfaceType } from './settings';
import type { Track } from './track';
import {
  makeBannerTexture,
  makeCheckerTexture,
  makeFloorTexture,
  makeStripeTexture,
  makeSurfaceTexture,
  makeTextTexture,
} from './textures';

export interface Arena {
  group: THREE.Group;
  setSurface: (k: SurfaceType) => void;
  driverStand: THREE.Vector3;
}
export type ArenaTheme = 'haruna' | 'prodrift';

function ribbon(track: Track, i0: number, count: number, off0: number, off1: number, y: number, vScale: number) {
  const N = track.count;
  const pos: number[] = [];
  const uv: number[] = [];
  const idx: number[] = [];
  const s0 = track.pts[((i0 % N) + N) % N].s;
  let acc = 0;
  let prevS = s0;
  for (let k = 0; k <= count; k++) {
    const p = track.pts[(((i0 + k) % N) + N) % N];
    let ds = p.s - prevS;
    if (ds < 0) ds += track.length;
    acc += k === 0 ? 0 : ds;
    prevS = p.s;
    pos.push(p.x + p.nx * off0, y, -(p.y + p.ny * off0));
    pos.push(p.x + p.nx * off1, y, -(p.y + p.ny * off1));
    uv.push(0, acc / vScale, 1, acc / vScale);
    if (k < count) {
      const a = k * 2;
      // orientation chosen so faces point up for off0 > off1 (left -> right)
      if (off0 > off1) idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      else idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export function buildArena(track: Track, theme: ArenaTheme = 'haruna'): Arena {
  const group = new THREE.Group();
  const hw = track.halfWidth;

  // ---------------- Arena floor (concrete) ----------------
  const floorTex = makeFloorTexture();
  floorTex.repeat.set(90 / 5, 64 / 5);
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(90, 64),
    new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.9, metalness: 0 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(0, 0, 2);
  floor.receiveShadow = true;
  group.add(floor);

  // ---------------- Track floor (P-tile area, world aligned) ----------------
  const surfTex: Record<SurfaceType, THREE.Texture> = {
    ptile: makeSurfaceTexture('ptile'),
    concrete: makeSurfaceTexture('concrete'),
    carpet: makeSurfaceTexture('carpet'),
  };
  const W = 41;
  const H = 21.5;
  for (const t of Object.values(surfTex)) t.repeat.set(W / 1.2, H / 1.2);
  const surfMat = new THREE.MeshStandardMaterial({ map: surfTex.ptile, roughness: 0.5, metalness: 0.02 });
  const surf = new THREE.Mesh(new THREE.PlaneGeometry(W, H), surfMat);
  surf.rotation.x = -Math.PI / 2;
  surf.position.set(0, 0.002, 0);
  surf.receiveShadow = true;
  group.add(surf);
  // border trim around tile area
  const trimMat = new THREE.MeshStandardMaterial({ color: theme === 'prodrift' ? 0xffc400 : 0xe8e8e8, roughness: 0.6 });
  for (const [w, d, x, z] of [
    [W + 0.3, 0.15, 0, H / 2],
    [W + 0.3, 0.15, 0, -H / 2],
    [0.15, H, W / 2, 0],
    [0.15, H, -W / 2, 0],
  ]) {
    const t = new THREE.Mesh(new THREE.BoxGeometry(w, 0.01, d), trimMat);
    t.position.set(x, 0.004, z);
    t.receiveShadow = true;
    group.add(t);
  }

  const setSurface = (k: SurfaceType) => {
    surfMat.map = surfTex[k];
    surfMat.roughness = k === 'concrete' ? 0.28 : k === 'carpet' ? 0.95 : 0.5;
    surfMat.needsUpdate = true;
  };

  // ---------------- Painted edge lines ----------------
  const lineMat = new THREE.MeshStandardMaterial({ color: 0xf2f2f2, roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -1 });
  for (const sgn of [1, -1]) {
    const l = new THREE.Mesh(ribbon(track, 0, track.count, sgn * (hw - 0.02), sgn * (hw - 0.07), 0.0035, 1), lineMat);
    if (sgn < 0) l.geometry = ribbon(track, 0, track.count, sgn * (hw - 0.07), sgn * (hw - 0.02), 0.0035, 1);
    l.receiveShadow = true;
    group.add(l);
  }

  // ---------------- Curbs at corners (inner side) ----------------
  const curbTex = makeStripeTexture('#d91e26', '#f4f4f4', true);
  const curbMat = new THREE.MeshStandardMaterial({ map: curbTex, roughness: 0.55, polygonOffset: true, polygonOffsetFactor: -2 });
  const N = track.count;
  let i = 0;
  const curv = track.pts.map((_, k) => track.curvature(k));
  while (i < N) {
    const c = curv[i];
    if (Math.abs(c) > 0.075) {
      const sign = Math.sign(c);
      let j = i;
      while (j < N && Math.abs(curv[j]) > 0.06 && Math.sign(curv[j]) === sign) j++;
      const count = j - i;
      if (count > 8) {
        const off0 = sign > 0 ? hw : -hw + 0.22;
        const off1 = sign > 0 ? hw - 0.22 : -hw;
        const g = ribbon(track, i, count, off0, off1, 0.0045, 0.5);
        const m = new THREE.Mesh(g, curbMat);
        m.receiveShadow = true;
        group.add(m);
      }
      i = j;
    } else i++;
  }

  // ---------------- Foam barriers (both sides) ----------------
  const barrierTex = makeStripeTexture('#f5f5f5', theme === 'prodrift' ? '#d91e26' : '#1d56ff');
  barrierTex.repeat.set(Math.round(track.length / 1.0), 1);
  const barrierTex2 = barrierTex.clone();
  barrierTex2.repeat.set(Math.round((track.length * 1.15) / 1.0), 1);
  barrierTex2.needsUpdate = true;
  for (const [off, tex] of [
    [hw + 0.065, barrierTex],
    [-(hw + 0.065), barrierTex2],
  ] as [number, THREE.Texture][]) {
    const curve = new THREE.CatmullRomCurve3(track.edge(off, 0.06), true, 'catmullrom', 0.2);
    const tube = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 900, 0.062, 10, true),
      new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85 }),
    );
    tube.castShadow = true;
    tube.receiveShadow = true;
    group.add(tube);
  }

  // ---------------- Start / finish ----------------
  const p0 = track.pts[0];
  const ang = Math.atan2(p0.ty, p0.tx);
  const checker = new THREE.Mesh(
    new THREE.PlaneGeometry(hw * 2, 0.28),
    new THREE.MeshStandardMaterial({ map: makeCheckerTexture(10), roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -3 }),
  );
  checker.rotation.x = -Math.PI / 2;
  checker.rotation.z = ang + Math.PI / 2;
  checker.position.set(p0.x, 0.005, -p0.y);
  group.add(checker);
  const gantry = new THREE.Group();
  const postMat = new THREE.MeshStandardMaterial({ color: 0x1b1d22, metalness: 0.6, roughness: 0.4 });
  for (const sgn of [1, -1]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.9, 0.08), postMat);
    post.position.set(0, 0.45, sgn * (hw + 0.3));
    post.castShadow = true;
    gantry.add(post);
  }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.22, (hw + 0.3) * 2 + 0.1), postMat);
  beam.position.set(0, 0.9, 0);
  beam.castShadow = true;
  gantry.add(beam);
  const sign = makeTextTexture('START • FINISH', { w: 1024, h: 128, bg: '#0d0f14', fg: '#ffffff', stripe: '#ffcc00' });
  for (const sx of [1, -1]) {
    const pl = new THREE.Mesh(new THREE.PlaneGeometry((hw + 0.3) * 2, 0.2), new THREE.MeshBasicMaterial({ map: sign }));
    pl.position.set(sx * 0.052, 0.9, 0);
    pl.rotation.y = (sx * Math.PI) / 2;
    gantry.add(pl);
  }
  gantry.position.set(p0.x, 0, -p0.y);
  gantry.rotation.y = ang;
  group.add(gantry);

  // ---------------- Infield decor: logo + cones ----------------
  const logo = new THREE.Mesh(
    new THREE.PlaneGeometry(8, 2),
    new THREE.MeshStandardMaterial({
      map: theme === 'prodrift'
        ? makeTextTexture('PRODRIFT', { w: 1024, h: 256, fg: 'rgba(255,255,255,0.9)', sub: 'SIRKUIT PINUS', subColor: 'rgba(255,204,0,0.9)' })
        : makeTextTexture('Mt. HARUNA', { w: 1024, h: 256, fg: 'rgba(255,255,255,0.9)', sub: 'TOUGE DOWNHILL', subColor: 'rgba(255,204,0,0.9)' }),
      transparent: true,
      depthWrite: false,
      roughness: 0.6,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    }),
  );
  logo.rotation.x = -Math.PI / 2;
  logo.position.set(0, 0.004, 1.2);
  group.add(logo);

  const coneGeo = new THREE.ConeGeometry(0.045, 0.11, 16);
  const coneMat = new THREE.MeshStandardMaterial({ color: 0xff5a0a, roughness: 0.5 });
  const coneBase = new THREE.BoxGeometry(0.08, 0.008, 0.08);
  const stripeMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
  const stripeGeo = new THREE.CylinderGeometry(0.026, 0.032, 0.018, 16);
  for (let k = 0; k < N; k += 6) {
    const c = curv[k];
    if (Math.abs(c) < 0.12) continue;
    const p = track.pts[k];
    const off = Math.sign(c) * (hw + 0.28);
    const x = p.x + p.nx * off;
    const y = p.y + p.ny * off;
    const cone = new THREE.Group();
    const cm = new THREE.Mesh(coneGeo, coneMat);
    cm.position.y = 0.063;
    cm.castShadow = true;
    cone.add(cm);
    const cb = new THREE.Mesh(coneBase, coneMat);
    cb.position.y = 0.004;
    cone.add(cb);
    const st = new THREE.Mesh(stripeGeo, stripeMat);
    st.position.y = 0.06;
    cone.add(st);
    cone.position.set(x, 0, -y);
    group.add(cone);
  }

  // ---------------- Building ----------------
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x252931, roughness: 0.9 });
  const bandMat = new THREE.MeshStandardMaterial({ color: theme === 'prodrift' ? 0xb3121b : 0x14532d, roughness: 0.7 });
  const BW = 76;
  const BD = 54;
  const BH = 10;
  const walls: [number, number, number, number][] = [
    [0, -BD / 2 + 2, 0, BW],
    [0, BD / 2 + 2, Math.PI, BW],
    [-BW / 2, 2, Math.PI / 2, BD],
    [BW / 2, 2, -Math.PI / 2, BD],
  ];
  for (const [x, z, ry, len] of walls) {
    const w = new THREE.Mesh(new THREE.PlaneGeometry(len, BH), wallMat);
    w.position.set(x, BH / 2, z);
    w.rotation.y = ry;
    group.add(w);
    const band = new THREE.Mesh(new THREE.PlaneGeometry(len, 1.2), bandMat);
    band.position.set(x, 0.6, z);
    band.rotation.y = ry;
    band.translateZ(0.02);
    group.add(band);
  }
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(BW, BD), new THREE.MeshStandardMaterial({ color: 0x14161b, roughness: 1 }));
  ceil.rotation.x = Math.PI / 2;
  ceil.position.set(0, BH, 2);
  group.add(ceil);
  const lampGeo = new THREE.BoxGeometry(4, 0.12, 0.7);
  const lampMat = new THREE.MeshBasicMaterial({ color: 0xfff8ec });
  const lamps = new THREE.InstancedMesh(lampGeo, lampMat, 24);
  let li = 0;
  const mtx = new THREE.Matrix4();
  for (let lx = 0; lx < 6; lx++)
    for (let lz = 0; lz < 4; lz++) {
      mtx.setPosition(-27 + lx * 10.8, BH - 0.1, -12 + lz * 8.5);
      lamps.setMatrixAt(li++, mtx);
    }
  group.add(lamps);

  // banners
  const banners = theme === 'prodrift'
    ? [
        makeBannerTexture('PRODRIFT', 'OFFICIAL DRIFT CHAMPIONSHIP', '#b3121b', '#ffcc00'),
        makeBannerTexture('SIRKUIT PINUS', 'PINE CIRCUIT • 2.94 KM', '#13151c', '#ffd23f'),
        makeBannerTexture('RMX 2.5', 'RWD DRIFT • RTR', '#13151c', '#ff2b2b'),
        makeBannerTexture('MGX GYRO', 'STABILITAS SAAT SUDUT LEBAR', '#0f2a6b', '#4fc3ff'),
        makeBannerTexture('FULL PROPO', 'KONTROL HALUS & PRESISI', '#1b1b1b', '#7cff3a'),
        makeBannerTexture('DRIFT ARENA', 'P-TILE INDOOR TRACK', '#2a0f3a', '#ff2fa8'),
      ]
    : [
        makeBannerTexture('Mt. HARUNA', 'TOUGE DOWNHILL', '#0d3b1e', '#ffd23f'),
        makeBannerTexture('AKINA', 'TOUGE SECTION', '#8f1d1d', '#ffffff'),
        makeBannerTexture('HAIRPIN', 'REM SEBELUM BELOK', '#111111', '#ffd23f'),
        makeBannerTexture('TOUGE', 'BRAKE • ROTATE • PIN', '#101c2c', '#7cff3a'),
        makeBannerTexture('Mt. HARUNA', '297 m DI ATAS LAUT', '#1d4fd8', '#ffffff'),
        makeBannerTexture('PRODRIFT', 'OFFICIAL TOUGE PARTNER', '#2a0f3a', '#ff2fa8'),
      ];
  const bannerSpots: [number, number, number][] = [
    [-18, -BD / 2 + 2.05, 0],
    [0, -BD / 2 + 2.05, 0],
    [18, -BD / 2 + 2.05, 0],
    [-BW / 2 + 0.05, -4, Math.PI / 2],
    [BW / 2 - 0.05, -4, -Math.PI / 2],
    [-BW / 2 + 0.05, 12, Math.PI / 2],
  ];
  bannerSpots.forEach(([x, z, ry], k) => {
    const b = new THREE.Mesh(new THREE.PlaneGeometry(12, 3), new THREE.MeshBasicMaterial({ map: banners[k % banners.length] }));
    b.position.set(x, 3.6, z);
    b.rotation.y = ry;
    group.add(b);
  });

  // driver stand (2D y = -12.6 -> world z = +12.6)
  const standZ = 12.8;
  const standMat = new THREE.MeshStandardMaterial({ color: 0x30343c, roughness: 0.7, metalness: 0.2 });
  const stand = new THREE.Mesh(new THREE.BoxGeometry(9, 1.7, 2.2), standMat);
  stand.position.set(0, 0.85, standZ);
  stand.castShadow = true;
  stand.receiveShadow = true;
  group.add(stand);
  const deckTop = new THREE.Mesh(new THREE.BoxGeometry(9.1, 0.06, 2.3), new THREE.MeshStandardMaterial({ color: 0x8a6a3d, roughness: 0.8 }));
  deckTop.position.set(0, 1.73, standZ);
  group.add(deckTop);
  const railMat = new THREE.MeshStandardMaterial({ color: 0xffc400, metalness: 0.5, roughness: 0.4 });
  const rail = new THREE.Mesh(new THREE.BoxGeometry(9, 0.05, 0.05), railMat);
  rail.position.set(0, 2.75, standZ - 1.05);
  group.add(rail);
  for (let k = -4; k <= 4; k += 1) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.05, 1, 0.05), railMat);
    post.position.set(k, 2.25, standZ - 1.05);
    group.add(post);
  }
  for (let k = 0; k < 6; k++) {
    const step = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.28, 0.35), standMat);
    step.position.set(5.2, 0.14 + k * 0.28, standZ + 1.0 - k * 0.35);
    step.receiveShadow = true;
    group.add(step);
  }
  const standSign = new THREE.Mesh(
    new THREE.PlaneGeometry(4, 0.6),
    new THREE.MeshBasicMaterial({ map: makeTextTexture('DRIVER STAND', { w: 1024, h: 160, bg: '#b3121b', fg: '#fff' }) }),
  );
  standSign.position.set(0, 1.0, standZ - 1.11);
  standSign.rotation.y = Math.PI;
  group.add(standSign);
  standSign.rotation.y = 0;
  standSign.position.z = standZ - 1.111;
  standSign.scale.x = 1;
  standSign.lookAt(0, 1.0, 0);

  // pit tables along back wall
  const tableMat = new THREE.MeshStandardMaterial({ color: 0xd8d8d8, roughness: 0.6 });
  const caseMats = [0xb3121b, 0x1d56ff, 0x222222, 0xffc400].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 }));
  for (let k = 0; k < 8; k++) {
    const t = new THREE.Mesh(new THREE.BoxGeometry(3, 0.08, 1), tableMat);
    t.position.set(-24 + k * 6.8, 0.8, -BD / 2 + 3.4);
    t.castShadow = true;
    group.add(t);
    for (const lx of [-1.4, 1.4]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.8, 0.9), tableMat);
      leg.position.set(t.position.x + lx, 0.4, t.position.z);
      group.add(leg);
    }
    const cs = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.3, 0.4), caseMats[k % 4]);
    cs.position.set(t.position.x - 0.6, 0.99, t.position.z);
    group.add(cs);
    const cs2 = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.12, 0.25), caseMats[(k + 1) % 4]);
    cs2.position.set(t.position.x + 0.7, 0.9, t.position.z + 0.1);
    group.add(cs2);
  }

  return { group, setSurface, driverStand: new THREE.Vector3(0.5, 3.15, standZ - 1.25) };
}
