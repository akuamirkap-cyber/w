import * as THREE from 'three';

function canvas(w: number, h: number) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  return { c, ctx };
}

function toTexture(c: HTMLCanvasElement, repeat = true, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (repeat) {
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.RepeatWrapping;
  }
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

function rand(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function noise(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number, seed = 1) {
  const r = rand(seed);
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (r() - 0.5) * amount;
    d[i] += n;
    d[i + 1] += n;
    d[i + 2] += n;
  }
  ctx.putImageData(img, 0, 0);
}

/** Track surface textures. One texture repeat = 4x4 tiles (P-tile 30cm). */
export function makeSurfaceTexture(kind: 'ptile' | 'concrete' | 'carpet') {
  const S = 1024;
  const { c, ctx } = canvas(S, S);
  const r = rand(kind.length * 977);
  if (kind === 'ptile') {
    const n = 4;
    const ts = S / n;
    for (let y = 0; y < n; y++)
      for (let x = 0; x < n; x++) {
        const v = 128 + Math.floor((r() - 0.5) * 14) + ((x + y) % 2 ? 6 : -4);
        ctx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
        ctx.fillRect(x * ts, y * ts, ts, ts);
        // subtle speckles typical of vinyl tiles
        for (let k = 0; k < 260; k++) {
          const g = v + (r() - 0.5) * 50;
          ctx.fillStyle = `rgba(${g},${g},${g + 4},0.35)`;
          ctx.fillRect(x * ts + r() * ts, y * ts + r() * ts, 2 + r() * 3, 2 + r() * 3);
        }
      }
    noise(ctx, S, S, 10, 3);
    ctx.strokeStyle = 'rgba(55,58,64,0.85)';
    ctx.lineWidth = 3;
    for (let i = 0; i <= n; i++) {
      ctx.beginPath();
      ctx.moveTo(i * ts, 0);
      ctx.lineTo(i * ts, S);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * ts);
      ctx.lineTo(S, i * ts);
      ctx.stroke();
    }
  } else if (kind === 'concrete') {
    ctx.fillStyle = '#9a9a96';
    ctx.fillRect(0, 0, S, S);
    for (let k = 0; k < 900; k++) {
      const g = 150 + (r() - 0.5) * 40;
      ctx.fillStyle = `rgba(${g},${g},${g - 4},0.08)`;
      const rr = 10 + r() * 60;
      ctx.beginPath();
      ctx.arc(r() * S, r() * S, rr, 0, Math.PI * 2);
      ctx.fill();
    }
    noise(ctx, S, S, 16, 5);
    ctx.strokeStyle = 'rgba(60,60,60,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, S / 2);
    ctx.lineTo(S, S / 2);
    ctx.moveTo(S / 2, 0);
    ctx.lineTo(S / 2, S);
    ctx.stroke();
  } else {
    ctx.fillStyle = '#2b3442';
    ctx.fillRect(0, 0, S, S);
    noise(ctx, S, S, 34, 9);
    for (let k = 0; k < 4000; k++) {
      ctx.fillStyle = `rgba(${90 + r() * 40},${100 + r() * 40},${130 + r() * 40},0.12)`;
      ctx.fillRect(r() * S, r() * S, 1 + r() * 2, 1 + r() * 2);
    }
  }
  // faint rubber "racing line" smudges
  for (let k = 0; k < 40; k++) {
    ctx.strokeStyle = `rgba(20,20,22,${0.025 + r() * 0.035})`;
    ctx.lineWidth = 6 + r() * 14;
    ctx.beginPath();
    const x0 = r() * S;
    const y0 = r() * S;
    ctx.moveTo(x0, y0);
    ctx.quadraticCurveTo(x0 + (r() - 0.5) * 400, y0 + (r() - 0.5) * 400, x0 + (r() - 0.5) * 600, y0 + (r() - 0.5) * 600);
    ctx.stroke();
  }
  return toTexture(c);
}

export function makeFloorTexture() {
  const S = 1024;
  const { c, ctx } = canvas(S, S);
  ctx.fillStyle = '#4a4c50';
  ctx.fillRect(0, 0, S, S);
  const r = rand(42);
  for (let k = 0; k < 600; k++) {
    const g = 70 + (r() - 0.5) * 30;
    ctx.fillStyle = `rgba(${g},${g},${g + 3},0.1)`;
    ctx.beginPath();
    ctx.arc(r() * S, r() * S, 8 + r() * 70, 0, Math.PI * 2);
    ctx.fill();
  }
  noise(ctx, S, S, 18, 7);
  ctx.strokeStyle = 'rgba(25,25,28,0.6)';
  ctx.lineWidth = 3;
  ctx.strokeRect(0, 0, S, S);
  return toTexture(c);
}

export function makeInfieldTexture() {
  const S = 512;
  const { c, ctx } = canvas(S, S);
  ctx.fillStyle = '#1f2a24';
  ctx.fillRect(0, 0, S, S);
  noise(ctx, S, S, 30, 11);
  return toTexture(c);
}

export function makeCarbonTexture() {
  const S = 256;
  const { c, ctx } = canvas(S, S);
  const n = 16;
  const ts = S / n;
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) {
      const horiz = (x + y) % 4 < 2;
      const g = ctx.createLinearGradient(x * ts, y * ts, horiz ? x * ts + ts : x * ts, horiz ? y * ts : y * ts + ts);
      g.addColorStop(0, '#1a1a1c');
      g.addColorStop(0.5, horiz ? '#3a3b40' : '#2a2b2f');
      g.addColorStop(1, '#141416');
      ctx.fillStyle = g;
      ctx.fillRect(x * ts, y * ts, ts, ts);
    }
  return toTexture(c);
}

export function makeStripeTexture(c1: string, c2: string, vertical = false) {
  const { c, ctx } = canvas(64, 64);
  ctx.fillStyle = c1;
  ctx.fillRect(0, 0, 64, 64);
  ctx.fillStyle = c2;
  if (vertical) ctx.fillRect(0, 0, 64, 32);
  else ctx.fillRect(0, 0, 32, 64);
  return toTexture(c);
}

export function makeCheckerTexture(n = 8) {
  const { c, ctx } = canvas(256, 64);
  const s = 256 / (n * 2);
  for (let y = 0; y < 64 / s; y++)
    for (let x = 0; x < n * 2; x++) {
      ctx.fillStyle = (x + y) % 2 ? '#111' : '#f4f4f4';
      ctx.fillRect(x * s, y * s, s, s);
    }
  return toTexture(c, false);
}

export interface TextOpts {
  w?: number;
  h?: number;
  bg?: string;
  fg?: string;
  font?: string;
  sub?: string;
  subColor?: string;
  stripe?: string;
  align?: CanvasTextAlign;
}

export function makeTextTexture(text: string, o: TextOpts = {}) {
  const w = o.w ?? 512;
  const h = o.h ?? 128;
  const { c, ctx } = canvas(w, h);
  if (o.bg) {
    ctx.fillStyle = o.bg;
    ctx.fillRect(0, 0, w, h);
  }
  if (o.stripe) {
    ctx.fillStyle = o.stripe;
    ctx.fillRect(0, h * 0.82, w, h * 0.08);
  }
  ctx.fillStyle = o.fg ?? '#fff';
  ctx.textAlign = o.align ?? 'center';
  ctx.textBaseline = 'middle';
  ctx.font = o.font ?? `italic 900 ${Math.floor(h * 0.55)}px "Arial Black", Impact, sans-serif`;
  const x = o.align === 'left' ? h * 0.15 : w / 2;
  ctx.fillText(text, x, o.sub ? h * 0.4 : h * 0.5);
  if (o.sub) {
    ctx.fillStyle = o.subColor ?? '#ffcc00';
    ctx.font = `700 ${Math.floor(h * 0.2)}px Arial, sans-serif`;
    ctx.fillText(o.sub, x, h * 0.78);
  }
  const t = toTexture(c, false);
  return t;
}

export function makeBlobTexture() {
  const { c, ctx } = canvas(128, 128);
  const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 64);
  g.addColorStop(0, 'rgba(0,0,0,0.85)');
  g.addColorStop(0.55, 'rgba(0,0,0,0.45)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 128, 128);
  return toTexture(c, false, false);
}

export function makeSoftDotTexture() {
  const { c, ctx } = canvas(64, 64);
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.4, 'rgba(255,255,255,0.55)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  return toTexture(c, false, false);
}

/** Simple label (battery / motor / electronics stickers). */
export function makeLabelTexture(lines: string[], bg: string, fg: string, w = 256, h = 128) {
  const { c, ctx } = canvas(w, h);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = fg;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  lines.forEach((l, i) => {
    const size = i === 0 ? h * 0.32 : h * 0.17;
    ctx.font = `${i === 0 ? 'italic 900' : '700'} ${Math.floor(size)}px Arial, sans-serif`;
    ctx.fillText(l, w / 2, h * (lines.length === 1 ? 0.5 : 0.32 + i * 0.3));
  });
  return toTexture(c, false);
}

/** Wide sponsor banner for arena walls. */
export function makeBannerTexture(title: string, sub: string, bg: string, accent: string) {
  const w = 1024;
  const h = 256;
  const { c, ctx } = canvas(w, h);
  const g = ctx.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, bg);
  g.addColorStop(1, '#0b0b10');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = accent;
  ctx.beginPath();
  ctx.moveTo(0, h);
  ctx.lineTo(w * 0.18, 0);
  ctx.lineTo(w * 0.24, 0);
  ctx.lineTo(w * 0.06, h);
  ctx.fill();
  ctx.fillStyle = '#fff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `italic 900 ${h * 0.42}px "Arial Black", Impact, sans-serif`;
  ctx.fillText(title, w * 0.58, h * 0.42);
  ctx.fillStyle = accent;
  ctx.font = `700 ${h * 0.15}px Arial, sans-serif`;
  ctx.fillText(sub, w * 0.58, h * 0.78);
  return toTexture(c, false);
}
