// ============================================================
//  MST RMX 2.5 – 1/10 RC drift car physics
//  Planar 4-wheel model (x/y plane, yaw) + load transfer,
//  combined-slip tire model, brushless motor/ESC, gyro & servo.
//  2D frame: x right, y up (seen from above), yaw CCW positive.
//  Local car frame: x forward, y left.
// ============================================================
import type { Settings } from './settings';

export const GRAV = 9.81;
const DEG = Math.PI / 180;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const SURFACE_MU: Record<string, number> = { ptile: 0.62, concrete: 0.54, carpet: 0.78 };
export const TIRE_MU: Record<string, number> = { hard: 0.86, standard: 1.0, soft: 1.14 };

const VMIN = 0.5; // low-speed slip denominator (m/s)
const K_PEAK = 0.14; // slip ratio at peak force
const A_PEAK = Math.tan(9 * DEG); // slip angle at peak force
const GYRO_K = 0.9; // yaw-rate loop gain (assisted mode)
const GYRO_K_CLASSIC = 0.5; // pure rate gyro: rad per rad/s at 100% gain
const CDA = 0.012; // aero drag area
const KPI = 6; // kingpin inclination (deg) – RMX 2.5 steering upright

export interface DriveInput {
  steer: number; // -1..1, + = left
  throttle: number; // 0..1 (after EPA)
  brake: number; // 0..1
  handbrake: boolean;
  /** Drift button (Rally Lab SPACE): the rear lets go WITHOUT braking. Optional — RC mode never sets it. */
  drift?: boolean;
}

export interface WheelState {
  x: number; // local position (forward)
  y: number; // local position (left)
  steer: number; // rad (includes toe/ackermann)
  load: number; // N
  vLong: number;
  vLat: number;
  fx: number;
  fy: number;
  omega: number; // rad/s
  spin: number; // accumulated angle
  slide: number; // 0..1
  slipVel: number; // m/s
  camber: number; // effective camber deg
  compression: number; // visual suspension compression (m)
}

function tireShape(s: number, falloff: number) {
  if (s <= 1) return s * (2 - s);
  return 1 - falloff * (1 - Math.exp(-(s - 1) * 1.15));
}

export class CarPhysics {
  readonly mass = 1.75;
  readonly Iz = 0.018;
  readonly R = 0.0325;
  readonly tF = 0.174;
  readonly tR = 0.168;
  readonly frontWeight = 0.46; // "Gravity frame" rear-biased balance
  readonly Irear = 4.0e-4; // rear axle + reflected drivetrain inertia
  readonly Ifront = 1.4e-4;
  readonly Tstall = 1.1; // N·m at rear axle (2500Kv brushless, 2S)
  readonly omegaMax = 10 / 0.0325; // free wheel speed at 100% (≈36 km/h)

  rearGrip = 0.92; // rear/front tyre grip balance (drift-oriented setup)
  wheelGrip = [1, 1, 1, 1]; // per-wheel surface grip multiplier (kerb / gravel / touge asphalt)
  driveGain = 1; // motor torque multiplier (1 = stock RMX 2.5, >1 for touge uphill/downhill punch)
  L = 0.257;
  a = 0.139; // CG -> front axle
  b = 0.118; // CG -> rear axle
  h = 0.032; // CG height

  // --- state ---
  x = 0;
  y = 0;
  heading = 0;
  vx = 0;
  vy = 0;
  r = 0;
  omegaR = 0;
  servo = 0;
  gyroRate = 0; // filtered yaw-rate sensor
  tcCut = 0; // traction control throttle reduction (telemetry)
  // drift button tuning (Space initiates slide: drops rear sideways grip 50-70%, preserves forward drive, gentle yaw impulse, 0.2-0.4s lerp recovery)
  driftGripDrop = 0.62; // 62% rear sideways grip drop while Space is held
  driftFwdGripKeep = 0.12; // forward acceleration grip stays ~88-100% intact mid-corner
  driftYawImpulse = 0.72; // gentle yaw impulse (rad/s) on Space press when steering A/D
  driftAmt = 0; // 0..1 linear ramp/recovery state
  private driftPrev = false;
  axF = 0;
  ayF = 0;
  roll = 0;
  rollV = 0;
  pitch = 0;
  pitchV = 0;

  // --- telemetry ---
  u = 0;
  v = 0;
  speed = 0;
  beta = 0;
  gyroCorr = 0;
  userSteer = 0;
  reversing = false;
  braking = false;
  motorThr = 0;
  rearSlide = 0;
  frontSlide = 0;
  wheels: WheelState[] = [];

  constructor() {
    for (let i = 0; i < 4; i++) {
      this.wheels.push({
        x: 0,
        y: 0,
        steer: 0,
        load: 0,
        vLong: 0,
        vLat: 0,
        fx: 0,
        fy: 0,
        omega: 0,
        spin: 0,
        slide: 0,
        slipVel: 0,
        camber: 0,
        compression: 0,
      });
    }
  }

  setPose(x: number, y: number, heading: number) {
    this.x = x;
    this.y = y;
    this.heading = heading;
    this.vx = this.vy = this.r = 0;
    this.omegaR = 0;
    this.servo = 0;
    this.gyroRate = 0;
    this.driftAmt = 0;
    this.driftPrev = false;
    this.axF = this.ayF = 0;
    this.roll = this.rollV = this.pitch = this.pitchV = 0;
    this.reversing = false;
  }

  private updateGeometry(s: Settings) {
    this.L = s.wheelbase / 1000;
    this.b = this.L * this.frontWeight;
    this.a = this.L - this.b;
    this.h = 0.026 + s.rideHeight * 0.001 + (s.motorPos === 'high' ? 0.004 : 0);
    const w = this.wheels;
    w[0].x = this.a;
    w[0].y = this.tF / 2;
    w[1].x = this.a;
    w[1].y = -this.tF / 2;
    w[2].x = -this.b;
    w[2].y = this.tR / 2;
    w[3].x = -this.b;
    w[3].y = -this.tR / 2;
  }

  step(dt: number, inp: DriveInput, s: Settings) {
    this.updateGeometry(s);
    const m = this.mass;
    const R = this.R;
    const cosH = Math.cos(this.heading);
    const sinH = Math.sin(this.heading);
    const u = this.vx * cosH + this.vy * sinH;
    const v = -this.vx * sinH + this.vy * cosH;
    const r = this.r;
    const awd = s.drivetrain === 'AWD';
    const k = awd ? s.awdRatio : 0;

    // ---------------- ESC logic (forward / brake / reverse) ----------------
    let thr = inp.throttle;
    let brake = 0;
    if (inp.brake > 0.01) {
      if (u > 0.35 && !this.reversing) {
        brake = inp.brake;
        thr = 0;
      } else if (u < 0.6) {
        this.reversing = true;
        thr = -inp.brake * 0.5;
      }
    } else if (this.reversing && thr > 0.01) {
      this.reversing = false;
    }
    if (inp.brake <= 0.01 && thr <= 0.01) this.reversing = false;
    // ---- Kontrol Traksi / Anti-Spin (comfort assist, 0 = off) ----
    // 1) rear-wheel slip limiter that opens up with speed (controllable wheelspin at low speed)
    // 2) stability control: ease off the throttle only when the car is about to spin
    //    (yaw rate above the gyro target, or drift angle beyond ~50°). Normal drifting is untouched.
    const tc = (s.tractionControl ?? 0) / 100;
    const avgGrip = clamp(0.25 * (this.wheelGrip[0] + this.wheelGrip[1] + this.wheelGrip[2] + this.wheelGrip[3]), 0.4, 2.0);
    const muTc = (SURFACE_MU[s.surface] ?? 0.62) * (TIRE_MU[s.tire] ?? 1) * avgGrip;
    const rLimTc = Math.min((s.yawLimit ?? 195) * DEG, (muTc * GRAV * 1.25) / Math.max(Math.abs(u), 0.6));
    const spd0 = Math.hypot(u, v);
    const bAbs = spd0 > 0.5 ? Math.abs(Math.atan2(v, Math.max(Math.abs(u), 0.05))) : 0;
    this.tcCut = 0;
    if (tc > 0 && thr > 0.01 && !this.reversing) {
      const recovering = !inp.drift && Math.abs(inp.steer) < 0.45 && bAbs > 8 * DEG;
      const slipAllow = (7.5 - 4.8 * tc) * (recovering ? 0.34 : 1);
      const thrSlip = Math.min(thr, (Math.max(0, u) + slipAllow) / (this.omegaMax * this.R));
      const betaStart = inp.drift ? 42 * DEG : 34 * DEG;
      const yawEx = Math.max(0, Math.abs(this.gyroRate) / rLimTc - 1.05);
      const betaEx = Math.max(0, (bAbs - betaStart) / (22 * DEG));
      const cut = clamp(tc * (yawEx * 2.4 + betaEx * 1.65), 0, 0.92);
      this.tcCut = Math.max(cut, 1 - thrSlip / thr);
      thr = thrSlip * (1 - cut);
    }
    // ---- Batas Kecepatan (speed limiter, 0 = off): caps straight-line speed, keeps drift power below it ----
    const vLim = (s.speedLimit ?? 0) / 3.6;
    if (vLim > 0 && thr > 0.01 && !this.reversing) {
      const spdL = Math.hypot(u, v);
      if (spdL > vLim) thr *= Math.max(0, 1 - (spdL - vLim) / 0.8);
    }
    this.braking = brake > 0.01;
    this.motorThr = thr;

    // ---------------- Drift button: sideways grip drop + yaw impulse + 0.2-0.4s lerp recovery ----------------
    const dBtn = !!inp.drift;
    if (dBtn && !this.driftPrev) {
      if (u > 0.8 && Math.abs(inp.steer) > 0.08) {
        this.r += Math.sign(inp.steer) * this.driftYawImpulse;
      }
      if (u > 0.8) this.omegaR = Math.max(this.omegaR, (u + 1.5) / R);
    }
    if (dBtn) {
      this.driftAmt = Math.min(1, this.driftAmt + dt / 0.045);
    } else {
      const sharpSteer = Math.abs(inp.steer) > 0.55;
      const recTime = !sharpSteer && thr > 0.05 ? 0.24 : 0.34;
      this.driftAmt = Math.max(0, this.driftAmt - dt / recTime);
    }
    this.driftPrev = dBtn;
    const rearSideFactor = 1 - this.driftGripDrop * this.driftAmt * (1 - 0.32 * Math.min(1, this.rearSlide));
    const rearFwdFactor = 1 - this.driftFwdGripKeep * this.driftAmt;

    // ---------------- Steering: user + gyro -> servo ----------------
    // MGX gyro = yaw-rate feedback + light auto counter-steer (25-45 deg window for tap-tap WASD)
    const maxSteer = s.steerAngle * DEG;
    const user = inp.steer * maxSteer;
    this.gyroRate += (r - this.gyroRate) * (1 - Math.exp(-dt / 0.012));
    const muNow = (SURFACE_MU[s.surface] ?? 0.62) * (TIRE_MU[s.tire] ?? 1) * avgGrip;
    const antiSpin = tc > 0 && u > 0.8 ? tc * clamp((bAbs - (inp.drift ? 27 : 22) * DEG) / (20 * DEG), 0, 1) : 0;
    let cmd = user;
    const fwdDir = u >= -0.2 ? 1 : -1;
    if (s.gyroOn) {
      const G = s.gyroGain / 100;
      if (s.steerAssist) {
        const V = Math.max(Math.abs(u), 0.6);
        const rLim = Math.min((s.yawLimit ?? 195) * DEG, (muNow * GRAV * 1.25) / V);
        const rCmd = inp.steer * rLim * fwdDir * (1 - 0.65 * antiSpin);
        const dKin = Math.atan((this.L * rCmd) / V) * fwdDir;
        const ff = (1 - G) * user * (1 - 0.78 * antiSpin) + G * dKin;
        const fb = G * GYRO_K * (rCmd - this.gyroRate) * fwdDir;
        cmd = ff + fb;
        // Light auto counter-steer in 25-45 deg sweet spot when W is held so tap-tap A/D feels effortless
        if (tc > 0 && u > 0.8 && thr > 0.1 && bAbs > 18 * DEG) {
          const betaSigned = Math.atan2(v, Math.max(u, 0.1));
          const holdAssist = tc * clamp((bAbs - 18 * DEG) / (16 * DEG), 0, 1) * (Math.abs(inp.steer) < 0.2 ? 0.85 : 0.45);
          const sweetCounter = clamp(-betaSigned * 0.92, -maxSteer, maxSteer);
          cmd = lerp(cmd, sweetCounter, holdAssist * 0.55);
        }
      } else {
        // classic pure rate-mode gyro
        cmd = user - G * GYRO_K_CLASSIC * this.gyroRate * fwdDir;
      }
    }
    if (s.steerAssist && u > 0.8) {
      // keep the front tyres near their peak slip angle (keys are on/off)
      const thetaF = Math.atan2(v + r * this.a, u);
      const G = s.gyroOn ? s.gyroGain / 100 : 0;
      const off = Math.atan(A_PEAK) * (1.5 + 3 * (1 - G)) * (1 - 0.45 * antiSpin);
      cmd = clamp(cmd, thetaF - off, thetaF + off);
    }
    cmd = clamp(cmd, -maxSteer, maxSteer);
    const rate = (60 * DEG) / s.servoSpeed;
    this.servo += clamp(cmd - this.servo, -rate * dt, rate * dt);
    this.userSteer = user;
    this.gyroCorr = cmd - user;

    // per-wheel steering with Ackermann & toe
    const d = this.servo;
    let dFL = d;
    let dFR = d;
    const ad = Math.abs(d);
    if (ad > 1e-4) {
      const ack = s.ackermann / 100;
      const Rt = this.L / Math.tan(ad);
      const inner = Math.min(Math.atan2(this.L, Rt - this.tF / 2), 80 * DEG);
      const outer = Math.atan2(this.L, Rt + this.tF / 2);
      const dIn = ad + (inner - ad) * ack;
      const dOut = ad + (outer - ad) * ack;
      if (d > 0) {
        dFL = dIn;
        dFR = dOut;
      } else {
        dFL = -dOut;
        dFR = -dIn;
      }
    }
    const W = this.wheels;
    W[0].steer = dFL + s.toeF * DEG;
    W[1].steer = dFR - s.toeF * DEG;
    W[2].steer = -s.toeR * DEG;
    W[3].steer = s.toeR * DEG;

    // ---------------- Loads (with filtered load transfer) ----------------
    const L = this.L;
    const Nf0 = (m * GRAV * this.b) / L;
    const Nr0 = (m * GRAV * this.a) / L;
    const dLong = (m * this.axF * this.h) / L;
    const Nf = Nf0 - dLong;
    const Nr = Nr0 + dLong;
    const tAvg = (this.tF + this.tR) / 2;
    const dLat = (m * this.ayF * this.h) / tAvg;
    const kF = 0.6 + s.springF;
    const kR = 0.6 + s.springR;
    const lam = kF / (kF + kR);
    const dF = dLat * lam;
    const dR = dLat * (1 - lam);
    const Nmin = 0.03 * m * GRAV * 0.25;
    W[0].load = Math.max(Nmin, Nf / 2 - dF);
    W[1].load = Math.max(Nmin, Nf / 2 + dF);
    W[2].load = Math.max(Nmin, Nr / 2 - dR);
    W[3].load = Math.max(Nmin, Nr / 2 + dR);
    const N0 = (m * GRAV) / 4;

    // ---------------- Camber (static + roll + caster/KPI) ----------------
    const softness = 1 / (0.45 + 0.11 * (s.springF + s.springR) * 0.5);
    const rollDegSigned = clamp(this.ayF / GRAV, -1.6, 1.6) * 3.2 * softness * (this.h / 0.032);
    for (let i = 0; i < 4; i++) {
      const w = W[i];
      const side = w.y > 0 ? 1 : -1; // +1 left wheel
      let c = i < 2 ? s.camberF : s.camberR;
      c += -side * 0.5 * rollDegSigned; // roll-induced camber
      if (i < 2) {
        const sd = Math.sin(w.steer);
        c += side * s.caster * sd + KPI * 0.8 * (1 - Math.cos(w.steer));
      }
      w.camber = c;
    }

    // ---------------- Tire forces ----------------
    const muBase = (SURFACE_MU[s.surface] ?? 0.62) * (TIRE_MU[s.tire] ?? 1);
    const longMultR = 1 - 0.03 * Math.abs(s.camberR);
    let sumFx = 0;
    let sumFy = 0;
    let Mz = 0;
    let reactR = 0;
    let reactF = 0;
    let rs = 0;
    let fs = 0;
    for (let i = 0; i < 4; i++) {
      const w = W[i];
      const front = i < 2;
      const cvx = u - r * w.y;
      const cvy = v + r * w.x;
      const cs = Math.cos(w.steer);
      const sn = Math.sin(w.steer);
      const vl = cvx * cs + cvy * sn;
      const vt = -cvx * sn + cvy * cs;
      const denom = Math.max(Math.abs(vl), VMIN);
      const driven = !front || awd;
      const om = front ? this.omegaR * k : this.omegaR;
      const kappa = driven ? (om * R - vl) / denom : 0;
      const tanA = vt / denom;
      const sx = kappa / K_PEAK;
      const sy = tanA / A_PEAK;
      const sMag = Math.hypot(sx, sy);
      const opt = front ? -4 : -2;
      const dc = w.camber - opt;
      const camberGrip = clamp(1 - 0.006 * dc * dc, 0.7, 1.03);
      const loadSens = clamp(1 - 0.16 * (w.load / N0 - 1), 0.7, 1.2);
      const muLat = muBase * camberGrip * loadSens * (front ? 1.04 : this.rearGrip * rearSideFactor) * this.wheelGrip[i];
      const muLong = muBase * camberGrip * loadSens * (front ? 1.04 : this.rearGrip * rearFwdFactor) * this.wheelGrip[i];
      let fx = 0;
      let fy = 0;
      if (sMag > 1e-6) {
        const shape = tireShape(sMag, front ? 0.1 : 0.15);
        fx = ((muLong * w.load * shape * sx) / sMag) * (front ? 1 : longMultR);
        fy = (-muLat * w.load * shape * sy) / sMag;
      }
      const Fx = fx * cs - fy * sn;
      const Fy = fx * sn + fy * cs;
      sumFx += Fx;
      sumFy += Fy;
      Mz += w.x * Fy - w.y * Fx;
      if (front) reactF += fx * R;
      else reactR += fx * R;

      w.vLong = vl;
      w.vLat = vt;
      w.fx = fx;
      w.fy = fy;
      w.omega = driven ? om : vl / R;
      w.spin += w.omega * dt;
      const slipLong = driven ? om * R - vl : 0;
      w.slipVel = Math.hypot(slipLong, vt);
      w.slide = clamp((w.slipVel - 0.35) / 2.2, 0, 1);
      if (front) fs += w.slide * 0.5;
      else rs += w.slide * 0.5;
    }
    this.rearSlide = rs;
    this.frontSlide = fs;

    // ---------------- Motor / drivetrain ----------------
    const Ieff = this.Irear + (awd ? k * k * this.Ifront : 0);
    const om = this.omegaR;
    let Tm: number;
    if (Math.abs(thr) > 0.01) {
      const e = thr - om / this.omegaMax;
      Tm = this.Tstall * this.driveGain * (awd ? 1.45 : 1) * (thr > 0 ? clamp(e, -0.03, 1) : clamp(e, -1, 0.03));
    } else {
      Tm = -Math.sign(om) * (0.004 + (s.dragBrake / 100) * 0.16) * Math.min(1, Math.abs(om) / 15);
    }
    const Tload = reactR + k * reactF;
    let newOm = om + ((Tm - Tload - 2e-5 * om) / Ieff) * dt;
    const Tb = brake * 0.24 + (inp.handbrake ? 0.9 : 0);
    if (Tb > 0) {
      const maxDelta = (Tb / Ieff) * dt;
      if (Math.abs(newOm) <= maxDelta) newOm = 0;
      else newOm -= Math.sign(newOm) * maxDelta;
    }
    this.omegaR = newOm;

    // ---------------- Body integration ----------------
    const spd = Math.hypot(this.vx, this.vy);
    const drag = 0.5 * 1.2 * CDA * spd;
    let Fwx = sumFx * cosH - sumFy * sinH - drag * this.vx;
    let Fwy = sumFx * sinH + sumFy * cosH - drag * this.vy;
    const rr = 0.012 * m * GRAV * Math.tanh(u / 0.15);
    Fwx -= rr * cosH;
    Fwy -= rr * sinH;
    const slidingNow = bAbs > 10 * DEG || this.rearSlide > 0.2 || this.driftAmt > 0.05;
    const assistDamp = s.steerAssist && s.gyroOn && slidingNow ? 0.006 : 0;
    const yawDamp = (0.002 + 0.0006 * (s.caster - 6) + assistDamp + (tc > 0 && slidingNow ? 0.016 * tc : 0)) * Math.min(1, spd / 2);
    this.vx += (Fwx / m) * dt;
    this.vy += (Fwy / m) * dt;
    this.r += ((Mz - yawDamp * r) / this.Iz) * dt;
    if (tc > 0 || (s.steerAssist && s.gyroOn)) {
      const baseLim = tc > 0 ? Math.min((s.yawLimit ?? 195) * 1.15, 165) : (s.yawLimit ?? 195) * 1.1;
      const rMax = baseLim * DEG;
      this.r = clamp(this.r, -rMax, rMax);
    }
    const newSpd = Math.hypot(this.vx, this.vy);
    if ((tc > 0 || s.steerAssist) && newSpd > 0.8) {
      const ux = this.vx / newSpd;
      const uy = this.vy / newSpd;
      const fwdDot = ux * cosH + uy * sinH; // dot product forward · velocity_dir
      const safeCos = Math.cos(55 * DEG);
      if (fwdDot < safeCos) {
        const excess = clamp((safeCos - fwdDot) / 0.57, 0, 1);
        this.r *= Math.exp(-(6 + 10 * tc) * excess * dt);
        const lerpAlpha = clamp((2.8 + 4.5 * tc) * excess * dt, 0, 0.22);
        const nvx = lerp(ux, cosH, lerpAlpha);
        const nvy = lerp(uy, sinH, lerpAlpha);
        const nLen = Math.hypot(nvx, nvy) || 1;
        this.vx = (nvx / nLen) * newSpd;
        this.vy = (nvy / nLen) * newSpd;
      }
    }
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.heading += this.r * dt;

    // ---------------- Load transfer filter (damper) ----------------
    const tau = lerp(0.11, 0.03, (s.damping - 1) / 9) / Math.sqrt((s.springF + s.springR + 1) / 8);
    const kfil = 1 - Math.exp(-dt / tau);
    this.axF += (sumFx / m - this.axF) * kfil;
    this.ayF += (sumFy / m - this.ayF) * kfil;

    // ---------------- Visual sprung-mass motion ----------------
    const rollTarget = rollDegSigned * DEG;
    const pitchTarget = clamp(this.axF / GRAV, -1.5, 1.5) * 2.2 * softness * DEG;
    const wn = 2 * Math.PI * 5.5;
    const zeta = lerp(0.18, 0.95, (s.damping - 1) / 9);
    this.rollV += (wn * wn * (rollTarget - this.roll) - 2 * zeta * wn * this.rollV) * dt;
    this.roll += this.rollV * dt;
    this.pitchV += (wn * wn * (pitchTarget - this.pitch) - 2 * zeta * wn * this.pitchV) * dt;
    this.pitch += this.pitchV * dt;
    for (let i = 0; i < 4; i++) {
      const w = W[i];
      w.compression = clamp(-w.y * Math.sin(this.roll) - w.x * Math.sin(this.pitch), -0.008, 0.008);
    }

    // ---------------- Telemetry ----------------
    const nu = this.vx * cosH + this.vy * sinH;
    const nv = -this.vx * sinH + this.vy * cosH;
    this.u = nu;
    this.v = nv;
    this.speed = Math.hypot(nu, nv);
    this.beta = this.speed > 0.6 && nu > -0.1 ? Math.atan2(nv, Math.max(nu, 1e-3)) : 0;
  }

  /** World-space impulse at world point (px,py). */
  applyImpulse(px: number, py: number, jx: number, jy: number) {
    this.vx += jx / this.mass;
    this.vy += jy / this.mass;
    const rx = px - this.x;
    const ry = py - this.y;
    this.r += (rx * jy - ry * jx) / this.Iz;
  }
}
