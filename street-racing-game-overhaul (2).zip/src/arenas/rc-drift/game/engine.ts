import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { CarPhysics, type DriveInput } from './physics';
import { buildCar, updateCarVisual, type CarVisual } from './carModel';
import { Track, TRACKS, readArenaTrackId, type ArenaTrackId } from './track';
import { buildArena, type Arena } from './arena';
import { Skidmarks, Smoke } from './effects';
import { AudioEngine } from './audio';
import { PRESETS, settingsStore, uiStore, type Settings, type SurfaceType, type UIMode } from './settings';
import { makeBlobTexture } from './textures';
import { ManeuverDetector } from './maneuvers';

export const CAMERA_NAMES = ['Kejar', 'Kejar Jauh', 'Panggung Pilot', 'FPV Onboard', 'Atas'];

export interface Telemetry {
  speedKmh: number;
  driftAngle: number;
  steerInput: number;
  servo: number;
  userSteer: number;
  gyroCorr: number;
  throttle: number;
  brake: number;
  handbrake: boolean;
  reversing: boolean;
  yawRate: number;
  rearSlide: number;
  rpm: number;
  drifting: boolean;
  driftScore: number;
  multiplier: number;
  totalScore: number;
  bestDrift: number;
  lap: number;
  lapTime: number;
  lastLap: number;
  bestLap: number;
  camera: number;
  x: number;
  y: number;
  heading: number;
  loads: number[];
  fps: number;
  donuts: number;
  eights: number;
  loopProgress: number;
  loopDir: number;
  tcCut: number;
}

export type GameEvent =
  | { type: 'drift'; score: number; label: string; mult: number }
  | { type: 'crash'; lost: number }
  | { type: 'lap'; time: number; best: boolean }
  | { type: 'maneuver'; kind: 'donut' | 'eight'; count: number; bonus: number }
  | { type: 'info'; text: string; tone?: 'good' | 'warn' | 'info' };

const DEG = 180 / Math.PI;
const H_STEP = 1 / 1000;

function lerpAngle(a: number, b: number, t: number) {
  let d = b - a;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return a + d * t;
}
const moveToward = (v: number, target: number, step: number) =>
  v < target ? Math.min(target, v + step) : Math.max(target, v - step);

function driftLabel(sc: number) {
  if (sc < 500) return 'DRIFT';
  if (sc < 1500) return 'NICE DRIFT';
  if (sc < 4000) return 'GREAT DRIFT';
  if (sc < 9000) return 'AWESOME DRIFT';
  return 'LEGENDARY DRIFT';
}

export const engineRef: { current: GameEngine | null } = { current: null };

const eventListeners = new Set<(e: GameEvent) => void>();
export function onGameEvent(fn: (e: GameEvent) => void) {
  eventListeners.add(fn);
  return () => {
    eventListeners.delete(fn);
  };
}

export class GameEngine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  car = new CarPhysics();
  vis: CarVisual;
  /** Arena track: Mt. Haruna Touge (default) or the PRODRIFT race circuit. */
  trackId: ArenaTrackId = readArenaTrackId();
  track = new Track(TRACKS[this.trackId].control);
  arena: Arena;
  skid = new Skidmarks();
  smoke = new Smoke();
  audio = new AudioEngine();
  telemetry: Telemetry;
  camMode = 0;
  maneuver = new ManeuverDetector();

  private container: HTMLElement;
  private sun: THREE.DirectionalLight;
  private blob: THREE.Mesh;
  private keys = new Set<string>();
  private ctrl: DriveInput = { steer: 0, throttle: 0, brake: 0, handbrake: false };
  private unsubs: (() => void)[] = [];
  private raf = 0;
  private lastT = 0;
  private acc = 0;
  private hint = -1;
  private prevIdx = 0;
  private halfway = false;
  private lapStart = -1;
  private time = 0;
  private camPos = new THREE.Vector3(0, 1, 3);
  private camLook = new THREE.Vector3();
  private camYaw = 0;
  private orbit = 0.6;
  private snapCam = true;
  private shake = 0;
  private impact = 0;
  private smokeAcc = [0, 0, 0, 0];
  private fpsAcc = 60;
  private curSurface: SurfaceType | null = null;
  private lastMode: UIMode;
  private ro: ResizeObserver;
  // scoring
  private driftScore = 0;
  private driftTime = 0;
  private mult = 1;
  private nextMultAt = 1.5;
  private lastSign = 0;
  private grace = 0;
  private totalScore = 0;
  private bestDrift = 0;
  private bestLap = 0;
  private lastLap = 0;
  private lap = 0;

  constructor(container: HTMLElement) {
    this.container = container;
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    const r = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    r.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    r.setSize(w, h);
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.05;
    r.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(r.domElement);
    r.domElement.style.display = 'block';
    this.renderer = r;

    this.camera = new THREE.PerspectiveCamera(60, w / h, 0.03, 160);
    this.scene.background = new THREE.Color(0x0c0e13);
    this.scene.fog = new THREE.Fog(0x0c0e13, 35, 90);
    const pmrem = new THREE.PMREMGenerator(r);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.65;

    this.scene.add(new THREE.HemisphereLight(0xe4ecff, 0x3b342b, 0.85));
    this.sun = new THREE.DirectionalLight(0xfff6e8, 2.3);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -2.2;
    sc.right = 2.2;
    sc.top = 2.2;
    sc.bottom = -2.2;
    sc.near = 0.5;
    sc.far = 14;
    this.sun.shadow.bias = -0.0003;
    this.sun.shadow.normalBias = 0.003;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    const fill = new THREE.DirectionalLight(0xbcd4ff, 0.5);
    fill.position.set(-10, 8, -6);
    this.scene.add(fill);

    this.arena = buildArena(this.track, this.trackId);
    this.scene.add(this.arena.group);
    this.scene.add(this.skid.mesh);
    this.scene.add(this.smoke.points);

    const s = settingsStore.get();
    this.vis = buildCar(s.bodyColor);
    this.scene.add(this.vis.root);
    this.blob = new THREE.Mesh(
      new THREE.PlaneGeometry(0.5, 0.27),
      new THREE.MeshBasicMaterial({ map: makeBlobTexture(), transparent: true, depthWrite: false, opacity: 0.5 }),
    );
    this.blob.rotation.x = -Math.PI / 2;
    this.blob.renderOrder = 1;
    this.scene.add(this.blob);

    this.telemetry = {
      speedKmh: 0,
      driftAngle: 0,
      steerInput: 0,
      servo: 0,
      userSteer: 0,
      gyroCorr: 0,
      throttle: 0,
      brake: 0,
      handbrake: false,
      reversing: false,
      yawRate: 0,
      rearSlide: 0,
      rpm: 0,
      drifting: false,
      driftScore: 0,
      multiplier: 1,
      totalScore: 0,
      bestDrift: 0,
      lap: 0,
      lapTime: 0,
      lastLap: 0,
      bestLap: 0,
      camera: 0,
      x: 0,
      y: 0,
      heading: 0,
      loads: [0, 0, 0, 0],
      fps: 60,
      donuts: 0,
      eights: 0,
      loopProgress: 0,
      loopDir: 0,
      tcCut: 0,
    };
    try {
      this.bestDrift = Number(localStorage.getItem('rmx25-best-drift') || 0);
      this.bestLap = Number(localStorage.getItem('rmx25-best-lap') || 0);
    } catch {
      /* ignore */
    }

    this.placeAtStart();
    this.applySettings();
    this.lastMode = uiStore.get().mode;
    this.unsubs.push(settingsStore.subscribe(() => this.applySettings()));
    this.unsubs.push(uiStore.subscribe(() => this.onModeChange()));
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onBlur);
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    engineRef.current = this;
    uiStore.set({ trackId: this.trackId });
    (window as unknown as { __rmx: GameEngine; __rmxSettings: typeof settingsStore }).__rmx = this;
    (window as unknown as { __rmxSettings: typeof settingsStore }).__rmxSettings = settingsStore;
    this.raf = requestAnimationFrame(this.frame);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onBlur);
    this.ro.disconnect();
    this.unsubs.forEach((u) => u());
    this.renderer.dispose();
    this.renderer.domElement.remove();
    this.audio.ctx?.close();
    if (engineRef.current === this) engineRef.current = null;
  }

  private emit(e: GameEvent) {
    eventListeners.forEach((l) => l(e));
  }

  // ------------------------------------------------------------------
  resize() {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    if (!w || !h) return;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  setTrack(id: ArenaTrackId) {
    if (id === this.trackId) return;
    this.trackId = id;
    try { localStorage.setItem('rmx-arena.track', id); } catch { /* storage optional */ }
    // dispose the old arena geometry/materials fully so no GPU memory leaks on swap
    const stale = this.arena.group;
    this.scene.remove(stale);
    stale.traverse(object => {
      const mesh = object as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry?.dispose();
      const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(material)) for (const entry of material) { (entry as THREE.MeshStandardMaterial).map?.dispose(); entry.dispose(); }
      else if (material) { (material as THREE.MeshStandardMaterial).map?.dispose(); material.dispose(); }
    });
    this.track = new Track(TRACKS[id].control);
    this.arena = buildArena(this.track, id);
    this.scene.add(this.arena.group);
    this.placeAtStart();
    const p0 = this.track.pts[0];
    this.car.setPose(p0.x, p0.y, Math.atan2(p0.ty, p0.tx));
    this.driftScore = 0;
    this.resetCombo();
    this.maneuver.reset();
    this.camYaw = this.car.heading;
    this.snapCam = true;
    uiStore.set({ trackId: id });
    this.emit({ type: 'info', text: `LINTASAN: ${TRACKS[id].name.toUpperCase()}`, tone: 'good' });
  }

  placeAtStart() {
    const N = this.track.count;
    const p = this.track.pts[N - 14];
    this.car.setPose(p.x, p.y, Math.atan2(p.ty, p.tx));
    this.hint = N - 14;
    this.prevIdx = N - 14;
    this.camYaw = this.car.heading;
    this.snapCam = true;
  }

  resetCar() {
    const nr = this.track.nearest(this.car.x, this.car.y, -1);
    const off = Math.max(-0.8, Math.min(0.8, nr.offset));
    this.car.setPose(nr.cx + nr.nx * off, nr.cy + nr.ny * off, Math.atan2(nr.ty, nr.tx));
    this.hint = nr.i;
    this.driftScore = 0;
    this.resetCombo();
    this.maneuver.reset();
    this.camYaw = this.car.heading;
    this.snapCam = true;
    this.emit({ type: 'info', text: 'MOBIL DIRESET', tone: 'info' });
  }

  setCamera(i: number) {
    this.camMode = (i + CAMERA_NAMES.length) % CAMERA_NAMES.length;
    this.snapCam = true;
    this.emit({ type: 'info', text: `KAMERA: ${CAMERA_NAMES[this.camMode].toUpperCase()}`, tone: 'info' });
  }

  applyPreset(id: string) {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    settingsStore.set(p.values);
    this.audio.beep(2100, 0.05, 2);
    this.emit({ type: 'info', text: `PRESET: ${p.name.toUpperCase()}`, tone: 'good' });
  }

  // ------------------------------------------------------------------
  private applySettings() {
    const s = settingsStore.get();
    this.vis.paint.color.set(s.bodyColor);
    this.vis.bodyShell.visible = s.showBody;
    if (s.surface !== this.curSurface) {
      this.arena.setSurface(s.surface);
      this.curSurface = s.surface;
    }
    this.skid.mesh.visible = s.skidmarks;
    this.smoke.points.visible = s.smoke;
    this.audio.setEnabled(s.sound);
  }

  private onModeChange() {
    const mode = uiStore.get().mode;
    if (mode === this.lastMode) return;
    if (mode === 'drive') {
      this.audio.init();
      this.audio.setEnabled(settingsStore.get().sound);
      if (this.lastMode === 'start') this.audio.beep(2400, 0.05, 2);
    } else {
      this.audio.silence();
    }
    this.keys.clear();
    this.snapCam = true;
    this.lastMode = mode;
  }

  private onBlur = () => this.keys.clear();
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };
  private onKeyDown = (e: KeyboardEvent) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'Tab'].includes(e.code)) e.preventDefault();
    if (uiStore.get().mode !== 'drive') return;
    this.keys.add(e.code);
    if (e.repeat) return;
    const s = settingsStore.get();
    const info = (text: string, tone: 'good' | 'warn' | 'info' = 'info') => {
      this.emit({ type: 'info', text, tone });
      this.audio.beep(tone === 'warn' ? 900 : 1900, 0.05);
    };
    switch (e.code) {
      case 'KeyG':
        settingsStore.set({ gyroOn: !s.gyroOn });
        info(!s.gyroOn ? `GYRO MGX AKTIF • ${s.gyroGain}%` : 'GYRO MATI — HARDCORE!', !s.gyroOn ? 'good' : 'warn');
        break;
      case 'KeyQ':
      case 'KeyE': {
        const g = Math.max(0, Math.min(100, s.gyroGain + (e.code === 'KeyE' ? 5 : -5)));
        settingsStore.set({ gyroGain: g });
        info(`GAIN GYRO ${g}%`);
        break;
      }
      case 'KeyT': {
        const d = s.drivetrain === 'RWD' ? 'AWD' : 'RWD';
        settingsStore.set({ drivetrain: d });
        info(d === 'AWD' ? 'PENGGERAK: AWD (MUDAH)' : 'PENGGERAK: RWD (REALISTIS)', 'good');
        break;
      }
      case 'KeyZ':
      case 'KeyX': {
        const v = Math.max(30, Math.min(100, s.throttleEPA + (e.code === 'KeyX' ? 5 : -5)));
        settingsStore.set({ throttleEPA: v });
        info(`THROTTLE EPA ${v}%`);
        break;
      }
      case 'KeyF':
        settingsStore.set({ steerAssist: !s.steerAssist });
        info(!s.steerAssist ? 'ASISTEN SETIR AKTIF' : 'ASISTEN SETIR MATI (MURNI)', !s.steerAssist ? 'good' : 'warn');
        break;
      case 'KeyC':
        this.setCamera(this.camMode + 1);
        this.audio.beep(1500, 0.04);
        break;
      case 'KeyR':
        this.resetCar();
        break;
      case 'KeyB':
        settingsStore.set({ showBody: !s.showBody });
        info(s.showBody ? 'BODY DILEPAS — LIHAT SASIS RMX 2.5' : 'BODY TERPASANG');
        break;
      case 'KeyM':
        settingsStore.set({ sound: !s.sound });
        this.emit({ type: 'info', text: s.sound ? 'SUARA MATI' : 'SUARA AKTIF' });
        break;
      case 'Digit1':
      case 'Digit2':
      case 'Digit3':
      case 'Digit4':
      case 'Digit5':
        this.applyPreset(PRESETS[Number(e.code.slice(5)) - 1].id);
        break;
    }
  };

  private updateInput(dt: number, s: Settings) {
    const k = this.keys;
    const left = k.has('KeyA') || k.has('ArrowLeft');
    const right = k.has('KeyD') || k.has('ArrowRight');
    const up = k.has('KeyW') || k.has('ArrowUp');
    const down = k.has('KeyS') || k.has('ArrowDown');
    const shift = k.has('ShiftLeft') || k.has('ShiftRight');
    const target = (left ? 1 : 0) - (right ? 1 : 0);
    const rise = dt / s.steerResponse;
    let st = this.ctrl.steer;
    if (target === 0) st = moveToward(st, 0, rise * 2);
    else if (st * target < 0) st = moveToward(st, target, rise * 2.2);
    else st = moveToward(st, target, rise);
    this.ctrl.steer = st;
    const thrTarget = up ? (shift ? s.featherLevel / 100 : 1) * (s.throttleEPA / 100) : 0;
    const tr = dt / s.throttleResponse;
    this.ctrl.throttle =
      this.ctrl.throttle < thrTarget ? Math.min(thrTarget, this.ctrl.throttle + tr) : Math.max(thrTarget, this.ctrl.throttle - tr * 1.8);
    this.ctrl.brake = moveToward(this.ctrl.brake, down ? 1 : 0, dt / 0.12);
    this.ctrl.handbrake = k.has('Space');
  }

  private zeroInput(dt: number) {
    this.ctrl.steer = moveToward(this.ctrl.steer, 0, dt * 6);
    this.ctrl.throttle = 0;
    this.ctrl.brake = 0;
    this.ctrl.handbrake = false;
  }

  // ------------------------------------------------------------------
  private collide() {
    const car = this.car;
    const c = Math.cos(car.heading);
    const sn = Math.sin(car.heading);
    const rad = 0.1;
    const lim = this.track.halfWidth + 0.003 - rad;
    for (const lx of [0.125, -0.115]) {
      const px = car.x + c * lx;
      const py = car.y + sn * lx;
      const nr = this.track.nearest(px, py, this.hint, 30);
      let pen = 0;
      let nx = 0;
      let ny = 0;
      if (nr.offset > lim) {
        pen = nr.offset - lim;
        nx = -nr.nx;
        ny = -nr.ny;
      } else if (nr.offset < -lim) {
        pen = -lim - nr.offset;
        nx = nr.nx;
        ny = nr.ny;
      }
      if (pen <= 0) continue;
      car.x += nx * pen;
      car.y += ny * pen;
      const cpx = px + nx * pen - nx * rad;
      const cpy = py + ny * pen - ny * rad;
      const rx = cpx - car.x;
      const ry = cpy - car.y;
      const vcx = car.vx - car.r * ry;
      const vcy = car.vy + car.r * rx;
      const vn = vcx * nx + vcy * ny;
      if (vn >= 0) continue;
      const rn = rx * ny - ry * nx;
      const kn = 1 / car.mass + (rn * rn) / car.Iz;
      const jn = (-(1 + 0.32) * vn) / kn;
      const tx = -ny;
      const ty = nx;
      const vt = vcx * tx + vcy * ty;
      const rt = rx * ty - ry * tx;
      const kt = 1 / car.mass + (rt * rt) / car.Iz;
      let jt = -vt / kt;
      const mu = 0.22;
      jt = Math.max(-mu * jn, Math.min(mu * jn, jt));
      car.applyImpulse(cpx, cpy, jn * nx + jt * tx, jn * ny + jt * ty);
      this.impact = Math.max(this.impact, -vn);
    }
  }

  private resetCombo() {
    this.driftTime = 0;
    this.mult = 1;
    this.nextMultAt = 1.5;
    this.lastSign = 0;
    this.grace = 0;
  }

  private bankDrift() {
    const sc = Math.round(this.driftScore);
    if (sc > 40) {
      this.totalScore += sc;
      const best = sc > this.bestDrift;
      if (best) {
        this.bestDrift = sc;
        try {
          localStorage.setItem('rmx25-best-drift', String(sc));
        } catch {
          /* ignore */
        }
      }
      this.emit({ type: 'drift', score: sc, label: driftLabel(sc) + (best ? ' • REKOR BARU!' : ''), mult: this.mult });
    }
    this.driftScore = 0;
    this.resetCombo();
  }

  private updateScoring(dt: number) {
    const car = this.car;
    const beta = car.beta * DEG;
    const ab = Math.abs(beta);
    const drifting = car.speed > 1.4 && ab > 12 && ab < 110 && car.u > 0.15;
    if (drifting) {
      const sign = Math.sign(beta);
      if (this.driftScore > 0 && this.lastSign !== 0 && sign !== this.lastSign) {
        this.mult = Math.min(8, this.mult + 0.5);
        this.emit({ type: 'info', text: `TRANSISI! COMBO x${this.mult.toFixed(1)}`, tone: 'good' });
      }
      this.lastSign = sign;
      this.driftTime += dt;
      this.grace = 0;
      if (this.driftTime > this.nextMultAt) {
        this.mult = Math.min(8, this.mult + 0.5);
        this.nextMultAt += 1.5;
      }
      this.driftScore += ab * car.speed * 2.2 * dt * this.mult;
    } else if (this.driftScore > 0) {
      this.grace += dt;
      if (this.grace > 0.8) this.bankDrift();
    }
    if (this.impact > 0.9 && this.driftScore > 0) {
      const lost = Math.round(this.driftScore);
      this.driftScore = 0;
      this.resetCombo();
      this.emit({ type: 'crash', lost });
    }
  }

  private updateTrackProgress(t: number, scoring: boolean) {
    const car = this.car;
    const nr = this.track.nearest(car.x, car.y, this.hint, 40);
    this.hint = nr.i;
    const N = this.track.count;
    const i = nr.i;
    if (Math.abs(i - N / 2) < N * 0.08) this.halfway = true;
    if (this.prevIdx > N * 0.85 && i < N * 0.15) {
      if (scoring) {
        if (this.lapStart >= 0 && this.halfway) {
          const lt = t - this.lapStart;
          this.lastLap = lt;
          this.lap++;
          const best = this.bestLap === 0 || lt < this.bestLap;
          if (best) {
            this.bestLap = lt;
            try {
              localStorage.setItem('rmx25-best-lap', String(lt));
            } catch {
              /* ignore */
            }
          }
          this.emit({ type: 'lap', time: lt, best });
        }
        this.lapStart = t;
        this.halfway = false;
      }
    } else if (this.prevIdx < N * 0.15 && i > N * 0.85) {
      this.halfway = false;
    }
    this.prevIdx = i;
  }

  // ------------------------------------------------------------------
  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    const t = now / 1000;
    let dt = this.lastT ? t - this.lastT : 1 / 60;
    this.lastT = t;
    dt = Math.min(Math.max(dt, 0), 0.1);
    this.fpsAcc += (1 / Math.max(dt, 1e-3) - this.fpsAcc) * 0.05;
    const s = settingsStore.get();
    const mode = uiStore.get().mode;
    const running = mode === 'drive' || mode === 'start';

    if (mode === 'drive') this.updateInput(dt, s);
    else this.zeroInput(dt);

    this.impact = 0;
    if (running) {
      this.acc += dt;
      let steps = 0;
      while (this.acc >= H_STEP && steps < 110) {
        this.car.step(H_STEP, this.ctrl, s);
        this.collide();
        this.acc -= H_STEP;
        steps++;
      }
      if (steps >= 110) this.acc = 0;
      this.time += dt;
      this.updateTrackProgress(this.time, mode === 'drive');
      if (mode === 'drive') {
        this.updateScoring(dt);
        const mv = this.maneuver.step(dt, this.car);
        if (mv) {
          const bonus = mv.type === 'donut' ? 150 * Math.min(mv.streak, 5) : 800;
          this.totalScore += bonus;
          this.emit({ type: 'maneuver', kind: mv.type, count: mv.type === 'donut' ? mv.streak : mv.count, bonus });
          this.audio.beep(mv.type === 'donut' ? 2200 : 2600, 0.05, mv.type === 'donut' ? 1 : 3);
        }
      }
      if (this.impact > 0.25) {
        this.audio.hit(this.impact);
        this.shake = Math.min(1, this.shake + this.impact * 0.25);
      }
    }

    updateCarVisual(this.vis, this.car, s, t, running ? dt : 0, this.ctrl.handbrake);
    this.updateEffects(dt, s, running);
    this.updateCamera(dt, mode);
    this.updateSun();
    if (running) {
      this.audio.update(Math.abs(this.car.omegaR) / this.car.omegaMax, Math.abs(this.car.motorThr), Math.max(this.car.rearSlide, this.car.frontSlide * 0.6), this.car.speed);
    }
    this.renderer.render(this.scene, this.camera);
    this.updateTelemetry(s);
  };

  private updateEffects(dt: number, s: Settings, running: boolean) {
    const car = this.car;
    const c = Math.cos(car.heading);
    const sn = Math.sin(car.heading);
    this.blob.position.set(car.x, 0.0045, -car.y);
    this.blob.rotation.z = car.heading;
    if (running) {
      for (let i = 0; i < 4; i++) {
        const w = car.wheels[i];
        const wx = car.x + c * w.x - sn * w.y;
        const wy = car.y + sn * w.x + c * w.y;
        const slide = w.slide * Math.min(1, car.speed / 0.8 + (i >= 2 ? Math.abs(car.omegaR * car.R) / 2.5 : 0));
        if (s.skidmarks && slide > 0.22) {
          const a = car.heading + w.steer;
          this.skid.add(i, wx, -wy, Math.cos(a), -Math.sin(a), slide);
        } else this.skid.lift(i);
        if (s.smoke && i >= 2 && slide > 0.3) {
          this.smokeAcc[i] += dt * slide * 40;
          while (this.smokeAcc[i] > 1) {
            this.smokeAcc[i] -= 1;
            this.smoke.spawn(wx, 0.014, -wy, car.vx, -car.vy, slide);
          }
        }
      }
    }
    this.skid.flush();
    this.smoke.update(running ? dt : 0);
    this.smoke.material.uniforms.scale.value =
      this.renderer.domElement.height / (2 * Math.tan((this.camera.fov * Math.PI) / 360));
  }

  private updateSun() {
    const car = this.car;
    this.sun.position.set(car.x + 2.2, 5.5, -car.y + 1.6);
    this.sun.target.position.set(car.x, 0, -car.y);
    this.sun.target.updateMatrixWorld();
  }

  private updateCamera(dt: number, mode: UIMode) {
    const car = this.car;
    const cam = this.camera;
    const cx = car.x;
    const cz = -car.y;
    const pos = new THREE.Vector3();
    const look = new THREE.Vector3();
    let fov = 60;
    let near = 0.03;
    let posRate = 9;
    let lookRate = 14;
    let onboard = false;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    const snap = this.snapCam;

    if (mode === 'start' || mode === 'setup') {
      this.orbit += dt * (mode === 'start' ? 0.22 : 0.16);
      const r = mode === 'start' ? 0.9 : 0.78;
      pos.set(cx + Math.cos(this.orbit) * r, mode === 'start' ? 0.27 : 0.32, cz + Math.sin(this.orbit) * r);
      look.set(cx, 0.045, cz);
      fov = mode === 'start' ? 42 : 40;
      posRate = 3;
      lookRate = 6;
    } else {
      const speed = car.speed;
      switch (this.camMode) {
        case 0:
        case 1: {
          const velAng = Math.atan2(car.vy, car.vx);
          let tgt = car.heading;
          if (speed > 0.8 && car.u > -0.2) tgt = lerpAngle(car.heading, velAng, 0.6);
          if (car.u < -0.3) tgt = car.heading;
          this.camYaw = lerpAngle(this.camYaw, tgt, 1 - Math.exp(-dt * 4.5));
          const far = this.camMode === 1;
          const dist = far ? 2.2 : 0.95;
          const ht = far ? 1.0 : 0.34;
          const fx = Math.cos(this.camYaw);
          const fy = Math.sin(this.camYaw);
          pos.set(cx - fx * dist, ht, cz + fy * dist);
          look.set(cx + fx * 0.35, 0.05, cz - fy * 0.35);
          fov = (far ? 55 : 62) + Math.min(10, speed * 1.1);
          break;
        }
        case 2: {
          pos.copy(this.arena.driverStand);
          look.set(cx, 0.06, cz);
          const d = pos.distanceTo(look);
          fov = Math.max(10, Math.min(50, 2 * Math.atan(1.7 / d) * DEG));
          posRate = 50;
          lookRate = 7;
          break;
        }
        case 3: {
          onboard = true;
          near = 0.01;
          fov = 82;
          break;
        }
        case 4: {
          pos.set(cx, 7.5, cz + 3.6);
          look.set(cx, 0, cz);
          fov = 48;
          posRate = 6;
          break;
        }
      }
    }

    if (mode === 'setup' && w > 900) cam.setViewOffset(w, h, -Math.min(250, w * 0.18), 0, w, h);
    else if (cam.view && cam.view.enabled) cam.clearViewOffset();

    if (onboard) {
      this.vis.root.updateMatrixWorld(true);
      const sp = this.vis.sprung;
      const hc = this.vis.hCG;
      const p = sp.localToWorld(new THREE.Vector3(-0.004, 0.142 - hc, 0));
      const l = sp.localToWorld(new THREE.Vector3(1.2, 0.07 - hc, 0));
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(sp.getWorldQuaternion(new THREE.Quaternion()));
      cam.position.copy(p);
      cam.up.copy(up);
      cam.lookAt(l);
      this.camPos.copy(p);
      this.camLook.copy(l);
    } else {
      cam.up.set(0, 1, 0);
      if (snap) {
        this.camPos.copy(pos);
        this.camLook.copy(look);
      } else {
        this.camPos.lerp(pos, 1 - Math.exp(-dt * posRate));
        this.camLook.lerp(look, 1 - Math.exp(-dt * lookRate));
      }
      cam.position.copy(this.camPos);
      if (this.shake > 0.001) {
        cam.position.x += (Math.random() - 0.5) * this.shake * 0.03;
        cam.position.y += (Math.random() - 0.5) * this.shake * 0.03;
        this.shake *= Math.exp(-dt * 8);
      }
      cam.lookAt(this.camLook);
    }
    this.snapCam = false;
    if (Math.abs(cam.fov - fov) > 0.01 || cam.near !== near) {
      cam.fov = snap ? fov : cam.fov + (fov - cam.fov) * (1 - Math.exp(-dt * 6));
      cam.near = near;
      cam.updateProjectionMatrix();
    }
  }

  private updateTelemetry(s: Settings) {
    const car = this.car;
    const T = this.telemetry;
    const maxSteer = (s.steerAngle * Math.PI) / 180;
    T.speedKmh = car.speed * 3.6;
    T.driftAngle = car.beta * DEG;
    T.steerInput = this.ctrl.steer;
    T.servo = car.servo / maxSteer;
    T.userSteer = car.userSteer / maxSteer;
    T.gyroCorr = car.gyroCorr / maxSteer;
    T.throttle = Math.max(0, car.motorThr);
    T.brake = car.braking ? this.ctrl.brake : 0;
    T.handbrake = this.ctrl.handbrake;
    T.reversing = car.reversing;
    T.yawRate = car.r * DEG;
    T.rearSlide = car.rearSlide;
    T.rpm = Math.abs(car.omegaR) / car.omegaMax;
    T.drifting = this.driftScore > 0;
    T.driftScore = this.driftScore;
    T.multiplier = this.mult;
    T.totalScore = this.totalScore;
    T.bestDrift = this.bestDrift;
    T.lap = this.lap;
    T.lapTime = this.lapStart >= 0 ? this.time - this.lapStart : 0;
    T.lastLap = this.lastLap;
    T.bestLap = this.bestLap;
    T.camera = this.camMode;
    T.x = car.x;
    T.y = car.y;
    T.heading = car.heading;
    for (let i = 0; i < 4; i++) T.loads[i] = car.wheels[i].load;
    T.fps = this.fpsAcc;
    T.donuts = this.maneuver.donuts;
    T.eights = this.maneuver.eights;
    T.loopProgress = this.maneuver.progress;
    T.loopDir = this.maneuver.dir;
    T.tcCut = car.tcCut;
  }
}
