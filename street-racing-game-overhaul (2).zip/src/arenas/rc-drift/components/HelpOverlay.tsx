const KEYS: [string, string][] = [
  ['W / ↑', 'Gas — ditahan makin dalam (ramping proporsional)'],
  ['SHIFT + W', 'Gas halus / feathering untuk menahan sudut drift'],
  ['S / ↓', 'Rem ESC, tahan saat berhenti = mundur'],
  ['A / D  •  ← / →', 'Setir proporsional (tap = sedikit, tahan = penuh)'],
  ['SPACE', 'Rem tangan (bantuan inisiasi drift)'],
  ['G', 'Gyro MGX on / off'],
  ['Q / E', 'Gain gyro −5% / +5%'],
  ['F', 'Asisten setir keyboard on / off'],
  ['T', 'Penggerak RWD ↔ AWD'],
  ['Z / X', 'Throttle EPA −5% / +5%'],
  ['1 2 3 4 5', 'Preset: RTR • Pemula AWD • Pro • Tanpa Gyro • Santai Donut & 8'],
  ['C', 'Kamera: Kejar • Jauh • Panggung Pilot • FPV • Atas'],
  ['B', 'Lepas / pasang body (lihat sasis bekerja)'],
  ['R', 'Reset mobil ke lintasan'],
  ['M', 'Suara on / off'],
  ['TAB / P / ESC', 'Garasi setup (pause)'],
];

const TIPS = [
  ['Donut (preset 5)', 'Dari pelan/berhenti: tahan W + tahan A (atau D). Mobil langsung muter donut stabil ±1,9 detik per putaran — kontrol traksi & gyro menahannya agar tidak spin.'],
  ['Angka 8 (preset 5)', 'Tahan W. Donut ke kiri (A) ±1 putaran, lalu pindah ke D saat mobil menghadap ke titik tengah → mobil berayun ke lingkaran kedua. Ulangi bergantian. Bonus tiap angka 8!'],
  ['Masuk drift', 'Saat mendekati tikungan, tahan W lalu tahan A/D. Buntut keluar dan gyro langsung counter-steer otomatis.'],
  ['Tahan sudut', 'Main gas: W penuh = sudut makin besar, SHIFT+W = sudut stabil, lepas W = mobil kembali lurus & grip.'],
  ['Transisi', 'Saat drift ke kiri, tekan D sambil tetap gas → mobil berayun ke kanan. Setiap transisi menambah combo.'],
  ['Sering spin?', 'Turunkan Throttle EPA (Z), naikkan gain gyro (E), atau coba AWD (T). Preset 2 paling nyaman untuk pemula.'],
  ['Kurang menyamping?', 'Naikkan EPA (X), turunkan toe-in belakang, keraskan pegas belakang, atau pakai ban keras.'],
  ['Rasa RC asli', 'Kamera Panggung Pilot (C) = melihat mobil dari driver stand seperti di track RC sungguhan.'],
];

export default function HelpOverlay() {
  return (
    <div className="font-game absolute inset-0 flex items-center justify-center bg-black/75 p-4 text-white backdrop-blur-sm">
      <div className="max-h-full w-full max-w-5xl overflow-y-auto rounded-2xl border border-white/10 bg-[#0b0d12]/95 p-6 shadow-2xl">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-[11px] font-black tracking-[0.35em] text-amber-400">BANTUAN</div>
            <div className="font-title text-3xl font-black italic">Cara Drift dengan Keyboard</div>
          </div>
          <div className="text-sm text-white/50">Tekan H / ESC / ENTER untuk kembali</div>
        </div>
        <div className="mt-5 grid gap-6 md:grid-cols-2">
          <div>
            <div className="mb-2 text-[11px] font-black tracking-[0.3em] text-white/50">TOMBOL</div>
            <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 text-sm">
              {KEYS.map(([k, v]) => (
                <div key={k} className="contents">
                  <kbd className="h-fit rounded-md bg-white/15 px-2 py-0.5 text-center text-xs font-black">{k}</kbd>
                  <span className="text-white/80">{v}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-2 text-[11px] font-black tracking-[0.3em] text-white/50">TIPS DRIFT</div>
            <div className="space-y-2">
              {TIPS.map(([a, b], i) => (
                <div key={a} className="rounded-xl border border-white/10 bg-white/5 p-3">
                  <div className="text-sm font-black text-amber-300">
                    {i + 1}. {a}
                  </div>
                  <div className="text-[13px] leading-snug text-white/75">{b}</div>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-xl border border-sky-400/30 bg-sky-500/10 p-3 text-[13px] text-sky-100/90">
              <b>Skor:</b> poin = sudut drift × kecepatan × combo. Combo naik tiap 1.5 detik drift & setiap transisi. Menabrak barrier saat drift
              menghapus combo.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
