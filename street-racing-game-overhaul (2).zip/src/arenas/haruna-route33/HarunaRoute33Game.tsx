import './index.css';
import Hud from './hud/Hud';
import HarunaScene from './scene/HarunaScene';

export default function HarunaRoute33Game({ onExit }: { onExit: () => void }) {
  return (
    <div className="haruna-route33-root">
      <div className="app">
        <HarunaScene />
        <Hud onExit={onExit} />
      </div>
    </div>
  );
}
