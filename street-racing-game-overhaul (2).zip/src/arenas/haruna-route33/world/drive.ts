import { sampleAt, type Sample } from "./track";

export type CarState = {
  x: number;
  y: number;
  z: number;
  dist: number;
  fromStart: number;
  lateral: number;
  heading: number;
  slip: number;
  speed: number;
  steer: number;
  gear: number;
  pitch: number;
  roll: number;
};

export type DriveInput = {
  throttle: number;
  brake: number;
  steer: number;
  handbrake: boolean;
};

export type DriveResult = {
  drift: number;
  offroad: boolean;
  impact: number;
  rpm: number;
};

const GEAR_TOP = [0, 12, 22, 32, 42, 52];
/** Max hold angle, about 48 degrees. A gyro never lets it run to 180. */
const MAX_SLIP = 0.84;

export function spawnCar(s: Sample): CarState {
  return {
    x: s.x,
    y: s.y,
    z: s.z,
    dist: s.dist,
    fromStart: s.fromStart,
    lateral: 0,
    heading: s.heading,
    slip: 0,
    speed: 0,
    steer: 0,
    gear: 1,
    pitch: 0,
    roll: 0,
  };
}

export function stepCar(
  car: CarState,
  input: DriveInput,
  samples: Sample[],
  dt: number,
): DriveResult {
  const step = Math.min(0.033, Math.max(0.001, dt));
  const here = sampleAt(samples, car.dist);
  const steerIn = clamp(input.steer, -1, 1);
  car.steer += (steerIn - car.steer) * Math.min(1, step * 9);

  let gear = car.gear;
  const top = GEAR_TOP[gear] ?? 52;
  const bottom = (GEAR_TOP[gear - 1] ?? 0) * 0.72;
  if (car.speed > top && gear < 5) gear += 1;
  else if (car.speed < bottom && gear > 1) gear -= 1;
  car.gear = gear;
  const ratio = [0, 2.05, 1.55, 1.22, 1, 0.86][gear] ?? 1;

  const speedAbs = Math.abs(car.speed);
  const ready = clamp((speedAbs - 5) / 8, 0, 1);
  const hand = input.handbrake && speedAbs > 6;

  const facing = Math.sin(car.heading) * here.tx + Math.cos(car.heading) * here.tz;
  const engine = input.throttle * 10.6 * ratio * Math.max(0.2, 1 - car.speed / 44);
  const drag = 0.008 * car.speed * Math.abs(car.speed) + 0.22;
  const brake = input.brake * (car.speed >= 0 ? 16 : 5);
  let accel = engine - drag - brake - 9.8 * here.grade * Math.max(facing, 0.35);
  if (hand) accel -= Math.min(speedAbs, 8) * 0.35;
  if (car.speed < 0.25 && input.brake > 0.6 && input.throttle < 0.05) car.speed -= 5 * step;
  else car.speed += accel * step;
  car.speed = clamp(car.speed, -5, 42);

  // Road curvature wants a matching slide: left corner (curv > 0) wants nose-left (negative slip).
  const corner = clamp(-here.curv * 7.5, -0.42, 0.42) * ready;
  let goal = car.steer * MAX_SLIP * ready + corner * (0.55 + Math.abs(car.steer) * 0.45);
  if (hand) goal += car.steer * 0.22 * ready;
  goal = clamp(goal, -MAX_SLIP, MAX_SLIP);

  // Gyro: ease toward the hold angle. Countersteer just moves the target, it cannot wind up.
  const follow = hand ? 7.5 : 5.2;
  car.slip += (goal - car.slip) * Math.min(1, step * follow);
  if (Math.abs(car.slip) > MAX_SLIP * 0.92) {
    car.slip *= Math.exp(-step * 3.5);
  }
  car.slip = clamp(car.slip, -MAX_SLIP, MAX_SLIP);

  // Heading is the road direction plus a capped slide. The car rotates with the hairpin.
  car.heading = wrap(here.heading + car.slip);

  const travel = car.speed * Math.max(0.62, Math.cos(car.slip));
  car.dist += travel * step;
  car.lateral += Math.sin(car.slip) * car.speed * 0.42 * step;
  car.lateral *= Math.exp(-step * 1.15);

  const last = samples[samples.length - 1].dist;
  car.dist = clamp(car.dist, samples[0].dist + 1, last - 1);
  const s = sampleAt(samples, car.dist);
  const limit = Math.max(1.5, s.halfW - 0.8);
  let impact = 0;
  if (car.lateral > limit) {
    car.lateral = limit;
    car.slip *= 0.92;
    impact = 0.25;
  } else if (car.lateral < -limit) {
    car.lateral = -limit;
    car.slip *= 0.92;
    impact = 0.25;
  }

  car.x = s.x + s.rx * car.lateral;
  car.z = s.z + s.rz * car.lateral;
  car.y = s.y + Math.sin(s.bank) * car.lateral;
  car.fromStart = s.fromStart;
  car.pitch = -Math.atan(clamp(s.grade, -0.1, 0.1));
  car.roll = s.bank - car.slip * 0.16;

  const drift = Math.min(1, Math.abs(car.slip) / 0.55);
  const rpm = Math.min(100, 18 + (speedAbs / Math.max(8, top)) * 68 + input.throttle * 12);
  return { drift, offroad: Math.abs(car.lateral) > s.halfW - 0.35, impact, rpm };
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function wrap(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

export function rivalSpeed(curv: number) {
  const tight = Math.min(1, Math.abs(curv) * 16);
  return 12 + (1 - tight) * 18;
}
