// Tiny WebAudio synth: 4-cylinder engine note, tyre squeal, wind and impact thumps.

export class GameAudio {
  ctx: AudioContext | null = null;
  master!: GainNode;
  engA!: OscillatorNode;
  engB!: OscillatorNode;
  engGain!: GainNode;
  engFilter!: BiquadFilterNode;
  squealGain!: GainNode;
  squealFilter!: BiquadFilterNode;
  windGain!: GainNode;
  noiseBuf!: AudioBuffer;
  muted = false;

  start() {
    if (this.ctx) {
      void this.ctx.resume();
      return;
    }
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.5;
    this.master.connect(ctx.destination);

    // noise buffer
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    // engine
    this.engA = ctx.createOscillator();
    this.engA.type = 'sawtooth';
    this.engB = ctx.createOscillator();
    this.engB.type = 'square';
    this.engFilter = ctx.createBiquadFilter();
    this.engFilter.type = 'lowpass';
    this.engFilter.frequency.value = 600;
    this.engFilter.Q.value = 3;
    this.engGain = ctx.createGain();
    this.engGain.gain.value = 0.0;
    const g2 = ctx.createGain();
    g2.gain.value = 0.35;
    this.engA.connect(this.engFilter);
    this.engB.connect(g2);
    g2.connect(this.engFilter);
    this.engFilter.connect(this.engGain);
    this.engGain.connect(this.master);
    this.engA.start();
    this.engB.start();

    // tyre squeal (band-passed noise)
    const sq = ctx.createBufferSource();
    sq.buffer = this.noiseBuf;
    sq.loop = true;
    this.squealFilter = ctx.createBiquadFilter();
    this.squealFilter.type = 'bandpass';
    this.squealFilter.frequency.value = 1500;
    this.squealFilter.Q.value = 6;
    this.squealGain = ctx.createGain();
    this.squealGain.gain.value = 0;
    sq.connect(this.squealFilter);
    this.squealFilter.connect(this.squealGain);
    this.squealGain.connect(this.master);
    sq.start();

    // wind
    const w = ctx.createBufferSource();
    w.buffer = this.noiseBuf;
    w.loop = true;
    const wf = ctx.createBiquadFilter();
    wf.type = 'lowpass';
    wf.frequency.value = 700;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0;
    w.connect(wf);
    wf.connect(this.windGain);
    this.windGain.connect(this.master);
    w.start();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.5, this.ctx.currentTime, 0.05);
  }

  update(rpm: number, throttle: number, speedMs: number, squeal: number, active: boolean) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const f = (rpm / 60) * 2; // 4-stroke 4-cyl: 2 firings per rev
    this.engA.frequency.setTargetAtTime(f, t, 0.03);
    this.engB.frequency.setTargetAtTime(f * 0.5, t, 0.03);
    this.engFilter.frequency.setTargetAtTime(280 + rpm * 0.28 + throttle * 700, t, 0.05);
    this.engGain.gain.setTargetAtTime(active ? 0.1 + throttle * 0.12 : 0.0, t, 0.08);
    this.squealGain.gain.setTargetAtTime(active ? Math.min(0.26, squeal * 0.26) : 0, t, 0.05);
    this.squealFilter.frequency.setTargetAtTime(1100 + squeal * 700 + speedMs * 12, t, 0.08);
    this.windGain.gain.setTargetAtTime(active ? Math.min(0.2, speedMs * 0.005) : 0, t, 0.2);
  }

  thump(strength: number) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 500 + strength * 40;
    const g = ctx.createGain();
    const t = ctx.currentTime;
    g.gain.setValueAtTime(Math.min(0.7, 0.1 + strength * 0.04), t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t);
    src.stop(t + 0.4);
  }

  beep(freq: number, dur = 0.18) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const o = ctx.createOscillator();
    o.type = 'square';
    o.frequency.value = freq;
    const g = ctx.createGain();
    const t = ctx.currentTime;
    g.gain.setValueAtTime(0.14, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
}
