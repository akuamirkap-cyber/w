import { useEffect, useRef, useState, useCallback } from 'react';
import { Game, type Hud } from './game/game';

const fmtTime = (t: number) => {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const ms = Math.floor((t * 100) % 100);
  return `${m}:${String(s).padStart(2, '0')}.${String(ms).padStart(2, '0')}`;
};

function rankFor(t: number) {
  if (t < 150) return 'S';
  if (t < 172) return 'A';
  if (t < 200) return 'B';
  return 'C';
}

const KEYS: [string, string][] = [
  ['W / ↑', 'Gas'],
  ['S / ↓', 'Brake · Reverse'],
  ['A D / ← →', 'Steer'],
  ['SPACE', 'Handbrake'],
  ['SHIFT', 'Clutch kick'],
  ['C', 'Camera'],
  ['T', 'Time of day'],
  ['R', 'Respawn (+5s)'],
  ['G', 'Drift assist'],
  ['M · P', 'Mute · Pause'],
];

function Minimap({ game, hud }: { game: Game | null; hud: Hud | null }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c || !game || !game.track) return;
    const ctx = c.getContext('2d')!;
    const W = c.width;
    const H = c.height;
    ctx.clearRect(0, 0, W, H);
    const b = game.mapBounds;
    const pad = 14;
    const sx = (W - pad * 2) / (b.x1 - b.x0);
    const sz = (H - pad * 2) / (b.z1 - b.z0);
    const sc = Math.min(sx, sz);
    const ox = (W - (b.x1 - b.x0) * sc) / 2;
    const oz = (H - (b.z1 - b.z0) * sc) / 2;
    const P = (x: number, z: number): [number, number] => [ox + (x - b.x0) * sc, oz + (z - b.z0) * sc];
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(0,0,0,0.55)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    game.mapPts.forEach(([x, z], i) => {
      const [px, pz] = P(x, z);
      if (i === 0) ctx.moveTo(px, pz);
      else ctx.lineTo(px, pz);
    });
    ctx.stroke();
    ctx.strokeStyle = '#f2f0e8';
    ctx.lineWidth = 3;
    ctx.stroke();
    // progress
    const n = game.mapPts.length;
    const pi = Math.min(n - 1, Math.floor(((hud?.s ?? 0) / game.track.n) * n));
    ctx.strokeStyle = '#ff9d1c';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i <= pi; i++) {
      const [px, pz] = P(game.mapPts[i][0], game.mapPts[i][1]);
      if (i === 0) ctx.moveTo(px, pz);
      else ctx.lineTo(px, pz);
    }
    ctx.stroke();
    const [cx, cz] = P(game.sim.x, game.sim.z);
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = '#111';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(cx, cz, 5.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#ff3b30';
    ctx.beginPath();
    ctx.arc(cx, cz, 3, 0, Math.PI * 2);
    ctx.fill();
  }, [game, hud]);
  return <canvas ref={ref} width={130} height={300} className="block" />;
}

function Tach({ rpm, gear }: { rpm: number; gear: number }) {
  const segs = 22;
  const lit = Math.round(Math.min(1, Math.max(0, (rpm - 1000) / 7500)) * segs);
  return (
    <div className="flex items-end gap-[3px]">
      {Array.from({ length: segs }).map((_, i) => {
        const on = i < lit;
        const red = i >= segs - 5;
        const h = 10 + i * 0.9;
        return (
          <div
            key={i}
            style={{
              height: h,
              background: on ? (red ? '#ff3b30' : i > segs - 9 ? '#ffb020' : '#ffffff') : 'rgba(255,255,255,0.16)',
              transform: 'skewX(-18deg)',
              width: 6,
              boxShadow: on && red ? '0 0 8px #ff3b30' : undefined,
            }}
          />
        );
      })}
      <div className="ml-3 text-white/90 font-black italic text-3xl leading-none w-8 text-center">{gear < 0 ? 'R' : gear}</div>
    </div>
  );
}

export default function HarunaDownhillGame({ onExit }: { onExit: () => void }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [progress, setProgress] = useState({ p: 0, label: 'Starting…' });
  const [ready, setReady] = useState(false);
  const [hud, setHud] = useState<Hud | null>(null);
  const [now, setNow] = useState(0);
  const [touch, setTouch] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const host = hostRef.current!;
    let cancelled = false;
    const game = new Game(host);
    gameRef.current = game;
    (window as unknown as { __game: Game }).__game = game;
    game
      .init((p, label) => !cancelled && setProgress({ p, label }))
      .then(() => {
        if (!cancelled) setReady(true);
      })
      .catch((e) => {
        console.error(e);
        setError(String(e?.message ?? e));
      });
    setTouch(window.matchMedia('(pointer: coarse)').matches);
    const id = window.setInterval(() => {
      if (gameRef.current && gameRef.current.mode !== 'loading') {
        setHud({ ...gameRef.current.hud });
        setNow(performance.now());
      }
    }, 66);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const g = gameRef.current;
  const start = useCallback(() => gameRef.current?.startRun(), []);
  const menu = useCallback(() => gameRef.current?.toMenu(), []);

  const setTouchKey = (k: 'left' | 'right' | 'gas' | 'brake' | 'hb', v: boolean) => {
    if (gameRef.current) gameRef.current.touch[k] = v;
  };
  const tBtn = (k: 'left' | 'right' | 'gas' | 'brake' | 'hb', label: string, cls = '') => (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        setTouchKey(k, true);
      }}
      onPointerUp={() => setTouchKey(k, false)}
      onPointerLeave={() => setTouchKey(k, false)}
      onPointerCancel={() => setTouchKey(k, false)}
      className={`select-none touch-none rounded-2xl bg-black/45 border border-white/30 text-white font-black italic backdrop-blur-sm active:bg-orange-500/70 ${cls}`}
    >
      {label}
    </button>
  );

  const mode = hud?.mode ?? 'loading';
  const inRun = mode === 'running' || mode === 'countdown';
  const sectionVisible = hud && now - hud.sectionAt < 3800 && mode === 'running';
  const wallFlash = hud && now - hud.wallAt < 260;
  const trackKm = g?.track ? (g.track.length / 1000).toFixed(1) : '3.1';
  const drop = g?.track ? Math.round(g.track.y[0] - g.track.y[g.track.n - 1]) : 330;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#9fc6e8] text-white select-none" style={{ fontFamily: "'Rajdhani','Noto Sans JP','Segoe UI',system-ui,sans-serif" }}>
      <div ref={hostRef} className="absolute inset-0" />

      {/* sun bloom + soft grading */}
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at 82% -5%, rgba(255,228,170,0.34) 0%, rgba(255,228,170,0.0) 52%), linear-gradient(180deg, rgba(120,170,255,0.06) 0%, rgba(255,190,120,0.05) 100%)', mixBlendMode: 'screen' }} />
      {/* vignette */}
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(10,12,30,0.42) 100%)' }} />
      {wallFlash && <div className="pointer-events-none absolute inset-0" style={{ boxShadow: 'inset 0 0 140px 30px rgba(255,40,30,0.55)' }} />}

      {/* loading */}
      {!ready && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center" style={{ background: 'linear-gradient(160deg,#1c2b4a 0%,#3b5d86 55%,#f0a868 120%)' }}>
          <div className="text-[13px] tracking-[0.5em] text-white/70 mb-2">TOUGE DRIFT</div>
          <div className="text-7xl sm:text-8xl font-black italic tracking-tight" style={{ textShadow: '0 6px 0 rgba(0,0,0,0.25)' }}>
            榛名山
          </div>
          <div className="text-xl tracking-[0.35em] text-orange-300 font-bold mt-1">MT. HARUNA</div>
          <div className="mt-10 w-72 h-2 rounded-full bg-white/15 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-orange-300 to-orange-500 transition-all duration-300" style={{ width: `${progress.p * 100}%` }} />
          </div>
          <div className="mt-3 text-sm text-white/70 tracking-wider">{error ? `Error: ${error}` : progress.label}</div>
        </div>
      )}

      {/* title screen */}
      {ready && mode === 'menu' && (
        <div className="absolute inset-0 z-30 flex flex-col justify-between p-6 sm:p-10" style={{ background: 'linear-gradient(90deg, rgba(8,14,34,0.72) 0%, rgba(8,14,34,0.25) 48%, rgba(8,14,34,0) 70%)' }}>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-1.5 bg-orange-400 skew-x-[-18deg]" />
              <div>
                <div className="text-[11px] tracking-[0.45em] text-white/70">LOW-POLY TOUGE SIMULATION</div>
                <div className="text-sm font-bold tracking-widest text-orange-300">GUNMA · JAPAN</div>
              </div>
            </div>
            <div className="flex gap-2 text-right">
              {[
                [trackKm, 'KM'],
                ['7', 'HAIRPINS'],
                [`−${drop}`, 'M DESCENT'],
              ].map(([a, b]) => (
                <div key={b} className="bg-black/35 backdrop-blur-sm border border-white/15 px-3 py-1.5 skew-x-[-10deg]">
                  <div className="skew-x-[10deg]">
                    <div className="text-2xl font-black italic leading-none">{a}</div>
                    <div className="text-[10px] tracking-widest text-white/60">{b}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="max-w-xl">
            <div className="text-xl sm:text-2xl font-bold tracking-[0.4em] text-orange-300 mb-1">榛名山 · AKINA TOUGE</div>
            <h1 className="text-6xl sm:text-8xl font-black italic leading-[0.88] tracking-tight" style={{ textShadow: '0 6px 0 rgba(0,0,0,0.35)' }}>
              MT. HARUNA
              <br />
              <span className="text-orange-400">DOWNHILL</span>
            </h1>
            <p className="mt-4 max-w-md text-white/80 text-lg leading-snug">
              Turun dari puncak melewati lima hairpin beruntun, gutter beton, dan terowongan sakura. Drift bergaya RC-gyro: tahan gas + arah belok, mobil menjaga sudut drift sendiri. Lepas arah untuk meluruskan, jangan sentuh guardrail.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={start}
                className="group relative bg-orange-500 hover:bg-orange-400 transition px-10 py-3 text-3xl font-black italic tracking-wider skew-x-[-14deg] shadow-[0_8px_0_#a24b00] active:translate-y-1 active:shadow-[0_4px_0_#a24b00]"
              >
                <span className="inline-block skew-x-[14deg]">START RUN ▸</span>
              </button>
              <div className="text-sm text-white/70 tracking-widest">
                PRESS <kbd className="px-2 py-0.5 border border-white/40 rounded bg-black/30">ENTER</kbd>
              </div>
            </div>
            <div className="mt-4 text-sm text-orange-200/90 tracking-wide max-w-xl">
              TIPS: masuk tikungan ±45–55 km/h → tahan <b>W + A/D</b> (atau tap <b>SHIFT</b> / <b>SPACE</b> untuk memancing drift). Rem sebentar bila terlalu cepat.
            </div>
            <div className="mt-6 grid grid-cols-2 sm:grid-cols-5 gap-x-5 gap-y-2 text-sm max-w-3xl">
              {KEYS.map(([k, v]) => (
                <div key={k} className="flex flex-col">
                  <span className="text-orange-300 font-bold tracking-wider">{k}</span>
                  <span className="text-white/70 text-[13px]">{v}</span>
                </div>
              ))}
            </div>
            <div className="mt-5 flex gap-2 items-center text-xs tracking-widest text-white/70">
              <button onClick={() => gameRef.current?.cyclePreset()} className="border border-white/30 px-3 py-1 bg-black/30 hover:bg-white/15">
                ☀ {hud?.preset ?? 'SUNNY DAY'}
              </button>
              <button onClick={() => gameRef.current?.toggleMute()} className="border border-white/30 px-3 py-1 bg-black/30 hover:bg-white/15">
                {hud?.muted ? '🔇 SOUND OFF' : '🔊 SOUND ON'}
              </button>
              <button onClick={onExit} className="border border-amber-400/60 px-3 py-1 bg-amber-500/20 text-amber-200 hover:bg-amber-500/35 cursor-pointer">
                ← MENU ARENA
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HUD */}
      {ready && hud && inRun && (
        <>
          {/* time + progress */}
          <div className="absolute top-5 left-5 sm:left-8 z-20">
            <div className="flex items-center gap-3">
              <div className="h-12 w-1.5 bg-orange-400 skew-x-[-18deg]" />
              <div>
                <div className="text-[11px] tracking-[0.4em] text-white/70">TIME {hud.penalty > 0 ? `· +${hud.penalty}s PENALTY` : ''}</div>
                <div className="text-5xl font-black italic leading-none tabular-nums" style={{ textShadow: '0 3px 0 rgba(0,0,0,0.35)' }}>
                  {fmtTime(hud.time)}
                </div>
              </div>
            </div>
            <div className="mt-3 w-64 h-2 bg-black/35 skew-x-[-18deg] overflow-hidden border border-white/20">
              <div className="h-full bg-gradient-to-r from-orange-300 to-orange-500" style={{ width: `${hud.progress * 100}%` }} />
            </div>
            <div className="mt-1 text-[11px] tracking-[0.3em] text-white/70 tabular-nums">
              {Math.round(hud.progress * 100)}% · {(hud.progress * (g?.track ? g.track.length / 1000 : 3)).toFixed(2)} KM
            </div>
          </div>

          {/* drift score */}
          <div className="absolute top-5 left-1/2 -translate-x-1/2 z-20 text-center">
            <div className="text-[11px] tracking-[0.45em] text-white/70">DRIFT SCORE</div>
            <div className="text-4xl font-black italic tabular-nums" style={{ textShadow: '0 3px 0 rgba(0,0,0,0.35)' }}>
              {Math.round(hud.score).toLocaleString()}
            </div>
            <div className="h-14">
              {hud.chain > 5 && (
                <div className="mt-1 inline-flex items-center gap-3 px-4 py-1 skew-x-[-12deg]" style={{ background: hud.drifting ? 'linear-gradient(90deg,#ff7a00,#ffb020)' : 'rgba(0,0,0,0.45)' }}>
                  <div className="skew-x-[12deg] flex items-center gap-3">
                    <span className="text-2xl font-black italic tabular-nums">+{Math.round(hud.chain).toLocaleString()}</span>
                    <span className="text-xl font-black italic text-black/80 bg-white/90 px-2 leading-tight">×{hud.mult}</span>
                    <span className="text-sm tracking-wider tabular-nums">{Math.round(hud.angle)}°</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* minimap */}
          <div className="absolute bottom-5 left-5 z-20 hidden sm:block">
            <div className="bg-black/35 backdrop-blur-sm border border-white/20 p-1.5 rounded-sm">
              <Minimap game={g} hud={hud} />
            </div>
          </div>

          {/* speed */}
          <div className="absolute bottom-5 right-5 sm:right-8 z-20 text-right">
            <div className="flex items-end justify-end gap-2">
              <div className="text-[110px] sm:text-[140px] leading-[0.8] font-black italic tabular-nums" style={{ textShadow: '0 6px 0 rgba(0,0,0,0.35)' }}>
                {Math.round(hud.speed)}
              </div>
              <div className="pb-2 text-left">
                <div className="text-2xl font-black italic text-orange-300">KM/H</div>
                <div className="text-[11px] tracking-widest text-white/70">{hud.cam} CAM</div>
              </div>
            </div>
            <div className="mt-3 flex justify-end">
              <Tach rpm={hud.rpm} gear={hud.gear} />
            </div>
          </div>

          {/* helper chips */}
          <div className="absolute top-5 right-5 sm:right-8 z-20 flex flex-col items-end gap-1 text-[11px] tracking-widest text-white/80">
            <div className="bg-black/30 px-2 py-0.5">☀ {hud.preset}</div>
            <div className="bg-black/30 px-2 py-0.5">ASSIST {hud.assist ? 'ON' : 'OFF'} (G)</div>
            <div className="bg-black/30 px-2 py-0.5">C CAM · T TIME · R RESPAWN · P PAUSE</div>
            <div className="bg-black/30 px-2 py-0.5 opacity-70">{hud.fps} FPS</div>
          </div>

          {/* section toast */}
          {sectionVisible && (
            <div className="absolute left-5 sm:left-8 top-40 z-20 animate-[slide_0.5s_ease-out]">
              <div className="inline-block bg-orange-500 text-black px-4 py-1 skew-x-[-14deg] font-black italic text-2xl tracking-wide shadow-[0_4px_0_rgba(0,0,0,0.3)]">
                <span className="inline-block skew-x-[14deg]">{hud.section}</span>
              </div>
            </div>
          )}

          {/* countdown */}
          {mode === 'countdown' && (
            <div className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none">
              <div key={hud.countdown} className="text-[220px] font-black italic text-white leading-none animate-[pop_0.9s_ease-out]" style={{ textShadow: '0 10px 0 rgba(0,0,0,0.3), 0 0 60px rgba(255,160,40,0.8)' }}>
                {hud.countdown > 0 ? hud.countdown : 'GO!'}
              </div>
            </div>
          )}

          {/* pause */}
          {hud.paused && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/55 backdrop-blur-sm">
              <div className="text-7xl font-black italic">PAUSED</div>
              <div className="mt-3 text-white/70 tracking-widest">PRESS P OR ESC TO RESUME</div>
              <div className="mt-6 flex gap-3">
                <button onClick={() => gameRef.current?.togglePause()} className="bg-orange-500 px-8 py-2 text-xl font-black italic skew-x-[-12deg]">
                  <span className="inline-block skew-x-[12deg]">RESUME</span>
                </button>
                <button onClick={menu} className="bg-white/15 px-8 py-2 text-xl font-black italic skew-x-[-12deg] border border-white/30">
                  <span className="inline-block skew-x-[12deg]">MENU</span>
                </button>
                <button onClick={onExit} className="bg-amber-500/25 px-8 py-2 text-xl font-black italic skew-x-[-12deg] border border-amber-400/50 text-amber-200">
                  <span className="inline-block skew-x-[12deg]">PILIH ARENA</span>
                </button>
              </div>
            </div>
          )}

          {/* touch controls */}
          {touch && (
            <>
              <div className="absolute bottom-6 left-4 z-30 flex gap-3">
                {tBtn('left', '◀', 'w-20 h-20 text-3xl')}
                {tBtn('right', '▶', 'w-20 h-20 text-3xl')}
              </div>
              <div className="absolute bottom-40 right-4 z-30 flex flex-col gap-3 items-end">
                {tBtn('hb', 'HB', 'w-16 h-16 text-xl')}
              </div>
              <div className="absolute bottom-6 right-4 z-30 flex gap-3">
                {tBtn('brake', 'BRK', 'w-20 h-20 text-lg')}
                {tBtn('gas', 'GAS', 'w-24 h-24 text-xl')}
              </div>
            </>
          )}
        </>
      )}

      {/* results */}
      {ready && hud && mode === 'finished' && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/35">
          <div className="w-[min(92vw,640px)] bg-[#0c1426]/90 border border-white/20 backdrop-blur-md p-8 skew-x-[-3deg]">
            <div className="skew-x-[3deg]">
              <div className="text-[11px] tracking-[0.5em] text-orange-300">RUN COMPLETE · 麓 AKINA FOOT</div>
              <div className="flex items-end justify-between mt-2">
                <div>
                  <div className="text-6xl font-black italic tabular-nums">{fmtTime(hud.time)}</div>
                  <div className="text-sm text-white/60 tracking-widest">{hud.penalty > 0 ? `INCLUDES +${hud.penalty}s PENALTY` : 'CLEAN RUN'}</div>
                </div>
                <div className="text-9xl font-black italic leading-none text-orange-400" style={{ textShadow: '0 6px 0 rgba(0,0,0,0.4)' }}>
                  {rankFor(hud.time)}
                </div>
              </div>
              <div className="mt-6 grid grid-cols-3 gap-4">
                {[
                  ['DRIFT SCORE', Math.round(hud.score).toLocaleString()],
                  ['BEST CHAIN', Math.round(hud.bestChain).toLocaleString()],
                  ['TOP SPEED', `${Math.round(hud.topSpeed)} km/h`],
                ].map(([a, b]) => (
                  <div key={a} className="border-t-2 border-orange-400 pt-2">
                    <div className="text-[10px] tracking-[0.3em] text-white/60">{a}</div>
                    <div className="text-2xl font-black italic tabular-nums">{b}</div>
                  </div>
                ))}
              </div>
              <div className="mt-8 flex gap-3">
                <button onClick={start} className="bg-orange-500 hover:bg-orange-400 px-8 py-2 text-xl font-black italic skew-x-[-12deg]">
                  <span className="inline-block skew-x-[12deg]">RUN AGAIN</span>
                </button>
                <button onClick={menu} className="bg-white/10 hover:bg-white/20 px-8 py-2 text-xl font-black italic skew-x-[-12deg] border border-white/30">
                  <span className="inline-block skew-x-[12deg]">MAIN MENU</span>
                </button>
                <button onClick={onExit} className="bg-amber-500/20 hover:bg-amber-500/35 px-8 py-2 text-xl font-black italic skew-x-[-12deg] border border-amber-400/50 text-amber-200">
                  <span className="inline-block skew-x-[12deg]">PILIH ARENA</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
