import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { V3SurfaceTextureSet } from '../../rc-drift/pigeon/haruna-v3/textures';
import {
  createBillboardMaterials, createCrosswalkMaterial, createFacadeStyles, createLaneMarkingTexture, createRoofMaterial,
  createSidewalkMaterial, createStorefrontMaterial, makeRng,
} from './cityTextures';
import type { TimeOfDay } from './lighting';

export const LANE_W = 3.5;
export const LANES = 6;
export const ROAD_W = LANE_W * LANES;        // 21 m two-way avenue
export const ROAD_HALF = ROAD_W / 2;
export const SIDEWALK_W = 5;
export const FACADE_X = ROAD_HALF + SIDEWALK_W; // 15.5 m
export const CHUNK_LEN = 60;
const POOL = 15;            // 15 x 60 m = 900 m of streamed Manhattan
const BEHIND = 2;
const FLOOR = 3.6;

/** Lane centre x. Lanes 0..2 run +Z (player direction, right-hand side = -x), lanes 3..5 are oncoming (+x). */
export function laneX(lane: number) {
  return -ROAD_HALF + LANE_W * (lane + 0.5);
}
export const PLAYER_LANES = [0, 1, 2];
export const ONCOMING_LANES = [3, 4, 5];

type DetailMat = 'metal' | 'wood' | 'parapet' | 'lamp' | 'trunk' | 'leaf' | 'hydrant' | 'signalRed' | 'signalGreen' | 'signalAmber' | 'signalBox' | 'curb' | 'planter' | 'glassDark';
const DETAIL_ORDER: DetailMat[] = ['metal', 'wood', 'parapet', 'lamp', 'trunk', 'leaf', 'hydrant', 'signalRed', 'signalGreen', 'signalAmber', 'signalBox', 'curb', 'planter', 'glassDark'];

type Part = { geo: THREE.BufferGeometry; mat: number };

/** Split a box into facade faces (px,nx,pz,nz) and roof faces (py,ny) with metre-based tiled UVs. */
function boxParts(w: number, h: number, d: number, tileW: number, tileH: number, facade: number, roof: number, roofTile = 6): [Part, Part] {
  const geo = new THREE.BoxGeometry(w, h, d);
  const uv = geo.attributes.uv as THREE.BufferAttribute;
  const scale: [number, number][] = [
    [d / tileW, h / tileH], [d / tileW, h / tileH],
    [w / roofTile, d / roofTile], [w / roofTile, d / roofTile],
    [w / tileW, h / tileH], [w / tileW, h / tileH],
  ];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) {
    const k = f * 4 + i;
    uv.setXY(k, uv.getX(k) * scale[f][0], uv.getY(k) * scale[f][1]);
  }
  const idx = geo.index!;
  const pick = (faces: number[]) => {
    const out: number[] = [];
    for (const f of faces) for (let i = 0; i < 6; i++) out.push(idx.getX(f * 6 + i));
    const g = geo.clone();
    g.setIndex(out);
    g.clearGroups();
    return g;
  };
  const sides = pick([0, 1, 4, 5]), top = pick([2, 3]);
  geo.dispose();
  return [{ geo: sides, mat: facade }, { geo: top, mat: roof }];
}

/** Merge parts sorted by material so each material is exactly one contiguous group (one draw call). */
function mergeParts(parts: Part[]): THREE.BufferGeometry | null {
  if (!parts.length) return null;
  parts.sort((a, b) => a.mat - b.mat);
  const merged = mergeGeometries(parts.map(p => p.geo), true);
  if (!merged) return null;
  const groups = merged.groups.map((g, i) => ({ start: g.start, count: g.count, mat: parts[i].mat }));
  merged.clearGroups();
  let cur: { start: number; count: number; mat: number } | null = null;
  for (const g of groups) {
    if (cur && cur.mat === g.mat && cur.start + cur.count === g.start) cur.count += g.count;
    else { if (cur) merged.addGroup(cur.start, cur.count, cur.mat); cur = { ...g }; }
  }
  if (cur) merged.addGroup(cur.start, cur.count, cur.mat);
  for (const p of parts) p.geo.dispose();
  return merged;
}

function placed(geo: THREE.BufferGeometry, x: number, y: number, z: number, ry = 0) {
  if (ry) geo.rotateY(ry);
  geo.translate(x, y, z);
  return geo;
}

function part(geo: THREE.BufferGeometry, mat: number): Part {
  geo.clearGroups();
  return { geo, mat };
}

export type StreetTreeAsset = {
  /** Pre-built V3 broadleaf variants (geometry cloned & transformed per tree). */
  templates: { leaves: THREE.BufferGeometry; bark?: THREE.BufferGeometry }[];
  leafMat: THREE.Material;
  leafDepth?: THREE.Material;
  barkMat?: THREE.Material;
  barkDepth?: THREE.Material;
};

export type CityMaterials = ReturnType<typeof createCityMaterials>;
export function createCityMaterials(v3: V3SurfaceTextureSet, aniso: number) {
  const facades = createFacadeStyles(aniso);
  const roof = createRoofMaterial(aniso);
  const asphalt = new THREE.MeshStandardMaterial({
    // Mt. Haruna V3 2048 px HD asphalt PBR set, identical material response to the touge surface.
    map: v3.asphalt.map, normalMap: v3.asphalt.normalMap, normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: v3.asphalt.roughnessMap, roughness: 0.9, metalness: 0.03, envMapIntensity: 0.92,
  });
  const markings = createLaneMarkingTexture(aniso, ROAD_W, LANE_W);
  const crosswalk = createCrosswalkMaterial(aniso);
  const sidewalk = createSidewalkMaterial(aniso);
  const storefronts = [createStorefrontMaterial(aniso, 11), createStorefrontMaterial(aniso, 23), createStorefrontMaterial(aniso, 37)];
  const billboards = createBillboardMaterials(aniso);
  const details: Record<DetailMat, THREE.MeshStandardMaterial> = {
    metal: new THREE.MeshStandardMaterial({ color: 0x3b3f44, roughness: 0.55, metalness: 0.75 }),
    wood: new THREE.MeshStandardMaterial({ color: 0x6b4a33, roughness: 0.9, metalness: 0 }),
    parapet: new THREE.MeshStandardMaterial({ color: 0x8c877c, roughness: 0.9, metalness: 0 }),
    lamp: new THREE.MeshStandardMaterial({ color: 0xfff2d0, emissive: 0xffe2a8, emissiveIntensity: 0.6, roughness: 0.4 }),
    trunk: new THREE.MeshStandardMaterial({ color: 0x4f3a2a, roughness: 0.95 }),
    leaf: new THREE.MeshStandardMaterial({ color: 0x3f7a35, roughness: 0.85, flatShading: true }),
    hydrant: new THREE.MeshStandardMaterial({ color: 0xc8362b, roughness: 0.5, metalness: 0.3 }),
    signalRed: new THREE.MeshStandardMaterial({ color: 0x4a0b0b, emissive: 0xff2a1a, emissiveIntensity: 2.5 }),
    signalGreen: new THREE.MeshStandardMaterial({ color: 0x0b3a1a, emissive: 0x2cff7a, emissiveIntensity: 2.2 }),
    signalAmber: new THREE.MeshStandardMaterial({ color: 0x3a2a08, emissive: 0xffb020, emissiveIntensity: 0.0 }),
    signalBox: new THREE.MeshStandardMaterial({ color: 0x1f2a1f, roughness: 0.6, metalness: 0.5 }),
    curb: new THREE.MeshStandardMaterial({ color: 0x9d9a92, roughness: 0.95 }),
    planter: new THREE.MeshStandardMaterial({ color: 0x3a3a3a, roughness: 0.9 }),
    glassDark: new THREE.MeshStandardMaterial({ color: 0x1e2a36, roughness: 0.15, metalness: 0.6, envMapIntensity: 1.2 }),
  };
  return { facades, roof, asphalt, markings, crosswalk, sidewalk, storefronts, billboards, details };
}

type ChunkKind = 'block' | 'cross';

type Chunk = {
  group: THREE.Group;
  index: number;
  kind: ChunkKind;
};

function buildChunk(mats: CityMaterials, seed: number, kind: ChunkKind, treeAsset?: StreetTreeAsset): THREE.Group {
  const rng = makeRng(seed);
  const g = new THREE.Group();
  const towers: Part[] = [];
  const details: Part[] = [];
  const shops: Part[] = [];
  const boards: Part[] = [];
  const treeLeaves: THREE.BufferGeometry[] = [];
  const treeBark: THREE.BufferGeometry[] = [];
  const F = mats.facades.length; // roof material index
  const di = (m: DetailMat) => DETAIL_ORDER.indexOf(m);

  const gapStart = 20, gapEnd = 40; // cross street span inside a 'cross' chunk

  function tower(cx: number, cz: number, w: number, d: number, h: number, styleIdx: number, deco: boolean) {
    const style = mats.facades[styleIdx];
    const colW = style.tileW / 6, floors = Math.max(3, Math.round(h / FLOOR));
    const hh = floors * FLOOR;
    const ww = Math.max(colW * 3, Math.round(w / colW) * colW);
    if (!deco || hh < 50) {
      towers.push(...boxParts(ww, hh, d, style.tileW, style.tileH, styleIdx, F).map(pt => { placed(pt.geo, cx, hh / 2, cz); return pt; }));
      parapet(cx, cz, ww, d, hh);
      roofKit(cx, cz, ww, d, hh);
      return { w: ww, h: hh };
    }
    // Art-deco wedding-cake setbacks
    const tiers = [[1, 0.42], [0.78, 0.33], [0.56, 0.25]];
    let y = 0;
    let lastW = ww, lastD = d;
    for (const [f, hf] of tiers) {
      const tw = Math.max(colW * 2, Math.round(ww * f / colW) * colW), td = d * f;
      const th = Math.max(FLOOR * 2, Math.round(hh * hf / FLOOR) * FLOOR);
      towers.push(...boxParts(tw, th, td, style.tileW, style.tileH, styleIdx, F).map(pt => { placed(pt.geo, cx, y + th / 2, cz); return pt; }));
      parapet(cx, cz, tw, td, y + th);
      y += th; lastW = tw; lastD = td;
    }
    // spire
    details.push(part(placed(new THREE.CylinderGeometry(0.25, 0.9, hh * 0.16, 8), cx, y + hh * 0.08, cz), di('metal')));
    details.push(part(placed(new THREE.CylinderGeometry(0.05, 0.12, hh * 0.1, 6), cx, y + hh * 0.16 + hh * 0.05, cz), di('metal')));
    roofKit(cx, cz, lastW, lastD, y, true);
    return { w: ww, h: y };
  }

  function parapet(cx: number, cz: number, w: number, d: number, top: number) {
    const t = 0.5, ph = 1.1;
    details.push(part(placed(new THREE.BoxGeometry(w + 0.2, ph, t), cx, top + ph / 2, cz - d / 2), di('parapet')));
    details.push(part(placed(new THREE.BoxGeometry(w + 0.2, ph, t), cx, top + ph / 2, cz + d / 2), di('parapet')));
    details.push(part(placed(new THREE.BoxGeometry(t, ph, d), cx - w / 2, top + ph / 2, cz), di('parapet')));
    details.push(part(placed(new THREE.BoxGeometry(t, ph, d), cx + w / 2, top + ph / 2, cz), di('parapet')));
  }

  function roofKit(cx: number, cz: number, w: number, d: number, top: number, small = false) {
    // Classic NYC wooden water tower
    if (!small && rng() < 0.7) {
      const tx = cx + (rng() - 0.5) * (w - 8), tz = cz + (rng() - 0.5) * (d - 8);
      const legs = 3.2;
      for (const [ox, oz] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]])
        details.push(part(placed(new THREE.BoxGeometry(0.22, legs, 0.22), tx + ox, top + legs / 2, tz + oz), di('metal')));
      details.push(part(placed(new THREE.CylinderGeometry(1.9, 1.75, 3.6, 14), tx, top + legs + 1.8, tz), di('wood')));
      details.push(part(placed(new THREE.ConeGeometry(2.1, 1.4, 14), tx, top + legs + 3.6 + 0.7, tz), di('wood')));
    }
    // HVAC units
    const n = 1 + Math.floor(rng() * 3);
    for (let i = 0; i < n; i++) {
      const bw = 2 + rng() * 3, bd = 1.5 + rng() * 2.5, bh = 1 + rng() * 1.6;
      details.push(part(placed(new THREE.BoxGeometry(bw, bh, bd), cx + (rng() - 0.5) * (w - bw - 2), top + bh / 2, cz + (rng() - 0.5) * (d - bd - 2)), di('metal')));
    }
    // elevator bulkhead
    if (rng() < 0.6) {
      const bw = 4 + rng() * 3, bh = 3 + rng() * 1.5;
      details.push(part(placed(new THREE.BoxGeometry(bw, bh, bw * 0.8), cx + (rng() - 0.5) * (w - bw - 2), top + bh / 2, cz + (rng() - 0.5) * (d - bw - 2)), di('parapet')));
    }
    // antenna mast
    if (rng() < 0.3) details.push(part(placed(new THREE.CylinderGeometry(0.08, 0.14, 9, 6), cx + (rng() - 0.5) * w * 0.6, top + 4.5, cz + (rng() - 0.5) * d * 0.6), di('metal')));
  }

  function storefront(cz: number, w: number, side: number) {
    // Ground-floor commercial band flush with the facade facing the avenue (12 m per tile, 4.6 m tall).
    const geo = new THREE.PlaneGeometry(w, 4.6);
    const uv = geo.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < uv.count; i++) uv.setX(i, uv.getX(i) * (w / 12));
    const x = side * (FACADE_X - 0.06);
    placed(geo, x, 2.3, cz, side < 0 ? Math.PI / 2 : -Math.PI / 2);
    shops.push(part(geo, Math.floor(rng() * mats.storefronts.length)));
    // Awning boxes
    if (rng() < 0.5) {
      const aw = Math.min(w * 0.5, 9), ad = 1.6;
      details.push(part(placed(new THREE.BoxGeometry(ad, 0.12, aw), side * (FACADE_X - ad / 2), 3.3, cz + (rng() - 0.5) * (w - aw)), di(rng() < 0.5 ? 'hydrant' : 'planter')));
    }
  }

  function billboard(cx: number, cz: number, w: number, top: number) {
    // Rooftop billboard facing oncoming drivers (-Z)
    const bw = Math.min(w * 0.8, 16), bh = bw * 0.5;
    const geo = new THREE.PlaneGeometry(bw, bh);
    placed(geo, cx, top + 2 + bh / 2, cz - 1, Math.PI);
    boards.push(part(geo, Math.floor(rng() * mats.billboards.length)));
    details.push(part(placed(new THREE.BoxGeometry(bw + 0.4, bh + 0.4, 0.25), cx, top + 2 + bh / 2, cz - 0.8), di('metal')));
    for (const ox of [-bw * 0.35, bw * 0.35])
      details.push(part(placed(new THREE.BoxGeometry(0.2, bh + 2, 0.2), cx + ox, top + (bh + 2) / 2, cz - 0.5), di('metal')));
  }

  // ---- Front row: wall-to-wall Manhattan street frontage on both sides ----
  for (const side of [-1, 1]) {
    const spans: [number, number][] = kind === 'cross' ? [[0, gapStart - 3], [gapEnd + 3, CHUNK_LEN]] : [[0, CHUNK_LEN]];
    for (const [a, b] of spans) {
      let z = a;
      while (z < b - 6) {
        const remaining = b - z;
        let w = 12 + rng() * 20;
        if (remaining - w < 8) w = remaining;
        const d = 24 + rng() * 16;
        const tall = rng();
        const h = tall < 0.12 ? 110 + rng() * 60 : tall < 0.45 ? 45 + rng() * 45 : 18 + rng() * 26;
        const styleIdx = Math.floor(rng() * F);
        const deco = (mats.facades[styleIdx].name === 'artdeco' || mats.facades[styleIdx].name === 'white-terracotta' || mats.facades[styleIdx].name === 'limestone') && h > 60;
        const cx = side * (FACADE_X + d / 2), cz = z + w / 2;
        const built = tower(cx, cz, w, d, h, styleIdx, deco);
        storefront(cz, built.w - 0.4, side);
        if (built.h < 45 && rng() < 0.35) billboard(cx, cz - d / 2 + 4, built.w, built.h);
        z += built.w + 0.3;
      }
    }
  }
  // ---- Second & third rows: deeper skyline (next avenues' towers) ----
  for (const side of [-1, 1]) {
    for (let z = 0; z < CHUNK_LEN; z += 30) {
      if (kind === 'cross' && z + 15 > gapStart - 4 && z + 15 < gapEnd + 4) continue;
      if (rng() < 0.75) {
        const w = 22 + rng() * 16, d = 22 + rng() * 16, h = 60 + rng() * 150;
        const styleIdx = Math.floor(rng() * F);
        tower(side * (62 + rng() * 25 + d / 2), z + 15, w, d, h, styleIdx, rng() < 0.4);
      }
    }
    if (rng() < 0.45) {
      const w = 30 + rng() * 18, d = 30 + rng() * 18, h = 170 + rng() * 170;
      const styleIdx = [0, 1, 6, 5][Math.floor(rng() * 4)];
      tower(side * (120 + rng() * 60 + d / 2), 10 + rng() * 40, w, d, h, styleIdx, rng() < 0.5);
    }
  }

  // ---- Street level ----
  const road = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_W, CHUNK_LEN), mats.asphalt);
  road.rotation.x = -Math.PI / 2; road.position.set(0, 0, CHUNK_LEN / 2); road.receiveShadow = true;
  // asphalt tiling: 1 texture tile per 10.5 m
  const ruv = road.geometry.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < ruv.count; i++) ruv.setXY(i, ruv.getX(i) * (ROAD_W / 10.5), ruv.getY(i) * (CHUNK_LEN / 10.5));
  g.add(road);

  const marks = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_W, CHUNK_LEN), mats.markings);
  marks.rotation.x = -Math.PI / 2; marks.position.set(0, 0.012, CHUNK_LEN / 2); marks.receiveShadow = true;
  const muv = marks.geometry.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < muv.count; i++) muv.setXY(i, muv.getX(i), muv.getY(i) * (CHUNK_LEN / 12));
  g.add(marks);

  const walkGeos: THREE.BufferGeometry[] = [];
  function sidewalk(x: number, z: number, w: number, len: number) {
    const geo = new THREE.BoxGeometry(w, 0.16, len);
    const uv = geo.attributes.uv as THREE.BufferAttribute;
    for (let i = 8; i < 12; i++) uv.setXY(i, uv.getX(i) * (w / 5), uv.getY(i) * (len / 5));
    walkGeos.push(placed(geo, x, 0.08, z));
    details.push(part(placed(new THREE.BoxGeometry(0.3, 0.17, len), x - Math.sign(x) * (w / 2 - 0.15), 0.085, z), di('curb')));
  }
  if (kind === 'cross') {
    for (const side of [-1, 1]) {
      sidewalk(side * (ROAD_HALF + SIDEWALK_W / 2), gapStart / 2 - 1.5, SIDEWALK_W, gapStart - 3);
      sidewalk(side * (ROAD_HALF + SIDEWALK_W / 2), gapEnd + 3 + (CHUNK_LEN - gapEnd - 3) / 2, SIDEWALK_W, CHUNK_LEN - gapEnd - 3);
      // sidewalks along the cross street
      for (const zz of [gapStart - 1.5, gapEnd + 1.5]) {
        const geo = new THREE.BoxGeometry(150, 0.16, 3);
        const uv = geo.attributes.uv as THREE.BufferAttribute;
        for (let i = 8; i < 12; i++) uv.setXY(i, uv.getX(i) * 30, uv.getY(i) * 0.6);
        walkGeos.push(placed(geo, side * (FACADE_X + 75), 0.08, zz));
      }
    }
    // cross street asphalt + markings
    const cross = new THREE.Mesh(new THREE.PlaneGeometry(340, 14), mats.asphalt);
    cross.rotation.x = -Math.PI / 2; cross.position.set(0, -0.004, (gapStart + gapEnd) / 2); cross.receiveShadow = true;
    const cuv = cross.geometry.attributes.uv as THREE.BufferAttribute;
    for (let i = 0; i < cuv.count; i++) cuv.setXY(i, cuv.getX(i) * (340 / 10.5), cuv.getY(i) * (14 / 10.5));
    g.add(cross);
    for (const side of [-1, 1]) {
      const cm = new THREE.Mesh(new THREE.PlaneGeometry(14, 160), mats.markings);
      cm.rotation.x = -Math.PI / 2; cm.rotation.z = Math.PI / 2; cm.position.set(side * (ROAD_HALF + 80), 0.011, (gapStart + gapEnd) / 2);
      const cmuv = cm.geometry.attributes.uv as THREE.BufferAttribute;
      for (let i = 0; i < cmuv.count; i++) cmuv.setXY(i, 0.5 + (cmuv.getX(i) - 0.5) * (14 / ROAD_W), cmuv.getY(i) * (160 / 12));
      g.add(cm);
    }
    // crosswalks across the avenue
    for (const zz of [gapStart + 1.6, gapEnd - 1.6]) {
      const cw = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_W, 3), mats.crosswalk);
      cw.rotation.x = -Math.PI / 2; cw.position.set(0, 0.016, zz); g.add(cw);
    }
    // stop lines
    details.push(part(placed(new THREE.BoxGeometry(ROAD_HALF - 0.5, 0.01, 0.5), -ROAD_HALF / 2, 0.018, gapStart - 0.6), di('parapet')));
    details.push(part(placed(new THREE.BoxGeometry(ROAD_HALF - 0.5, 0.01, 0.5), ROAD_HALF / 2, 0.018, gapEnd + 0.6), di('parapet')));
    // traffic signals on mast arms (avenue direction)
    const green = rng() < 0.75;
    function signal(x: number, z: number, side: number, facing: number) {
      const poleH = 7.5;
      details.push(part(placed(new THREE.CylinderGeometry(0.16, 0.2, poleH, 8), x, poleH / 2, z), di('metal')));
      const arm = 7.5;
      details.push(part(placed(new THREE.BoxGeometry(arm, 0.22, 0.22), x - side * arm / 2, poleH - 0.3, z), di('metal')));
      for (const ox of [arm * 0.45, arm * 0.9]) {
        const hx = x - side * ox;
        details.push(part(placed(new THREE.BoxGeometry(0.42, 1.25, 0.4), hx, poleH - 1.15, z), di('signalBox')));
        details.push(part(placed(new THREE.SphereGeometry(0.15, 10, 8), hx, poleH - 0.78, z + facing * 0.2), di(green ? 'signalBox' : 'signalRed')));
        details.push(part(placed(new THREE.SphereGeometry(0.15, 10, 8), hx, poleH - 1.15, z + facing * 0.2), di('signalAmber')));
        details.push(part(placed(new THREE.SphereGeometry(0.15, 10, 8), hx, poleH - 1.52, z + facing * 0.2), di(green ? 'signalGreen' : 'signalBox')));
      }
      // pedestrian signal + sign
      details.push(part(placed(new THREE.BoxGeometry(0.3, 0.4, 0.12), x - side * 0.3, 3.2, z + facing * 0.3), di('signalBox')));
    }
    signal(-(ROAD_HALF + 0.6), gapStart - 1.0, -1, -1);
    signal(ROAD_HALF + 0.6, gapEnd + 1.0, 1, 1);
    // street name sign poles at corners
    for (const side of [-1, 1]) for (const zz of [gapStart - 1.2, gapEnd + 1.2]) {
      details.push(part(placed(new THREE.CylinderGeometry(0.06, 0.07, 3.6, 6), side * (ROAD_HALF + 1.2), 1.8, zz), di('metal')));
      details.push(part(placed(new THREE.BoxGeometry(1.6, 0.28, 0.04), side * (ROAD_HALF + 1.2), 3.4, zz), di('signalGreen')));
    }
  } else {
    for (const side of [-1, 1]) sidewalk(side * (ROAD_HALF + SIDEWALK_W / 2), CHUNK_LEN / 2, SIDEWALK_W, CHUNK_LEN);
  }
  if (walkGeos.length) {
    const walk = new THREE.Mesh(mergeGeometries(walkGeos, false)!, mats.sidewalk);
    walk.receiveShadow = true; walk.castShadow = false;
    g.add(walk);
    walkGeos.forEach(w => w.dispose());
  }

  // Cobra-head street lamps, alternating sides every 30 m
  for (let i = 0; i < 2; i++) {
    const z = 15 + i * 30;
    if (kind === 'cross' && z > gapStart - 4 && z < gapEnd + 4) continue;
    const side = (i + (seed & 1)) % 2 === 0 ? -1 : 1;
    const x = side * (ROAD_HALF + 0.7);
    details.push(part(placed(new THREE.CylinderGeometry(0.11, 0.16, 9.5, 8), x, 4.75, z), di('metal')));
    details.push(part(placed(new THREE.BoxGeometry(4.2, 0.14, 0.14), x - side * 2.1, 9.3, z), di('metal')));
    details.push(part(placed(new THREE.BoxGeometry(1.1, 0.22, 0.4), x - side * 4.0, 9.2, z), di('metal')));
    details.push(part(placed(new THREE.BoxGeometry(0.8, 0.08, 0.3), x - side * 4.0, 9.05, z), di('lamp')));
  }
  // Street trees in sidewalk pits — real Mt. Haruna V3 broadleaf (Momiji maple) assets
  const planters: Part[] = [];
  for (const side of [-1, 1]) {
    for (let z = 7; z < CHUNK_LEN; z += 12) {
      if (kind === 'cross' && z > gapStart - 5 && z < gapEnd + 5) continue;
      if (rng() < 0.15) continue;
      const x = side * (ROAD_HALF + 1.65);
      planters.push(part(placed(new THREE.BoxGeometry(1.9, 0.07, 1.9), x, 0.19, z), di('planter')));
      if (treeAsset && treeAsset.templates.length) {
        const tmpl = treeAsset.templates[Math.floor(rng() * treeAsset.templates.length)];
        const scale = 0.42 + rng() * 0.2; // Konara scaled to street-tree height (~6–8 m)
        const m = new THREE.Matrix4().compose(
          new THREE.Vector3(x + (rng() - 0.5) * 0.4, 0.2, z + (rng() - 0.5) * 0.4),
          new THREE.Quaternion().setFromEuler(new THREE.Euler((rng() - 0.5) * 0.05, rng() * Math.PI * 2, (rng() - 0.5) * 0.05)),
          new THREE.Vector3(scale, scale * (0.9 + rng() * 0.25), scale),
        );
        const lg = tmpl.leaves.clone().applyMatrix4(m); treeLeaves.push(lg);
        if (tmpl.bark) treeBark.push(tmpl.bark.clone().applyMatrix4(m));
      } else {
        // Fallback if the V3 library is unavailable: simple stylized tree
        const th = 3 + rng() * 1.5;
        details.push(part(placed(new THREE.CylinderGeometry(0.14, 0.2, th, 7), x, th / 2 + 0.2, z), di('trunk')));
        const canopy = new THREE.SphereGeometry(1.7 + rng() * 0.8, 6, 4);
        details.push(part(placed(canopy, x, th + 1.2, z), di('leaf')));
      }
    }
  }
  details.push(...planters);
  for (const side of [-1, 1]) {
    // hydrant
    const hz = 4 + rng() * (CHUNK_LEN - 8);
    if (!(kind === 'cross' && hz > gapStart - 4 && hz < gapEnd + 4)) {
      const hx = side * (ROAD_HALF + 1.0);
      details.push(part(placed(new THREE.CylinderGeometry(0.16, 0.2, 0.8, 8), hx, 0.56, hz), di('hydrant')));
      details.push(part(placed(new THREE.SphereGeometry(0.17, 8, 6), hx, 0.98, hz), di('hydrant')));
      details.push(part(placed(new THREE.BoxGeometry(0.5, 0.14, 0.14), hx, 0.7, hz), di('hydrant')));
    }
    // trash can / newspaper box
    const tz = 4 + rng() * (CHUNK_LEN - 8);
    if (!(kind === 'cross' && tz > gapStart - 4 && tz < gapEnd + 4)) {
      details.push(part(placed(new THREE.CylinderGeometry(0.42, 0.38, 1.05, 10), side * (ROAD_HALF + 1.1), 0.68, tz), di('metal')));
    }
  }

  // ---- Merge & attach (one draw call per material) ----
  const towerGeo = mergeParts(towers)!;
  const towerMesh = new THREE.Mesh(towerGeo, [...mats.facades.map(f => f.material), mats.roof]);
  towerMesh.castShadow = true; towerMesh.receiveShadow = true;
  g.add(towerMesh);

  const detGeo = mergeParts(details);
  if (detGeo) {
    const detMesh = new THREE.Mesh(detGeo, DETAIL_ORDER.map(k => mats.details[k]));
    detMesh.castShadow = true; detMesh.receiveShadow = true;
    g.add(detMesh);
  }
  const shopGeo = mergeParts(shops);
  if (shopGeo) {
    const shopMesh = new THREE.Mesh(shopGeo, mats.storefronts);
    shopMesh.receiveShadow = true;
    g.add(shopMesh);
  }
  const boardGeo = mergeParts(boards);
  if (boardGeo) g.add(new THREE.Mesh(boardGeo, mats.billboards));

  if (treeLeaves.length && treeAsset) {
    const flatten = (g: THREE.BufferGeometry) => (g.index ? g.toNonIndexed() : g);
    const leafGeo = mergeGeometries(treeLeaves.map(flatten), false);
    treeLeaves.forEach(x => x.dispose());
    if (leafGeo) {
      const leafMesh = new THREE.Mesh(leafGeo, treeAsset.leafMat);
      leafMesh.name = 'Haruna V3 street maple (Momiji)';
      leafMesh.castShadow = true; leafMesh.receiveShadow = true;
      if (treeAsset.leafDepth) leafMesh.customDepthMaterial = treeAsset.leafDepth;
      g.add(leafMesh);
    }
    if (treeBark.length && treeAsset.barkMat) {
      const barkGeo = mergeGeometries(treeBark.map(flatten), false);
      treeBark.forEach(x => x.dispose());
      if (barkGeo) {
        const barkMesh = new THREE.Mesh(barkGeo, treeAsset.barkMat);
        barkMesh.name = 'Haruna V3 maple bark';
        barkMesh.castShadow = true; barkMesh.receiveShadow = true;
        if (treeAsset.barkDepth) barkMesh.customDepthMaterial = treeAsset.barkDepth;
        g.add(barkMesh);
      }
    } else { treeBark.forEach(x => x.dispose()); }
  }
  g.matrixAutoUpdate = true;
  return g;
}

export type City = {
  group: THREE.Group;
  materials: CityMaterials;
  /** Stream the chunk ring around the player's z. */
  update(playerZ: number): void;
  /** True when the z position lies inside an intersection gap (for crossing traffic / lights). */
  setMood(mood: TimeOfDay): void;
  dispose(): void;
};

export function createCity(scene: THREE.Scene, mats: CityMaterials, treeAsset?: StreetTreeAsset): City {
  const group = new THREE.Group();
  group.name = 'Manhattan avenue';
  scene.add(group);
  const chunks: Chunk[] = [];
  for (let i = 0; i < POOL; i++) {
    const kind: ChunkKind = i % 4 === 3 ? 'cross' : 'block';
    const g = buildChunk(mats, 1337 + i * 101, kind, treeAsset);
    chunks.push({ group: g, index: i, kind });
    group.add(g);
  }
  let head = -BEHIND; // chunk index at the back of the ring
  function layout() {
    for (let i = 0; i < POOL; i++) {
      const slot = head + i;
      const c = chunks[((slot % POOL) + POOL) % POOL];
      c.group.position.z = slot * CHUNK_LEN;
      c.index = slot;
    }
  }
  layout();

  return {
    group,
    materials: mats,
    update(playerZ) {
      const current = Math.floor(playerZ / CHUNK_LEN);
      const desiredHead = current - BEHIND;
      if (desiredHead !== head) { head = desiredHead; layout(); }
    },
    setMood(mood) {
      const night = mood === 'night', dusk = mood === 'dusk';
      for (const f of mats.facades) f.material.emissiveIntensity = night ? 1.6 : dusk ? 0.9 : 0.22;
      mats.details.lamp.emissiveIntensity = night ? 6 : dusk ? 3 : 0.6;
      for (const s of mats.storefronts) s.emissiveIntensity = night ? 0.35 : dusk ? 0.2 : 0;
      for (const b of mats.billboards) { b.emissiveMap = b.map; b.emissiveIntensity = night ? 1.2 : dusk ? 0.7 : 0.15; b.needsUpdate = true; }
    },
    dispose() {
      scene.remove(group);
      group.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh) m.geometry.dispose(); });
      for (const f of mats.facades) { f.material.map?.dispose(); f.material.roughnessMap?.dispose(); f.material.emissiveMap?.dispose(); f.material.dispose(); }
      mats.roof.map?.dispose(); mats.roof.dispose();
      mats.markings.map?.dispose(); mats.markings.dispose();
      mats.crosswalk.map?.dispose(); mats.crosswalk.dispose();
      mats.sidewalk.map?.dispose(); mats.sidewalk.roughnessMap?.dispose(); mats.sidewalk.dispose();
      for (const s of mats.storefronts) { s.map?.dispose(); s.dispose(); }
      for (const b of mats.billboards) { b.map?.dispose(); b.dispose(); }
      for (const k of DETAIL_ORDER) mats.details[k].dispose();
      mats.asphalt.dispose();
    },
  };
}
