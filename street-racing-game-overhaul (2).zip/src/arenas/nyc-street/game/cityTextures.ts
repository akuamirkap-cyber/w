import * as THREE from 'three';

/**
 * Procedural NYC material library. Every texture is generated on a canvas at load time
 * (no external assets), tiled through geometry UVs so hundreds of towers share ~10 materials.
 */
export type FacadeStyle = {
  name: string;
  /** metres covered by one texture tile horizontally / vertically */
  tileW: number;
  tileH: number;
  material: THREE.MeshStandardMaterial;
};

type Rng = () => number;
export function makeRng(seed: number): Rng {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0;
    return (s >>> 0) / 4294967296;
  };
}

function canvas(size: number, h = size) {
  const c = document.createElement('canvas');
  c.width = size; c.height = h;
  return { c, ctx: c.getContext('2d')! };
}

function tex(c: HTMLCanvasElement, color: boolean, aniso: number, repeat = true) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = color ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  t.anisotropy = aniso;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.needsUpdate = true;
  return t;
}

function grain(ctx: CanvasRenderingContext2D, w: number, h: number, amount: number, rng: Rng, count = 9000) {
  for (let i = 0; i < count; i++) {
    const x = rng() * w, y = rng() * h, a = rng() * amount;
    ctx.fillStyle = rng() > 0.5 ? `rgba(255,255,255,${a})` : `rgba(0,0,0,${a})`;
    ctx.fillRect(x, y, 1 + rng() * 2, 1 + rng() * 2);
  }
}

type FacadeSpec = {
  name: string;
  wall: string;
  wallAlt?: string;
  glass: string[];
  frame: string;
  cols: number;      // windows per tile horizontally
  rows: number;      // floors per tile
  tileW: number;     // metres per tile horizontally
  tileH: number;     // metres per tile vertically
  windowW: number;   // fraction of column used by glass
  windowH: number;   // fraction of floor used by glass
  piers?: boolean;   // vertical stone piers (art deco)
  spandrel?: string; // curtain wall spandrel band colour
  brick?: boolean;
  litChance: number;
  roughWall: number;
  roughGlass: number;
  metal: number;
  env: number;
  curtain?: boolean;
};

function buildFacade(spec: FacadeSpec, aniso: number, seed: number): FacadeStyle {
  const rng = makeRng(seed);
  const S = 1024;
  const { c: albedo, ctx: a } = canvas(S);
  const { c: rough, ctx: r } = canvas(S);
  const { c: emis, ctx: e } = canvas(S);

  // Wall base
  a.fillStyle = spec.wall; a.fillRect(0, 0, S, S);
  r.fillStyle = `rgb(${spec.roughWall * 255},${spec.roughWall * 255},${spec.roughWall * 255})`; r.fillRect(0, 0, S, S);
  e.fillStyle = '#000'; e.fillRect(0, 0, S, S);

  if (spec.brick) {
    const bh = S / (spec.rows * 12), bw = bh * 2.3;
    for (let y = 0; y < S; y += bh) {
      const off = (Math.floor(y / bh) % 2) * bw * 0.5;
      for (let x = -bw; x < S; x += bw) {
        const v = 0.86 + rng() * 0.28;
        const col = new THREE.Color(spec.wall).multiplyScalar(v);
        a.fillStyle = `#${col.getHexString()}`;
        a.fillRect(x + off + 1, y + 1, bw - 2, bh - 2);
      }
    }
  } else if (spec.wallAlt) {
    // stone courses
    const ch = S / (spec.rows * 3);
    for (let y = 0; y < S; y += ch) {
      a.fillStyle = (Math.floor(y / ch) % 2 === 0) ? spec.wall : spec.wallAlt;
      a.fillRect(0, y, S, ch);
      a.fillStyle = 'rgba(0,0,0,0.12)'; a.fillRect(0, y, S, 2);
    }
  }
  grain(a, S, S, 0.06, rng, 14000);

  const colW = S / spec.cols, rowH = S / spec.rows;
  if (spec.piers) {
    for (let i = 0; i < spec.cols; i++) {
      const x = i * colW;
      a.fillStyle = 'rgba(255,255,255,0.10)'; a.fillRect(x, 0, colW * 0.16, S);
      a.fillStyle = 'rgba(0,0,0,0.16)'; a.fillRect(x + colW * 0.16, 0, 4, S);
    }
  }
  for (let j = 0; j < spec.rows; j++) {
    const y0 = j * rowH;
    if (spec.curtain && spec.spandrel) {
      a.fillStyle = spec.spandrel; a.fillRect(0, y0 + rowH * spec.windowH, S, rowH * (1 - spec.windowH));
      r.fillStyle = '#5a5a5a'; r.fillRect(0, y0 + rowH * spec.windowH, S, rowH * (1 - spec.windowH));
    } else {
      // floor slab shadow line
      a.fillStyle = 'rgba(0,0,0,0.10)'; a.fillRect(0, y0 + rowH - 3, S, 3);
    }
    for (let i = 0; i < spec.cols; i++) {
      const x0 = i * colW;
      const gw = colW * spec.windowW, gh = rowH * spec.windowH;
      const gx = x0 + (colW - gw) * 0.5, gy = y0 + (spec.curtain ? 0 : (rowH - gh) * 0.42);
      // frame
      a.fillStyle = spec.frame; a.fillRect(gx - 4, gy - 4, gw + 8, gh + 8);
      // glass with vertical gradient (sky reflection top, darker interior bottom)
      const gcol = spec.glass[Math.floor(rng() * spec.glass.length)];
      const grd = a.createLinearGradient(0, gy, 0, gy + gh);
      grd.addColorStop(0, new THREE.Color(gcol).multiplyScalar(1.25).getStyle());
      grd.addColorStop(1, new THREE.Color(gcol).multiplyScalar(0.55).getStyle());
      a.fillStyle = grd; a.fillRect(gx, gy, gw, gh);
      // blinds / curtains / interior variety
      const k = rng();
      if (k < 0.18) { a.fillStyle = 'rgba(230,225,210,0.75)'; a.fillRect(gx, gy, gw, gh * (0.3 + rng() * 0.5)); }
      else if (k < 0.26) { a.fillStyle = 'rgba(20,24,30,0.55)'; a.fillRect(gx, gy, gw, gh); }
      // mullion
      a.fillStyle = spec.frame;
      if (!spec.curtain) a.fillRect(gx + gw * 0.5 - 1.5, gy, 3, gh);
      a.fillRect(gx, gy + gh * 0.5 - 1, gw, 2);
      // roughness: glass is smooth
      r.fillStyle = `rgb(${spec.roughGlass * 255},${spec.roughGlass * 255},${spec.roughGlass * 255})`;
      r.fillRect(gx, gy, gw, gh);
      // lit windows (subtle at day; drives emissive)
      if (rng() < spec.litChance) {
        const warm = rng() < 0.7;
        e.fillStyle = warm ? `rgba(255,${190 + Math.floor(rng() * 40)},${110 + Math.floor(rng() * 50)},1)` : 'rgba(190,220,255,1)';
        e.fillRect(gx, gy, gw, gh);
      }
      // sill
      if (!spec.curtain) { a.fillStyle = 'rgba(255,255,255,0.18)'; a.fillRect(gx - 6, gy + gh + 4, gw + 12, 4); }
    }
  }
  // dirt streaks
  for (let i = 0; i < 60; i++) {
    const x = rng() * S;
    a.fillStyle = `rgba(0,0,0,${0.02 + rng() * 0.05})`;
    a.fillRect(x, rng() * S, 2 + rng() * 6, 80 + rng() * 300);
  }

  const material = new THREE.MeshStandardMaterial({
    map: tex(albedo, true, aniso),
    roughnessMap: tex(rough, false, aniso),
    emissiveMap: tex(emis, true, aniso),
    emissive: new THREE.Color(0xffffff),
    emissiveIntensity: 0.22,
    roughness: 1,
    metalness: spec.metal,
    envMapIntensity: spec.env,
  });
  material.name = spec.name;
  return { name: spec.name, tileW: spec.tileW, tileH: spec.tileH, material };
}

export function createFacadeStyles(aniso: number): FacadeStyle[] {
  const specs: FacadeSpec[] = [
    { name: 'glass-blue', wall: '#38414d', glass: ['#6f93b8', '#7fa2c4', '#5f84ab'], frame: '#1f2429', cols: 6, rows: 4, tileW: 9, tileH: 14.4, windowW: 0.92, windowH: 0.72, curtain: true, spandrel: '#2b3138', litChance: 0.16, roughWall: 0.6, roughGlass: 0.12, metal: 0.55, env: 1.25 },
    { name: 'glass-green', wall: '#2f3a3a', glass: ['#7fb3a6', '#8cc1b4', '#6ea396'], frame: '#1b2020', cols: 5, rows: 4, tileW: 8, tileH: 14.4, windowW: 0.94, windowH: 0.78, curtain: true, spandrel: '#1c2325', litChance: 0.12, roughWall: 0.55, roughGlass: 0.1, metal: 0.6, env: 1.3 },
    { name: 'limestone', wall: '#cdbf9f', wallAlt: '#c3b492', glass: ['#3b4a5c', '#425568', '#2f3d4c'], frame: '#2a2a28', cols: 5, rows: 4, tileW: 10, tileH: 15.2, windowW: 0.5, windowH: 0.56, litChance: 0.2, roughWall: 0.92, roughGlass: 0.18, metal: 0.02, env: 0.6 },
    { name: 'brick-red', wall: '#8a4a3a', brick: true, glass: ['#3a4653', '#2d3844', '#46525f'], frame: '#dcd6c4', cols: 4, rows: 4, tileW: 8, tileH: 13.6, windowW: 0.46, windowH: 0.58, litChance: 0.26, roughWall: 0.96, roughGlass: 0.2, metal: 0.0, env: 0.5 },
    { name: 'brick-brown', wall: '#6d5346', brick: true, glass: ['#34404a', '#2a333c'], frame: '#2d2a26', cols: 5, rows: 4, tileW: 9, tileH: 13.6, windowW: 0.5, windowH: 0.6, litChance: 0.22, roughWall: 0.95, roughGlass: 0.2, metal: 0.0, env: 0.5 },
    { name: 'artdeco', wall: '#d8cfbd', glass: ['#2f3b48', '#3a4858'], frame: '#4c463c', cols: 6, rows: 4, tileW: 9, tileH: 14.8, windowW: 0.48, windowH: 0.66, piers: true, litChance: 0.18, roughWall: 0.9, roughGlass: 0.16, metal: 0.03, env: 0.7 },
    { name: 'dark-steel', wall: '#1d1f24', glass: ['#4a5a6a', '#55667a', '#3c4a58'], frame: '#4a3a2a', cols: 6, rows: 4, tileW: 9, tileH: 14.4, windowW: 0.9, windowH: 0.76, curtain: true, spandrel: '#232629', litChance: 0.14, roughWall: 0.5, roughGlass: 0.1, metal: 0.7, env: 1.15 },
    { name: 'concrete-70s', wall: '#9a9790', glass: ['#3e4b57', '#4a5868'], frame: '#2b2d2f', cols: 7, rows: 4, tileW: 10.5, tileH: 14.4, windowW: 0.86, windowH: 0.5, litChance: 0.15, roughWall: 0.93, roughGlass: 0.15, metal: 0.02, env: 0.6 },
    { name: 'white-terracotta', wall: '#e5e1d6', wallAlt: '#dcd7cb', glass: ['#2e3a46', '#394756'], frame: '#3b3f44', cols: 5, rows: 4, tileW: 9, tileH: 15, windowW: 0.52, windowH: 0.62, piers: true, litChance: 0.17, roughWall: 0.88, roughGlass: 0.16, metal: 0.03, env: 0.7 },
  ];
  return specs.map((s, i) => buildFacade(s, aniso, 1000 + i * 7919));
}

export function createRoofMaterial(aniso: number) {
  const rng = makeRng(99);
  const { c, ctx } = canvas(512);
  ctx.fillStyle = '#5b5955'; ctx.fillRect(0, 0, 512, 512);
  grain(ctx, 512, 512, 0.12, rng, 12000);
  // tar seams
  ctx.strokeStyle = 'rgba(0,0,0,0.25)'; ctx.lineWidth = 3;
  for (let i = 0; i < 8; i++) { ctx.beginPath(); ctx.moveTo(0, i * 64 + 20); ctx.lineTo(512, i * 64 + 20); ctx.stroke(); }
  return new THREE.MeshStandardMaterial({ map: tex(c, true, aniso), roughness: 0.95, metalness: 0, envMapIntensity: 0.4 });
}

export function createSidewalkMaterial(aniso: number) {
  const rng = makeRng(7);
  const S = 1024;
  const { c, ctx } = canvas(S);
  ctx.fillStyle = '#a9a69d'; ctx.fillRect(0, 0, S, S);
  grain(ctx, S, S, 0.09, rng, 30000);
  // slabs: 1 tile = 5 m x 5 m -> ~1.5 m slabs
  const n = 3.3, s = S / n;
  ctx.strokeStyle = 'rgba(40,40,36,0.55)'; ctx.lineWidth = 4;
  for (let i = 0; i <= n; i++) {
    ctx.beginPath(); ctx.moveTo(i * s, 0); ctx.lineTo(i * s, S); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i * s); ctx.lineTo(S, i * s); ctx.stroke();
  }
  // gum stains / cracks
  for (let i = 0; i < 120; i++) { ctx.fillStyle = `rgba(30,30,30,${0.1 + rng() * 0.3})`; ctx.beginPath(); ctx.arc(rng() * S, rng() * S, 2 + rng() * 5, 0, Math.PI * 2); ctx.fill(); }
  const { c: rc, ctx: rctx } = canvas(256);
  rctx.fillStyle = '#e6e6e6'; rctx.fillRect(0, 0, 256, 256); grain(rctx, 256, 256, 0.2, rng, 3000);
  return new THREE.MeshStandardMaterial({ map: tex(c, true, aniso), roughnessMap: tex(rc, false, aniso), roughness: 1, metalness: 0, envMapIntensity: 0.5 });
}

/** Lane markings for a 6-lane two-way avenue: transparent overlay laid over the V3 asphalt. One tile = full road width x 12 m. */
export function createLaneMarkingTexture(aniso: number, roadWidth: number, laneWidth: number) {
  const W = 1024, H = 512; // H spans 12 m along the road
  const { c, ctx } = canvas(W, H);
  ctx.clearRect(0, 0, W, H);
  const px = (x: number) => (x / roadWidth + 0.5) * W; // x in metres (centre 0)
  const lanes = Math.round(roadWidth / laneWidth);
  const lineW = Math.max(4, W * (0.15 / roadWidth));
  // dashed white lane lines (3 m dash, 9 m gap)
  ctx.fillStyle = 'rgba(236,236,230,0.92)';
  for (let i = 1; i < lanes; i++) {
    if (i === lanes / 2) continue;
    const x = px(-roadWidth / 2 + i * laneWidth);
    ctx.fillRect(x - lineW / 2, 0, lineW, H * 0.25);
  }
  // double yellow centre
  ctx.fillStyle = 'rgba(232,186,60,0.95)';
  ctx.fillRect(px(0) - lineW * 1.6, 0, lineW, H);
  ctx.fillRect(px(0) + lineW * 0.6, 0, lineW, H);
  // solid white edge lines
  ctx.fillStyle = 'rgba(236,236,230,0.9)';
  ctx.fillRect(px(-roadWidth / 2 + 0.3), 0, lineW, H);
  ctx.fillRect(px(roadWidth / 2 - 0.3) - lineW, 0, lineW, H);
  const t = tex(c, true, aniso);
  return new THREE.MeshStandardMaterial({ map: t, transparent: true, roughness: 0.55, metalness: 0, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
}

export function createCrosswalkMaterial(aniso: number) {
  const { c, ctx } = canvas(512, 256);
  ctx.clearRect(0, 0, 512, 256);
  ctx.fillStyle = 'rgba(236,236,230,0.9)';
  for (let i = 0; i < 12; i++) ctx.fillRect(i * 42.6 + 8, 20, 26, 216);
  return new THREE.MeshStandardMaterial({ map: tex(c, true, aniso, false), transparent: true, roughness: 0.55, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
}

/** Ground-floor storefront band: dark glass shops with coloured awnings and signage. One tile = 12 m wide x 4.6 m tall. */
export function createStorefrontMaterial(aniso: number, seed: number) {
  const rng = makeRng(seed);
  const W = 1024, H = 384;
  const { c, ctx } = canvas(W, H);
  ctx.fillStyle = '#3a3733'; ctx.fillRect(0, 0, W, H);
  const shops = 3, sw = W / shops;
  const awn = ['#8d1f24', '#1f5d3a', '#1f3f7a', '#8c6a1f', '#2a2a2a', '#5d1f6e'];
  for (let i = 0; i < shops; i++) {
    const x0 = i * sw;
    // pilaster
    ctx.fillStyle = '#6a6358'; ctx.fillRect(x0, 0, 22, H);
    // glass
    const g = ctx.createLinearGradient(0, 70, 0, H);
    g.addColorStop(0, '#5b6b78'); g.addColorStop(1, '#1b2128');
    ctx.fillStyle = g; ctx.fillRect(x0 + 30, 110, sw - 60, H - 118);
    // door
    ctx.fillStyle = '#2c3238'; ctx.fillRect(x0 + sw * 0.62, 150, 70, H - 158);
    ctx.fillStyle = '#9aa3aa'; ctx.fillRect(x0 + sw * 0.62 + 30, 230, 6, 30);
    // interior glow
    ctx.fillStyle = 'rgba(255,220,170,0.18)'; ctx.fillRect(x0 + 40, 150, sw * 0.5, 120);
    // sign band
    ctx.fillStyle = '#1a1a1c'; ctx.fillRect(x0 + 22, 20, sw - 22, 70);
    ctx.fillStyle = ['#f2d16b', '#ffffff', '#ff6b5e', '#7fd5ff'][Math.floor(rng() * 4)];
    ctx.font = 'bold 44px Barlow, Arial, sans-serif'; ctx.textBaseline = 'middle';
    const names = ['DELI', 'PIZZA', 'BODEGA', 'COFFEE', 'BAGELS', 'PHARMACY', 'DINER', 'NAILS', 'BAR', 'LIQUOR', 'TAILOR', 'BOOKS'];
    ctx.fillText(names[Math.floor(rng() * names.length)], x0 + 48, 55);
    // awning
    if (rng() < 0.65) {
      ctx.fillStyle = awn[Math.floor(rng() * awn.length)];
      ctx.fillRect(x0 + 26, 90, sw - 52, 30);
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.fillRect(x0 + 26, 118, sw - 52, 6);
    }
    // roll-up grille slats sometimes
    if (rng() < 0.2) { ctx.fillStyle = 'rgba(120,120,120,0.55)'; for (let y = 120; y < H; y += 10) ctx.fillRect(x0 + 30, y, sw - 60, 4); }
  }
  return new THREE.MeshStandardMaterial({ map: tex(c, true, aniso), roughness: 0.5, metalness: 0.15, envMapIntensity: 0.8, emissive: new THREE.Color(0xffd8a8), emissiveIntensity: 0.0 });
}

export function createBillboardMaterials(aniso: number) {
  const palettes = [
    ['#0f172a', '#38bdf8', 'DRIVE', 'NIGHT & DAY'],
    ['#7f1d1d', '#fde68a', 'BIG APPLE', 'STREET KINGS'],
    ['#064e3b', '#a7f3d0', 'BROADWAY', 'LIVE TONIGHT'],
    ['#1e1b4b', '#f0abfc', 'MIDTOWN', 'EXPRESS'],
    ['#111827', '#f97316', 'NITRO', '2X BOOST'],
  ];
  return palettes.map(([bg, fg, a, b], i) => {
    const { c, ctx } = canvas(512, 256);
    ctx.fillStyle = bg; ctx.fillRect(0, 0, 512, 256);
    ctx.fillStyle = fg; ctx.fillRect(24, 24, 464, 6);
    ctx.font = 'italic 900 78px Barlow Condensed, Barlow, Arial, sans-serif'; ctx.textBaseline = 'top';
    ctx.fillText(a, 32, 48);
    ctx.font = '700 40px Barlow, Arial, sans-serif'; ctx.fillStyle = '#ffffff';
    ctx.fillText(b, 34, 150);
    ctx.fillStyle = fg; ctx.fillRect(24, 226, 464, 6);
    const m = new THREE.MeshStandardMaterial({ map: tex(c, true, aniso, false), roughness: 0.6, metalness: 0, emissive: new THREE.Color(0xffffff), emissiveMap: null, emissiveIntensity: 0 });
    m.name = `billboard-${i}`;
    return m;
  });
}
