/**
 * Lightweight procedural SFX layer for the street racer (near-miss whoosh, NOS hiss,
 * impacts, curb scrape, wind). Runs on its own AudioContext next to the BMW engine core.
 */
export function createSfx() {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let enabled = true;
  let noiseBuffer: AudioBuffer | null = null;
  let wind: { src: AudioBufferSourceNode; gain: GainNode; filter: BiquadFilterNode } | null = null;
  let nos: { src: AudioBufferSourceNode; gain: GainNode; filter: BiquadFilterNode } | null = null;

  function ensure() {
    if (ctx) { if (ctx.state !== 'running') void ctx.resume(); return ctx; }
    const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC({ latencyHint: 'interactive' });
    master = ctx.createGain();
    master.gain.value = enabled ? 0.9 : 0;
    master.connect(ctx.destination);
    const len = ctx.sampleRate * 2;
    noiseBuffer = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuffer.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // constant wind bed
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer; src.loop = true;
    const filter = ctx.createBiquadFilter(); filter.type = 'bandpass'; filter.frequency.value = 400; filter.Q.value = 0.6;
    const gain = ctx.createGain(); gain.gain.value = 0;
    src.connect(filter); filter.connect(gain); gain.connect(master);
    src.start();
    wind = { src, gain, filter };
    // NOS hiss layer
    const nsrc = ctx.createBufferSource(); nsrc.buffer = noiseBuffer; nsrc.loop = true;
    const nf = ctx.createBiquadFilter(); nf.type = 'highpass'; nf.frequency.value = 1800;
    const ng = ctx.createGain(); ng.gain.value = 0;
    nsrc.connect(nf); nf.connect(ng); ng.connect(master);
    nsrc.start();
    nos = { src: nsrc, gain: ng, filter: nf };
    return ctx;
  }

  function burst(duration: number, filterType: BiquadFilterType, freqFrom: number, freqTo: number, level: number, q = 1) {
    const c = ensure(); if (!c || !master || !noiseBuffer || !enabled) return;
    const src = c.createBufferSource(); src.buffer = noiseBuffer;
    const f = c.createBiquadFilter(); f.type = filterType; f.Q.value = q;
    const g = c.createGain();
    const t = c.currentTime;
    f.frequency.setValueAtTime(freqFrom, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, freqTo), t + duration);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(level, t + Math.min(0.03, duration * 0.2));
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t); src.stop(t + duration + 0.05);
    src.onended = () => { g.disconnect(); f.disconnect(); };
  }

  function tone(freq: number, duration: number, level: number, type: OscillatorType = 'sine', slideTo?: number) {
    const c = ensure(); if (!c || !master || !enabled) return;
    const o = c.createOscillator(), g = c.createGain(), t = c.currentTime;
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + duration);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(level, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + duration + 0.02);
    o.onended = () => g.disconnect();
  }

  return {
    unlock() { ensure(); },
    setEnabled(v: boolean) { enabled = v; if (master && ctx) master.gain.setTargetAtTime(v ? 0.9 : 0, ctx.currentTime, 0.05); },
    whoosh(closeness: number, oncoming: boolean) {
      burst(0.32 + closeness * 0.15, 'bandpass', oncoming ? 2600 : 1800, 240, 0.28 + closeness * 0.3, 1.4);
      tone(oncoming ? 920 : 760, 0.12, 0.05, 'triangle', oncoming ? 1500 : 1180);
    },
    nitro(on: boolean) {
      if (on) { burst(0.5, 'lowpass', 900, 3200, 0.35, 0.8); tone(180, 0.4, 0.08, 'sawtooth', 420); }
      else burst(0.35, 'highpass', 3000, 600, 0.12, 0.7);
    },
    crash(intensity: number) {
      burst(0.28 + intensity * 0.25, 'lowpass', 1400, 90, 0.45 + intensity * 0.5, 0.9);
      tone(90, 0.35, 0.18 + intensity * 0.2, 'triangle', 42);
      burst(0.5, 'highpass', 5000, 2000, 0.12 + intensity * 0.2, 0.5); // glass tinkle
    },
    scrape(intensity: number) { burst(0.25, 'bandpass', 3200, 2200, 0.1 + intensity * 0.18, 3); },
    wreck() { burst(1.2, 'lowpass', 600, 60, 0.6, 0.7); tone(70, 1.1, 0.25, 'sawtooth', 30); },
    update(_dt: number, speedRatio: number, nitroActive: boolean) {
      if (!ctx || !wind || !nos) return;
      const t = ctx.currentTime;
      const w = Math.max(0, speedRatio - 0.12);
      wind.gain.gain.setTargetAtTime(enabled ? w * w * 0.55 : 0, t, 0.12);
      wind.filter.frequency.setTargetAtTime(300 + speedRatio * 1400, t, 0.15);
      nos.gain.gain.setTargetAtTime(enabled && nitroActive ? 0.16 : 0, t, 0.08);
      nos.filter.frequency.setTargetAtTime(1200 + speedRatio * 2600, t, 0.1);
    },
    dispose() {
      try { wind?.src.stop(); nos?.src.stop(); } catch { /* already stopped */ }
      void ctx?.close();
      ctx = null; master = null; wind = null; nos = null;
    },
  };
}
export type Sfx = ReturnType<typeof createSfx>;
