import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Camera, Flame, Gauge, Home, MoonStar, Pause, Play, RotateCcw, SlidersHorizontal, Sun, Sunset, Trophy, Volume2, VolumeX, Wrench, X } from 'lucide-react';
import { createEngine, type CameraMode, type Engine, type GameEvent, type GamePhase, type LightingSnapshot, type Telemetry } from './game/engine';
import type { TimeOfDay } from './game/lighting';
import { LIGHT_SLIDERS } from '../rc-drift/pigeon/drive-lighting';
import './nyc.css';

const SETTINGS_KEY = 'nyc-street.settings.v2';
type Settings = { sound: boolean; camera: CameraMode; mood: TimeOfDay };
const CAMERAS: CameraMode[] = ['chase', 'cockpit', 'hood', 'far'];
const CAMERA_LABEL: Record<CameraMode, string> = { chase: 'Belakang', cockpit: 'Kokpit', hood: 'Bemper', far: 'Jauh' };
function readSettings(): Settings {
  try {
    const v = JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? '{}');
    return { sound: v.sound !== false, camera: (CAMERAS.includes(v.camera) ? v.camera : 'chase') as CameraMode, mood: (['day', 'dusk', 'night'].includes(v.mood) ? v.mood : 'day') as TimeOfDay };
  } catch { return { sound: true, camera: 'chase', mood: 'day' }; }
}
function saveSettings(s: Settings) { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* optional */ } }

const emptyTelemetry: Telemetry = { phase: 'ready', kmh: 0, nitro: 55, nitroActive: false, health: 100, score: 0, distance: 0, time: 0, combo: 0, nearMisses: 0, overtakes: 0, crashes: 0, gear: '1', rpm: 0.15, camera: 'chase', mood: 'day', topSpeed: 0, best: 0, slipDeg: 0, drifting: false, driftPoints: 0, driftBanked: 0, handbrake: false };

type Toast = { id: number; text: string; sub?: string; tone: 'gold' | 'red' | 'blue' | 'white' | 'violet' };

const fmt = (n: number) => Math.floor(n).toLocaleString('id-ID');
const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

const SUN_SLIDERS: { key: 'sunElevation' | 'sunAzimuth' | 'godRays' | 'fog' | 'exposure'; name: string; min: number; max: number; step: number; unit: string; desc: string }[] = [
  { key: 'sunElevation', name: 'Elevasi matahari', min: 6, max: 80, step: 1, unit: '°', desc: 'Tinggi matahari di atas cakrawala (bayangan gedung memanjang saat rendah)' },
  { key: 'sunAzimuth', name: 'Azimuth matahari', min: -180, max: 180, step: 1, unit: '°', desc: '0° = lurus di ujung avenue, ±90° = dari sisi gedung' },
  { key: 'godRays', name: 'God rays', min: 0, max: 2.5, step: 0.05, unit: '×', desc: 'Sinar volumetrik di antara pencakar langit' },
  { key: 'fog', name: 'Kabut kota', min: 0.2, max: 2.5, step: 0.05, unit: '×', desc: 'Kepekatan haze (sama dengan slider kabut Haruna V3)' },
  { key: 'exposure', name: 'Exposure', min: 0.4, max: 2, step: 0.05, unit: '×', desc: 'Kecerahan komposit volumetrik' },
];

export default function NycStreetGame({ onExit, onGarage }: { onExit?: () => void; onGarage?: () => void }) {
  const host = useRef<HTMLDivElement>(null);
  const engine = useRef<Engine | undefined>(undefined);
  const [settings, setSettings] = useState<Settings>(readSettings);
  const [telemetry, setTelemetry] = useState<Telemetry>(emptyTelemetry);
  const [phase, setPhase] = useState<GamePhase>('ready');
  const [progress, setProgress] = useState({ label: 'Memuat…', pct: 0 });
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [flash, setFlash] = useState<'crash' | 'nitro' | null>(null);
  const [final, setFinal] = useState<{ score: number; best: boolean } | null>(null);
  const [showHelp, setShowHelp] = useState(false);
  const [lightPanel, setLightPanel] = useState(false);
  const [light, setLight] = useState<LightingSnapshot | null>(null);
  const toastId = useRef(0);
  const phaseRef = useRef<GamePhase>('ready');
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const pushToast = useCallback((text: string, tone: Toast['tone'], sub?: string) => {
    const id = ++toastId.current;
    setToasts(t => [...t.slice(-3), { id, text, sub, tone }]);
    window.setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 1400);
  }, []);

  useEffect(() => {
    const abort = new AbortController();
    const el = host.current!;
    let disposed = false;
    createEngine(el, {
      onTelemetry: t => { setTelemetry(t); if (t.phase !== phaseRef.current) { phaseRef.current = t.phase; setPhase(t.phase); } },
      onEvent: (e: GameEvent) => {
        if (e.type === 'nearMiss') pushToast(`NEAR MISS +${fmt(e.points)}`, e.oncoming ? 'red' : 'gold', e.combo > 1 ? `COMBO x${e.combo}${e.oncoming ? ' · LAWAN ARAH 2X' : ''}` : e.oncoming ? 'LAWAN ARAH 2X' : undefined);
        else if (e.type === 'crash') { pushToast(e.headOn ? 'TABRAKAN FRONTAL!' : 'TABRAKAN', 'red', `-${Math.round(e.damage)} kondisi`); setFlash('crash'); window.setTimeout(() => setFlash(null), 260); }
        else if (e.type === 'nitro') { if (e.on) { setFlash('nitro'); window.setTimeout(() => setFlash(null), 400); } }
        else if (e.type === 'drift') pushToast(e.lost ? 'DRIFT HILANG' : `DRIFT +${fmt(e.points)}`, e.lost ? 'red' : 'violet', e.lost ? 'tabrakan membatalkan skor' : `${e.seconds.toFixed(1)} dtk · NOS terisi`);
        else if (e.type === 'milestone') pushToast(`${fmt(e.distance)} M`, 'blue', '+150 BONUS JARAK');
        else if (e.type === 'wrecked') { setFinal({ score: e.score, best: e.best }); phaseRef.current = 'wrecked'; setPhase('wrecked'); }
      },
      onProgress: (label, pct) => setProgress({ label, pct }),
    }, abort.signal, { sound: settingsRef.current.sound, headlights: settingsRef.current.mood !== 'day', camera: settingsRef.current.camera, mood: settingsRef.current.mood })
      .then(e => { if (disposed) { e?.dispose(); return; } engine.current = e; if (e) { setLight(e.lighting()); } setReady(Boolean(e)); })
      .catch(err => { console.error(err); setProgress({ label: 'Gagal memuat WebGL. Coba browser lain.', pct: 1 }); });
    return () => { disposed = true; abort.abort(); engine.current?.dispose(); engine.current = undefined; };
  }, [pushToast]);

  // Keyboard
  useEffect(() => {
    const steer = { left: false, right: false };
    const apply = () => engine.current?.setInput({ steer: (steer.left ? 1 : 0) - (steer.right ? 1 : 0) });
    const down = (e: KeyboardEvent) => {
      if (e.repeat && !['Space', 'ShiftLeft', 'ShiftRight', 'KeyN'].includes(e.code)) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'BUTTON') && e.code !== 'Escape') return;
      switch (e.code) {
        case 'KeyA': case 'ArrowLeft': steer.left = true; apply(); e.preventDefault(); break;
        case 'KeyD': case 'ArrowRight': steer.right = true; apply(); e.preventDefault(); break;
        case 'KeyS': case 'ArrowDown': engine.current?.setInput({ brake: true }); e.preventDefault(); break;
        case 'KeyW': case 'ArrowUp': engine.current?.setInput({ power: true }); e.preventDefault(); break;
        case 'Space': if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ handbrake: true }); e.preventDefault(); break;
        case 'ShiftLeft': case 'ShiftRight': case 'KeyN':
          if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ nitro: true });
          e.preventDefault(); break;
        case 'Enter': if (phaseRef.current === 'ready') startRun(); else if (phaseRef.current === 'wrecked') restart(); break;
        case 'KeyR': if (phaseRef.current !== 'ready') restart(); break;
        case 'KeyC': if (engine.current) { const m = engine.current.cycleCamera(); setSettings(s => { const n = { ...s, camera: m }; saveSettings(n); return n; }); } break;
        case 'KeyT': if (engine.current) { const m = engine.current.cycleMood(); setSettings(s => { const n = { ...s, mood: m }; saveSettings(n); return n; }); } break;
        case 'KeyL': setLightPanel(v => !v); break;
        case 'KeyM': toggleSound(); break;
        case 'KeyP': case 'Escape': togglePause(); break;
        case 'KeyH': setShowHelp(v => !v); break;
      }
    };
    const up = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyA': case 'ArrowLeft': steer.left = false; apply(); break;
        case 'KeyD': case 'ArrowRight': steer.right = false; apply(); break;
        case 'KeyS': case 'ArrowDown': engine.current?.setInput({ brake: false }); break;
        case 'KeyW': case 'ArrowUp': engine.current?.setInput({ power: false }); break;
        case 'Space': engine.current?.setInput({ handbrake: false }); break;
        case 'ShiftLeft': case 'ShiftRight': case 'KeyN': engine.current?.setInput({ nitro: false }); break;
      }
    };
    const blur = () => { steer.left = steer.right = false; apply(); engine.current?.setInput({ brake: false, nitro: false, power: false, handbrake: false }); };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up); window.addEventListener('blur', blur);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', blur); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function startRun() { engine.current?.unlockAudio(); engine.current?.start(); setFinal(null); }
  function restart() { engine.current?.restart(); setFinal(null); setToasts([]); }
  function togglePause() {
    if (phaseRef.current === 'running') engine.current?.pause(true);
    else if (phaseRef.current === 'paused') engine.current?.pause(false);
  }
  function toggleSound() {
    setSettings(s => { const n = { ...s, sound: !s.sound }; saveSettings(n); engine.current?.sound(n.sound); return n; });
  }
  function setCamera(m: CameraMode) { engine.current?.camera(m); setSettings(s => { const n = { ...s, camera: m }; saveSettings(n); return n; }); }
  function setMood(m: TimeOfDay) { engine.current?.mood(m); setSettings(s => { const n = { ...s, mood: m }; saveSettings(n); return n; }); }

  const touch = (patch: Parameters<Engine['setInput']>[0]) => () => engine.current?.setInput(patch);

  const t = telemetry;
  const speedRatio = Math.min(1, t.kmh / 446);
  const nitroLow = t.nitro < 8;
  const healthTone = t.health > 60 ? '#7ef0a0' : t.health > 30 ? '#ffb248' : '#ff4d4d';
  const nextCamera = CAMERAS[(CAMERAS.indexOf(settings.camera) + 1) % CAMERAS.length];

  return (
    <div className="nyc-root" data-phase={phase}>
      <div ref={host} className="nyc-canvas" onPointerDown={() => engine.current?.unlockAudio()} />

      <div className={`nyc-vignette ${t.nitroActive ? 'is-nitro' : ''} ${t.health < 30 && phase === 'running' ? 'is-hurt' : ''}`} aria-hidden="true" />
      {flash && <div className={`nyc-flash nyc-flash-${flash}`} aria-hidden="true" />}

      {!ready && (
        <div className="nyc-overlay nyc-loading">
          <div className="nyc-brand"><span>NYC</span> STREET KINGS</div>
          <div className="nyc-progress"><div style={{ width: `${Math.round(progress.pct * 100)}%` }} /></div>
          <p>{progress.label}</p>
        </div>
      )}

      {ready && (
        <>
          <header className="nyc-top">
            <div className="nyc-top-left">
              {onExit && <button type="button" className="nyc-icon" onClick={onExit} title="Kembali ke menu (F2)" aria-label="Kembali ke menu"><Home size={18} /></button>}
              <button type="button" className="nyc-icon" onClick={toggleSound} title="Suara (M)" aria-label="Suara">{settings.sound ? <Volume2 size={18} /> : <VolumeX size={18} />}</button>
              <button type="button" className="nyc-icon nyc-icon-wide" onClick={() => setCamera(nextCamera)} title="Kamera (C)" aria-label="Kamera"><Camera size={18} /><span>{CAMERA_LABEL[settings.camera]}</span></button>
              <button type="button" className="nyc-icon" onClick={() => setMood(settings.mood === 'day' ? 'dusk' : settings.mood === 'dusk' ? 'night' : 'day')} title="Waktu (T)" aria-label="Waktu">
                {settings.mood === 'day' ? <Sun size={18} /> : settings.mood === 'dusk' ? <Sunset size={18} /> : <MoonStar size={18} />}
              </button>
              <button type="button" className={`nyc-icon ${lightPanel ? 'is-on' : ''}`} onClick={() => setLightPanel(v => !v)} title="Pencahayaan & sudut matahari (L)" aria-label="Pencahayaan"><SlidersHorizontal size={18} /></button>
              {phase !== 'ready' && <button type="button" className="nyc-icon" onClick={togglePause} title="Pause (P)" aria-label="Pause">{phase === 'paused' ? <Play size={18} /> : <Pause size={18} />}</button>}
            </div>
            <div className="nyc-score">
              <small>SKOR</small>
              <b>{fmt(t.score)}</b>
              <span><Trophy size={11} /> {fmt(Math.max(t.best, t.score))}</span>
            </div>
            <div className="nyc-stats">
              <div><small>JARAK</small><b>{(t.distance / 1000).toFixed(2)}<i>km</i></b></div>
              <div><small>WAKTU</small><b>{fmtTime(t.time)}</b></div>
              <div><small>NEAR MISS</small><b>{t.nearMisses}</b></div>
              <div><small>DRIFT</small><b>{fmt(t.driftBanked)}</b></div>
            </div>
          </header>

          {t.combo > 1 && phase === 'running' && <div className="nyc-combo" key={t.combo}>COMBO <b>x{t.combo}</b></div>}

          {(t.drifting || t.driftPoints > 0) && phase === 'running' && (
            <div className={`nyc-drift ${t.drifting ? 'is-live' : ''}`}>
              <small>{t.handbrake ? 'E-BRAKE DRIFT' : 'DRIFT'} · {Math.abs(Math.round(t.slipDeg))}°</small>
              <b>+{fmt(t.driftPoints)}</b>
            </div>
          )}

          <div className="nyc-toasts" aria-live="polite">
            {toasts.map(x => <div key={x.id} className={`nyc-toast tone-${x.tone}`}><b>{x.text}</b>{x.sub && <small>{x.sub}</small>}</div>)}
          </div>

          <footer className="nyc-bottom">
            <div className="nyc-health">
              <small><Wrench size={11} /> KONDISI</small>
              <div className="nyc-bar"><div style={{ width: `${t.health}%`, background: healthTone }} /></div>
            </div>
            <div className={`nyc-speedo ${t.nitroActive ? 'is-nitro' : ''}`}>
              <svg viewBox="0 0 200 120" aria-hidden="true">
                <path d="M20 110 A80 80 0 0 1 180 110" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="10" strokeLinecap="round" />
                <path d="M20 110 A80 80 0 0 1 180 110" fill="none" stroke={t.nitroActive ? '#58d8ff' : '#ffb248'} strokeWidth="10" strokeLinecap="round" strokeDasharray={`${speedRatio * 251.3} 251.3`} style={{ filter: t.nitroActive ? 'drop-shadow(0 0 8px #58d8ff)' : 'drop-shadow(0 0 6px rgba(255,178,72,.55))' }} />
                <path d="M100 110 L100 30" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="1" transform={`rotate(${-90 + speedRatio * 180} 100 110)`} />
              </svg>
              <div className="nyc-kmh"><b>{Math.round(t.kmh)}</b><small>km/h</small></div>
              <div className="nyc-gear"><span>{t.gear === 'R' ? 'R' : `G${t.gear}`}</span><i style={{ width: `${Math.round(t.rpm * 100)}%` }} /></div>
            </div>
            <div className={`nyc-nitro ${t.nitroActive ? 'is-active' : ''} ${nitroLow ? 'is-low' : ''}`}>
              <small><Flame size={11} /> NOS <em>2X</em></small>
              <div className="nyc-bar nyc-bar-nitro"><div style={{ width: `${t.nitro}%` }} /></div>
              <span>{t.nitroActive ? 'BOOST AKTIF' : nitroLow ? 'ISI: NEAR MISS / DRIFT' : 'TAHAN SHIFT / N'}</span>
            </div>
          </footer>

          <div className="nyc-touch" aria-hidden="true">
            <button type="button" className="nyc-tbtn nyc-tbtn-left" onPointerDown={touch({ steer: 1 })} onPointerUp={touch({ steer: 0 })} onPointerCancel={touch({ steer: 0 })} onPointerLeave={touch({ steer: 0 })}>◀</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-right" onPointerDown={touch({ steer: -1 })} onPointerUp={touch({ steer: 0 })} onPointerCancel={touch({ steer: 0 })} onPointerLeave={touch({ steer: 0 })}>▶</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-brake" onPointerDown={touch({ brake: true })} onPointerUp={touch({ brake: false })} onPointerCancel={touch({ brake: false })} onPointerLeave={touch({ brake: false })}>REM</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-drift" onPointerDown={touch({ handbrake: true })} onPointerUp={touch({ handbrake: false })} onPointerCancel={touch({ handbrake: false })} onPointerLeave={touch({ handbrake: false })}>DRIFT</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-nos" onPointerDown={() => { if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ nitro: true }); }} onPointerUp={touch({ nitro: false })} onPointerCancel={touch({ nitro: false })} onPointerLeave={touch({ nitro: false })}>NOS</button>
          </div>

          {lightPanel && light && (
            <aside className="nyc-light" aria-label="Pengaturan pencahayaan">
              <header>
                <div><p className="nyc-kicker">RIG MT. HARUNA V3 · TERSINKRON</p><h3>Matahari & Cahaya</h3></div>
                <button type="button" className="nyc-icon" onClick={() => setLightPanel(false)} aria-label="Tutup"><X size={16} /></button>
              </header>
              <div className="nyc-light-moods">
                {(['day', 'dusk', 'night'] as TimeOfDay[]).map(m => <button key={m} type="button" aria-pressed={settings.mood === m} onClick={() => setMood(m)}>{m === 'day' ? 'Siang' : m === 'dusk' ? 'Senja' : 'Malam'}</button>)}
              </div>
              {SUN_SLIDERS.map(sl => (
                <label key={sl.key} className="nyc-slider">
                  <span>{sl.name}<em>{sl.unit === '°' ? `${Math.round(light.v2[sl.key])}°` : `${light.v2[sl.key].toFixed(2)}×`}</em></span>
                  <input type="range" min={sl.min} max={sl.max} step={sl.step} value={light.v2[sl.key]}
                    onChange={e => { const next = engine.current?.setSun({ [sl.key]: Number(e.target.value) }); if (next) setLight(next); }} />
                  <small>{sl.desc}</small>
                </label>
              ))}
              {LIGHT_SLIDERS.map(sl => (
                <label key={sl.key} className="nyc-slider">
                  <span>{sl.name}<em>{light.state[sl.key]}%</em></span>
                  <input type="range" min={0} max={100} step={1} value={light.state[sl.key]}
                    onChange={e => { const next = engine.current?.setLightLevels({ [sl.key]: Number(e.target.value) }); if (next) setLight(next); }} />
                  <small>{sl.desc}</small>
                </label>
              ))}
              <div className="nyc-light-actions">
                <button type="button" className="nyc-secondary" onClick={() => { const next = engine.current?.resetLighting(); if (next) setLight(next); }}><RotateCcw size={14} /> Reset ke preset V3 (42° / 28°)</button>
              </div>
            </aside>
          )}
        </>
      )}

      {ready && phase === 'ready' && !lightPanel && (
        <div className="nyc-overlay nyc-start">
          <div className="nyc-start-card">
            <p className="nyc-kicker">PRODRIFT · MANHATTAN AVENUE · FISIKA DRIFT & PENCAHAYAAN MT. HARUNA V3</p>
            <h1 className="nyc-brand"><span>NYC</span> STREET KINGS</h1>
            <p className="nyc-lede">Pacu Group B di avenue 6 lajur Manhattan dengan fisika drift Mt. Haruna: bebas belok, <b>E-brake drift</b>, power-over, manji antar lajur. Salip serapat mungkin untuk <b>NEAR MISS</b>, isi tabung <b>NOS</b>, lalu boost ke <b>2x kecepatan maksimal (446 km/h)</b>. Lajur kiri lawan arah = poin ganda, risiko ganda. <b>Awas perempatan — mobil melintas!</b></p>
            <div className="nyc-keys">
              <div><kbd>A</kbd><kbd>D</kbd> / <kbd>◀</kbd><kbd>▶</kbd><span>Belok</span></div>
              <div><kbd>SPASI</kbd><span>Handbrake / E-brake drift</span></div>
              <div><kbd>SHIFT</kbd> / <kbd>N</kbd><span>NOS 2X</span></div>
              <div><kbd>W</kbd> / <kbd>▲</kbd><span>Gas penuh (power-over)</span></div>
              <div><kbd>S</kbd> / <kbd>▼</kbd><span>Rem / mundur</span></div>
              <div><kbd>C</kbd><span>Kamera: belakang · kokpit · bemper · jauh</span></div>
              <div><kbd>L</kbd><span>Sudut matahari & cahaya</span></div>
              <div><kbd>T</kbd><span>Siang / Senja / Malam</span></div>
              <div><kbd>R</kbd><span>Ulang</span></div>
            </div>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={startRun}><Play size={20} /> MULAI BALAPAN</button>
              {onGarage && <button type="button" className="nyc-secondary" onClick={onGarage}><Wrench size={16} /> Garasi & Arena Klasik</button>}
              <button type="button" className="nyc-secondary" onClick={() => setLightPanel(true)}><SlidersHorizontal size={16} /> Atur matahari</button>
            </div>
            {t.best > 0 && <p className="nyc-best"><Trophy size={13} /> Rekor terbaik: <b>{fmt(t.best)}</b></p>}
          </div>
        </div>
      )}

      {phase === 'paused' && (
        <div className="nyc-overlay nyc-pause">
          <div className="nyc-start-card nyc-compact">
            <h2>JEDA</h2>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={() => engine.current?.pause(false)}><Play size={18} /> Lanjut</button>
              <button type="button" className="nyc-secondary" onClick={restart}><RotateCcw size={16} /> Ulang</button>
              {onExit && <button type="button" className="nyc-secondary" onClick={onExit}><ArrowLeft size={16} /> Menu</button>}
            </div>
          </div>
        </div>
      )}

      {phase === 'wrecked' && final && (
        <div className="nyc-overlay nyc-over">
          <div className="nyc-start-card">
            <p className="nyc-kicker">MOBIL RUSAK TOTAL</p>
            <h2>{final.best ? 'REKOR BARU!' : 'RUN SELESAI'}</h2>
            <div className="nyc-final"><small>SKOR</small><b>{fmt(final.score)}</b></div>
            <div className="nyc-grid">
              <div><small>Jarak</small><b>{(t.distance / 1000).toFixed(2)} km</b></div>
              <div><small>Top speed</small><b>{Math.round(t.topSpeed)} km/h</b></div>
              <div><small>Near miss</small><b>{t.nearMisses}</b></div>
              <div><small>Skor drift</small><b>{fmt(t.driftBanked)}</b></div>
              <div><small>Tabrakan</small><b>{t.crashes}</b></div>
              <div><small>Waktu</small><b>{fmtTime(t.time)}</b></div>
            </div>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={restart}><RotateCcw size={18} /> BALAP LAGI</button>
              {onExit && <button type="button" className="nyc-secondary" onClick={onExit}><ArrowLeft size={16} /> Menu</button>}
            </div>
          </div>
        </div>
      )}

      {showHelp && (
        <div className="nyc-help">
          <b><Gauge size={12} /> Tips</b> Near miss &lt; 1,15 m mengisi NOS · drift dibank saat slide berakhir (juga mengisi NOS) · lawan arah 2x poin · tabrakan membatalkan drift & combo · kondisi pulih jika 6 detik tanpa benturan.
        </div>
      )}
    </div>
  );
}
