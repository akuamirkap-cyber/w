import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig, type Plugin } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const POKI_SDK_TAG = '<script src="https://game-cdn.poki.com/scripts/v2/poki-sdk.js"></script>';

function pokiHeadSdkPlugin(): Plugin {
  return {
    name: "poki-head-sdk",
    transformIndexHtml(html) {
      if (process.env.VITE_ADS_PLATFORM !== "poki") return html;
      if (html.includes("poki-sdk.js")) return html;
      return html.replace("</head>", `  ${POKI_SDK_TAG}\n  </head>`);
    },
  };
}

// https://vite.dev/config/
export default defineConfig(() => {
  const useSingleFile = process.env.SINGLE_FILE === "1";
  return {
    base: "./",
    plugins: [
      react(),
      tailwindcss(),
      pokiHeadSdkPlugin(),
      ...(useSingleFile ? [viteSingleFile()] : []),
    ],
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "src"),
      },
    },
  };
});
