import React, { useRef, useState, useLayoutEffect } from 'react';
import { setFrameScale } from '../utils/frameScale';

interface ScaledFrameProps {
  baseWidth: number;
  baseHeight: number;
  children: React.ReactNode;
}

/**
 * Scales a fixed-size stage (`baseWidth` x `baseHeight`, 16:9 for this game)
 * proportionally so it always fits its container: the whole stage is visible,
 * the aspect ratio never changes, and the stage is centred. On a 16:9 viewport
 * (640x360, 836x470, 1031x580, 1920x1080, ...) it fills the screen edge to edge.
 */
export default function ScaledFrame({ baseWidth, baseHeight, children }: ScaledFrameProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState<number | null>(null);

  useLayoutEffect(() => {
    let retry = 0;
    let raf = 0;
    const updateScale = () => {
      if (!containerRef.current) return;
      const { clientWidth, clientHeight } = containerRef.current;
      if (clientWidth > 0 && clientHeight > 0) {
        // Uniform "contain" fit: the same factor on both axes keeps 16:9 exact.
        const s = Math.max(0.05, Math.min(clientWidth / baseWidth, clientHeight / baseHeight));
        setScale(s);
        setFrameScale(s);
        retry = 0;
      } else if (retry < 60) {
        retry += 1;
        raf = requestAnimationFrame(updateScale);
      }
    };

    updateScale();
    const observer = new ResizeObserver(updateScale);
    if (containerRef.current) observer.observe(containerRef.current);
    window.addEventListener('resize', updateScale);
    window.addEventListener('orientationchange', updateScale);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      window.removeEventListener('resize', updateScale);
      window.removeEventListener('orientationchange', updateScale);
    };
  }, [baseWidth, baseHeight]);

  const currentScale = scale ?? 1;

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative overflow-hidden flex items-center justify-center bg-[#05060a] select-none"
    >
      <div
        style={{
          width: baseWidth,
          height: baseHeight,
          transform: `scale(${currentScale})`,
          transformOrigin: 'center center',
          willChange: 'transform',
          flexShrink: 0,
          opacity: scale === null ? 0 : 1,
        }}
        className="relative overflow-hidden"
      >
        {children}
      </div>
    </div>
  );
}
