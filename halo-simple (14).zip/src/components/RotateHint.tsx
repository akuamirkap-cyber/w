import { useEffect, useState } from 'react';
import { useLanguage } from '../i18n/useLanguage';

/**
 * Small, non-blocking nudge shown under the 16:9 stage when a phone is held
 * upright. The stage itself is still rendered (letterboxed) — the game never
 * refuses to run — but at 412 px wide a 16:9 stage is only ~232 px tall, so
 * the player is told that turning the phone gives the full-size picture.
 *
 * Hidden on desktop-sized portrait windows (the stage is already big enough)
 * and after the player dismisses it for the session.
 */
const PORTRAIT_QUERY = '(orientation: portrait) and (max-width: 820px)';

function useIsNarrowPortrait(): boolean {
  const [narrowPortrait, setNarrowPortrait] = useState(() =>
    typeof window !== 'undefined' && typeof window.matchMedia === 'function'
      ? window.matchMedia(PORTRAIT_QUERY).matches
      : false,
  );
  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return;
    const mq = window.matchMedia(PORTRAIT_QUERY);
    const update = () => setNarrowPortrait(mq.matches);
    update();
    mq.addEventListener?.('change', update);
    return () => mq.removeEventListener?.('change', update);
  }, []);
  return narrowPortrait;
}

export default function RotateHint() {
  const narrowPortrait = useIsNarrowPortrait();
  const [dismissed, setDismissed] = useState(false);
  const [language] = useLanguage();
  if (!narrowPortrait || dismissed) return null;

  const copy =
    language === 'id'
      ? { title: 'Putar perangkat ke landscape', body: 'Game ini dirancang untuk layar 16:9.', close: 'Tutup' }
      : { title: 'Rotate your device to landscape', body: 'This game is designed for a 16:9 screen.', close: 'Dismiss' };

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-[60] flex justify-center px-4"
      style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 18px)' }}
      role="status"
      aria-live="polite"
    >
      <div className="pointer-events-auto flex max-w-sm items-center gap-3 rounded-2xl border border-white/10 bg-[#0d1117]/95 px-4 py-3 text-slate-100 shadow-[0_12px_40px_rgba(0,0,0,0.6)] backdrop-blur">
        <span
          aria-hidden="true"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500/15 text-sky-300"
        >
          <svg
            viewBox="0 0 24 24"
            className="h-6 w-6"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ animation: 'rotate-hint-spin 2.4s ease-in-out infinite' }}
          >
            <rect x="7" y="2.5" width="10" height="19" rx="2" />
            <path d="M11 18.5h2" />
          </svg>
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-bold leading-tight tracking-wide">{copy.title}</div>
          <div className="mt-0.5 text-[11px] leading-snug text-slate-400">{copy.body}</div>
        </div>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          className="shrink-0 rounded-lg px-2 py-1 text-[11px] font-semibold text-slate-300 hover:bg-white/10 active:bg-white/15"
          aria-label={copy.close}
        >
          ✕
        </button>
      </div>
      <style>{`
        @keyframes rotate-hint-spin {
          0%, 20% { transform: rotate(0deg); }
          55%, 80% { transform: rotate(90deg); }
          100% { transform: rotate(0deg); }
        }
      `}</style>
    </div>
  );
}
