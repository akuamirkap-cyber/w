/**
 * Live CSS scale of the 16:9 game stage.
 *
 * The game draws into fixed, world-sized canvases (landscape 760x420) that the
 * shell scales with a CSS `transform` so the whole stage always fits the
 * viewport at exactly 16:9 (640x360, 836x470, 1031x580, 1920x1080, ...).
 *
 * A CSS transform does not change `devicePixelRatio`, so without this store a
 * 760 px wide canvas shown at Full HD would be rasterised at 760 px and then
 * stretched 2.5x — visibly soft. `ScaledFrame` publishes its current scale here
 * and `mobilePerf.ts` folds it into the backing-store DPR every canvas asks
 * for, which keeps the vector art crisp at every standard 16:9 size.
 */
let frameScale = 1;
const listeners = new Set<(scale: number) => void>();

/** Current stage scale (CSS px of one world px). Always finite and > 0. */
export function getFrameScale(): number {
  return frameScale;
}

/**
 * Publish a new stage scale. Tiny changes (sub-percent) are ignored so a mobile
 * address-bar collapse does not rebuild every canvas backing store.
 */
export function setFrameScale(next: number): void {
  if (!Number.isFinite(next) || next <= 0) return;
  if (Math.abs(next - frameScale) < 0.005) return;
  frameScale = next;
  for (const listener of listeners) {
    try {
      listener(frameScale);
    } catch {
      /* one broken listener must not stop the others */
    }
  }
}

/** Subscribe to scale changes; returns the unsubscribe function. */
export function subscribeFrameScale(listener: (scale: number) => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
