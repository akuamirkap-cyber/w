import { JUICE, levelConfig } from '../../perfect-shot/play/levels';
import type { BossHead } from './bossCatalog';
import { bossHeadFor } from './bossIdentity';
import { bossLaughEyeOpacity, drawBossLaughEyes } from './bossExpressions';
import { drawBossAngryFace, drawBossDefeatFace, drawBossLaughExtras } from './bossFaceFx';
import { drawFace, type Style } from './faces';
import { drawRgbGlowSprite } from './art/glowSprite';
import { W } from './layout';

const TAU = Math.PI * 2;

/** Player lives in a Swarm run. */
export const SWARM_MAX_LIVES = 3;

/** Dead-center bullseye radius fraction: hitting within this earns the full 10 coins. */
export const SWARM_BULLSEYE_RATIO = 0.17;

/** Radius of regular thrown Swarm wheels (world px). */
export const SWARM_WHEEL_RADIUS = 48;

/** Radius of the Swarm Boss (world px). */
export const SWARM_BOSS_RADIUS = 90;

/**
 * Mini-boss wheels are 20% smaller than the Boss (100% - 20% = 80% of boss size).
 */
export const SWARM_MINI_BOSS_SCALE = 0.8;
export const SWARM_MINI_BOSS_RADIUS = Math.round(SWARM_BOSS_RADIUS * SWARM_MINI_BOSS_SCALE); // 72 (exact 80%)

/**
 * World Y coordinate of the defense line right in front of the player's gun.
 * In landscape (display X = H - worldY), y = 506 corresponds to display X = 254.
 */
export const SWARM_DANGER_WORLD_Y = 506;

/** Top and bottom world-X margins (display Y bounds) so wheels bounce right at the bottom edge while staying clear of the top HUD. */
export const SWARM_LANE_MIN_X = 74;
export const SWARM_LANE_MAX_X = W - 6;

const FALLBACK_STYLES: Style[] = ['orange', 'wood', 'target'];

export interface SwarmHitMark {
  /** Local coordinates relative to wheel center (in wheel's own rotated frame for spinning wheels). */
  lx: number;
  ly: number;
  coins: number;
  age: number;
  crackAngle: number;
  rgb?: string;
  radiusScale?: number;
  weaponId?: string;
}

export interface SwarmItem {
  /** knife = obstacle blade planted in the rim; bullet = a round stuck by an earlier hit. */
  kind: 'knife' | 'bullet';
  /** Angle in the wheel's own (rotating) art frame. */
  angle: number;
  variant?: number;
  tilt?: number;
  w?: string;
  age: number;
  hue?: number;
  big?: number;
  scale?: number;
  rgb?: string;
  tint?: string;
}

/** Plant `count` obstacle knives around the rim, evenly spread with jitter. */
export function plantSwarmKnives(count: number, seed = Math.random()): SwarmItem[] {
  const items: SwarmItem[] = [];
  const base = seed * TAU;
  for (let i = 0; i < count; i++) {
    const a = base + (i / Math.max(1, count)) * TAU + (Math.random() - 0.5) * (TAU / Math.max(3, count * 3));
    items.push({ kind: 'knife', angle: ((a % TAU) + TAU) % TAU, variant: (i + Math.floor(seed * 7)) % 3, tilt: (Math.random() - 0.5) * 10, age: 10 });
  }
  return items;
}

/**
 * The single transform a Swarm target is drawn with (translate -> scale -> rotate).
 * Collision uses exactly the same frame, so rounds stop on the pixels you see.
 */
export function swarmTargetFrame(t: SwarmTarget, orientation: 'portrait' | 'landscape') {
  const travelFrac = Math.max(0, Math.min(1, t.y / SWARM_DANGER_WORLD_Y));
  const approach = 0.9 + travelFrac * 0.14;
  const bump = 1 + t.hitBump * 0.035;
  // Classic wheel squash: flatten along the shot, widen across it, overshoot, settle.
  const sq = Math.max(-1.15, Math.min(1.28, t.squish ?? 0));
  const squashX = Math.max(0.82, 1 + sq * 0.15);
  const squashY = Math.max(0.76, 1 - sq * 0.185);
  const sx = approach * bump * squashX;
  const sy = approach * bump * squashY;
  const rot = t.isBoss
    ? (orientation === 'landscape' ? -Math.PI / 2 : 0) + t.rot + Math.sin(t.age * 2.4 + t.wavePhase) * 0.03
    : t.rot;
  return { x: t.x, y: t.y, sx, sy, rot };
}

/** World-Y where the Swarm boss lands and stays (display x ≈ 610 in landscape). */
export const SWARM_BOSS_LAND_Y = 150;

export interface SwarmThrowSlot {
  /** Side offset (-1 or +1) relative to aim direction. */
  side: -1 | 1;
  /** Knife variant (0..2) held by this hand. */
  variant: number;
  /** Aim angle in world radians. */
  angle: number;
  /** Hand grip center in world coordinates. */
  x: number;
  y: number;
  /** True while this hand is performing the active windup/release throw. */
  throwing?: boolean;
  /** Current hand pose ('grip' holding knife, 'throw' open-palm release). */
  pose?: 'grip' | 'throw';
  /** 0..1 smooth recovery progress after grabbing a fresh knife. */
  reloadT?: number;
}

export interface SwarmTarget {
  items: SwarmItem[];
  /** Boss only: it flies in from the right, lands here and stays. */
  landY?: number;
  landed?: boolean;
  /** Boss only: seconds until it begins preparing its next knife throw. */
  throwT?: number;
  /** Boss only: throw telegraph & release animation state. */
  throwPhase?: 'idle' | 'windup' | 'release';
  throwAnimT?: number;
  throwAnimDur?: number;
  throwSeq?: number;
  throwHands?: SwarmThrowSlot[];
  /** Boss only: multi-stage dramatic defeat sequence (smoke + mini-explosions before final shatter). */
  dying?: boolean;
  dyingT?: number;
  dyingDur?: number;
  nextBlastT?: number;
  /** Squash & stretch spring (same feel as the classic Martian Heat-Ray hit bounce). */
  squish?: number;
  squishV?: number;
  id: number;
  /** World X = screen Y in landscape (0 = top, 420 = bottom). */
  x: number;
  /** World Y = H - screen X in landscape (0 = right edge, 760 = left edge). */
  y: number;
  /** World X velocity (screen vertical velocity). */
  vx: number;
  /** World Y velocity (screen right->left speed, positive moves toward player). */
  vy: number;
  /** Gentle gravity/arc along screen vertical (+world X = downward on screen). */
  ax: number;
  baseVy: number;
  waveAmp: number;
  waveFreq: number;
  wavePhase: number;
  radius: number;
  rot: number;
  rotSpeed: number;
  hp: number;
  maxHp: number;
  isBoss: boolean;
  isMiniBoss: boolean;
  head?: BossHead;
  artKey: string;
  artLevel: number;
  style: Style;
  juice: string[];
  spawnDelay: number;
  spawned: boolean;
  alive: boolean;
  age: number;
  hitFlash: number;
  hitBump: number;
  knockbackVy: number;
  /** Trail of recent world positions for air-throw motion streaks. */
  trail: { x: number; y: number }[];
  hitMarks: SwarmHitMark[];
  /** True for fast-hurled wheels that rush rapidly toward the player's gun. */
  isFastThrow?: boolean;
}

/**
 * Calculate coins earned from a hit based on distance from the wheel's center ("titik tengah"):
 * - Dead center (<= 17% of radius): 10 coins!
 * - Farther from center: smoothly drops down to 1 coin at the outer rim.
 */
export function calcSwarmCoinReward(dist: number, radius: number): number {
  const safeR = Math.max(1, radius);
  const norm = Math.max(0, Math.min(1, dist / safeR));
  if (norm <= SWARM_BULLSEYE_RATIO) return 10;
  const t = (norm - SWARM_BULLSEYE_RATIO) / (1 - SWARM_BULLSEYE_RATIO);
  return Math.max(1, Math.min(9, Math.round(9 - t * 8)));
}

/** Round position within a 5-round cycle: 1, 2, 3, 4 (regular) or 5 (Boss). */
export function swarmCycleSlot(round: number): 1 | 2 | 3 | 4 | 5 {
  const slot = ((Math.max(1, Math.floor(round)) - 1) % 5) + 1;
  return slot as 1 | 2 | 3 | 4 | 5;
}

/**
 * Recommended per-round Swarm ammo budget: covers every wheel HP, shooting
 * stuck knives off wheels, thrown boss knives, and reasonable margin for
 * fast-moving bouncing wheels, scaled cleanly by weapon burst/ammo character.
 */
export function calcSwarmRoundAmmo(
  round: number,
  targets: SwarmTarget[],
  weaponAmmoDelta = 0,
  burst = 1,
): number {
  const n = Math.max(1, Math.floor(round));
  const slot = swarmCycleSlot(n);
  const cycle = Math.floor((n - 1) / 5);
  const totalHp = targets.reduce((sum, t) => sum + Math.max(1, t.maxHp), 0);
  const totalKnives = targets.reduce(
    (sum, t) => sum + t.items.filter((it) => it.kind === 'knife').length,
    0,
  );
  const baseBySlot: Record<1 | 2 | 3 | 4 | 5, number> = {
    1: Math.max(12, totalHp * 2 + totalKnives + 5),
    2: Math.max(15, totalHp * 2 + totalKnives + 6),
    3: Math.max(20, totalHp * 2 + totalKnives + 6),
    4: Math.max(24, totalHp * 2 + totalKnives + 6),
    5: Math.max(30 + cycle * 4, totalHp * 2 + totalKnives + 9),
  };
  const base = baseBySlot[slot] + (slot < 5 ? cycle * 2 : 0);
  const burstMult = burst > 1 ? 1 + (burst - 1) * 0.45 : 1;
  const raw = Math.round(base * burstMult) + Math.max(-2, weaponAmmoDelta);
  const minSafe = totalHp + totalKnives + 5;
  return Math.max(minSafe, Math.min(48, raw));
}

/**
 * Build the exact wave of Swarm targets for `round`:
 * - Round 1 (slot 1): 1 wheel
 * - Round 2 (slot 2): 2 wheels (mix of 1-hit & 2-hit)
 * - Round 3 (slot 3): 3 wheels (mix of 1-hit & 2-hit)
 * - Round 4 (slot 4): 4 wheels (mix of 1-hit & 2-hit)
 * - Round 5 (slot 5, BOSS): 1 Boss + 5 mini-boss wheels (same boss art, 20% smaller than boss!)
 * Cycles repeat at Round 6..10, 11..15, etc. with faster throws and the next Boss in BOSS_CATALOG!
 */
export function buildSwarmWave(
  round: number,
  keyForLevel: (lv: number) => string,
  nextIdStart = 1,
): SwarmTarget[] {
  const n = Math.max(1, Math.floor(round));
  const slot = swarmCycleSlot(n);
  const cycle = Math.floor((n - 1) / 5);
  const speedScale = 1 + Math.min(0.45, cycle * 0.08);
  const targets: SwarmTarget[] = [];
  let nextId = nextIdStart;

  if (slot === 5) {
    // BOSS ROUND: 1 Boss, THEN 5 wheels matching the Boss but 20% smaller!
    const head = bossHeadFor(n) ?? 'pirate';
    const artKey = keyForLevel(n);
    const bossHp = 10 + cycle * 3;
    const bossR = SWARM_BOSS_RADIUS;

    targets.push({
      id: nextId++,
      x: 215,
      y: -bossR - 24,
      vx: 0,
      vy: 42 * speedScale,
      ax: 0,
      baseVy: 42 * speedScale,
      waveAmp: 62,
      waveFreq: 1.35 + Math.min(0.5, cycle * 0.08),
      wavePhase: Math.random() * TAU,
      radius: bossR,
      rot: 0,
      rotSpeed: 0,
      hp: bossHp,
      maxHp: bossHp,
      items: plantSwarmKnives(3 + Math.min(2, cycle)),
      landY: SWARM_BOSS_LAND_Y,
      landed: false,
      throwT: 1.4,
      isBoss: true,
      isMiniBoss: false,
      head,
      artKey,
      artLevel: n,
      style: 'target',
      juice: JUICE.boss,
      spawnDelay: 0.25,
      spawned: false,
      alive: true,
      age: 0,
      hitFlash: 0,
      hitBump: 0,
      knockbackVy: 0,
      trail: [],
      hitMarks: [],
    });

    // The boss fights alone: no mini-boss minions.
    return targets;
  }

  // REGULAR ROUNDS 1, 2, 3, 4: lively bouncy waves + fast-thrown incoming wheels!
  const count = slot === 1 ? 2 : slot;
  const hpTables: Record<1 | 2 | 3 | 4, number[]> = {
    1: [cycle % 2 === 0 ? 2 : 1, 1],
    2: [2, 1],
    3: [2, 1, 2],
    4: [2, 1, 2, 1],
  };
  const hpList = hpTables[slot];

  // Spread vertical lanes cleanly across the 420px display height
  const lanePresets: Record<1 | 2 | 3 | 4, number[]> = {
    1: [185, 295],
    2: [155, 295],
    3: [142, 238, 322],
    4: [132, 206, 276, 336],
  };
  const lanes = lanePresets[slot].slice();
  // Gently shuffle lane assignment for freshness while keeping spacing wide
  for (let i = lanes.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [lanes[i], lanes[j]] = [lanes[j], lanes[i]];
  }

  const slotSpeeds: Record<1 | 2 | 3 | 4, number> = {
    1: 76,
    2: 88,
    3: 100,
    4: 112,
  };
  const spawnGaps: Record<1 | 2 | 3 | 4, number> = {
    1: 1.25,
    2: 1.05,
    3: 0.92,
    4: 0.82,
  };
  const slotRotBoost = 1 + (slot - 1) * 0.1;
  const cycleStartLevel = cycle * 5 + 1;
  for (let i = 0; i < count; i++) {
    const r = SWARM_WHEEL_RADIUS;
    const hp = hpList[i];
    const isFastThrow =
      (slot === 1 && i === 1) ||
      (slot === 2 && i === 1) ||
      (slot === 3 && i === 1) ||
      (slot === 4 && (i === 1 || i === 3));
    // Pull real Game B wheel art for each wheel in the wave
    const artLevel = cycleStartLevel + ((slot - 1 + i) % 4);
    const cfg = levelConfig(artLevel);
    const artKey = keyForLevel(artLevel);
    const laneX = Math.max(
      SWARM_LANE_MIN_X + r,
      Math.min(SWARM_LANE_MAX_X - r, lanes[i] + (Math.random() - 0.5) * 20),
    );
    // Gentle floaty arc gravity so wheels bounce very high without moving too fast,
    // and keep incoming approach speed readable (including faster thrown wheels).
    const baseVy = isFastThrow
      ? (135 + slot * 11 + Math.random() * 14) * speedScale
      : (slotSpeeds[slot] + (i % 2) * 6 + Math.random() * 8) * speedScale;
    const gravityScale = 0.95 + slot * 0.06;
    const tossUp = isFastThrow
      ? -(135 + Math.random() * 55) * (laneX > 220 ? 1.15 : 0.78)
      : -(125 + Math.random() * 55) * (laneX > 220 ? 1.15 : 0.78);
    const ax = isFastThrow
      ? (185 + Math.random() * 35) * gravityScale
      : (145 + Math.random() * 30) * gravityScale;

    targets.push({
      id: nextId++,
      x: laneX,
      y: -r - 20,
      vx: tossUp,
      vy: baseVy,
      ax,
      baseVy,
      waveAmp: 0,
      waveFreq: 0,
      wavePhase: Math.random() * TAU,
      radius: r,
      rot: Math.random() * TAU,
      rotSpeed:
        (i % 2 === 0 ? 1 : -1) *
        (1.35 + Math.random() * 0.7) *
        slotRotBoost *
        (isFastThrow ? 1.25 : 1) *
        (1 + Math.min(0.4, cycle * 0.06)),
      hp,
      maxHp: hp,
      items: plantSwarmKnives(isFastThrow ? 1 : Math.min(3, (slot >= 3 ? 2 : 1) + (cycle > 0 ? 1 : 0))),
      isBoss: false,
      isMiniBoss: false,
      isFastThrow,
      artKey,
      artLevel,
      style: FALLBACK_STYLES[(artLevel - 1) % FALLBACK_STYLES.length],
      juice: JUICE[cfg.target] ?? JUICE.orange,
      spawnDelay: 0.25 + i * spawnGaps[slot] + (isFastThrow && slot === 1 ? 0.2 : 0),
      spawned: false,
      alive: true,
      age: 0,
      hitFlash: 0,
      hitBump: 0,
      knockbackVy: 0,
      trail: [],
      hitMarks: [],
    });
  }

  return targets;
}

export interface SwarmDrawContext {
  time: number;
  orientation: 'portrait' | 'landscape';
  aimWorld: { x: number; y: number } | null;
  getArt: (key: string) => HTMLImageElement | null;
  getLaughArt: (key: string) => HTMLImageElement | null;
  getArtClip?: (key: string) => { region: Path2D; size: number } | null;
  bossRage: boolean;
  bossMood: 'idle' | 'angry' | 'laugh' | 'defeat';
  bossMoodAge: number;
  bossMoodLeft: number;
  frame: (t: SwarmTarget) => { x: number; y: number; sx: number; sy: number; rot: number };
  /** Knives and stuck rounds, drawn in the rotating art frame BEFORE the art (their buried half is hidden). */
  drawItems: (c: CanvasRenderingContext2D, t: SwarmTarget) => void;
}

/**
 * Draw one live Swarm wheel (regular wheel, Boss, or 20%-smaller Mini-Boss wheel)
 * inside Game.ts's world coordinate space.
 */
export function drawSwarmTarget(
  c: CanvasRenderingContext2D,
  t: SwarmTarget,
  env: SwarmDrawContext,
) {
  if (!t.alive || !t.spawned) return;
  const R = t.radius;
  const landscape = env.orientation === 'landscape';

  // Approach depth feel: starts slightly smaller at the far right edge and grows
  // subtly as it gets thrown closer toward us on the left!
  const fr = env.frame(t);
  const dyingP = t.dying ? Math.min(1, (t.dyingT ?? 0) / Math.max(0.1, t.dyingDur ?? 1.4)) : 0;
  const shakeX = t.dying ? Math.sin(env.time * 74) * (3.2 + 5.5 * dyingP) : 0;
  const shakeY = t.dying ? Math.cos(env.time * 63) * (2.6 + 4.5 * dyingP) : 0;

  // 1) Velocity-scaled aerodynamic slipstream ribbon & parallel wind streaks behind fast wheels
  if (!t.isBoss) {
    const netVy = t.baseVy + t.knockbackVy;
    const speedMag = Math.hypot(t.vx, netVy);
    const speedNorm = Math.max(0, Math.min(1, (speedMag - 75) / 145));
    const ux = speedMag > 1 ? t.vx / speedMag : 0;
    const uy = speedMag > 1 ? netVy / speedMag : 1;
    const px = -uy;
    const py = ux;

    if (t.trail.length >= 2) {
      c.save();
      c.lineCap = 'round';
      for (let i = 0; i < t.trail.length; i++) {
        const pt = t.trail[i];
        const frac = (i + 1) / (t.trail.length + 1);
        c.globalAlpha = frac * (t.isFastThrow ? 0.28 : 0.14 + 0.16 * speedNorm);
        c.fillStyle = t.knockbackVy < -20
          ? 'rgba(253,224,71,0.55)'
          : t.isFastThrow
            ? 'rgba(251,146,60,0.62)'
            : 'rgba(255,255,255,0.5)';
        c.beginPath();
        c.arc(pt.x, pt.y, R * (0.55 + frac * 0.36), 0, TAU);
        c.fill();
      }
      c.restore();
    }

    if (speedMag > 65 || t.isFastThrow) {
      const tailLen = (t.isFastThrow ? 78 : 36) + speedNorm * (t.isFastThrow ? 86 : 68);
      const laneOffsets = [-0.72, -0.34, 0.34, 0.72];
      c.save();
      c.globalCompositeOperation = 'lighter';
      c.lineCap = 'round';
      for (let li = 0; li < laneOffsets.length; li++) {
        const off = laneOffsets[li] * R;
        const backOffset = (li === 0 || li === 3 ? 0.15 : 0.35) * R;
        const sx = fr.x - ux * backOffset + px * off;
        const sy = fr.y - uy * backOffset + py * off;
        const ex = sx - ux * tailLen * (li % 2 === 0 ? 0.82 : 1);
        const ey = sy - uy * tailLen * (li % 2 === 0 ? 0.82 : 1);
        const sg = c.createLinearGradient(sx, sy, ex, ey);
        if (t.isFastThrow) {
          sg.addColorStop(0, `rgba(255,250,210,${(0.36 + 0.34 * speedNorm).toFixed(3)})`);
          sg.addColorStop(0.42, `rgba(251,146,60,${(0.24 + 0.24 * speedNorm).toFixed(3)})`);
          sg.addColorStop(1, 'rgba(239,68,68,0)');
        } else {
          sg.addColorStop(0, `rgba(255,255,255,${(0.18 + 0.28 * speedNorm).toFixed(3)})`);
          sg.addColorStop(0.45, `rgba(186,230,253,${(0.11 + 0.16 * speedNorm).toFixed(3)})`);
          sg.addColorStop(1, 'rgba(255,255,255,0)');
        }
        c.strokeStyle = sg;
        c.lineWidth = (li === 1 || li === 2 ? 2.1 : 1.4) * (t.isFastThrow ? 1.35 : 1);
        c.beginPath();
        c.moveTo(sx, sy);
        c.lineTo(ex, ey);
        c.stroke();
      }
      c.restore();
    }
  }

  c.save();
  c.translate(fr.x + shakeX, fr.y + shakeY);

  // 2) Speed aura on fast-thrown wheels + danger pulse near defense line
  if (t.isFastThrow && !t.isBoss) {
    const pulse = 0.55 + 0.45 * Math.sin(env.time * 22);
    c.save();
    c.globalCompositeOperation = 'lighter';
    drawRgbGlowSprite(c, 0, 0, R * 1.4, R * 1.4, '251,146,60', 0.26 + 0.16 * pulse);
    c.restore();
  }
  const danger = Math.max(0, (t.y - 340) / (SWARM_DANGER_WORLD_Y - 340));
  if (danger > 0.02) {
    const pulse = 0.55 + 0.45 * Math.sin(env.time * 16);
    c.save();
    c.globalCompositeOperation = 'lighter';
    drawRgbGlowSprite(c, 0, 0, R * 1.48, R * 1.48, '239,68,68', danger * (0.55 + 0.45 * pulse));
    c.restore();
  }

  // 3) Boss rage or dramatic meltdown aura
  if (t.isBoss && t.dying) {
    const flick = 0.55 + 0.45 * Math.sin(env.time * 42);
    const rad = R * (1.45 + 0.35 * dyingP + 0.14 * flick);
    c.save();
    c.globalCompositeOperation = 'lighter';
    drawRgbGlowSprite(c, 0, 0, rad, rad, '255,115,40', (0.45 + 0.55 * dyingP) * flick);
    c.restore();
  } else if (t.isBoss && env.bossRage) {
    const pulse = 0.5 + 0.5 * Math.sin(env.time * TAU * 0.6);
    const rad = R * (1.52 + 0.1 * pulse);
    c.save();
    c.globalCompositeOperation = 'lighter';
    drawRgbGlowSprite(c, 0, 0, rad, rad, '239,68,68', (0.34 + 0.16 * pulse) / 0.42);
    c.restore();
  }

  c.scale(fr.sx, fr.sy);

  // 4) Ambient drop shadow (downward in screen space = +x in landscape, +y in portrait)
  if (!t.isBoss) {
    c.beginPath();
    c.arc(landscape ? 9 : 0, landscape ? 0 : 9, R + 4, 0, TAU);
    c.fillStyle = 'rgba(0,0,0,0.34)';
    c.fill();
  }

  // 5) Wheel / Boss artwork (exact Game B SVG raster or instant drawFace fallback)
  const artImg = env.getArt(t.artKey);
  c.save();
  // Boss AND wheels spin like classic mode; knives & stuck rounds ride the same frame.
  c.rotate(fr.rot);
  env.drawItems(c, t);

  if (artImg && artImg.complete && artImg.naturalWidth > 0) {
    c.drawImage(artImg, -R, -R, R * 2, R * 2);
  } else {
    drawFace(c, R, t.style);
  }

  // Dramatic scorched overheat flash pulsing during boss defeat sequence
  if (t.isBoss && t.dying) {
    const heat = (0.28 + 0.38 * dyingP) * (0.5 + 0.5 * Math.sin(env.time * 38));
    c.save();
    c.globalCompositeOperation = 'lighter';
    drawRgbGlowSprite(c, 0, 0, R * 0.95, R * 0.95, '255,140,45', heat);
    c.restore();
  }

  // Boss live facial expressions (defeat / angry / laugh / rage)
  if (t.isBoss && t.head) {
    const fadeIn = Math.min(1, env.bossMoodAge / 0.11);
    const fadeOut = (over: number) => Math.min(1, env.bossMoodLeft / over);
    if (t.dying || env.bossMood === 'defeat') {
      drawBossDefeatFace(c, t.head, R, t.dying ? 1 : fadeIn, env.time);
    } else if (env.bossMood === 'laugh') {
      const k = bossLaughEyeOpacity(env.bossMoodAge, env.bossMoodLeft);
      const laughImg = env.getLaughArt(t.artKey);
      if (laughImg) drawBossLaughEyes(c, laughImg, t.head, R, k);
      drawBossLaughExtras(c, t.head, R, k, env.time);
    } else if (env.bossMood === 'angry') {
      drawBossAngryFace(c, t.head, R, fadeIn * fadeOut(0.22), env.time, env.bossRage);
    } else if (env.bossRage) {
      drawBossAngryFace(c, t.head, R, 0.6 + 0.2 * Math.sin(env.time * 7), env.time, true);
    }
  }

  // 6) Sleek impact craters, cooling ember rims, & hairline fractures on damaged wheels / boss
  // Cropped strictly inside the drawn wheel / boss head silhouette so cracks never float in empty space.
  if (t.hitMarks.length > 0) {
    c.save();
    const hasArtImg = !!(artImg && artImg.complete && artImg.naturalWidth > 0);
    const artClip = hasArtImg ? (env.getArtClip?.(t.artKey) ?? null) : null;
    if (artClip) {
      const k = (2 * R) / artClip.size;
      const half = artClip.size / 2;
      c.scale(k, k);
      c.translate(-half, -half);
      c.clip(artClip.region);
      c.translate(half, half);
      c.scale(1 / k, 1 / k);
    } else {
      c.beginPath();
      c.arc(0, 0, R, 0, TAU);
      c.clip();
    }
    for (const hm of t.hitMarks) {
      const rScale = hm.radiusScale ?? 1;
      const hot = Math.max(0, 1 - hm.age / 0.65);
      const craterR = Math.max(3.4, R * 0.078) * rScale;
      const rgb = hm.rgb ?? '255,195,105';
      c.save();
      c.translate(hm.lx, hm.ly);

      // Hot cooling bloom around fresh impact site
      if (hot > 0.02) {
        c.save();
        c.globalCompositeOperation = 'lighter';
        drawRgbGlowSprite(c, 0, 0, craterR * (3.1 + hot * 1.4), craterR * (3.1 + hot * 1.4), rgb, hot * 0.72);
        c.restore();
      }

      // Crisp jagged hairline fracture lines radiating inward
      c.strokeStyle = 'rgba(18,10,14,0.78)';
      c.lineWidth = 1.45;
      c.lineCap = 'round';
      for (let k = 0; k < 6; k++) {
        const a = hm.crackAngle + (k / 6) * TAU + (k % 2 ? 0.2 : -0.18);
        const len = R * (0.16 + (k % 3) * 0.075) * rScale;
        const mx = Math.cos(a) * len * 0.52;
        const my = Math.sin(a) * len * 0.52;
        const ex = Math.cos(a + (k % 2 ? 0.16 : -0.14)) * len;
        const ey = Math.sin(a + (k % 2 ? 0.16 : -0.14)) * len;
        c.beginPath();
        c.moveTo(0, 0);
        c.lineTo(mx, my);
        c.lineTo(ex, ey);
        c.stroke();
        if (hot > 0.15 && k % 2 === 0) {
          c.save();
          c.globalCompositeOperation = 'lighter';
          c.strokeStyle = `rgba(${rgb},${(hot * 0.68).toFixed(3)})`;
          c.lineWidth = 1.05;
          c.beginPath();
          c.moveTo(0, 0);
          c.lineTo(mx, my);
          c.stroke();
          c.restore();
        }
      }

      // Deep beveled scorch socket
      c.fillStyle = 'rgba(14,9,12,0.82)';
      c.beginPath();
      c.arc(0, 0, craterR, 0, TAU);
      c.fill();

      // Glowing cooling rim / metallic lip
      c.strokeStyle = hot > 0.05
        ? `rgba(${rgb},${(0.45 + hot * 0.55).toFixed(3)})`
        : 'rgba(255,220,165,0.42)';
      c.lineWidth = 1.35;
      c.stroke();

      // Pinpoint hot ember core while fresh
      if (hot > 0.25) {
        c.fillStyle = `rgba(255,248,225,${(hot * 0.9).toFixed(3)})`;
        c.beginPath();
        c.arc(0, 0, craterR * 0.42, 0, TAU);
        c.fill();
      }
      c.restore();
    }
    c.restore();
  }
  c.restore();

  // 7) Armored rim indicator for 2-HP wheels (still at 2 HP) so 2-hit vs 1-hit reads instantly!
  if (!t.isBoss && t.maxHp === 2 && t.hp === 2) {
    c.save();
    c.strokeStyle = '#fbbf24';
    c.lineWidth = 4.2;

    c.beginPath();
    c.arc(0, 0, R + 2.5, 0, TAU);
    c.stroke();

    c.strokeStyle = 'rgba(255,255,255,0.65)';
    c.lineWidth = 1.4;
    c.setLineDash([8, 6]);
    c.beginPath();
    c.arc(0, 0, R + 2.5, env.time * 1.8, env.time * 1.8 + TAU);
    c.stroke();
    c.setLineDash([]);
    c.restore();
  } else if (!t.isBoss && t.maxHp === 2 && t.hp === 1) {
    // Cracked rim glow when armor has been broken (1 shot remaining!)
    c.save();
    c.strokeStyle = 'rgba(248,113,113,0.75)';
    c.lineWidth = 2.4;
    c.setLineDash([5, 5]);
    c.beginPath();
    c.arc(0, 0, R + 1.5, 0, TAU);
    c.stroke();
    c.setLineDash([]);
    c.restore();
  } else if (t.isMiniBoss) {
    // Subtle crimson aura ring for mini-boss wheels so they stand out as boss clones
    c.save();
    c.strokeStyle = 'rgba(251,113,133,0.55)';
    c.lineWidth = 2.4;
    c.beginPath();
    c.arc(0, 0, R + 1.5, 0, TAU);
    c.stroke();
    c.restore();
  }

  // 8) Hit flash highlight
  if (t.hitFlash > 0.02) {
    c.save();
    c.globalCompositeOperation = 'lighter';
    c.fillStyle = `rgba(255,255,255,${Math.min(0.65, t.hitFlash * 0.55)})`;
    c.beginPath();
    c.arc(0, 0, R, 0, TAU);
    c.fill();
    c.restore();
  }

  // 10) Compact upright HP badge for 2-HP wheels (so 2-shot vs 1-shot is immediately clear)
  if (!t.isBoss && t.maxHp > 1) {
    c.save();
    if (landscape) c.rotate(-Math.PI / 2);
    const badgeY = -R - 11;
    c.fillStyle = 'rgba(8,16,28,0.86)';
    c.strokeStyle = t.hp === 2 ? '#fbbf24' : '#f87171';
    c.lineWidth = 1.5;
    c.beginPath();
    c.roundRect(-17, badgeY - 7, 34, 14, 7);
    c.fill();
    c.stroke();

    // Two crisp HP pips
    for (let i = 0; i < t.maxHp; i++) {
      const px = (i - (t.maxHp - 1) / 2) * 11;
      c.beginPath();
      c.arc(px, badgeY, 3.6, 0, TAU);
      c.fillStyle = i < t.hp ? (t.hp === 2 ? '#fde047' : '#fb7185') : 'rgba(255,255,255,0.18)';
      c.fill();
    }
    c.restore();
  }

  c.restore();
}

/**
 * Draw crisp tactical crosshair at the mouse pointer in display space.
 */
export function drawSwarmCrosshair(
  c: CanvasRenderingContext2D,
  pointer: { x: number; y: number },
  hoverState: 'none' | 'body' | 'bullseye',
  recoil: number,
  time: number,
) {
  const spread = (hoverState === 'bullseye' ? 11 : 14) + recoil * 12;
  const color = hoverState === 'bullseye'
    ? '#ffd23f'
    : hoverState === 'body'
      ? '#38bdf8'
      : 'rgba(255,255,255,0.82)';

  c.save();
  c.translate(pointer.x, pointer.y);

  // Subtle dark outer halo for readability over bright wheels
  c.strokeStyle = 'rgba(0,0,0,0.65)';
  c.lineWidth = 4;
  c.beginPath();
  c.arc(0, 0, spread, 0, TAU);
  c.stroke();

  // Main ring
  c.strokeStyle = color;
  c.lineWidth = hoverState === 'bullseye' ? 2.4 : 1.8;
  c.beginPath();
  c.arc(0, 0, spread, 0, TAU);
  c.stroke();

  // Four crisp reticle ticks
  const tickIn = spread * 0.52;
  const tickOut = spread + 6;
  c.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const a = (i * Math.PI) / 2 + (hoverState === 'bullseye' ? time * 1.4 : 0);
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    c.strokeStyle = 'rgba(0,0,0,0.65)';
    c.lineWidth = 3.8;
    c.beginPath();
    c.moveTo(cos * tickIn, sin * tickIn);
    c.lineTo(cos * tickOut, sin * tickOut);
    c.stroke();

    c.strokeStyle = color;
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(cos * tickIn, sin * tickIn);
    c.lineTo(cos * tickOut, sin * tickOut);
    c.stroke();
  }

  // Exact center aim dot
  c.fillStyle = hoverState === 'bullseye' ? '#fffbeb' : color;
  c.beginPath();
  c.arc(0, 0, hoverState === 'bullseye' ? 2.8 : 2, 0, TAU);
  c.fill();

  c.restore();
}

/**
 * Draw Swarm player lives (hearts) cleanly below the score in display space.
 */
export function drawSwarmHearts(
  c: CanvasRenderingContext2D,
  x: number,
  y: number,
  lives: number,
  maxLives: number,
  damageFlash: number,
) {
  c.save();
  for (let i = 0; i < maxLives; i++) {
    const alive = i < lives;
    const cx = x + i * 24;
    const pulse = alive && damageFlash > 0 ? 1 + damageFlash * 0.25 : 1;
    c.save();
    c.translate(cx, y);
    c.scale(pulse, pulse);
    c.beginPath();
    c.moveTo(0, 6);
    c.bezierCurveTo(-11, -1, -11, -10, -4.5, -10);
    c.bezierCurveTo(-1.5, -10, 0, -7.2, 0, -5.8);
    c.bezierCurveTo(0, -7.2, 1.5, -10, 4.5, -10);
    c.bezierCurveTo(11, -10, 11, -1, 0, 6);
    c.closePath();

    c.lineWidth = 2.5;
    c.strokeStyle = 'rgba(0,0,0,0.72)';
    c.stroke();

    if (alive) {
      const grad = c.createLinearGradient(0, -10, 0, 6);
      grad.addColorStop(0, '#ff6b81');
      grad.addColorStop(0.5, '#ef4444');
      grad.addColorStop(1, '#b91c1c');
      c.fillStyle = grad;
      c.fill();
      // Glossy specular dot
      c.fillStyle = 'rgba(255,255,255,0.55)';
      c.beginPath();
      c.ellipse(-4, -6.5, 2.2, 1.3, -0.5, 0, TAU);
      c.fill();
    } else {
      c.fillStyle = 'rgba(15,23,42,0.58)';
      c.fill();
    }
    c.restore();
  }
  c.restore();
}

export const SWARM_BOMB_RADIUS = 32;

export interface SwarmBomb {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  ax: number;
  rot: number;
  rotSpeed: number;
  radius: number;
  spawnDelay: number;
  spawned: boolean;
  alive: boolean;
  age: number;
}

/**
 * Spawn one lobbed iron bomb thrown from right to left across rounds 1-4.
 * Players must hold fire and let it sail off-screen (shooting it triggers instant death).
 */
export function buildSwarmBomb(
  round: number,
  id: number,
  spawnDelay: number,
  targetX = 210,
  targetY = 640,
): SwarmBomb {
  const n = Math.max(1, Math.floor(round));
  const slot = swarmCycleSlot(n);
  const cycle = Math.floor((n - 1) / 5);
  const speedScale = 1 + Math.min(0.65, cycle * 0.11);
  const r = SWARM_BOMB_RADIUS;
  const startY = -r - 26;
  const startX = Math.max(185, Math.min(305, targetX + (Math.random() - 0.5) * 64));
  const vy = (148 + slot * 12 + Math.random() * 14) * speedScale;
  const arcScale = vy / 160;
  // Exact ballistic curve so the bomb arcs up in the arena and drops directly over the player's gun!
  const flightTime = Math.max(1.2, (targetY - startY) / vy);
  const maxDrop = Math.max(55, Math.min(startX, targetX) - 86);
  const ax = Math.min((120 + Math.random() * 24) * arcScale * arcScale, (7.6 * maxDrop) / (flightTime * flightTime));
  const vx = (targetX - startX) / flightTime - 0.5 * ax * flightTime;

  return {
    id,
    x: startX,
    y: startY,
    vx,
    vy,
    ax,
    rot: 0,
    rotSpeed: (Math.random() < 0.5 ? 1 : -1) * (0.45 + Math.random() * 0.3),
    radius: r,
    spawnDelay,
    spawned: false,
    alive: true,
    age: 0,
  };
}

function bombWorldRot(b: SwarmBomb, orientation: 'portrait' | 'landscape'): number {
  const arcTilt = Math.max(-0.34, Math.min(0.34, (b.vx / Math.max(80, b.vy)) * 0.35));
  const rock = Math.sin(b.age * 3.8 + b.id) * 0.1;
  return (orientation === 'landscape' ? -Math.PI / 2 : 0) + arcTilt + rock;
}

/** Exact world position of the bomb's lit fuse tip for live sparks/smoke. */
export function swarmBombFuseTipWorld(
  b: SwarmBomb,
  orientation: 'portrait' | 'landscape',
): { x: number; y: number } {
  const r = b.radius;
  const rot = bombWorldRot(b, orientation);
  const fx = r * 0.48;
  const fy = -r * 1.48;
  const cs = Math.cos(rot);
  const sn = Math.sin(rot);
  return {
    x: b.x + fx * cs - fy * sn,
    y: b.y + fx * sn + fy * cs,
  };
}

/** Classic round iron bomb with skull warning emblem and flickering fiery fuse. */
export function drawSwarmBomb(
  c: CanvasRenderingContext2D,
  b: SwarmBomb,
  time: number,
  orientation: 'portrait' | 'landscape',
) {
  if (!b.alive || !b.spawned) return;
  const R = b.radius;
  const pulse = 0.55 + 0.45 * Math.sin(time * 16 + b.id);
  const rot = bombWorldRot(b, orientation);

  const speed = Math.hypot(b.vx, b.vy) || 1;
  const ux = b.vx / speed;
  const uy = b.vy / speed;
  const px = -uy;
  const py = ux;

  // Aerodynamic warning wake behind thrown bomb
  c.save();
  c.globalCompositeOperation = 'lighter';
  c.lineCap = 'round';
  for (const frac of [-0.65, 0, 0.65]) {
    const tail = frac === 0 ? 58 : 42;
    const sx = b.x + px * (R * frac);
    const sy = b.y + py * (R * frac);
    const ex = sx - ux * tail;
    const ey = sy - uy * tail;
    const bg = c.createLinearGradient(sx, sy, ex, ey);
    bg.addColorStop(0, 'rgba(251,146,60,0.42)');
    bg.addColorStop(1, 'rgba(251,146,60,0)');
    c.strokeStyle = bg;
    c.lineWidth = frac === 0 ? 2.4 : 1.5;
    c.beginPath();
    c.moveTo(sx, sy);
    c.lineTo(ex, ey);
    c.stroke();
  }
  c.restore();

  c.save();
  c.translate(b.x, b.y);

  // 1) Fiery hazard aura so the player recognizes it immediately
  c.save();
  c.globalCompositeOperation = 'lighter';
  drawRgbGlowSprite(c, 0, 0, R * 1.85, R * 1.85, '255,90,25', 0.45 + 0.24 * pulse);
  c.restore();

  // 2) Soft airborne drop shadow
  c.beginPath();
  c.arc(orientation === 'landscape' ? 8 : 0, orientation === 'landscape' ? 0 : 8, R + 2, 0, TAU);
  c.fillStyle = 'rgba(0,0,0,0.34)';
  c.fill();

  c.rotate(rot);

  // 3) Braided fuse cord curving out from the top collar
  c.save();
  c.lineCap = 'round';
  c.strokeStyle = '#451a03';
  c.lineWidth = 6.2;
  c.beginPath();
  c.moveTo(0, -R * 0.88);
  c.quadraticCurveTo(R * 0.14, -R * 1.45, R * 0.48, -R * 1.48);
  c.stroke();

  c.strokeStyle = '#d97706';
  c.lineWidth = 3.8;
  c.stroke();

  c.strokeStyle = '#fde68a';
  c.lineWidth = 1.6;
  c.setLineDash([4, 4]);
  c.stroke();
  c.setLineDash([]);
  c.restore();

  // 4) Metallic fuse cap / collar on top of bomb
  c.save();
  c.fillStyle = '#475569';
  c.strokeStyle = '#020617';
  c.lineWidth = 2.2;
  c.beginPath();
  c.roundRect(-R * 0.26, -R * 1.05, R * 0.52, R * 0.28, 4);
  c.fill();
  c.stroke();
  c.fillStyle = 'rgba(255,255,255,0.28)';
  c.fillRect(-R * 0.16, -R * 1.01, R * 0.16, R * 0.18);
  c.restore();

  // 5) Dark iron spherical bomb body
  const bodyGrad = c.createRadialGradient(-R * 0.34, -R * 0.36, R * 0.12, 0, 0, R);
  bodyGrad.addColorStop(0, '#64748b');
  bodyGrad.addColorStop(0.32, '#1e293b');
  bodyGrad.addColorStop(0.78, '#0f172a');
  bodyGrad.addColorStop(1, '#020617');
  c.beginPath();
  c.arc(0, 0, R, 0, TAU);
  c.fillStyle = bodyGrad;
  c.fill();
  c.lineWidth = 2.6;
  c.strokeStyle = '#020617';
  c.stroke();

  // Glossy metallic specular highlight
  c.save();
  c.rotate(-0.55);
  c.fillStyle = 'rgba(255,255,255,0.24)';
  c.beginPath();
  c.ellipse(-R * 0.38, -R * 0.28, R * 0.22, R * 0.11, -0.35, 0, TAU);
  c.fill();
  c.restore();

  // 6) Skull danger icon on the bomb face
  c.save();
  c.translate(0, R * 0.04);
  const sr = R * 0.44;
  // Subtle red warning halo around the skull
  c.beginPath();
  c.arc(0, 0, sr * 1.32, 0, TAU);
  c.strokeStyle = `rgba(239,68,68,${(0.45 + 0.3 * pulse).toFixed(3)})`;
  c.lineWidth = 2;
  c.stroke();

  // Skull cranium + jaw silhouette
  c.fillStyle = '#f8fafc';
  c.strokeStyle = '#020617';
  c.lineWidth = 1.8;
  c.lineJoin = 'round';
  c.beginPath();
  c.arc(0, -sr * 0.16, sr * 0.88, Math.PI * 0.82, Math.PI * 0.18, false);
  c.lineTo(sr * 0.5, sr * 0.38);
  c.lineTo(sr * 0.46, sr * 0.84);
  c.lineTo(-sr * 0.46, sr * 0.84);
  c.lineTo(-sr * 0.5, sr * 0.38);
  c.closePath();
  c.fill();
  c.stroke();

  // Angry skull eye sockets
  c.fillStyle = '#0f172a';
  c.beginPath();
  c.ellipse(-sr * 0.32, -sr * 0.04, sr * 0.22, sr * 0.24, -0.18, 0, TAU);
  c.fill();
  c.beginPath();
  c.ellipse(sr * 0.32, -sr * 0.04, sr * 0.22, sr * 0.24, 0.18, 0, TAU);
  c.fill();

  // Tiny red danger pinpoints in eyes
  c.fillStyle = '#ef4444';
  c.beginPath();
  c.arc(-sr * 0.31, -sr * 0.04, sr * 0.07, 0, TAU);
  c.arc(sr * 0.31, -sr * 0.04, sr * 0.07, 0, TAU);
  c.fill();

  // Nasal cavity
  c.fillStyle = '#0f172a';
  c.beginPath();
  c.moveTo(0, sr * 0.18);
  c.lineTo(sr * 0.12, sr * 0.4);
  c.lineTo(-sr * 0.12, sr * 0.4);
  c.closePath();
  c.fill();

  // Teeth notches
  c.strokeStyle = '#0f172a';
  c.lineWidth = 1.6;
  c.beginPath();
  c.moveTo(-sr * 0.22, sr * 0.56);
  c.lineTo(-sr * 0.22, sr * 0.84);
  c.moveTo(0, sr * 0.56);
  c.lineTo(0, sr * 0.84);
  c.moveTo(sr * 0.22, sr * 0.56);
  c.lineTo(sr * 0.22, sr * 0.84);
  c.stroke();
  c.restore();

  // 7) Burning fiery flame & crackling spark rays at fuse tip
  const fx = R * 0.48;
  const fy = -R * 1.48;
  const flicker = 0.85 + 0.3 * Math.sin(time * 34 + b.id);
  c.save();
  c.translate(fx, fy);

  c.save();
  c.globalCompositeOperation = 'lighter';
  drawRgbGlowSprite(c, 0, 0, 24 * flicker, 24 * flicker, '255,150,35', 0.92);
  c.restore();

  // Star-like spark rays
  c.strokeStyle = '#fef08a';
  c.lineWidth = 1.8;
  c.lineCap = 'round';
  for (let i = 0; i < 6; i++) {
    const a = time * 8 + (i / 6) * TAU;
    const len = (6 + (i % 2) * 5) * flicker;
    c.beginPath();
    c.moveTo(Math.cos(a) * 3, Math.sin(a) * 3);
    c.lineTo(Math.cos(a) * len, Math.sin(a) * len);
    c.stroke();
  }

  // Outer red-orange flame teardrop
  c.fillStyle = '#f97316';
  c.beginPath();
  c.moveTo(0, -13 * flicker);
  c.quadraticCurveTo(8 * flicker, -2, 0, 5);
  c.quadraticCurveTo(-8 * flicker, -2, 0, -13 * flicker);
  c.fill();

  // Inner bright yellow-white core
  c.fillStyle = '#fef9c3';
  c.beginPath();
  c.moveTo(0, -8 * flicker);
  c.quadraticCurveTo(4.2 * flicker, -1, 0, 3.2);
  c.quadraticCurveTo(-4.2 * flicker, -1, 0, -8 * flicker);
  c.fill();
  c.restore();

  c.restore();
}
