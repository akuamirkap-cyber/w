import type { BossHead } from './bossCatalog';
import { bossWeaponMeta, drawBossWeapon } from './bossWeaponArt';
import { drawKnife } from './knifeArt';
import { drawRgbGlowSprite } from './art/glowSprite';

const TAU = Math.PI * 2;
const OUTLINE = '#1a1020';

export interface BossHandPalette {
  palmLight: string;
  palmMid: string;
  palmDark: string;
  crease: string;
  claw?: string;
  accent?: string;
}

const HAND_PALETTES: Record<BossHead, BossHandPalette> = {
  pirate: {
    palmLight: '#f6c5a3',
    palmMid: '#e19c73',
    palmDark: '#b36b46',
    crease: 'rgba(110, 48, 22, 0.42)',
  },
  jester: {
    palmLight: '#ffffff',
    palmMid: '#e9eef6',
    palmDark: '#cbd5e1',
    crease: 'rgba(107, 33, 168, 0.28)',
    accent: '#d946ef',
  },
  dragon: {
    palmLight: '#fdba74',
    palmMid: '#ea580c',
    palmDark: '#9a3412',
    crease: 'rgba(67, 20, 7, 0.48)',
    claw: '#fef3c7',
  },
  skeleton: {
    palmLight: '#ffffff',
    palmMid: '#e2e8f0',
    palmDark: '#94a3b8',
    crease: 'rgba(51, 65, 85, 0.45)',
  },
  tiki: {
    palmLight: '#d97706',
    palmMid: '#92400e',
    palmDark: '#5c2808',
    crease: 'rgba(28, 12, 4, 0.5)',
    accent: '#2dd4bf',
  },
  viking: {
    palmLight: '#f8d2b8',
    palmMid: '#dfa580',
    palmDark: '#b57852',
    crease: 'rgba(105, 56, 30, 0.4)',
  },
  oni: {
    palmLight: '#f87171',
    palmMid: '#dc2626',
    palmDark: '#7f1d1d',
    crease: 'rgba(69, 10, 10, 0.5)',
    claw: '#1e1b18',
  },
  robot: {
    palmLight: '#cbd5e1',
    palmMid: '#64748b',
    palmDark: '#334155',
    crease: 'rgba(15, 23, 42, 0.55)',
    accent: '#22d3ee',
  },
  alien: {
    palmLight: '#d8b4fe',
    palmMid: '#a855f7',
    palmDark: '#6b21a8',
    crease: 'rgba(59, 7, 100, 0.48)',
  },
  vampire: {
    palmLight: '#f5eff2',
    palmMid: '#d6c8d0',
    palmDark: '#9f8c97',
    crease: 'rgba(88, 28, 45, 0.36)',
    claw: '#991b1b',
  },
  sun: {
    palmLight: '#fef08a',
    palmMid: '#f59e0b',
    palmDark: '#b45309',
    crease: 'rgba(120, 53, 15, 0.45)',
    accent: '#fffbeb',
  },
};

export function bossHandPalette(head?: BossHead): BossHandPalette {
  return (head && HAND_PALETTES[head]) || HAND_PALETTES.pirate;
}

function makePalmGradient(c: CanvasRenderingContext2D, pal: BossHandPalette, x0: number, y0: number, x1: number, y1: number) {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  g.addColorStop(0, pal.palmLight);
  g.addColorStop(0.55, pal.palmMid);
  g.addColorStop(1, pal.palmDark);
  return g;
}

function roundPill(c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w * 0.5, h * 0.5);
  c.beginPath();
  c.moveTo(x + rr, y);
  c.lineTo(x + w - rr, y);
  c.quadraticCurveTo(x + w, y, x + w, y + rr);
  c.lineTo(x + w, y + h - rr);
  c.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  c.lineTo(x + rr, y + h);
  c.quadraticCurveTo(x, y + h, x, y + h - rr);
  c.lineTo(x, y + rr);
  c.quadraticCurveTo(x, y, x + rr, y);
  c.closePath();
}

export interface BossHandDrawOpts {
  head?: BossHead;
  /** -1 or +1 to mirror thumb/finger orientation naturally per side. */
  side: -1 | 1;
  /** 'grip' = holding the knife before throwing; 'throw' = open palm follow-through after release. */
  pose: 'grip' | 'throw';
  /** Knife variant (0..2) drawn inside the grip when pose === 'grip'. */
  knifeVariant: number;
  /** Knife pixel height (e.g. OBSTACLE_KNIFE_H * 0.72). */
  knifeHeight: number;
  /** 0..1 progress within the current phase (used for danger pulse / finger splay). */
  progress: number;
  /** Overall scale & opacity. */
  scale?: number;
  alpha?: number;
  time?: number;
}

/**
 * Draw a disembodied boss hand (telapak tangan tanpa lengan — palm + fingers only,
 * cleanly rounded at the base with zero wrist or forearm).
 *
 * Local space:
 *   (0, 0) = grip / palm center
 *   -y     = forward toward the target (blade tip direction)
 *   +y     = rounded base of the palm
 */
export function drawFloatingBossHand(c: CanvasRenderingContext2D, opts: BossHandDrawOpts) {
  const pal = bossHandPalette(opts.head);
  const scale = opts.scale ?? 1;
  const alpha = opts.alpha ?? 1;
  if (alpha <= 0.01 || scale <= 0.01) return;

  c.save();
  c.globalAlpha *= alpha;
  c.scale(scale, scale);

  if (opts.pose === 'grip') {
    drawGrippingHand(c, pal, opts);
  } else {
    drawThrowingOpenHand(c, pal, opts);
  }

  c.restore();
}

function drawGrippingHand(c: CanvasRenderingContext2D, pal: BossHandPalette, opts: BossHandDrawOpts) {
  const kh = opts.knifeHeight;
  const dangerPulse = 0.55 + 0.45 * Math.sin((opts.time ?? 0) * 20);
  const chargeGlow = Math.min(1, 0.35 + opts.progress * 0.65);

  // 1) Back of the palm (mirrored by side, strictly rounded base with NO arm)
  c.save();
  c.scale(opts.side, 1);

  // Soft shadow behind the floating palm
  c.beginPath();
  c.ellipse(1.5, 2.5, 13.5, 14.5, 0, 0, TAU);
  c.fillStyle = 'rgba(0,0,0,0.28)';
  c.fill();

  // Rounded palm body (back layer behind knife handle)
  c.beginPath();
  c.moveTo(-11, -7);
  c.quadraticCurveTo(-13.5, 3, -10.5, 11.5);
  c.quadraticCurveTo(-6, 16.5, 0.5, 16.2);
  c.quadraticCurveTo(8, 15.8, 11.8, 10.5);
  c.quadraticCurveTo(14, 3, 12.2, -7.5);
  c.quadraticCurveTo(9, -12, 0.5, -12);
  c.quadraticCurveTo(-8.5, -12, -11, -7);
  c.closePath();

  c.fillStyle = makePalmGradient(c, pal, -12, -12, 12, 16);
  c.fill();
  c.lineWidth = 2;
  c.lineJoin = 'round';
  c.strokeStyle = OUTLINE;
  c.stroke();

  // Optional robot / tiki / jester palm detail on the palm heel
  if (pal.accent) {
    c.save();
    c.globalAlpha *= 0.85;
    c.beginPath();
    c.arc(0, 4, 3.2, 0, TAU);
    c.fillStyle = pal.accent;
    c.fill();
    c.restore();
  }
  c.restore();

  // 2) The boss's unique weapon held inside the palm (grip centered at (0, 0), tip pointing -y)
  const wMeta = bossWeaponMeta(opts.head);
  c.save();
  // Boss-themed danger aura on the weapon so the player spots the incoming throw immediately
  c.save();
  c.globalCompositeOperation = 'lighter';
  drawRgbGlowSprite(c, 0, -kh * 0.42, 36, 44, wMeta.glowRgb, 0.78 * chargeGlow * dangerPulse);
  c.restore();

  c.translate(0, -kh * 0.79);
  if (opts.head) {
    drawBossWeapon(c, opts.head, kh);
  } else {
    drawKnife(c, opts.knifeVariant, kh);
  }
  c.restore();

  // 3) Curled fingers & thumb in FRONT of the knife handle (truly gripping it)
  c.save();
  c.scale(opts.side, 1);

  const fingerSpecs = [
    { y: -9.8, w: 13.8, h: 5.1, x: -2.2 },
    { y: -4.4, w: 15.2, h: 5.2, x: -3.2 },
    { y: 1.1, w: 14.4, h: 5.0, x: -2.8 },
    { y: 6.4, w: 12.4, h: 4.7, x: -1.6 },
  ];

  for (let i = 0; i < fingerSpecs.length; i++) {
    const f = fingerSpecs[i];
    roundPill(c, f.x, f.y, f.w, f.h, 2.5);
    c.fillStyle = makePalmGradient(c, pal, f.x, f.y, f.x + f.w, f.y + f.h);
    c.fill();
    c.lineWidth = 1.65;
    c.strokeStyle = OUTLINE;
    c.stroke();

    // Knuckle highlight on the outer bend
    c.beginPath();
    c.moveTo(f.x + f.w * 0.45, f.y + 1.3);
    c.lineTo(f.x + f.w * 0.82, f.y + 1.3);
    c.strokeStyle = 'rgba(255,255,255,0.42)';
    c.lineWidth = 1;
    c.lineCap = 'round';
    c.stroke();

    // Optional claw tip on the inside edge for monster bosses
    if (pal.claw) {
      c.beginPath();
      c.moveTo(f.x + 0.5, f.y + 1.2);
      c.lineTo(f.x - 2.6, f.y + f.h * 0.5);
      c.lineTo(f.x + 0.5, f.y + f.h - 1.1);
      c.closePath();
      c.fillStyle = pal.claw;
      c.fill();
      c.lineWidth = 1;
      c.strokeStyle = OUTLINE;
      c.stroke();
    }
  }

  // Opposing thumb wrapping across the front of the handle from the other side
  c.save();
  c.translate(-9.5, 4.5);
  c.rotate(-0.42);
  roundPill(c, -2.5, -3.2, 13.5, 6.2, 3.1);
  c.fillStyle = makePalmGradient(c, pal, -2, -3, 11, 3);
  c.fill();
  c.lineWidth = 1.75;
  c.strokeStyle = OUTLINE;
  c.stroke();
  // Thumb highlight
  c.beginPath();
  c.moveTo(1.5, -1.6);
  c.lineTo(7.5, -1.6);
  c.strokeStyle = 'rgba(255,255,255,0.4)';
  c.lineWidth = 1.1;
  c.lineCap = 'round';
  c.stroke();
  c.restore();

  c.restore();
}

function drawThrowingOpenHand(c: CanvasRenderingContext2D, pal: BossHandPalette, opts: BossHandDrawOpts) {
  const p = Math.max(0, Math.min(1, opts.progress));
  const splay = 0.7 + 0.3 * Math.sin(p * Math.PI * 0.5);

  c.save();
  c.scale(opts.side, 1);

  // Motion whoosh streaks behind the throwing palm
  const wMeta = bossWeaponMeta(opts.head);
  c.save();
  c.strokeStyle = `rgba(${wMeta.glowRgb}, ${(0.62 * (1 - p)).toFixed(3)})`;
  c.lineWidth = 2;
  c.lineCap = 'round';
  for (const wx of [-8, 0, 8]) {
    c.beginPath();
    c.moveTo(wx, 12);
    c.lineTo(wx * 0.85, 22 + p * 12);
    c.stroke();
  }
  c.restore();

  // Four open splayed fingers (extending forward toward -y)
  const openFingers = [
    { x: -9.5, y: -7.5, rot: -0.26 * splay, w: 5.0, h: 14.5 },
    { x: -3.8, y: -9.5, rot: -0.08 * splay, w: 5.2, h: 16.5 },
    { x: 2.0, y: -9.0, rot: 0.1 * splay, w: 5.0, h: 15.5 },
    { x: 7.4, y: -6.8, rot: 0.28 * splay, w: 4.5, h: 12.8 },
  ];
  for (const f of openFingers) {
    c.save();
    c.translate(f.x + f.w * 0.5, f.y);
    c.rotate(f.rot);
    roundPill(c, -f.w * 0.5, -f.h + 2, f.w, f.h, f.w * 0.48);
    c.fillStyle = makePalmGradient(c, pal, -f.w * 0.5, -f.h, f.w * 0.5, 2);
    c.fill();
    c.lineWidth = 1.65;
    c.strokeStyle = OUTLINE;
    c.stroke();
    c.restore();
  }

  // Open thumb splayed outward
  c.save();
  c.translate(-10.5, 2.5);
  c.rotate(-0.88 * splay);
  roundPill(c, -2.7, -12, 5.4, 13, 2.7);
  c.fillStyle = makePalmGradient(c, pal, -3, -12, 3, 1);
  c.fill();
  c.lineWidth = 1.65;
  c.strokeStyle = OUTLINE;
  c.stroke();
  c.restore();

  // Open palm (telapak tangan) in front, cleanly rounded heel with NO arm
  c.beginPath();
  c.moveTo(-11.2, -5.5);
  c.quadraticCurveTo(-13.2, 4, -9.8, 11.2);
  c.quadraticCurveTo(-5, 15.8, 0.5, 15.6);
  c.quadraticCurveTo(7.2, 15.4, 10.8, 10.2);
  c.quadraticCurveTo(13, 3.5, 11.4, -5.5);
  c.quadraticCurveTo(6, -10.2, 0, -10.2);
  c.quadraticCurveTo(-6.5, -10.2, -11.2, -5.5);
  c.closePath();
  c.fillStyle = makePalmGradient(c, pal, -12, -10, 12, 16);
  c.fill();
  c.lineWidth = 2;
  c.strokeStyle = OUTLINE;
  c.stroke();

  // Palm crease lines so it unmistakably reads as an open palm
  c.strokeStyle = pal.crease;
  c.lineWidth = 1.4;
  c.lineCap = 'round';
  c.beginPath();
  c.moveTo(-6.5, -1.5);
  c.quadraticCurveTo(0, 1.5, 7, -1.2);
  c.stroke();
  c.beginPath();
  c.moveTo(-5.5, 3.8);
  c.quadraticCurveTo(-0.5, 5.5, 4.5, 9.5);
  c.stroke();

  if (pal.accent) {
    c.beginPath();
    c.arc(0.5, 4, 3, 0, TAU);
    c.fillStyle = pal.accent;
    c.fill();
  }

  c.restore();
}
