import type { ProjKind } from '../weapons';
import { TAU, lin, radial, gunState } from './kit';
import { drawKerisSlideProjectile, drawSlide2DiamondBullet } from './specialGunArt';
import { drawHolyLightArrow } from './holyLight';

type C = CanvasRenderingContext2D;

function glowE(c: C, y: number, rx: number, ry: number, rgb: string, a: number) {
  c.save();
  c.globalCompositeOperation = 'lighter';
  const g = c.createRadialGradient(0, y, 1, 0, y, Math.max(rx, ry));
  g.addColorStop(0, `rgba(${rgb},${a})`);
  g.addColorStop(1, `rgba(${rgb},0)`);
  c.fillStyle = g;
  c.beginPath();
  c.ellipse(0, y, rx, ry, 0, 0, TAU);
  c.fill();
  c.restore();
}

export function drawProjectileExtra2(c: C, kind: ProjKind, len: number, t: number, _age: number, embedded = false) {
  switch (kind) {
    case 'keris': {
      drawKerisSlideProjectile(c, t, embedded);
      break;
    }
    case 'shark': {
      const wig = Math.sin(t * 16) * 2;
      c.beginPath();
      c.moveTo(0, -3);
      c.bezierCurveTo(8, 4, 8, len * 0.6, 2, len * 0.78);
      c.lineTo(-2, len * 0.78);
      c.bezierCurveTo(-8, len * 0.6, -8, 4, 0, -3);
      c.fillStyle = lin(c, -8, 8, ['#334155', '#94a3b8', '#e2e8f0']);
      c.fill();
      c.strokeStyle = '#1e293b';
      c.lineWidth = 1;
      c.stroke();
      c.fillStyle = '#475569';
      c.beginPath();
      c.moveTo(-6, len * 0.4);
      c.lineTo(-12, len * 0.55);
      c.lineTo(-5, len * 0.5);
      c.moveTo(6, len * 0.4);
      c.lineTo(12, len * 0.55);
      c.lineTo(5, len * 0.5);
      c.fill();
      c.beginPath();
      c.moveTo(0, len * 0.75);
      c.lineTo(-7 + wig, len + 2);
      c.lineTo(0, len * 0.9);
      c.lineTo(7 + wig, len + 2);
      c.closePath();
      c.fill();
      c.fillStyle = '#7f1d1d';
      c.beginPath();
      c.ellipse(0, 5, 4, 2.5, 0, 0, TAU);
      c.fill();
      c.fillStyle = '#fff';
      for (let i = -1; i <= 1; i++) {
        c.beginPath();
        c.moveTo(i * 2.2 - 1, 3.5);
        c.lineTo(i * 2.2, 5.5);
        c.lineTo(i * 2.2 + 1, 3.5);
        c.fill();
      }
      c.fillStyle = '#000';
      c.beginPath();
      c.arc(-4, 9, 1.2, 0, TAU);
      c.arc(4, 9, 1.2, 0, TAU);
      c.fill();
      break;
    }
    case 'ghost': {
      c.save();
      c.globalAlpha = 0.75 + 0.2 * Math.sin(t * 8);
      glowE(c, len * 0.4, 12, len * 0.6, '199,210,254', 0.5);
      c.beginPath();
      c.moveTo(-7, len * 0.7);
      c.lineTo(-7, 8);
      c.quadraticCurveTo(-7, -2, 0, -2);
      c.quadraticCurveTo(7, -2, 7, 8);
      c.lineTo(7, len * 0.7);
      for (let i = 0; i < 4; i++) c.quadraticCurveTo(5 - i * 4, len * 0.85 + Math.sin(t * 10 + i) * 3, 3.5 - i * 3.5, len * 0.7);
      c.closePath();
      c.fillStyle = 'rgba(238,242,255,0.95)';
      c.fill();
      c.fillStyle = '#1e1b4b';
      c.beginPath();
      c.ellipse(-2.5, 8, 1.6, 2.4, 0, 0, TAU);
      c.ellipse(2.5, 8, 1.6, 2.4, 0, 0, TAU);
      c.fill();
      c.beginPath();
      c.ellipse(0, 14, 1.6, 2, 0, 0, TAU);
      c.fill();
      c.restore();
      break;
    }
    case 'meteor': {
      const r = Math.min(9, len * 0.35);
      glowE(c, r + 2, 22, len * 0.9, '255,124,34', 0.64);
      const flame = c.createLinearGradient(0, r, 0, len + 22);
      flame.addColorStop(0, 'rgba(255,253,206,0.96)');
      flame.addColorStop(0.25, 'rgba(251,158,49,0.8)');
      flame.addColorStop(0.66, 'rgba(234,64,27,0.56)');
      flame.addColorStop(1, 'rgba(185,28,28,0)');
      c.fillStyle = flame;
      c.beginPath(); c.moveTo(-r, r);
      c.bezierCurveTo(-r - 5, len * 0.55, -4, len * 0.65, -3, len + 18);
      c.quadraticCurveTo(1, len * 0.88, 2, len * 0.72);
      c.quadraticCurveTo(6, len * 0.9, 3, len + 10);
      c.bezierCurveTo(r + 8, len * 0.45, r + 2, len * 0.24, r, r);
      c.closePath(); c.fill();
      c.fillStyle = 'rgba(255,230,124,0.88)';
      c.beginPath(); c.moveTo(-3, r + 5);
      c.quadraticCurveTo(-5, len * 0.55, 0, len * 0.78);
      c.quadraticCurveTo(4, len * 0.5, 3, r + 5); c.closePath(); c.fill();
      c.beginPath();
      for (let i = 0; i < 10; i++) {
        const angle = i * TAU / 10, size = r * (i % 2 ? 0.91 : 1.08);
        c.lineTo(Math.cos(angle) * size, r + Math.sin(angle) * size);
      }
      c.closePath(); c.fillStyle = radial(c, 0, r, r * 1.3,
        ['#e7d2b0', '#685455', '#241d24']); c.fill();
      c.strokeStyle = '#ff993f'; c.lineWidth = 1.5;
      c.beginPath(); c.moveTo(-r * 0.65, r - 4);
      c.lineTo(-2, r - 1); c.lineTo(1, r + 4); c.lineTo(r * 0.6, r + 2);
      c.moveTo(-2, r - 1); c.lineTo(1, r - r * 0.65); c.stroke();
      c.fillStyle = '#ffdb82';
      for (const [x, y, size] of [[-12, len * 0.5, 1.8], [11, len * 0.68, 1.5]]) {
        c.beginPath(); c.arc(x, y, size, 0, TAU); c.fill();
      }
      break;
    }
    case 'diamond': {
      c.save();
      if (!embedded) {
        c.rotate(Math.sin(t * 3 + gunState.diamondSeed) * 0.2);
      }
      drawSlide2DiamondBullet(
        c,
        embedded ? 11.5 : 12,
        t,
        gunState.diamondSeed,
        gunState.diamondFlash,
      );
      c.restore();
      break;
    }
    case 'holy': {
      drawHolyLightArrow(c, len, t, embedded ? 0.92 : 1);
      break;
    }
    default:
      break;
  }
}
