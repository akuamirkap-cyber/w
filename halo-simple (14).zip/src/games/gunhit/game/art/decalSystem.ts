import type { Weapon } from '../weapons';

const TAU = Math.PI * 2;

export function drawPreciseWeaponDecal(
  c: CanvasRenderingContext2D,
  R: number,
  a: number,
  w: Weapon,
  style: string,
  _time = 0,
  _tint?: string,
  impactPos?: { x: number; y: number; skipArcClip?: boolean }
) {
  const x = impactPos ? impactPos.x : Math.cos(a) * (R - 2.5);
  const y = impactPos ? impactPos.y : Math.sin(a) * (R - 2.5);
  const inward = a + Math.PI;

  c.save();
  if (!impactPos?.skipArcClip) {
    c.beginPath();
    c.arc(0, 0, R, 0, TAU);
    c.clip();
  }

  // Keris sticks cleanly onto the rim without a black hole.
  if (w.id === 'keris') {
    c.restore();
    return;
  }

  // 1. SENJATA LASER / PLASMA / ENERGI
  if (w.energy || w.beam || w.id === 'plasma' || w.id === 'laser') {
    c.save();
    c.translate(x, y);
    c.rotate(inward);

    const col = w.color || '#39ff9c';
    c.fillStyle = 'rgba(10, 8, 12, 0.85)';
    c.beginPath();
    c.roundRect(-2, -1, 4, 7, 2);
    c.fill();

    c.fillStyle = '#ffffff';
    c.beginPath();
    c.arc(0, 0, 1.2, 0, TAU);
    c.fill();

    c.strokeStyle = col;
    c.lineWidth = 1.2;
    c.beginPath();
    c.arc(0, 1, 3.5, 0, Math.PI);
    c.stroke();

    c.strokeStyle = 'rgba(255,255,255,0.7)';
    c.lineWidth = 0.8;
    c.beginPath();
    c.moveTo(-2, 0); c.lineTo(-6, 3);
    c.moveTo(2, 0); c.lineTo(6, 3);
    c.stroke();

    c.restore();
    c.restore();
    return;
  }

  if (w.id === 'bamboo') {
    c.save(); c.translate(x - Math.cos(a) * 5, y - Math.sin(a) * 5);
    c.rotate(inward - Math.PI / 2);
    const ash = c.createRadialGradient(0, 4, 1, 0, 4, 16);
    ash.addColorStop(0, 'rgba(255,255,234,0.81)');
    ash.addColorStop(0.55, 'rgba(240,221,164,0.53)');
    ash.addColorStop(1, 'rgba(226,215,186,0)');
    c.fillStyle = ash; c.beginPath(); c.ellipse(0, 4, 16, 11, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,248,216,0.91)'; c.lineWidth = 1.2;
    c.beginPath(); c.arc(0, 2, 5, 0, Math.PI * 1.4); c.stroke();
    c.fillStyle = '#f5a345'; c.beginPath(); c.arc(1, 2, 1.4, 0, TAU); c.fill();
    c.restore(); c.restore(); return;
  }

  if (w.id === 'dragon') {
    c.save(); c.translate(x - Math.cos(a) * 5, y - Math.sin(a) * 5);
    c.rotate(inward - Math.PI / 2);
    const ember = c.createRadialGradient(0, 2, 1, 0, 2, 14);
    ember.addColorStop(0, 'rgba(255,224,127,0.83)');
    ember.addColorStop(0.32, 'rgba(228,91,34,0.56)');
    ember.addColorStop(1, 'rgba(105,32,30,0)');
    c.fillStyle = ember; c.beginPath(); c.ellipse(0, 3, 13, 12, 0, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(255,221,126,0.84)'; c.lineWidth = 1.1;
    c.beginPath(); c.moveTo(-5, 4); c.lineTo(-2, 10); c.lineTo(-4, 15);
    c.moveTo(2, 1); c.lineTo(6, 11); c.lineTo(3, 16); c.stroke();
    c.restore(); c.restore(); return;
  }

  // 2. SENJATA TAJAM / SLIT (Crossbow, Nail Gun, Jarum Sumpit)
  if (w.half <= 3.2 || w.id === 'nail' || w.id === 'crossbow' || w.id === 'blowgun') {
    c.save();
    c.translate(x, y);
    c.rotate(inward);

    c.fillStyle = '#0a0808';
    c.beginPath();
    c.roundRect(-1.2, -1, 2.4, 8, 1.2);
    c.fill();

    c.fillStyle = 'rgba(255,255,255,0.85)';
    c.fillRect(-0.4, 0, 0.8, 6);

    c.restore();
    c.restore();
    return;
  }

  // 3. SENJATA CAIRAN / ORGANIK (Fish, Shark)
  if (w.id === 'fish' || w.id === 'shark') {
    c.save();
    c.translate(x, y);
    c.rotate(inward);

    c.fillStyle = 'rgba(56, 189, 248, 0.5)';
    c.beginPath();
    c.arc(0, 3, 4, 0, TAU);
    c.arc(-4, 6, 2, 0, TAU);
    c.arc(3, 7, 2.5, 0, TAU);
    c.fill();

    c.fillStyle = 'rgba(255,255,255,0.7)';
    c.beginPath();
    c.arc(-1, 2, 1.2, 0, TAU);
    c.fill();

    c.restore();
    c.restore();
    return;
  }

  // 4. SENJATA ES (Freeze Ray)
  if (w.slow && w.id === 'freeze') {
    c.save();
    c.translate(x, y);
    c.rotate(inward);

    c.strokeStyle = 'rgba(255,255,255,0.9)';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(0, -2); c.lineTo(0, 8);
    c.moveTo(-4, 3); c.lineTo(4, 3);
    c.moveTo(-3, 1); c.lineTo(3, 5);
    c.moveTo(3, 1); c.lineTo(-3, 5);
    c.stroke();

    c.fillStyle = 'rgba(186, 230, 253, 0.7)';
    c.beginPath();
    c.arc(0, 3, 2, 0, TAU);
    c.fill();

    c.restore();
    c.restore();
    return;
  }

  // 5. SENJATA LEDAKAN BESAR (RPG, Bazooka, Meteor)
  if (w.explode || w.id === 'bazooka' || w.id === 'rpg' || w.id === 'meteor') {
    c.save();
    c.translate(x, y);
    c.rotate(inward);

    const g = c.createRadialGradient(0, 3, 1, 0, 3, 12);
    g.addColorStop(0, 'rgba(15, 10, 8, 0.85)');
    g.addColorStop(0.5, 'rgba(60, 30, 10, 0.4)');
    g.addColorStop(1, 'rgba(0, 0, 0, 0)');
    c.fillStyle = g;
    c.beginPath();
    c.arc(0, 3, 12, 0, TAU);
    c.fill();

    c.strokeStyle = 'rgba(15, 10, 8, 0.9)';
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(0, 0); c.lineTo(-5, 9);
    c.moveTo(0, 0); c.lineTo(0, 11);
    c.moveTo(0, 0); c.lineTo(5, 9);
    c.stroke();

    c.fillStyle = '#ff8000';
    c.beginPath();
    c.arc(0, 1, 1.2, 0, TAU);
    c.fill();

    c.restore();
    c.restore();
    return;
  }

  // 6. DEFAULT SENJATA PELURU LOGAM (Pistol, AK-47, Shotgun, Minigun, Sniper, dll.)
  c.save();
  c.translate(x, y);
  c.rotate(inward);

  const darkColor = style === 'orange' ? '#5a2d0c' : '#140c06';

  c.fillStyle = 'rgba(0,0,0,0.22)';
  c.beginPath();
  c.arc(0, 2, 4.5, 0, TAU);
  c.fill();

  c.fillStyle = darkColor;
  c.beginPath();
  c.arc(0, 1.5, 2.4, 0, TAU);
  c.fill();

  c.strokeStyle = 'rgba(255, 255, 255, 0.6)';
  c.lineWidth = 0.8;
  c.beginPath();
  c.arc(0, 1.5, 2.2, Math.PI * 0.9, Math.PI * 1.7);
  c.stroke();

  c.strokeStyle = darkColor;
  c.lineWidth = 1.1;
  c.beginPath();
  c.moveTo(-1.8, 1);
  c.lineTo(-4.5, 5);
  c.moveTo(1.8, 1);
  c.lineTo(4.5, 5);
  c.stroke();

  c.restore();
  c.restore();
}
