import type { BossHead } from './bossCatalog';

const BW_W = 40;
const BW_H = 88;
const SPRITE_SCALE = 4;
const OUTLINE = '#1a1020';
const TAU = Math.PI * 2;

type Ctx = CanvasRenderingContext2D;

export interface BossWeaponMeta {
  id: BossHead;
  name: string;
  glowRgb: string;
  sparkColors: [string, string, string];
  trailColor: string;
  hitText: string;
  breakText: string;
}

const META: Record<BossHead, BossWeaponMeta> = {
  pirate: {
    id: 'pirate',
    name: 'Pedang Cutlass',
    glowRgb: '255,165,45',
    sparkColors: ['#fde68a', '#fb923c', '#ffffff'],
    trailColor: '#fbbf24',
    hitText: 'KENA PEDANG BAJAK LAUT!',
    breakText: 'PEDANG HANCUR!',
  },
  jester: {
    id: 'jester',
    name: 'Kartu Belati',
    glowRgb: '217,70,239',
    sparkColors: ['#f0abfc', '#fde047', '#4ade80'],
    trailColor: '#e879f9',
    hitText: 'KENA KARTU BELATI!',
    breakText: 'KARTU BELATI HANCUR!',
  },
  dragon: {
    id: 'dragon',
    name: 'Tombak Taring Naga',
    glowRgb: '249,115,22',
    sparkColors: ['#fdba74', '#86efac', '#fef08a'],
    trailColor: '#fb923c',
    hitText: 'KENA TARING NAGA!',
    breakText: 'TARING NAGA HANCUR!',
  },
  skeleton: {
    id: 'skeleton',
    name: 'Sabit Tulang',
    glowRgb: '239,68,68',
    sparkColors: ['#fca5a5', '#fef3c7', '#ffffff'],
    trailColor: '#f87171',
    hitText: 'KENA SABIT TENGKORAK!',
    breakText: 'SABIT TULANG HANCUR!',
  },
  tiki: {
    id: 'tiki',
    name: 'Tombak Obsidian',
    glowRgb: '45,212,191',
    sparkColors: ['#5eead4', '#4ade80', '#fb7185'],
    trailColor: '#2dd4bf',
    hitText: 'KENA TOMBAK TIKI!',
    breakText: 'TOMBAK TIKI HANCUR!',
  },
  viking: {
    id: 'viking',
    name: 'Kapak Badai',
    glowRgb: '56,189,248',
    sparkColors: ['#bae6fd', '#fb923c', '#ffffff'],
    trailColor: '#7dd3fc',
    hitText: 'KENA KAPAK VIKING!',
    breakText: 'KAPAK BADAI HANCUR!',
  },
  oni: {
    id: 'oni',
    name: 'Belati Oni',
    glowRgb: '239,68,68',
    sparkColors: ['#f87171', '#fde047', '#ffffff'],
    trailColor: '#ef4444',
    hitText: 'KENA BELATI ONI!',
    breakText: 'BELATI ONI HANCUR!',
  },
  robot: {
    id: 'robot',
    name: 'Pedang Plasma',
    glowRgb: '34,211,238',
    sparkColors: ['#67e8f9', '#ef4444', '#ffffff'],
    trailColor: '#22d3ee',
    hitText: 'KENA PEDANG ROBOT!',
    breakText: 'PEDANG PLASMA HANCUR!',
  },
  alien: {
    id: 'alien',
    name: 'Glaive Xenotech',
    glowRgb: '163,230,53',
    sparkColors: ['#bef264', '#c084fc', '#ffffff'],
    trailColor: '#a3e635',
    hitText: 'KENA GLAIVE ALIEN!',
    breakText: 'SENJATA ALIEN HANCUR!',
  },
  vampire: {
    id: 'vampire',
    name: 'Stiletto Kelelawar',
    glowRgb: '225,29,72',
    sparkColors: ['#fda4af', '#fb7185', '#ffffff'],
    trailColor: '#f43f5e',
    hitText: 'KENA STILETTO VAMPIR!',
    breakText: 'BELATI VAMPIR HANCUR!',
  },
  sun: {
    id: 'sun',
    name: 'Tombak Matahari',
    glowRgb: '251,191,36',
    sparkColors: ['#fef08a', '#fb923c', '#ffffff'],
    trailColor: '#facc15',
    hitText: 'KENA TOMBAK SURYA!',
    breakText: 'TOMBAK SURYA HANCUR!',
  },
};

export function bossWeaponMeta(head?: BossHead): BossWeaponMeta {
  return (head && META[head]) || META.pirate;
}

const grad = (c: Ctx, stops: [number, string][], x0: number, y0: number, x1: number, y1: number) => {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  for (const [at, col] of stops) g.addColorStop(at, col);
  return g;
};

const roundRectPath = (c: Ctx, x: number, y: number, w: number, h: number, r: number) => {
  const rr = Math.min(r, w * 0.5, h * 0.5);
  c.beginPath();
  c.moveTo(x + rr, y);
  c.lineTo(x + w - rr, y);
  c.quadraticCurveTo(x + w, y, x + w, y + rr);
  c.lineTo(x + w, y + h - rr);
  c.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  c.lineTo(x + rr, y + h);
  c.quadraticCurveTo(x, y + h, x, y + h - rr);
  c.lineTo(x, y + rr);
  c.quadraticCurveTo(x, y, x + rr, y);
  c.closePath();
};

const STEEL: [number, string][] = [
  [0, '#82909e'],
  [0.42, '#f8fafc'],
  [0.65, '#cbd5e1'],
  [1, '#5d6975'],
];

const GOLD: [number, string][] = [
  [0, '#fff7c2'],
  [0.5, '#f5b82e'],
  [1, '#925200'],
];

const WOOD: [number, string][] = [
  [0, '#5b2c0f'],
  [0.45, '#b8733a'],
  [1, '#421d06'],
];

function paintBossWeapon(c: Ctx, head: BossHead) {
  c.save();
  c.lineJoin = 'round';
  c.lineCap = 'round';
  c.lineWidth = 1.35;
  c.strokeStyle = OUTLINE;

  switch (head) {
    case 'pirate': {
      // Curved pirate cutlass with brass knuckle-bow D-guard
      c.beginPath();
      c.moveTo(21, 1);
      c.quadraticCurveTo(10, 14, 13.5, 52);
      c.lineTo(22.5, 52);
      c.quadraticCurveTo(21, 30, 26.5, 13);
      c.lineTo(23.5, 11);
      c.quadraticCurveTo(24.5, 6, 21, 1);
      c.closePath();
      c.fillStyle = grad(c, STEEL, 11, 1, 26, 52);
      c.fill();
      c.stroke();

      // Blade highlight edge
      c.beginPath();
      c.moveTo(20, 4.5);
      c.quadraticCurveTo(12.5, 17, 15.2, 49);
      c.strokeStyle = 'rgba(255,255,255,0.85)';
      c.lineWidth = 1.1;
      c.stroke();

      // D-shape brass knuckle guard
      c.beginPath();
      c.moveTo(15, 55);
      c.bezierCurveTo(4, 58, 4, 78, 16, 80);
      c.strokeStyle = OUTLINE;
      c.lineWidth = 4.4;
      c.stroke();
      c.strokeStyle = grad(c, GOLD, 5, 55, 16, 80);
      c.lineWidth = 2.4;
      c.stroke();

      // Grip
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      roundRectPath(c, 15.8, 55, 8.4, 24, 3);
      c.fillStyle = grad(c, WOOD, 15.8, 55, 24.2, 55);
      c.fill();
      c.stroke();

      // Crossbar collar
      roundRectPath(c, 9.5, 50.5, 20, 5.8, 2.4);
      c.fillStyle = grad(c, GOLD, 9.5, 50.5, 29.5, 56);
      c.fill();
      c.stroke();

      // Gold pommel cap
      c.beginPath();
      c.arc(20, 81.5, 4.2, 0, TAU);
      c.fillStyle = grad(c, GOLD, 16, 77, 24, 86);
      c.fill();
      c.stroke();
      break;
    }

    case 'jester': {
      // Razor playing-card dagger with purple/emerald diamond face + golden bells
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(31, 15);
      c.lineTo(28.5, 49);
      c.lineTo(11.5, 49);
      c.lineTo(9, 15);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#ffffff'], [0.7, '#f1f5f9'], [1, '#cbd5e1']], 9, 1, 31, 49);
      c.fill();
      c.stroke();

      // Beveled cutting edge rim
      c.beginPath();
      c.moveTo(20, 3.5);
      c.lineTo(29.2, 15.5);
      c.lineTo(27, 46);
      c.strokeStyle = 'rgba(148,163,184,0.85)';
      c.lineWidth = 1.4;
      c.stroke();

      // Split jester card diamond emblem
      c.beginPath();
      c.moveTo(20, 13);
      c.lineTo(26, 26);
      c.lineTo(20, 39);
      c.closePath();
      c.fillStyle = '#22c55e';
      c.fill();
      c.beginPath();
      c.moveTo(20, 13);
      c.lineTo(14, 26);
      c.lineTo(20, 39);
      c.closePath();
      c.fillStyle = '#a855f7';
      c.fill();
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.1;
      c.beginPath();
      c.moveTo(20, 13);
      c.lineTo(26, 26);
      c.lineTo(20, 39);
      c.lineTo(14, 26);
      c.closePath();
      c.stroke();

      // Crimson cross-band
      c.lineWidth = 1.35;
      roundRectPath(c, 8.5, 48, 23, 6.2, 2.8);
      c.fillStyle = '#ef4444';
      c.fill();
      c.stroke();

      // Twin jester bells at guard ends
      for (const bx of [7.5, 32.5]) {
        c.beginPath();
        c.arc(bx, 52.5, 3.6, 0, TAU);
        c.fillStyle = grad(c, GOLD, bx - 3, 49, bx + 3, 56);
        c.fill();
        c.stroke();
      }

      // Striped purple/gold handle
      roundRectPath(c, 16.2, 54, 7.6, 23, 2.5);
      c.fillStyle = '#6b21a8';
      c.fill();
      c.stroke();
      c.strokeStyle = '#fde047';
      c.lineWidth = 1.4;
      for (const yy of [59, 65, 71]) {
        c.beginPath();
        c.moveTo(16.5, yy);
        c.lineTo(23.5, yy + 2.5);
        c.stroke();
      }
      // Pommel bell
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      c.beginPath();
      c.arc(20, 81, 4.3, 0, TAU);
      c.fillStyle = grad(c, GOLD, 16, 77, 24, 85);
      c.fill();
      c.stroke();
      break;
    }

    case 'dragon': {
      // Dragon fang spearhead with magma vein + curved ivory dragon-horn guard
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(28.5, 22);
      c.lineTo(24.5, 26);
      c.lineTo(27.5, 38);
      c.lineTo(23, 49);
      c.lineTo(17, 49);
      c.lineTo(12.5, 38);
      c.lineTo(15.5, 26);
      c.lineTo(11.5, 22);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#334155'], [0.45, '#94a3b8'], [1, '#1e293b']], 11, 1, 29, 49);
      c.fill();
      c.stroke();

      // Glowing magma dragon vein
      c.beginPath();
      c.moveTo(20, 6);
      c.lineTo(20, 46);
      c.strokeStyle = '#f97316';
      c.lineWidth = 3;
      c.stroke();
      c.strokeStyle = '#fef08a';
      c.lineWidth = 1.2;
      c.stroke();

      // Twin curved ivory dragon horns flaring out as cross-spurs
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.3;
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20 + s * 3, 52);
        c.quadraticCurveTo(20 + s * 14, 48, 20 + s * 16.5, 34);
        c.quadraticCurveTo(20 + s * 10, 44, 20 + s * 4, 47);
        c.closePath();
        c.fillStyle = grad(c, [[0, '#fffaf0'], [1, '#d9c08a']], 20, 34, 20 + s * 16, 52);
        c.fill();
        c.stroke();
      }

      // Dragon-scale jade grip
      roundRectPath(c, 16, 51, 8, 26, 2.8);
      c.fillStyle = grad(c, [[0, '#166534'], [0.5, '#4ade80'], [1, '#14532d']], 16, 51, 24, 51);
      c.fill();
      c.stroke();

      // Amber dragon-eye pommel
      c.beginPath();
      c.arc(20, 81, 4.2, 0, TAU);
      c.fillStyle = '#f59e0b';
      c.fill();
      c.stroke();
      break;
    }

    case 'skeleton': {
      // Curved ivory-steel bone scythe with horned skull socket & spine handle
      // Sweeping crescent scythe blade
      c.beginPath();
      c.moveTo(24, 3.5);
      c.quadraticCurveTo(6, 4, 3.5, 29);
      c.quadraticCurveTo(9, 17, 22, 16);
      c.lineTo(22.5, 21);
      c.quadraticCurveTo(28, 12, 24, 3.5);
      c.closePath();
      c.fillStyle = grad(c, STEEL, 3.5, 3, 27, 29);
      c.fill();
      c.stroke();

      // Razor edge gleam
      c.beginPath();
      c.moveTo(22, 5.2);
      c.quadraticCurveTo(8, 6.5, 5.2, 24);
      c.strokeStyle = 'rgba(255,255,255,0.9)';
      c.lineWidth = 1;
      c.stroke();

      // Upper bone shank connecting scythe to skull
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      roundRectPath(c, 17, 13, 6, 28, 2);
      c.fillStyle = grad(c, [[0, '#fffef8'], [1, '#b9aa86']], 17, 13, 23, 13);
      c.fill();
      c.stroke();

      // Miniature skull collar at y = 45
      c.beginPath();
      c.arc(20, 45, 7, 0, TAU);
      c.fillStyle = '#f5efd8';
      c.fill();
      c.stroke();
      // Glowing red skeleton eyes
      c.fillStyle = '#ef4444';
      c.beginPath();
      c.arc(17.5, 44.5, 1.5, 0, TAU);
      c.arc(22.5, 44.5, 1.5, 0, TAU);
      c.fill();

      // Segmented vertebrae spine shaft
      for (let i = 0; i < 4; i++) {
        roundRectPath(c, 16.5, 53 + i * 6.5, 7, 5.4, 2.2);
        c.fillStyle = i % 2 === 0 ? '#f5efd8' : '#dfd2b5';
        c.fill();
        c.stroke();
      }
      // Joint knuckle pommel
      c.beginPath();
      c.arc(17.5, 81.5, 2.7, 0, TAU);
      c.arc(22.5, 81.5, 2.7, 0, TAU);
      c.fillStyle = '#ece3cb';
      c.fill();
      c.stroke();
      break;
    }

    case 'tiki': {
      // Serrated volcanic obsidian spearhead with teal markings & jungle leaves
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(28, 16);
      c.lineTo(24.5, 18);
      c.lineTo(29.5, 31);
      c.lineTo(25, 33);
      c.lineTo(26.5, 46);
      c.lineTo(13.5, 46);
      c.lineTo(15, 33);
      c.lineTo(10.5, 31);
      c.lineTo(15.5, 18);
      c.lineTo(12, 16);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#0f172a'], [0.45, '#475569'], [1, '#090d16']], 10, 1, 30, 46);
      c.fill();
      c.stroke();

      // Glowing teal tiki war-paint chevrons on obsidian blade
      c.strokeStyle = '#2dd4bf';
      c.lineWidth = 1.6;
      c.beginPath();
      c.moveTo(16.5, 21);
      c.lineTo(20, 15);
      c.lineTo(23.5, 21);
      c.moveTo(16, 33);
      c.lineTo(20, 27);
      c.lineTo(24, 33);
      c.stroke();

      // Twin green jungle leaves flaring at collar
      c.strokeStyle = '#064e3b';
      c.lineWidth = 1.2;
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20, 50);
        c.quadraticCurveTo(20 + s * 11, 41, 20 + s * 15, 50);
        c.quadraticCurveTo(20 + s * 9, 55, 20, 52);
        c.closePath();
        c.fillStyle = '#4ade80';
        c.fill();
        c.stroke();
      }

      // Carved cedar shaft + bone lashing bands
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      roundRectPath(c, 16.4, 49, 7.2, 32, 2.8);
      c.fillStyle = grad(c, WOOD, 16.4, 49, 23.6, 49);
      c.fill();
      c.stroke();

      c.strokeStyle = '#f5d9a8';
      c.lineWidth = 1.8;
      for (const yy of [51, 56, 75]) {
        c.beginPath();
        c.moveTo(16, yy);
        c.lineTo(24, yy + 2);
        c.stroke();
      }
      break;
    }

    case 'viking': {
      // Bearded Norse throwing battle axe with frost-steel crescent blade + top spike
      // Top spear tip + back hammer spike
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(23.2, 16);
      c.lineTo(35, 19.5);
      c.lineTo(24, 27);
      c.lineTo(16, 27);
      c.closePath();
      c.fillStyle = grad(c, STEEL, 16, 1, 35, 27);
      c.fill();
      c.stroke();

      // Sweeping bearded axe blade on left side
      c.beginPath();
      c.moveTo(20, 16);
      c.quadraticCurveTo(10, 14, 3, 5.5);
      c.quadraticCurveTo(1.5, 24, 5.5, 45);
      c.quadraticCurveTo(13, 35, 20, 34);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#7dd3fc'], [0.4, '#f8fafc'], [1, '#64748b']], 2, 5, 20, 45);
      c.fill();
      c.stroke();

      // Crisp frost-silver axe edge glint
      c.beginPath();
      c.moveTo(4.2, 8.5);
      c.quadraticCurveTo(2.8, 24, 6.2, 42);
      c.strokeStyle = '#ffffff';
      c.lineWidth = 1.3;
      c.stroke();

      // Ash-wood haft with fiery orange leather wrap + brass collar
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      roundRectPath(c, 16.2, 16, 7.6, 65, 3);
      c.fillStyle = grad(c, WOOD, 16.2, 16, 23.8, 16);
      c.fill();
      c.stroke();

      roundRectPath(c, 14.8, 32, 10.4, 6, 1.8);
      c.fillStyle = grad(c, GOLD, 14.8, 32, 25.2, 38);
      c.fill();
      c.stroke();

      // Pommel cap
      c.beginPath();
      c.arc(20, 81.5, 4.4, 0, TAU);
      c.fillStyle = grad(c, GOLD, 16, 77, 24, 86);
      c.fill();
      c.stroke();
      break;
    }

    case 'oni': {
      // Demon-horned notched blood-forged Oni tantō blade
      c.beginPath();
      c.moveTo(21, 1);
      c.lineTo(26.5, 16);
      c.lineTo(23.5, 21);
      c.lineTo(26.5, 29);
      c.lineTo(24.5, 49);
      c.lineTo(14.5, 49);
      c.quadraticCurveTo(13, 22, 21, 1);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#7f1d1d'], [0.45, '#fca5a5'], [0.65, '#ef4444'], [1, '#450a0a']], 13, 1, 27, 49);
      c.fill();
      c.stroke();

      // Silver cutting edge line
      c.beginPath();
      c.moveTo(20.5, 4);
      c.quadraticCurveTo(14.8, 24, 16.2, 47);
      c.strokeStyle = '#fef2f2';
      c.lineWidth = 1.15;
      c.stroke();

      // Twin curved golden Oni horns forming the guard
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20, 52);
        c.quadraticCurveTo(20 + s * 13, 52, 20 + s * 15, 37);
        c.quadraticCurveTo(20 + s * 9, 46, 20 + s * 3, 47.5);
        c.closePath();
        c.fillStyle = grad(c, GOLD, 20, 37, 20 + s * 15, 52);
        c.fill();
        c.stroke();
      }

      // Traditional Japanese tsuka handle with white diamond wrap
      roundRectPath(c, 16, 51, 8, 28, 2.2);
      c.fillStyle = '#18181b';
      c.fill();
      c.stroke();
      c.fillStyle = '#fffaf0';
      for (const yy of [55, 61.5, 68, 74]) {
        c.beginPath();
        c.moveTo(20, yy - 2.2);
        c.lineTo(22.4, yy);
        c.lineTo(20, yy + 2.2);
        c.lineTo(17.6, yy);
        c.closePath();
        c.fill();
      }
      // Pommel ring
      c.beginPath();
      c.arc(20, 81.5, 3.8, 0, TAU);
      c.fillStyle = '#dc2626';
      c.fill();
      c.stroke();
      break;
    }

    case 'robot': {
      // Cybernetic twin-pronged titanium plasma sword with neon-cyan core
      // Center plasma energy beam
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(25, 13);
      c.lineTo(23.5, 49);
      c.lineTo(16.5, 49);
      c.lineTo(15, 13);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#22d3ee'], [0.5, '#ecfeff'], [1, '#0891b2']], 15, 1, 25, 49);
      c.fill();
      c.strokeStyle = '#0e7490';
      c.stroke();

      // Outer brushed titanium prongs flanking the plasma blade
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20 + s * 3.5, 16);
        c.lineTo(20 + s * 8.5, 23);
        c.lineTo(20 + s * 7.5, 49);
        c.lineTo(20 + s * 3.2, 49);
        c.closePath();
        c.fillStyle = grad(c, STEEL, 12, 16, 28, 49);
        c.fill();
        c.stroke();
      }

      // Angular mecha cross-chassis with Robot's red LED core
      roundRectPath(c, 8.5, 48, 23, 7, 2);
      c.fillStyle = '#475569';
      c.fill();
      c.stroke();
      c.beginPath();
      c.arc(20, 51.5, 2.8, 0, TAU);
      c.fillStyle = '#ef4444';
      c.fill();
      c.stroke();

      // Bolted mech grip + cyan LED strip
      roundRectPath(c, 16, 55, 8, 25, 2);
      c.fillStyle = '#1e293b';
      c.fill();
      c.stroke();
      c.fillStyle = '#22d3ee';
      c.fillRect(18.6, 58, 2.8, 17);

      // Steel pommel block
      roundRectPath(c, 14.5, 79, 11, 5.5, 1.5);
      c.fillStyle = '#64748b';
      c.fill();
      c.stroke();
      break;
    }

    case 'alien': {
      // Bio-crystal xenotech lime & purple glaive-dart
      // Needle lime plasma crystal tip
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(26.2, 20);
      c.lineTo(22.5, 40);
      c.lineTo(17.5, 40);
      c.lineTo(13.8, 20);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#ecfccb'], [0.5, '#84cc16'], [1, '#3f6212']], 14, 1, 26, 40);
      c.fill();
      c.stroke();

      // Curved purple alien chitin mandibles
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20 + s * 4, 48);
        c.bezierCurveTo(20 + s * 17, 44, 20 + s * 16, 26, 20 + s * 9, 17);
        c.quadraticCurveTo(20 + s * 11, 31, 20 + s * 3.5, 42);
        c.closePath();
        c.fillStyle = grad(c, [[0, '#d8b4fe'], [0.6, '#7e22ce'], [1, '#3b0764']], 20, 17, 20 + s * 16, 48);
        c.fill();
        c.stroke();
      }

      // Glowing bio-orb core
      c.beginPath();
      c.arc(20, 42, 4.2, 0, TAU);
      c.fillStyle = '#bef264';
      c.fill();
      c.stroke();

      // Segmented purple xenotech grip
      roundRectPath(c, 16.5, 46, 7, 34, 3);
      c.fillStyle = grad(c, [[0, '#a855f7'], [1, '#3b0764']], 16.5, 46, 23.5, 46);
      c.fill();
      c.stroke();
      c.strokeStyle = '#a3e635';
      c.lineWidth = 1.4;
      for (const yy of [54, 62, 70]) {
        c.beginPath();
        c.moveTo(16.8, yy);
        c.lineTo(23.2, yy);
        c.stroke();
      }
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      c.beginPath();
      c.arc(20, 81.5, 3.6, 0, TAU);
      c.fillStyle = '#84cc16';
      c.fill();
      c.stroke();
      break;
    }

    case 'vampire': {
      // Gothic crimson-silver stiletto with scalloped bat-wing guard & fangs
      c.beginPath();
      c.moveTo(20, 1);
      c.lineTo(24.5, 18);
      c.lineTo(23.5, 49);
      c.lineTo(16.5, 49);
      c.lineTo(15.5, 18);
      c.closePath();
      c.fillStyle = grad(c, STEEL, 15.5, 1, 24.5, 49);
      c.fill();
      c.stroke();

      // Blood-ruby fuller groove
      c.beginPath();
      c.moveTo(20, 9);
      c.lineTo(20, 46);
      c.strokeStyle = '#be123c';
      c.lineWidth = 1.8;
      c.stroke();

      // Scalloped gothic bat-wing crossguard
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.35;
      c.beginPath();
      c.moveTo(20, 47.5);
      c.lineTo(37, 42);
      c.quadraticCurveTo(34, 52, 29, 55.5);
      c.quadraticCurveTo(24, 53.5, 20, 56);
      c.quadraticCurveTo(16, 53.5, 11, 55.5);
      c.quadraticCurveTo(6, 52, 3, 42);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#312e81'], [0.4, '#881337'], [1, '#111827']], 3, 42, 37, 56);
      c.fill();
      c.stroke();

      // Crimson ruby jewel at guard center
      c.beginPath();
      c.moveTo(20, 47);
      c.lineTo(23.2, 51.5);
      c.lineTo(20, 55.5);
      c.lineTo(16.8, 51.5);
      c.closePath();
      c.fillStyle = '#f43f5e';
      c.fill();
      c.stroke();

      // Pale bone/velvet grip
      roundRectPath(c, 16.4, 55.5, 7.2, 22, 2.5);
      c.fillStyle = '#18181b';
      c.fill();
      c.stroke();

      // Twin vampire fang pommel!
      c.fillStyle = '#ffffff';
      for (const s of [-1, 1]) {
        c.beginPath();
        c.moveTo(20 + s * 4.5, 77);
        c.lineTo(20 + s * 2.5, 85);
        c.lineTo(20 + s * 0.6, 77);
        c.closePath();
        c.fill();
        c.stroke();
      }
      break;
    }

    case 'sun': {
      // Blazing solar flame-halberd spearhead ringed by radiant golden sun-rays
      // Flame wave blade
      c.beginPath();
      c.moveTo(20, 1);
      c.quadraticCurveTo(27.5, 12, 22.5, 21);
      c.quadraticCurveTo(28.5, 31, 23.5, 42);
      c.lineTo(16.5, 42);
      c.quadraticCurveTo(11.5, 31, 17.5, 21);
      c.quadraticCurveTo(12.5, 12, 20, 1);
      c.closePath();
      c.fillStyle = grad(c, [[0, '#fffbeb'], [0.45, '#fde047'], [1, '#ea580c']], 12, 1, 28, 42);
      c.fill();
      c.stroke();

      // White-hot inner solar spine
      c.beginPath();
      c.moveTo(20, 5);
      c.lineTo(20, 39);
      c.strokeStyle = '#ffffff';
      c.lineWidth = 1.6;
      c.stroke();

      // Radiating spiked solar ring guard
      c.strokeStyle = OUTLINE;
      c.lineWidth = 1.25;
      c.beginPath();
      const spikes = 10;
      for (let i = 0; i < spikes * 2; i++) {
        const a = (i / (spikes * 2)) * TAU - Math.PI / 2;
        const rr = i % 2 === 0 ? 11.5 : 6.2;
        const px = 20 + Math.cos(a) * rr;
        const py = 46 + Math.sin(a) * rr;
        if (i === 0) c.moveTo(px, py);
        else c.lineTo(px, py);
      }
      c.closePath();
      c.fillStyle = grad(c, GOLD, 9, 35, 31, 57);
      c.fill();
      c.stroke();

      c.beginPath();
      c.arc(20, 46, 3.8, 0, TAU);
      c.fillStyle = '#fffbeb';
      c.fill();
      c.stroke();

      // Ceremonial gold-amber shaft
      c.lineWidth = 1.35;
      roundRectPath(c, 16.4, 52, 7.2, 25, 2.5);
      c.fillStyle = grad(c, GOLD, 16.4, 52, 23.6, 52);
      c.fill();
      c.stroke();

      // Flame teardrop pommel
      c.beginPath();
      c.moveTo(20, 76.5);
      c.quadraticCurveTo(25, 81, 20, 86);
      c.quadraticCurveTo(15, 81, 20, 76.5);
      c.closePath();
      c.fillStyle = '#f97316';
      c.fill();
      c.stroke();
      break;
    }
  }

  c.restore();
}

const SPRITES = new Map<BossHead, HTMLCanvasElement>();

function getSprite(head: BossHead): HTMLCanvasElement | null {
  const hit = SPRITES.get(head);
  if (hit) return hit;
  try {
    const cv = document.createElement('canvas');
    cv.width = BW_W * SPRITE_SCALE;
    cv.height = BW_H * SPRITE_SCALE;
    const c = cv.getContext('2d');
    if (!c) return null;
    c.scale(SPRITE_SCALE, SPRITE_SCALE);
    paintBossWeapon(c, head);
    SPRITES.set(head, cv);
    return cv;
  } catch {
    return null;
  }
}

export const bossWeaponWidth = (height: number) => (BW_W / BW_H) * height;

/**
 * Draw a boss-specific weapon with its tip at `(0, 0)` and grip around `y = 0.79 * height`.
 * Zero runtime gradient allocation: uses 4x cached offscreen sprite sheets.
 */
export function drawBossWeapon(
  c: CanvasRenderingContext2D,
  head: BossHead | undefined,
  height: number,
) {
  const key: BossHead = head ?? 'pirate';
  const w = bossWeaponWidth(height);
  const sprite = getSprite(key);
  if (sprite) {
    c.drawImage(sprite, -w / 2, 0, w, height);
    return;
  }
  c.save();
  c.scale(w / BW_W, height / BW_H);
  c.translate(-BW_W / 2, 0);
  paintBossWeapon(c, key);
  c.restore();
}
