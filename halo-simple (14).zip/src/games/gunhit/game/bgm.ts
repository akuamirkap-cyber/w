/**
 * Dynamic procedural Web Audio background soundtrack & arena ambience for Gun Hit.
 *
 * Adapts smoothly across Menu, Classic/Swarm Waves, Boss Fights, Boss Rage,
 * Round Clear, and Game Over while automatically ducking for big explosions
 * and gunshots so impact FX always cut through cleanly.
 */

export type BgmScene = 'menu' | 'play' | 'boss' | 'rage' | 'clear' | 'fail';

const mtof = (midi: number) => 440 * Math.pow(2, (midi - 69) / 12);

// Warm tactical A-minor / C-major palette (menu)
const MENU_CHORDS = [
  { root: 45, notes: [57, 60, 64, 67, 71] }, // Am9
  { root: 41, notes: [53, 57, 60, 64, 69] }, // Fmaj7
  { root: 38, notes: [50, 53, 57, 60, 64] }, // Dm9
  { root: 40, notes: [52, 55, 59, 62, 67] }, // Em7
];

// Energetic arcade action progression (active waves)
const PLAY_PROGRESSION = [
  { bass: 45, arp: [57, 60, 64, 67, 72, 67, 64, 60] }, // Am
  { bass: 41, arp: [53, 57, 60, 65, 69, 65, 60, 57] }, // F
  { bass: 48, arp: [55, 60, 64, 67, 72, 67, 64, 60] }, // C
  { bass: 43, arp: [55, 59, 62, 67, 71, 67, 62, 59] }, // G
];

// Dramatic minor-harmonic boss battle progression
const BOSS_PROGRESSION = [
  { bass: 40, arp: [52, 55, 59, 64, 67, 64, 59, 55] }, // Em
  { bass: 41, arp: [53, 57, 60, 65, 69, 65, 60, 57] }, // F
  { bass: 38, arp: [50, 53, 57, 62, 65, 62, 57, 53] }, // Dm
  { bass: 39, arp: [51, 55, 59, 63, 67, 63, 59, 55] }, // E7b9 tension
];

class GunHitBgm {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private duckGain!: GainNode;
  private padBus!: GainNode;
  private grooveBus!: GainNode;
  private windGain!: GainNode;
  private windFilter!: BiquadFilterNode;
  private windLfo: OscillatorNode | null = null;
  private windLfoGain: GainNode | null = null;
  private verbIn!: GainNode;
  private noiseBuf!: AudioBuffer;
  private windSrc: AudioBufferSourceNode | null = null;

  private enabled = true;
  private muted = false;
  private portalMuted = false;
  private volume = 1;
  private paused = false;
  private visAttached = false;

  private scene: BgmScene = 'menu';
  private intensity = 0.25; // 0..1 driven by wave speed & combo
  private tempoMult = 1;

  private timer = 0;
  private step = 0;
  private nextStepTime = 0;
  private menuChordIdx = 0;
  private nextMenuChordTime = 0;

  private ensureGraph(): AudioContext | null {
    if (this.ctx) return this.ctx;
    if (typeof window === 'undefined') return null;
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;

    const ctx = new AC();
    this.ctx = ctx;

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 16;
    comp.ratio.value = 3.5;
    comp.attack.value = 0.008;
    comp.release.value = 0.2;
    comp.connect(ctx.destination);

    this.master = ctx.createGain();
    this.master.gain.value = this.targetMasterGain();
    this.master.connect(comp);

    this.duckGain = ctx.createGain();
    this.duckGain.gain.value = 1;
    this.duckGain.connect(this.master);

    this.padBus = ctx.createGain();
    this.padBus.gain.value = 0.72;
    this.padBus.connect(this.duckGain);

    this.grooveBus = ctx.createGain();
    this.grooveBus.gain.value = 0.84;
    this.grooveBus.connect(this.duckGain);

    // Subtle stereo room reverb for atmospheric pads & plucks
    const verb = ctx.createConvolver();
    verb.buffer = this.buildImpulse(ctx, 2.2, 2.8);
    const vHp = ctx.createBiquadFilter();
    vHp.type = 'highpass';
    vHp.frequency.value = 260;
    const vLp = ctx.createBiquadFilter();
    vLp.type = 'lowpass';
    vLp.frequency.value = 4600;
    const vOut = ctx.createGain();
    vOut.gain.value = 0.34;
    this.verbIn = ctx.createGain();
    this.verbIn.connect(vHp);
    vHp.connect(vLp);
    vLp.connect(verb);
    verb.connect(vOut);
    vOut.connect(this.duckGain);

    // Reusable 2s white noise buffer
    const len = ctx.sampleRate * 2;
    this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const ch = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;

    // Continuous soft arena wind / tactical drone bed with slow breathing LFO
    this.windFilter = ctx.createBiquadFilter();
    this.windFilter.type = 'bandpass';
    this.windFilter.frequency.value = 420;
    this.windFilter.Q.value = 0.85;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0.022;
    this.windFilter.connect(this.windGain);
    this.windGain.connect(this.duckGain);

    const windLfo = ctx.createOscillator();
    windLfo.type = 'sine';
    windLfo.frequency.value = 0.14;
    const windLfoGain = ctx.createGain();
    windLfoGain.gain.value = 95;
    windLfo.connect(windLfoGain);
    windLfoGain.connect(this.windFilter.frequency);
    windLfo.start(ctx.currentTime);
    this.windLfo = windLfo;
    this.windLfoGain = windLfoGain;

    this.startWindBed(ctx);

    return ctx;
  }

  private startWindBed(ctx: AudioContext) {
    if (this.windSrc) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    src.connect(this.windFilter);
    src.start(ctx.currentTime);
    this.windSrc = src;
  }

  private buildImpulse(ctx: AudioContext, seconds: number, decay: number): AudioBuffer {
    const rate = ctx.sampleRate;
    const len = Math.max(1, Math.floor(rate * seconds));
    const buf = ctx.createBuffer(2, len, rate);
    const l = buf.getChannelData(0);
    const r = buf.getChannelData(1);
    for (let i = 0; i < len; i++) {
      const k = i / len;
      const env = Math.pow(1 - k, decay) * Math.min(1, i / (rate * 0.012));
      l[i] = (Math.random() * 2 - 1) * env;
      r[i] = (Math.random() * 2 - 1) * env;
    }
    return buf;
  }

  private shouldPlay(): boolean {
    return this.enabled && !this.muted && !this.portalMuted && !this.paused && this.volume > 0.005;
  }

  private targetMasterGain(): number {
    if (!this.shouldPlay()) return 0;
    return 0.42 * this.volume;
  }

  private syncGain(fade = 0.12) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.targetMasterGain(), t, fade);
  }

  unlock() {
    const ctx = this.ensureGraph();
    if (!ctx) return;
    if (ctx.state !== 'running') {
      void ctx.resume().catch(() => undefined);
    }
    if (typeof document !== 'undefined' && !this.visAttached) {
      this.visAttached = true;
      document.addEventListener('visibilitychange', () => {
        this.setPaused(document.hidden);
      });
    }
    this.setPaused(typeof document !== 'undefined' ? document.hidden : false);
    this.syncGain(0.15);
    this.ensureTimer();
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    if (on) {
      this.ensureGraph();
      this.ensureTimer();
    }
    this.syncGain(0.15);
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.syncGain(0.08);
  }

  setPortalMuted(m: boolean) {
    this.portalMuted = m;
    this.syncGain(0.06);
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, Number.isFinite(vol) ? vol : 1));
    this.syncGain(0.08);
  }

  setPaused(p: boolean) {
    this.paused = p;
    this.syncGain(0.1);
  }

  setScene(scene: BgmScene, intensity = this.intensity, tempoMult = 1) {
    const prev = this.scene;
    this.scene = scene;
    this.intensity = Math.max(0, Math.min(1, intensity));
    this.tempoMult = Math.max(0.85, Math.min(1.22, tempoMult));

    if (this.ctx && this.windFilter && this.windGain) {
      const t = this.ctx.currentTime;
      const windFreq = scene === 'rage' ? 820 : scene === 'boss' ? 650 : scene === 'play' ? 500 + this.intensity * 210 : 350;
      const windAmp = scene === 'fail' ? 0.01 : scene === 'menu' ? 0.019 : 0.025 + this.intensity * 0.016;
      this.windFilter.frequency.setTargetAtTime(windFreq, t, 0.35);
      this.windGain.gain.setTargetAtTime(windAmp, t, 0.35);
      if (this.windLfoGain) {
        this.windLfoGain.gain.setTargetAtTime(scene === 'menu' ? 85 : 120 + this.intensity * 70, t, 0.4);
      }
      if (this.windLfo) {
        this.windLfo.frequency.setTargetAtTime(scene === 'rage' ? 0.28 : 0.14 + this.intensity * 0.08, t, 0.4);
      }
    }

    if (prev !== scene && this.ctx && scene === 'play' && this.shouldPlay()) {
      this.nextStepTime = Math.max(this.nextStepTime, this.ctx.currentTime + 0.04);
    }
  }

  /** Briefly duck background music so gunshots & explosions stay punchy. */
  duck(depth = 0.68, hold = 0.18) {
    if (!this.ctx || !this.duckGain || !this.shouldPlay()) return;
    const t = this.ctx.currentTime;
    const g = this.duckGain.gain;
    g.cancelScheduledValues(t);
    g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(Math.max(0.35, Math.min(0.92, depth)), t + 0.015);
    g.setTargetAtTime(1, t + 0.03, hold * 0.6);
  }

  /** Short dual-band air whoosh accent when fast wheels / bombs zip near the defense line. */
  airWhoosh(pan = 0, intensity = 0.5) {
    if (!this.ctx || !this.shouldPlay() || this.ctx.state !== 'running') return;
    const ctx = this.ctx;
    const t = ctx.currentTime + 0.01;
    const dur = 0.24;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;

    const filt = ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.Q.value = 1.4;
    filt.frequency.setValueAtTime(340, t);
    filt.frequency.exponentialRampToValueAtTime(1750, t + dur * 0.48);
    filt.frequency.exponentialRampToValueAtTime(280, t + dur);

    const hi = ctx.createBiquadFilter();
    hi.type = 'highpass';
    hi.frequency.setValueAtTime(2400, t);

    const g = ctx.createGain();
    const peak = 0.095 * Math.max(0.25, Math.min(1, intensity));
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + dur * 0.42);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    const hiG = ctx.createGain();
    hiG.gain.setValueAtTime(0.0001, t);
    hiG.gain.exponentialRampToValueAtTime(peak * 0.32, t + dur * 0.35);
    hiG.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    const panner = ctx.createStereoPanner();
    panner.pan.setValueAtTime(Math.max(-0.85, Math.min(0.85, pan)), t);

    src.connect(filt);
    filt.connect(g);
    g.connect(panner);

    src.connect(hi);
    hi.connect(hiG);
    hiG.connect(panner);

    panner.connect(this.grooveBus);

    src.start(t, Math.random() * 1.2);
    src.stop(t + dur + 0.04);
  }

  private ensureTimer() {
    if (this.timer || typeof window === 'undefined') return;
    const ctx = this.ctx;
    if (!ctx) return;
    this.nextStepTime = ctx.currentTime + 0.06;
    this.nextMenuChordTime = ctx.currentTime + 0.06;
    this.timer = window.setInterval(() => this.tick(), 45);
  }

  private tick() {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== 'running' || !this.shouldPlay()) return;

    const now = ctx.currentTime;
    if (this.scene === 'menu' || this.scene === 'clear' || this.scene === 'fail') {
      if (this.nextMenuChordTime < now - 0.5) this.nextMenuChordTime = now + 0.05;
      while (this.nextMenuChordTime < now + 0.45) {
        this.scheduleMenuBar(this.nextMenuChordTime, this.menuChordIdx);
        this.menuChordIdx = (this.menuChordIdx + 1) % MENU_CHORDS.length;
        this.nextMenuChordTime += 3.2;
      }
      this.nextStepTime = now + 0.08;
      return;
    }

    // Active combat loop (play / boss / rage)
    const baseBpm =
      this.scene === 'rage' ? 138 :
      this.scene === 'boss' ? 130 :
      122 + this.intensity * 12;
    const bpm = baseBpm * this.tempoMult;
    const sixteenth = 60 / bpm / 4;

    if (this.nextStepTime < now - 0.35) this.nextStepTime = now + 0.04;
    while (this.nextStepTime < now + 0.24) {
      this.scheduleCombatStep(this.step, this.nextStepTime, sixteenth);
      this.step = (this.step + 1) % 64;
      this.nextStepTime += sixteenth;
    }
    this.nextMenuChordTime = now + 0.1;
  }

  private scheduleMenuBar(t: number, idx: number) {
    const ctx = this.ctx!;
    const chord = MENU_CHORDS[idx];
    const dur = 3.6;

    // Warm filtered tactical pad
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.Q.value = 0.7;
    lp.frequency.setValueAtTime(420, t);
    lp.frequency.linearRampToValueAtTime(1050, t + 1.5);
    lp.frequency.linearRampToValueAtTime(480, t + dur);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.24, t + 0.65);
    g.gain.setValueAtTime(0.22, t + 2.5);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);

    lp.connect(g);
    g.connect(this.padBus);
    const send = ctx.createGain();
    send.gain.value = 0.45;
    g.connect(send);
    send.connect(this.verbIn);

    // Deep sub root
    this.synthTone(ctx, {
      type: 'sine',
      freq: mtof(chord.root),
      t,
      a: 0.2,
      d: 2.8,
      peak: 0.22,
      dest: this.padBus,
      pan: 0,
    });

    for (let i = 0; i < chord.notes.length; i++) {
      const f = mtof(chord.notes[i]);
      const o = ctx.createOscillator();
      o.type = i % 2 === 0 ? 'triangle' : 'sawtooth';
      o.frequency.value = f;
      o.detune.value = (i - 2) * 4;
      const og = ctx.createGain();
      og.gain.value = o.type === 'sawtooth' ? 0.05 : 0.085;
      o.connect(og);
      og.connect(lp);
      o.start(t);
      o.stop(t + dur + 0.08);
    }

    // Gentle stereo chorus & fifth shimmer over the bar
    const arpOrder = [0, 2, 4, 3];
    for (let k = 0; k < 4; k++) {
      const note = chord.notes[arpOrder[k] % chord.notes.length] + (k === 2 ? 12 : 0);
      this.synthPluck(ctx, mtof(note), t + 0.25 + k * 0.78, 0.75, 0.075, (k - 1.5) * 0.35, 0.48);
    }
    this.synthPluck(ctx, mtof(chord.notes[2] + 19), t + 2.15, 0.9, 0.042, 0.42, 0.55);
  }

  private scheduleCombatStep(step: number, t: number, sixteenth: number) {
    const ctx = this.ctx!;
    const bar = Math.floor(step / 16) % 4;
    const p16 = step % 16;
    const isBoss = this.scene === 'boss' || this.scene === 'rage';
    const isRage = this.scene === 'rage';
    const prog = (isBoss ? BOSS_PROGRESSION : PLAY_PROGRESSION)[bar];

    // 1) Kick drum (four-on-the-floor pulse + extra boss/turnaround syncopation)
    if (p16 % 4 === 0 || (isBoss && (p16 === 10 || p16 === 14)) || (bar === 3 && p16 === 14)) {
      this.kick(ctx, t, isBoss ? 0.25 : 0.19 + this.intensity * 0.045);
    }

    // 2) Crisp light snare / rim click on beats 2 & 4 + turnaround fill
    if (p16 === 4 || p16 === 12 || (bar === 3 && p16 === 15)) {
      const fillScale = bar === 3 && p16 === 15 ? 0.65 : 1;
      this.snare(ctx, t, (isBoss ? 0.09 : 0.068) * fillScale);
    }

    // 3) Tight brushed hi-hat groove (16th off-beats scale with intensity)
    if (p16 % 2 === 1 || isRage || this.intensity > 0.48) {
      const accent = p16 % 4 === 2 ? 0.038 : p16 % 4 === 3 ? 0.025 : 0.017;
      this.hihat(ctx, t, accent * (isRage ? 1.28 : 0.92 + this.intensity * 0.18), ((p16 % 4) - 1.5) * 0.24);
    }

    // 4) Driving synth bass (octave pulse on 8ths & boss/turbo gallops)
    const playBass =
      p16 % 2 === 0 ||
      (isBoss && p16 % 4 === 3) ||
      (this.intensity > 0.6 && p16 % 4 === 3);
    if (playBass) {
      const oct = p16 % 4 === 2 ? 12 : 0;
      const f = mtof(prog.bass + oct);
      this.bassPluck(ctx, f, t, sixteenth * 1.75, isBoss ? 0.19 : 0.16, isBoss ? 1320 : 980 + this.intensity * 480);
    }

    // 5) Melodic tactical arpeggio with 4-bar turnaround lift
    if (p16 % 2 === 0 || (isRage && p16 % 4 === 1)) {
      const idx = Math.floor(p16 / 2) % prog.arp.length;
      const turnaroundLift = bar === 3 && p16 >= 12 ? 7 : 0;
      const midi = prog.arp[idx] + (isBoss && p16 >= 8 ? 0 : 12) + turnaroundLift;
      const pan = ((p16 % 8) - 3.5) * 0.15;
      const amp = isBoss ? 0.064 : 0.05 + this.intensity * 0.022;
      this.synthPluck(ctx, mtof(midi), t, sixteenth * 2.4, amp, pan, 0.3);
    }

    // 6) Dramatic pad stab on bar downbeats
    if (p16 === 0) {
      const chordAmp = isBoss ? 0.068 : 0.044;
      for (let i = 0; i < 3; i++) {
        this.synthTone(ctx, {
          type: isBoss ? 'sawtooth' : 'triangle',
          freq: mtof(prog.arp[i]),
          t,
          a: 0.08,
          d: sixteenth * 14,
          peak: chordAmp,
          dest: this.padBus,
          pan: (i - 1) * 0.32,
          filterHz: isBoss ? 1150 : 1450,
        });
      }
    }
  }

  private synthTone(
    ctx: AudioContext,
    o: {
      type: OscillatorType;
      freq: number;
      t: number;
      a: number;
      d: number;
      peak: number;
      dest: AudioNode;
      pan?: number;
      filterHz?: number;
    },
  ) {
    const osc = ctx.createOscillator();
    osc.type = o.type;
    osc.frequency.setValueAtTime(o.freq, o.t);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, o.t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.peak), o.t + o.a);
    g.gain.exponentialRampToValueAtTime(0.0001, o.t + o.a + o.d);

    let tail: AudioNode = g;
    if (o.filterHz) {
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.setValueAtTime(o.filterHz, o.t);
      osc.connect(f);
      f.connect(g);
    } else {
      osc.connect(g);
    }

    if (o.pan !== undefined) {
      const p = ctx.createStereoPanner();
      p.pan.setValueAtTime(o.pan, o.t);
      g.connect(p);
      tail = p;
    }
    tail.connect(o.dest);

    osc.start(o.t);
    osc.stop(o.t + o.a + o.d + 0.04);
  }

  private synthPluck(
    ctx: AudioContext,
    freq: number,
    t: number,
    dur: number,
    peak: number,
    pan: number,
    verbSend: number,
  ) {
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, t);

    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.Q.value = 1.4;
    filt.frequency.setValueAtTime(freq * 4.2, t);
    filt.frequency.exponentialRampToValueAtTime(Math.max(320, freq * 1.15), t + dur * 0.75);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    const p = ctx.createStereoPanner();
    p.pan.setValueAtTime(pan, t);

    osc.connect(filt);
    filt.connect(g);
    g.connect(p);
    p.connect(this.grooveBus);

    if (verbSend > 0) {
      const send = ctx.createGain();
      send.gain.value = verbSend;
      p.connect(send);
      send.connect(this.verbIn);
    }

    osc.start(t);
    osc.stop(t + dur + 0.04);
  }

  private bassPluck(
    ctx: AudioContext,
    freq: number,
    t: number,
    dur: number,
    peak: number,
    cutoff: number,
  ) {
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, t);

    const sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(freq * 0.5, t);

    const filt = ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.Q.value = 2.1;
    filt.frequency.setValueAtTime(cutoff, t);
    filt.frequency.exponentialRampToValueAtTime(160, t + dur * 0.9);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    const subG = ctx.createGain();
    subG.gain.setValueAtTime(0.0001, t);
    subG.gain.exponentialRampToValueAtTime(peak * 0.65, t + 0.008);
    subG.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    osc.connect(filt);
    filt.connect(g);
    g.connect(this.grooveBus);

    sub.connect(subG);
    subG.connect(this.grooveBus);

    osc.start(t);
    sub.start(t);
    osc.stop(t + dur + 0.04);
    sub.stop(t + dur + 0.04);
  }

  private kick(ctx: AudioContext, t: number, peak: number) {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(125, t);
    osc.frequency.exponentialRampToValueAtTime(42, t + 0.085);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

    osc.connect(g);
    g.connect(this.grooveBus);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  private snare(ctx: AudioContext, t: number, peak: number) {
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;

    const filt = ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.setValueAtTime(1900, t);
    filt.Q.value = 1.1;

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);

    src.connect(filt);
    filt.connect(g);
    g.connect(this.grooveBus);
    src.start(t, Math.random() * 1.1);
    src.stop(t + 0.11);
  }

  private hihat(ctx: AudioContext, t: number, peak: number, pan: number) {
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;

    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(7400, t);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.002);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.036);

    const p = ctx.createStereoPanner();
    p.pan.setValueAtTime(pan, t);

    src.connect(hp);
    hp.connect(g);
    g.connect(p);
    p.connect(this.grooveBus);
    src.start(t, Math.random() * 1.4);
    src.stop(t + 0.05);
  }
}

export const bgm = new GunHitBgm();
