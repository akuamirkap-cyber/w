/**
 * Recorded gunshots for the common firearms, shared by every audio engine.
 *
 * All four are CC0 / public-domain Freesound recordings, chosen by
 * measurement (attack time, body, tail, low-end share, clipping) over a wider
 * set of candidates, and embedded as base64 data URLs:
 *
 *   pistol  — "handgun-one-shot.wav" by DeltaCode   (#668348)
 *   ak47    — "Rifle Gun Shot 02.wav" by LilMati     (#484036), cut to 0.78 s
 *   shotgun — "shotgun-one-shot.wav" by DeltaCode    (#668353)
 *   nail    — "Nail_Gun.wav" by tec_studio           (#362329)
 *
 * Each gun's trigger is voiced by a different engine depending on the shot
 * card the player picked (slide 1's own synth, slide 4's `Synth`, slide 7's
 * `SFX`, slide 11's `Sound`), so the engines all call into here and the gun
 * sounds the same whichever card is active. Buffers are decoded once and
 * reused: an `AudioBuffer` is not tied to the context that decoded it, and a
 * buffer source resamples on play.
 */
import { SIDEARM_SHOT_DATA_URL } from '../assets/sidearmShotData';
import { AK47_SHOT_DATA_URL } from '../assets/ak47ShotData';
import { SHOTGUN_SHOT_DATA_URL } from '../assets/shotgunShotData';
import { NAIL_GUN_SHOT_DATA_URL } from '../assets/nailGunShotData';

export type GunSampleKind = 'pistol' | 'ak47' | 'shotgun' | 'nail';

interface SampleSpec {
  url: string;
  /** Random pitch spread (± fraction) so a clip of shots never reads as one looped file. */
  pitch: number;
  /** Optional fade: hold full level until `holdS`, then ramp out by `endS` (auto-fire stays tight). */
  holdS?: number;
  endS?: number;
}

const SPECS: Record<GunSampleKind, SampleSpec> = {
  pistol: { url: SIDEARM_SHOT_DATA_URL, pitch: 0.04 },
  ak47: { url: AK47_SHOT_DATA_URL, pitch: 0.05, holdS: 0.4, endS: 0.6 },
  shotgun: { url: SHOTGUN_SHOT_DATA_URL, pitch: 0.03 },
  nail: { url: NAIL_GUN_SHOT_DATA_URL, pitch: 0.06 },
};

const buffers: Partial<Record<GunSampleKind, AudioBuffer>> = {};
const loading = new Set<GunSampleKind>();

/**
 * Decode every sample once, off the hot path (called when an engine builds its
 * context during the menu prewarm). `decodeAudioData` runs on a worker; only
 * the data-URL → bytes step touches the main thread, a few ms per sample.
 */
export function loadGunSamples(ctx: BaseAudioContext): void {
  for (const kind of Object.keys(SPECS) as GunSampleKind[]) {
    if (buffers[kind] || loading.has(kind)) continue;
    loading.add(kind);
    const fail = () => {
      loading.delete(kind);
    };
    try {
      fetch(SPECS[kind].url)
        .then((res) => res.arrayBuffer())
        .then((bytes) => ctx.decodeAudioData(bytes))
        .then((decoded) => {
          buffers[kind] = decoded;
        })
        .catch(fail);
    } catch {
      fail();
    }
  }
}

/** True once `kind` can be played (engines fall back to synthesis before that). */
export function gunSampleReady(kind: GunSampleKind): boolean {
  return !!buffers[kind];
}

/**
 * Fire a sample into `dest` (an engine's master bus). Returns false when the
 * sample is not decoded yet, so the caller plays its synth recipe instead.
 *
 * @param gain  linear level into `dest` (the engine's own master gain follows).
 * @param send  optional reverb send `{ node, amount }` into the engine's
 *              convolver, so the shot sits in the same room as its other sounds.
 */
export function playGunSample(
  kind: GunSampleKind,
  ctx: AudioContext,
  dest: AudioNode,
  gain: number,
  send?: { node: AudioNode; amount: number } | null,
): boolean {
  const buffer = buffers[kind];
  if (!buffer) {
    loadGunSamples(ctx);
    return false;
  }
  try {
    const spec = SPECS[kind];
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    src.playbackRate.value = 1 - spec.pitch + Math.random() * spec.pitch * 2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    let stopAt = t + buffer.duration + 0.05;
    if (spec.holdS !== undefined && spec.endS !== undefined) {
      g.gain.setValueAtTime(gain, t + spec.holdS);
      g.gain.exponentialRampToValueAtTime(0.001, t + spec.endS);
      stopAt = t + spec.endS + 0.02;
    }
    src.connect(g);
    g.connect(dest);
    let s: GainNode | null = null;
    if (send && send.amount > 0) {
      s = ctx.createGain();
      s.gain.value = send.amount;
      g.connect(s);
      s.connect(send.node);
    }
    src.onended = () => {
      try {
        src.disconnect();
        g.disconnect();
        s?.disconnect();
      } catch {
        /* ignore */
      }
    };
    src.start(t);
    src.stop(stopAt);
    return true;
  } catch {
    return false;
  }
}
