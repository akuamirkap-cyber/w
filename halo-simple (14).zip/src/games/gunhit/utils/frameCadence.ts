/**
 * Frame-cadence governor: runs at full native display refresh rate (60 / 90 /
 * 120 / 144+ Hz) whenever frame work fits inside the VSync budget, and drops
 * smoothly onto a steady 60 Hz grid only if a high-refresh display is genuinely
 * overloaded by sustained heavy frames.
 */
const GRID_MS = 1000 / 60;

export class FrameCadence {
  /** Engage 60 Hz grid only when a high-refresh screen is overloaded. */
  private capped = false;
  private interval = 16.7;
  private work = 0;
  private warm = 0;
  private overload = 0;
  private recover = 0;
  private nextGrid = -Infinity;

  reset(): void {
    this.capped = false;
    this.interval = 16.7;
    this.work = 0;
    this.warm = 0;
    this.overload = 0;
    this.recover = 0;
    this.nextGrid = -Infinity;
  }

  get isCapped(): boolean {
    return this.capped;
  }

  /** Exponential averages of what the loop can actually observe. */
  private sample(intervalMs: number, workMs: number): void {
    // Ignore tab switches and other clock discontinuities.
    if (!Number.isFinite(intervalMs) || intervalMs <= 0 || intervalMs > 200) return;
    this.interval += (intervalMs - this.interval) * 0.08;
    this.work += (Math.max(0, workMs) - this.work) * 0.12;
  }

  /**
   * Decide whether this animation frame should draw.
   *
   * @param now      the timestamp handed to the RAF callback
   * @param interval milliseconds since the previous callback
   * @param work     milliseconds the previous frame spent in update + render
   */
  shouldRender(now: number, interval: number, work: number): boolean {
    this.sample(interval, work);
    if (this.warm < 30) {
      this.warm++;
      this.nextGrid = now + GRID_MS;
      return true;
    }
    const highRefresh = this.interval < 12.5;
    if (!this.capped) {
      // Only throttle high-refresh screens to 60 Hz if sustained CPU/render
      // work actually threatens to overrun the native VSync interval.
      const overloaded = highRefresh && this.work > Math.max(6.2, this.interval * 0.88);
      this.overload = overloaded ? this.overload + 1 : 0;
      if (this.overload >= 24) {
        this.capped = true;
        this.overload = 0;
        this.recover = 0;
        this.nextGrid = now + GRID_MS;
        return true;
      }
      return true;
    }
    // Release the 60 Hz cap once the display drops back to 60 Hz or work drops
    // cleanly below half the native refresh interval for ~0.75s.
    const canUnlock = this.interval > 14.5 || (highRefresh && this.work < this.interval * 0.55);
    this.recover = canUnlock ? this.recover + 1 : 0;
    if (this.recover >= 45) {
      this.capped = false;
      this.recover = 0;
      this.overload = 0;
      return true;
    }
    // Draw on the first frame at (or just before) each grid tick.
    const half = Math.max(1, this.interval) / 2;
    if (now < this.nextGrid - half) return false;
    // Keep the grid phase; re-anchor if the page stalled past a whole tick.
    this.nextGrid = now - this.nextGrid > GRID_MS ? now + GRID_MS : this.nextGrid + GRID_MS;
    return true;
  }
}
