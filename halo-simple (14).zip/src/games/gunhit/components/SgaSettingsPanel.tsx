import { useEffect, useRef, type CSSProperties } from 'react';
import type { SgaBackgroundTheme, SgaBgThemeOption } from '../game/backgroundThemes';
import type { SgaGameSpeed } from '../game/gameSpeed';
import type { SgaOrientation } from '../game/orientation';
import type { StyleId } from '../../perfect-shot/anim/presets';
import { LANGUAGES, type Language } from '../../../i18n/language';
import { t } from '../../../i18n/catalog';
import { tr } from '../../../i18n/strings';

type Props = {
  closing: boolean;
  muted: boolean;
  volume: number;
  sfxEnabled: boolean;
  musicEnabled: boolean;
  speed: SgaGameSpeed;
  speedOptions: readonly SgaGameSpeed[];
  /** Player-tuned projectile speed, 1x (normal) to 3x. */
  bulletSpeed: number;
  animSpeed: number;
  animGunStyle: StyleId;
  animSpeeds: readonly number[];
  animStyles: readonly { id: StyleId; name: string; icon: string; desc: string }[];
  onAnimSpeed: (speed: number) => void;
  onAnimGunStyle: (style: StyleId) => void;
  themes: readonly SgaBgThemeOption[];
  theme: SgaBackgroundTheme;
  orientation: SgaOrientation;
  onClose: () => void;
  onMute: () => void;
  onSfx: () => void;
  onMusic: () => void;
  onVolume: (value: number) => void;
  onSpeed: (value: SgaGameSpeed) => void;
  onBulletSpeed: (value: number) => void;
  /** COMBO TITIK mode: same-spot hits score 10 · 20 · 30 … as bonus coins. */
  spotCombo: boolean;
  onSpotCombo: () => void;
  onTheme: (value: SgaBackgroundTheme) => void;
  onOrientation: (value: SgaOrientation) => void;
  onReplayIntro: () => void;
  /** Opens the in-app privacy policy (Play Console requires it to be reachable). */
  onPrivacy: () => void;
  language: Language;
  onLanguage: (language: Language) => void;
  /** Reopens the CARA MAIN screen from Settings. */
  onHelp: () => void;
  /** Buka KAMUS BOS: animasi & pola putaran kesebelas bos. */
  onCodex: () => void;
  /** Opens the "delete all progress" confirmation. */
  onReset: () => void;
  onSpecial: (stage: 'boulder' | 'bonus' | 'treasure') => void;
  formatSpeed: (value: SgaGameSpeed) => string;
};

function GearEmblemIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" aria-hidden="true">
      <path
        d="M10.4 2.1h3.2l.55 2.05c.52.14 1.02.35 1.48.62l1.86-1.08 2.26 2.26-1.08 1.86c.27.46.48.96.62 1.48l2.05.55v3.2l-2.05.55a7.3 7.3 0 0 1-.62 1.48l1.08 1.86-2.26 2.26-1.86-1.08c-.46.27-.96.48-1.48.62l-.55 2.05h-3.2l-.55-2.05a7.3 7.3 0 0 1-1.48-.62l-1.86 1.08-2.26-2.26 1.08-1.86a7.3 7.3 0 0 1-.62-1.48L2.1 13.6v-3.2l2.05-.55c.14-.52.35-1.02.62-1.48L3.69 6.51l2.26-2.26 1.86 1.08c.46-.27.96-.48 1.48-.62l.55-2.05Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
        fill="currentColor"
        fillOpacity="0.2"
      />
      <circle cx="12" cy="12" r="6.1" stroke="currentColor" strokeOpacity="0.4" strokeWidth="1.1" strokeDasharray="2 2.2" />
      <circle cx="12" cy="12" r="3.4" stroke="#fbbf24" strokeWidth="1.8" fill="#091118" />
      <circle cx="12" cy="12" r="1.35" fill="#fbbf24" />
    </svg>
  );
}

function SpeakerIcon({ muted, low }: { muted: boolean; low: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
      <path d="M4 9.5h4.2l5-4v13l-5-4H4a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1Z" fill="currentColor" />
      {muted ? (
        <path d="M16.5 9.2 21 13.8m0-4.6-4.5 4.6" stroke="#fca5a5" strokeWidth="2.1" strokeLinecap="round" />
      ) : (
        <>
          <path d="M16.2 9.4a4.2 4.2 0 0 1 0 5.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          {!low && <path d="M18.8 6.8a7.8 7.8 0 0 1 0 10.4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.75" />}
        </>
      )}
    </svg>
  );
}

function TargetIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-amber-300" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="7.5" stroke="currentColor" strokeWidth="1.8" />
      <circle cx="12" cy="12" r="2.6" fill="currentColor" />
      <path d="M12 2v3M12 19v3M2 12h3M19 12h3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function MusicBarsIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-emerald-300" fill="none" aria-hidden="true">
      <path d="M9 17.2V6.6l9.5-1.8v10.4" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="6.8" cy="17.5" r="2.3" fill="currentColor" />
      <circle cx="16.3" cy="15.5" r="2.3" fill="currentColor" />
    </svg>
  );
}

function LockShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0 text-slate-300" fill="none" aria-hidden="true">
      <rect x="5.5" y="10.5" width="13" height="9.5" rx="2" stroke="currentColor" strokeWidth="1.8" fill="currentColor" fillOpacity="0.14" />
      <path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}

function TactileSwitch({ on }: { on: boolean }) {
  return (
    <span
      className={`relative inline-flex h-6 w-10 shrink-0 items-center rounded-md border p-0.5 transition-colors ${
        on
          ? 'border-emerald-300/60 bg-emerald-500/30'
          : 'border-white/15 bg-black/45'
      }`}
    >
      <span
        className={`h-4 w-4 rounded-[4px] shadow transition-all ${
          on
            ? 'translate-x-[17px] bg-emerald-300 shadow-[0_0_8px_rgba(110,231,183,0.75)]'
            : 'translate-x-0 bg-slate-400'
        }`}
      />
    </span>
  );
}

export default function SgaSettingsPanel({
  closing, muted, volume, sfxEnabled, musicEnabled,
  speed, speedOptions, onSpeed, formatSpeed,
  bulletSpeed, onBulletSpeed,
  themes, theme,
  onClose, onMute, onSfx, onMusic, onVolume, onTheme, onPrivacy,
  language, onLanguage, onHelp, onCodex, onReset,
}: Props) {
  const stripRef = useRef<HTMLDivElement>(null);
  const selectedTheme = themes.find((item) => item.id === theme) ?? themes[0];
  const percent = muted ? 0 : Math.round(volume * 100);
  const bulletPresets = [1, 1.5, 2, 3] as const;

  useEffect(() => {
    const node = stripRef.current?.querySelector<HTMLElement>(`[data-theme="${theme}"]`);
    node?.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'smooth' });
  }, [theme]);

  return (
    <div
      className={`a absolute inset-0 z-[70] grid place-items-center px-4 ${closing ? 'out-fade pointer-events-none' : 'in-fade'}`}
      style={{ '--d': '0ms', '--dur': closing ? '380ms' : '300ms' } as CSSProperties}
    >
      <button
        type="button"
        aria-label={tr(language, 'Tutup pengaturan')}
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-black/65 backdrop-blur-[3px]"
      />
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="gunhit-settings-title"
        className={`relative w-full max-w-[360px] max-h-[min(736px,94%)] overflow-y-auto thin-scroll rounded-2xl border border-slate-400/25 p-4 text-white shadow-[0_26px_64px_rgba(0,0,0,0.78),inset_0_1px_0_rgba(255,255,255,0.16)] ${closing ? 'st-pop-out' : 'st-pop-in'}`}
        style={{ background: 'linear-gradient(180deg, #13222d 0%, #0b141b 48%, #070c11 100%)' }}
      >
        {/* Top metallic chamfer accent */}
        <div className="pointer-events-none absolute inset-x-6 top-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400/75 to-transparent" aria-hidden="true" />

        <header className="flex items-center gap-2.5 border-b border-white/10 pb-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-amber-400/35 bg-gradient-to-b from-slate-800 to-slate-950 text-amber-300 shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]">
            <GearEmblemIcon />
          </span>
          <div className="min-w-0 flex-1">
            <h2 id="gunhit-settings-title" className="font-title text-[20px] leading-none tracking-wide text-white">
              {tr(language, 'PENGATURAN')}
            </h2>
            <p className="mt-1 font-title text-[10px] tracking-[0.16em] text-slate-300/65">
              {tr(language, 'AUDIO · TEMA · GAME SGA')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={tr(language, 'Tutup')}
            className="press grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-white/15 bg-white/[0.06] text-slate-200 transition hover:border-white/30 hover:bg-white/15"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
              <path d="M6.5 6.5 17.5 17.5M17.5 6.5 6.5 17.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
            </svg>
          </button>
        </header>

        {/* Precision Audio Mixer */}
        <section className="mt-3.5 rounded-xl border border-white/12 bg-[#070d12]/80 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onMute}
              aria-label={tr(language, 'Bisukan semua efek')}
              className={`press grid h-11 w-11 shrink-0 place-items-center rounded-xl border transition ${
                muted || volume === 0
                  ? 'border-rose-400/40 bg-rose-950/60 text-rose-200 shadow-[0_3px_0_#4c0519]'
                  : 'border-sky-300/40 bg-gradient-to-b from-sky-500 to-sky-700 text-white shadow-[0_3px_0_#0c4a6e]'
              }`}
            >
              <SpeakerIcon muted={muted || volume === 0} low={volume < 0.5} />
            </button>

            <div className="relative flex h-11 flex-1 items-center">
              {/* Background recessed channel + tick marks */}
              <div className="relative h-3 w-full overflow-hidden rounded-md border border-white/12 bg-black/70 shadow-inner">
                <div
                  className="h-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-cyan-300 shadow-[0_0_10px_rgba(52,211,153,0.55)]"
                  style={{ width: `${percent}%` }}
                />
                <div className="pointer-events-none absolute inset-0 flex justify-between px-[10%]">
                  {[0, 1, 2, 3].map((tick) => (
                    <span key={tick} className="h-full w-px bg-black/35" />
                  ))}
                </div>
              </div>
              {/* Machined metallic fader cap */}
              <div
                className="pointer-events-none absolute top-1/2 flex h-6 w-4 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-[4px] border border-white/75 bg-gradient-to-b from-slate-100 to-slate-400 shadow-[0_2px_6px_rgba(0,0,0,0.65)]"
                style={{ left: `${percent}%` }}
              >
                <span className="h-3 w-[2px] rounded-xs bg-slate-800/75" />
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={1}
                value={percent}
                onChange={(event) => onVolume(Number(event.target.value) / 100)}
                aria-label="Volume"
                aria-valuetext={`${percent}%`}
                className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
              />
            </div>

            <span className="font-title w-12 text-right font-mono text-[14px] tabular-nums text-emerald-300">
              {percent}%
            </span>
          </div>

          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={onSfx}
              aria-pressed={sfxEnabled && !muted}
              className="press font-title flex min-h-[44px] items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-[12px] text-white transition hover:border-white/25 hover:bg-white/[0.09]"
            >
              <span className="flex items-center gap-1.5">
                <TargetIcon />
                <span>{tr(language, 'Efek Suara')}</span>
              </span>
              <TactileSwitch on={sfxEnabled && !muted} />
            </button>
            <button
              type="button"
              onClick={onMusic}
              aria-pressed={musicEnabled}
              className="press font-title flex min-h-[44px] items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 text-[12px] text-white transition hover:border-white/25 hover:bg-white/[0.09]"
            >
              <span className="flex items-center gap-1.5">
                <MusicBarsIcon />
                <span>{tr(language, 'Musik Latar')}</span>
              </span>
              <TactileSwitch on={musicEnabled} />
            </button>
          </div>
        </section>

        {/* Speed & Tempo Gear Controls */}
        <section className="mt-3.5 rounded-xl border border-white/12 bg-[#070d12]/80 p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 font-title text-[11px] tracking-[0.14em] text-amber-300">
              <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 shrink-0" fill="currentColor" aria-hidden="true">
                <path d="M13.5 2 5 13.2h6.2L9.8 22 19 10.6h-6.1L13.5 2Z" />
              </svg>
              <span>{tr(language, 'KECEPATAN GAME')}</span>
            </span>
            <span className="font-mono text-[11px] font-black tabular-nums text-amber-200">
              {formatSpeed(speed)}
            </span>
          </div>
          <div className="mt-2 grid grid-cols-4 gap-1.5">
            {speedOptions.map((spd) => {
              const active = speed === spd;
              return (
                <button
                  key={spd}
                  type="button"
                  aria-pressed={active}
                  onClick={() => onSpeed(spd)}
                  className={`press min-h-[44px] whitespace-nowrap rounded-xl border px-1 py-1.5 text-center transition ${
                    active
                      ? 'border-amber-300/90 bg-amber-400/22 text-amber-100 shadow-[0_0_12px_rgba(251,191,36,0.28)]'
                      : 'border-white/10 bg-white/[0.04] text-slate-300/80 hover:border-white/25 hover:bg-white/10'
                  }`}
                >
                  <span className="block font-mono text-xs font-black tracking-wide tabular-nums">
                    {formatSpeed(spd)}
                  </span>
                  <span className="mt-0.5 block text-[8.5px] font-bold tracking-wider opacity-70">
                    {spd === 1 ? 'NORMAL' : 'TURBO'}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-white/10 pt-2.5">
            <span className="font-title text-[10.5px] tracking-[0.12em] text-slate-300/75">
              {tr(language, 'KECEPATAN')}
            </span>
            <div className="flex gap-1 rounded-lg border border-white/12 bg-black/45 p-1">
              {bulletPresets.map((bsp) => {
                const active = Math.abs(bulletSpeed - bsp) < 0.08;
                return (
                  <button
                    key={bsp}
                    type="button"
                    aria-pressed={active}
                    onClick={() => onBulletSpeed(bsp)}
                    className={`min-h-[34px] min-w-[42px] whitespace-nowrap rounded-md px-2 font-mono text-[11px] font-black tabular-nums transition ${
                      active
                        ? 'bg-sky-400/25 text-sky-200 shadow-[inset_0_0_0_1px_rgba(125,211,252,0.55)]'
                        : 'text-slate-300/70 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {bsp.toFixed(1)}x
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Background Theme Selector */}
        <section className="mt-3.5 rounded-xl border border-white/10 bg-black/30 p-3">
          <div className="flex items-baseline justify-between">
            <span className="font-title text-[11px] tracking-[0.14em] text-slate-300/65">
              {tr(language, 'TEMA LATAR')}
            </span>
            <span className="font-title text-[11px] text-amber-300">
              {tr(language, selectedTheme?.label ?? '')}
            </span>
          </div>
          <div
            ref={stripRef}
            className="no-scrollbar smooth-scroll -mx-1 mt-2 flex snap-x snap-proximity gap-2 overflow-x-auto px-1 py-1"
            style={{
              WebkitMaskImage: 'linear-gradient(90deg,transparent,#000 10px,#000 calc(100% - 10px),transparent)',
              maskImage: 'linear-gradient(90deg,transparent,#000 10px,#000 calc(100% - 10px),transparent)',
            }}
          >
            {themes.map((item) => {
              const active = theme === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-theme={item.id}
                  onClick={() => onTheme(item.id)}
                  title={tr(language, item.desc)}
                  aria-pressed={active}
                  className="press relative flex h-[60px] w-[58px] shrink-0 snap-center flex-col items-center justify-center gap-1 rounded-xl border-2 transition"
                  style={{
                    borderColor: active ? '#f59e0b' : 'rgba(255,255,255,0.14)',
                    background: item.swatch,
                    boxShadow: active ? '0 0 0 2px rgba(245,158,11,0.32), 0 4px 12px rgba(0,0,0,0.5)' : '0 2px 0 rgba(0,0,0,0.4)',
                    transform: active ? 'translateY(-1px)' : undefined,
                  }}
                >
                  <span className="text-[19px] leading-none drop-shadow">{item.icon}</span>
                  <span className="font-title text-[8.5px] leading-none text-white drop-shadow">{tr(language, item.label)}</span>
                  {active && (
                    <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-[4px] border border-emerald-200 bg-emerald-500 text-white shadow">
                      <svg viewBox="0 0 12 12" className="h-2.5 w-2.5" fill="none" aria-hidden="true">
                        <path d="M2.5 6.3 5 8.8 9.6 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* Language & Navigation Actions */}
        <section className="mt-3.5 rounded-xl border border-white/10 bg-black/35 p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="font-title text-[11px] tracking-[0.14em] text-slate-300/70">
              {t(language, 'settings.language')}
            </span>
            <div className="flex gap-1 rounded-lg border border-white/15 bg-black/45 p-1">
              {LANGUAGES.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => onLanguage(option.id)}
                  aria-pressed={language === option.id}
                  aria-label={option.label}
                  className={`min-h-[36px] min-w-[44px] rounded-md px-3 py-1 font-title text-[11px] tracking-wider transition ${
                    language === option.id
                      ? 'bg-amber-400 text-[#140e04] shadow-[inset_0_1px_0_rgba(255,255,255,0.4)]'
                      : 'text-slate-300/75 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {option.short}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-2.5 grid grid-cols-1 gap-2">
            <button
              type="button"
              onClick={onHelp}
              className="press font-title flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-sky-300/30 bg-sky-400/12 px-3 text-[12px] text-sky-100 transition hover:bg-sky-400/20"
            >
              {t(language, 'settings.help')}
            </button>
            <button
              type="button"
              onClick={onCodex}
              className="press font-title flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-fuchsia-300/30 bg-fuchsia-500/12 px-3 text-[12px] text-fuchsia-100 transition hover:bg-fuchsia-500/20"
            >
              {t(language, 'settings.codex')}
            </button>
            <button
              type="button"
              onClick={onReset}
              className="press font-title flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-rose-400/35 bg-rose-500/12 px-3 text-[12px] text-rose-200 transition hover:bg-rose-500/20"
            >
              {t(language, 'settings.reset')}
            </button>
          </div>
        </section>

        <button
          type="button"
          onClick={onPrivacy}
          className="press mt-2.5 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/[0.05] px-3 font-title text-[12px] text-slate-200 transition hover:bg-white/10"
        >
          <LockShieldIcon />
          <span>{tr(language, 'KEBIJAKAN PRIVASI')}</span>
        </button>

        <button
          type="button"
          onClick={onClose}
          className="press shine font-title mt-2.5 h-12 w-full rounded-xl border-2 border-[#0e5a26] bg-gradient-to-b from-[#6fe863] via-[#34c743] to-[#1a8e31] text-[16px] tracking-wide text-white shadow-[0_4px_0_#0e5a26,inset_0_1px_0_rgba(255,255,255,0.45)]"
          style={{ textShadow: '0 2px 0 #0e5a26' }}
        >
          {tr(language, 'SIMPAN & KEMBALI')}
        </button>
      </section>
    </div>
  );
}
