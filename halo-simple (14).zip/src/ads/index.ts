/**
 * Fasad monetisasi lintas portal.
 *
 * Portal web melarang SDK iklan milik portal lain, jadi provider dipilih dari
 * hostname, ancestor/referrer Poki, global window.PokiSDK (Poki Inspector),
 * env build VITE_ADS_PLATFORM, atau override ?ads=poki / ?ads=crazygames.
 *
 *   Capacitor native → Google AdMob (@capacitor-community/admob)
 *   Poki / Inspector → Poki SDK v2 (commercialBreak + rewardedBreak)
 *   *.crazygames.com → CrazyGames SDK v3 (dengan opsi wrapper yang diwajibkan QA)
 *   lainnya          → standalone: tanpa iklan jaringan; pemanggil memutuskan
 *                      fallback dev-nya (simulasi AdPlayer di game over).
 *
 * Semua fungsi tidak pernah throw dan tidak pernah menghentikan permainan.
 */
import type { AdSize, AdsProvider, PortalStore } from './poki';
import { createMemoryStore } from '../games/gunhit/game/safeStorage';
import { trackAdRewarded } from '../telemetry/gameAnalytics';

export type AdOutcome = 'shown' | 'denied' | 'unavailable';
export type AdsPlatform = 'poki' | 'crazygames' | 'native' | 'standalone';

export interface AdsPlatformProbe {
  hostname?: string;
  search?: string;
  isNative?: boolean;
}

function isPokiHost(rawHost: string): boolean {
  const host = rawHost.toLowerCase();
  return (
    host === 'poki.com' ||
    host.endsWith('.poki.com') ||
    host === 'poki-gdn.com' ||
    host.endsWith('.poki-gdn.com') ||
    host === 'poki.io' ||
    host.endsWith('.poki.io') ||
    host === 'poki.dev' ||
    host.endsWith('.poki.dev')
  );
}

function isCrazyGamesHost(rawHost: string): boolean {
  const host = rawHost.toLowerCase();
  return host === 'crazygames.com' || host.endsWith('.crazygames.com');
}

function extractHost(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

/**
 * Deteksi platform. `probe` opsional = seam unit test (sehingga tes tidak
 * perlu memalsukan window); tanpa probe ia membaca window seperti biasa.
 */
export function detectAdsPlatform(probe?: AdsPlatformProbe): AdsPlatform {
  const isNative = probe?.isNative ?? (() => {
    if (typeof window === 'undefined') return false;
    try {
      const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
      return !!cap?.isNativePlatform?.();
    } catch { return false; }
  })();
  if (isNative) return 'native';

  const search = probe?.search ?? (typeof window === 'undefined' ? '' : window.location.search);
  const forced = new URLSearchParams(search).get('ads');
  if (forced === 'poki' || forced === 'crazygames') return forced;

  const host = (probe?.hostname ?? (typeof window === 'undefined' ? '' : window.location.hostname)).toLowerCase();
  if (isCrazyGamesHost(host)) return 'crazygames';
  if (isPokiHost(host)) return 'poki';

  if (!probe && typeof window !== 'undefined') {
    const buildPlatform = (import.meta as unknown as { env?: Record<string, string | undefined> }).env?.VITE_ADS_PLATFORM;
    if (buildPlatform === 'poki' || buildPlatform === 'crazygames') return buildPlatform;

    try {
      const refHost = typeof document !== 'undefined' && document.referrer ? extractHost(document.referrer) : '';
      if (refHost && isPokiHost(refHost)) return 'poki';
    } catch { /* abaikan */ }

    try {
      const origins = window.location.ancestorOrigins;
      if (origins) {
        for (let i = 0; i < origins.length; i++) {
          if (isPokiHost(extractHost(origins[i]))) return 'poki';
        }
      }
    } catch { /* abaikan */ }

    const w = window as unknown as { PokiSDK?: unknown; CrazyGames?: unknown };
    if (w.PokiSDK && !w.CrazyGames) return 'poki';
  }

  return 'standalone';
}

let providerPromise: Promise<AdsProvider | null> | null = null;

/** Iklan yang benar-benar tampil, menunggu untuk disinkronkan ke server. */
let pendingAdsWatched = 0;
let lastRewardedAdAt = 0;

export function peekAdsWatchedPending(): number {
  return pendingAdsWatched;
}

/** Dipanggil klien setelah server mengakui sinkronnya. */
export function commitAdsWatched(count: number): void {
  pendingAdsWatched = Math.max(0, pendingAdsWatched - count);
}

function getProvider(): Promise<AdsProvider | null> {
  if (providerPromise) return providerPromise;
  const platform = detectAdsPlatform();
  if (platform === 'standalone') {
    providerPromise = Promise.resolve(null);
  } else if (platform === 'native') {
    providerPromise = import('./admob').then((m) => m.loadAdMobProvider());
  } else if (platform === 'poki') {
    providerPromise = import('./poki').then((m) => m.loadPokiProvider());
  } else {
    providerPromise = import('./crazygames').then((m) => m.loadCrazyGamesProvider());
  }
  // Kegagalan load/init tidak di-cache: script portal bisa saja telat tiba.
  providerPromise = providerPromise.then((p) => {
    if (!p) providerPromise = null;
    return p;
  });
  return providerPromise;
}

/**
 * Panggil sedini mungkin (boot halaman). Mengembalikan promise yang selesai
 * setelah provider termuat *dan* (portal) SDK.init() resolve — urutan wajib
 * sebelum save progres dibaca. Portal yang SDK-nya gagal mendapat toko memori,
 * sehingga localStorage tidak pernah tercampur di sana.
 */
export function initAds(): Promise<void> {
  return getProvider().then((p) => {
    const platform = detectAdsPlatform();
    if (platform === 'crazygames') {
      portalStore = p?.getDataStore?.() ?? createMemoryStore();
      if (p) {
        try { if (p.readMuted?.()) setPortalSettingMuted(true); } catch { /* abaikan */ }
        try { p.onMutedChange?.(setPortalSettingMuted); } catch { /* abaikan */ }
        try { portalLocale = p.readLocale?.() ?? ''; } catch { /* abaikan */ }
        try { portalDeviceType = p.readDeviceType?.() ?? ''; } catch { /* abaikan */ }
      } else if (typeof window !== 'undefined' && /[?&]muteAudio=true/.test(window.location.search)) {
        setPortalSettingMuted(true);
      }
    }
    p?.loadingStarted();
  });
}

let loadingFinished = false;

/* ------------------------- mute portal, iklan, & tab tersembunyi ------------------------ */
let portalMuted = false;
let adMuted = false;
let tabMuted = typeof document !== 'undefined' ? document.hidden : false;
let effectiveMuted = tabMuted;

try {
  // Tes lokal tanpa SDK: ?muteAudio=true memaksa mute (aturan: menang atas tombol game).
  if (typeof window !== 'undefined' && /[?&]muteAudio=true/.test(window.location.search)) {
    portalMuted = true;
    effectiveMuted = true;
  }
} catch { /* abaikan */ }

const portalMuteListeners = new Set<(muted: boolean) => void>();

function syncEffectiveMute(): void {
  const next = portalMuted || adMuted || tabMuted;
  if (effectiveMuted === next) return;
  effectiveMuted = next;
  portalMuteListeners.forEach((listener) => listener(next));
}

if (typeof document !== 'undefined') {
  const syncTabVisibility = () => {
    tabMuted = document.hidden;
    syncEffectiveMute();
  };
  document.addEventListener('visibilitychange', syncTabVisibility);
  if (typeof window !== 'undefined') {
    window.addEventListener('pagehide', () => {
      tabMuted = true;
      syncEffectiveMute();
    });
    window.addEventListener('pageshow', syncTabVisibility);
  }
}

function setPortalSettingMuted(next: boolean): void {
  portalMuted = next;
  syncEffectiveMute();
}

function setAdMuted(next: boolean): void {
  adMuted = next;
  syncEffectiveMute();
}

/** Status mute portal/iklan sekarang (termasuk override tes lokal ?muteAudio=true). */
export function isPortalMuted(): boolean {
  return effectiveMuted;
}

/** Langganan perubahan mute portal/iklan; cb dipanggil seketika dengan nilai kini. */
export function onPortalMuted(cb: (muted: boolean) => void): () => void {
  portalMuteListeners.add(cb);
  cb(effectiveMuted);
  return () => { portalMuteListeners.delete(cb); };
}

/* ------------------------- locale portal (system info) ------------------------ */
let portalLocale = '';
let portalDeviceType = '';
export function getPortalLocale(): string { return portalLocale; }
/** Jenis perangkat dari system-info portal (kosong = portal tak menjawab). */
export function getPortalDeviceType(): string { return portalDeviceType; }

/* ------------------------- save progres portal (SDK.data) ------------------------ */
let portalStore: PortalStore | null = null;
/** Backend penyimpanan ala localStorage dari portal (null = bukan platform portal). */
export function getPortalDataStore(): PortalStore | null {
  return portalStore;
}


/** Konversi loading→main (Poki) / loadingStop (CrazyGames). Tembak sekali. */
export function adsLoadingFinished(): void {
  if (loadingFinished) return;
  void getProvider().then((p) => {
    if (!p || loadingFinished) return;
    loadingFinished = true;
    p.loadingFinished();
  });
}

let playing = false;

/** Gameplay aktif (mulai/lanjut run). */
export function adsGameplayStart(): void {
  if (playing) return;
  playing = true;
  void getProvider().then((p) => p?.gameplayStart());
}

/** Gameplay berhenti (game over, menu, pause) — WAJIB sebelum setiap iklan. */
export function adsGameplayStop(): void {
  if (!playing) return;
  playing = false;
  void getProvider().then((p) => p?.gameplayStop());
}

/**
 * Commercial break (Poki midgame / jeda alami saat retry atau antar ronde).
 * Menghentikan gameplay, membisukan seluruh audio selama iklan berlangsung, dan
 * mengembalikan status mute pemain setelah iklan selesai tanpa pernah melempar error.
 */
export async function adsCommercialBreak(hooks?: { onAdStart?: () => void }): Promise<void> {
  const platform = detectAdsPlatform();
  if (platform === 'standalone') return;
  if (Date.now() - lastRewardedAdAt < 8000) return;
  const provider = await getProvider();
  if (!provider) return;
  const resumeAfter = playing;
  adsGameplayStop();
  setAdMuted(true);
  try {
    await provider.commercialBreak(() => {
      hooks?.onAdStart?.();
    });
  } catch {
    /* tanpa iklan pun lanjut */
  } finally {
    setAdMuted(false);
    if (resumeAfter) adsGameplayStart();
  }
}

/**
 * Rewarded video lintas portal.
 *  - 'shown'       → iklan tuntas → hadiah cair;
 *  - 'denied'      → ditutup/di-skip/unfilled → TANPA hadiah (jangan fallback);
 *  - 'unavailable' → tidak ada portal ads (dev/standalone) → caller boleh pakai
 *                    simulasi internal.
 */
export async function adsRewardedBreak(
  placement: string,
  size: AdSize,
  hooks?: { onAdStart?: () => void },
): Promise<AdOutcome> {
  const platform = detectAdsPlatform();
  const provider = await getProvider();
  // 'unavailable' (simulasi dev) HANYA untuk build standalone: di domain portal
  // QA melihat AdPlayer tiruan sebagai ad code pihak ketiga — dilarang.
  if (!provider) return platform === 'standalone' ? 'unavailable' : 'denied';
  const resumeAfter = playing;
  let adShown = false;
  adsGameplayStop();
  setAdMuted(true);
  try {
    const outcome = await provider.rewardedBreak(placement, size, () => {
      adShown = true;
      hooks?.onAdStart?.();
    });
    if (outcome === 'shown') {
      lastRewardedAdAt = Date.now();
      if (adShown) pendingAdsWatched += 1;
    }
    trackAdRewarded({ placement, outcome });
    return outcome;
  } catch {
    trackAdRewarded({ placement, outcome: 'denied' });
    return 'denied';
  } finally {
    setAdMuted(false);
    if (resumeAfter) adsGameplayStart();
  }
}

/** Panggil di momen seru: stage clear, bos tumbang, rekor baru. */
let lastHappy = 0;
export function adsHappytime(): void {
  const now = Date.now();
  if (now - lastHappy < 3000) return; // jangan spam event portal
  lastHappy = now;
  void getProvider().then((p) => p?.happytime?.());
}

/** Portal reward buttons harus disembunyikan bila pemain memakai adblock. */
export async function adsHasAdblock(): Promise<boolean> {
  const provider = await getProvider();
  if (!provider?.hasAdblock) return false;
  return provider.hasAdblock();
}
