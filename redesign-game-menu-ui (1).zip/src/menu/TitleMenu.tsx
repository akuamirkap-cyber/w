import { ReactNode } from 'react';
import { audioInit, snd } from '../game/ragdoll/audio';
import { tx } from '../i18n';
import { LangToggle } from '../LangToggle';
import './menu.css';

/* ---------- logo ---------- */

const NAVY = '#0a1a52';
const DEEP = '#050d38';

function Logo() {
  const top = { x: 100, y: 124, fontSize: 126, textLength: 462, lengthAdjust: 'spacingAndGlyphs' as const };
  const bot = { x: 104, y: 240, fontSize: 138, textLength: 492, lengthAdjust: 'spacingAndGlyphs' as const };
  const edge = { strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const };
  return (
    <svg viewBox="0 0 690 280" role="img" aria-hidden>
      <defs>
        <linearGradient id="mm-word-a" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset="0.52" stopColor="#ffffff" />
          <stop offset="0.56" stopColor="#d6ecff" />
          <stop offset="1" stopColor="#8fc8ff" />
        </linearGradient>
        <linearGradient id="mm-word-b" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff27a" />
          <stop offset="0.46" stopColor="#ffc928" />
          <stop offset="0.52" stopColor="#ffa91c" />
          <stop offset="1" stopColor="#f56f0a" />
        </linearGradient>
      </defs>

      <g transform="rotate(-4 345 140)">
        {/* deep drop behind everything */}
        <g transform="translate(0 11)" fill={DEEP} stroke={DEEP} strokeWidth="24" {...edge}>
          <text {...top}>RAGDOLL</text>
          <text {...bot}>ARCHER</text>
        </g>

        {/* the arrow threading between both words */}
        <g transform="translate(20 158) rotate(-3.2)">
          <path d="M26 0H604" stroke={NAVY} strokeWidth="17" strokeLinecap="round" />
          <path d="M26 0H604" stroke="#f79a16" strokeWidth="8.5" strokeLinecap="round" />
          <path d="M28 -2H602" stroke="#ffcf5a" strokeWidth="3" strokeLinecap="round" />
          <g stroke={NAVY} strokeWidth="5.5" strokeLinejoin="round">
            <path d="M8-5L-12-30H42L70-5Z" fill="#f2413a" />
            <path d="M8 5L-12 30H42L70 5Z" fill="#cf2630" />
            <path d="M-4-5L-22-24H2L22-5ZM-4 5L-22 24H2L22 5Z" fill="#ff6a5c" />
          </g>
          <path d="M600-24L662 0L600 24L614 0Z" fill="#cfdae6" stroke={NAVY} strokeWidth="6" strokeLinejoin="round" />
          <path d="M604-18L652 0H616Z" fill="#ffffff" />
        </g>

        <g fill={NAVY} stroke={NAVY} strokeWidth="21" {...edge}>
          <text {...top}>RAGDOLL</text>
          <text {...bot}>ARCHER</text>
        </g>
        <text {...top} fill="url(#mm-word-a)">RAGDOLL</text>
        <text {...bot} fill="url(#mm-word-b)">ARCHER</text>
      </g>
    </svg>
  );
}

/* ---------- icons ---------- */

const ico = { viewBox: '0 0 24 24', 'aria-hidden': true } as const;

const PlayIcon = () => (
  <svg {...ico}>
    <path d="M7 3.6v16.8a1.2 1.2 0 0 0 1.8 1L22 13a1.2 1.2 0 0 0 0-2L8.800 2.600A1.200 1.200 0 0 0 7 3.600z" fill="#fff" stroke={NAVY} strokeWidth="1.6" strokeLinejoin="round" />
  </svg>
);

const BowIcon = () => (
  <svg {...ico}>
    <path d="M8 2.500C16 4.500 19.500 9 19.500 12S16 19.500 8 21.500" fill="none" stroke={NAVY} strokeWidth="5.200" strokeLinecap="round" />
    <path d="M8 2.500C16 4.500 19.500 9 19.500 12S16 19.500 8 21.500" fill="none" stroke="#fff6d6" strokeWidth="2.800" strokeLinecap="round" />
    <path d="M8 2.500v19" stroke="#e9f4ff" strokeWidth="1.300" />
    <path d="M2.500 12H18" stroke={NAVY} strokeWidth="4" strokeLinecap="round" />
    <path d="M2.500 12H18" stroke="#ffd53e" strokeWidth="1.900" strokeLinecap="round" />
    <path d="M17 8.500l5.500 3.500-5.500 3.500z" fill="#fff" stroke={NAVY} strokeWidth="1.300" strokeLinejoin="round" />
  </svg>
);

const SkinIcon = () => (
  <svg {...ico}>
    <path d="M3.500 3l4.700 3.200h7.600L20.500 3v10.200a8.500 8.500 0 0 1-17 0z" fill="#eaf6ff" stroke={NAVY} strokeWidth="1.600" strokeLinejoin="round" />
    <path d="M3.500 9.200h17v4.200h-17z" fill="#ff5a52" />
    <path d="M6.200 10.200l4.300 1.100-1 2H6.800zM17.800 10.200l-4.300 1.100 1 2h2.700z" fill="#0a1a52" />
    <path d="M10 17.600c1.300.9 2.700.9 4 0" stroke="#0a1a52" strokeWidth="1.400" strokeLinecap="round" fill="none" />
  </svg>
);

const BookIcon = () => (
  <svg {...ico}>
    <path d="M2.500 4.500h7.200c1.300 0 2.300.8 2.300 2 0-1.200 1-2 2.300-2h7.200v14.800h-7.200c-1.300 0-2.300.6-2.300 1.600 0-1-1-1.600-2.300-1.600H2.500z" fill="#fff" stroke={NAVY} strokeWidth="1.600" strokeLinejoin="round" />
    <path d="M12 6.500v14" stroke={NAVY} strokeWidth="1.400" />
    <path d="M5 8.500h4.300M5 11.500h4.300M5 14.500h4.300M14.700 8.500H19M14.700 11.500H19M14.700 14.500H19" stroke="#f08a92" strokeWidth="1.400" strokeLinecap="round" />
  </svg>
);

const TreeIcon = () => (
  <svg {...ico}>
    <g fill="none" stroke={NAVY} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 21V10.500M5 5.500v4l7 4 7-4v-4" />
    </g>
    <g fill="none" stroke="#ffd53e" strokeWidth="2.400" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 21V10.500M5 5.500v4l7 4 7-4v-4" />
    </g>
    <g fill="#ffe680" stroke={NAVY} strokeWidth="1.300">
      <circle cx="5" cy="4.500" r="2.900" />
      <circle cx="12" cy="7.500" r="2.900" />
      <circle cx="19" cy="4.500" r="2.900" />
      <circle cx="12" cy="20.500" r="2.600" />
    </g>
  </svg>
);

const CalendarIcon = () => (
  <svg {...ico}>
    <rect x="2.800" y="4.200" width="18.400" height="17" rx="3" fill="#fff" stroke={NAVY} strokeWidth="1.600" />
    <path d="M2.800 7.200a3 3 0 0 1 3-3h12.400a3 3 0 0 1 3 3v2.600H2.800z" fill="#e052d8" stroke={NAVY} strokeWidth="1.600" strokeLinejoin="round" />
    <path d="M7.500 2.200v4M16.500 2.200v4" stroke={NAVY} strokeWidth="3.400" strokeLinecap="round" />
    <path d="M7.500 2.200v4M16.500 2.200v4" stroke="#fff" strokeWidth="1.500" strokeLinecap="round" />
    <g fill="#7b5cf0">
      <rect x="6" y="12" width="3" height="2.700" rx=".6" />
      <rect x="10.500" y="12" width="3" height="2.700" rx=".6" />
      <rect x="15" y="12" width="3" height="2.700" rx=".6" />
      <rect x="6" y="16.200" width="3" height="2.700" rx=".6" />
      <rect x="10.500" y="16.200" width="3" height="2.700" rx=".6" />
    </g>
  </svg>
);

/* ---------- pieces ---------- */

function MBtn({ tone, className = '', label, onClick, children }: { tone: string; className?: string; label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={() => {
        audioInit();
        snd.tap();
        onClick();
      }}
      className={`m-btn m-${tone} ${className}`}
    >
      {children}
    </button>
  );
}

export interface ClassicMode {
  name: string;
  icon: ReactNode;
  go: () => void;
}

interface Props {
  launching: boolean;
  best: number;
  coins: number;
  mute: boolean;
  onMute: () => void;
  cleared: number;
  levels: number;
  modes: ClassicMode[];
  classicOpen: boolean;
  setClassicOpen: (open: boolean) => void;
  bowName: string;
  skinName: string;
  onPlay: () => void;
  onBow: () => void;
  onSkin: () => void;
  onCodex: () => void;
  onSkillTree: () => void;
  onDaily: () => void;
  onFort: () => void;
}

export default function TitleMenu(p: Props) {
  const tap = (fn: () => void) => () => {
    audioInit();
    snd.tap();
    fn();
  };
  const up = p.launching ? 'g-title-exit-up' : 'g-drop';
  const down = p.launching ? 'g-dock-exit-down' : 'g-dock-enter';

  return (
    <div className="m-vars m-ui" onClick={() => p.classicOpen && p.setClassicOpen(false)}>
      {/* ---------- corner controls ---------- */}
      <div className={`m-top ${up}`} onClick={(e) => e.stopPropagation()}>
        <div className="m-top-row relative">
          <LangToggle compact />
          <button
            type="button"
            className={`m-chip m-chip-btn ${p.classicOpen ? 'ring-2 ring-[#ffd53e]' : ''}`}
            style={{ paddingLeft: 10 }}
            aria-expanded={p.classicOpen}
            aria-label={tx('Other classic game modes', 'Mode permainan klasik lainnya')}
            title={tx('Other classic game modes', 'Mode permainan klasik lainnya')}
            onClick={tap(() => p.setClassicOpen(!p.classicOpen))}
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
              <path d="M4 4h6.500v6.500H4zM13.500 4H20v6.500h-6.500zM4 13.500h6.500V20H4zM13.500 13.500H20V20h-6.500z" fill="currentColor" />
            </svg>
            <span>{tx('MODES', 'MODE')}</span>
          </button>
          <button
            type="button"
            className="m-chip m-chip-btn m-chip-icon"
            aria-label={p.mute ? tx('Unmute sound', 'Nyalakan suara') : tx('Mute sound', 'Matikan suara')}
            title={p.mute ? tx('Unmute sound', 'Nyalakan suara') : tx('Mute sound', 'Matikan suara')}
            onClick={tap(p.onMute)}
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
              <path d="M4 9.500h3.500L12 5.500v13l-4.500-4H4z" fill="currentColor" />
              {p.mute ? (
                <path d="M15 9.500l5 5m0-5l-5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
              ) : (
                <path d="M15 8.500a5 5 0 0 1 0 7M17.500 6a8.500 8.500 0 0 1 0 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
              )}
            </svg>
          </button>

          {p.classicOpen && (
            <div className="m-pop g-pop">
              <div className="mb-2 flex items-center justify-between px-1">
                <span className="text-xs font-extrabold tracking-wider text-[#ffd53e] italic">{tx('CLASSIC MODES', 'MODE KLASIK')}</span>
                <span className="text-[10px] font-bold text-[#a9d2ff]">{p.cleared}/{p.levels} {tx('missions', 'misi')}</span>
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {p.modes.map((m) => (
                  <button key={m.name} type="button" title={m.name} className="m-pop-item" onClick={tap(() => { p.setClassicOpen(false); m.go(); })}>
                    {m.icon}
                    <span>{m.name}</span>
                  </button>
                ))}
              </div>
              <button
                type="button"
                className="m-pop-item m-pop-wide"
                title={tx('Start directly at Level 2 to face the Sturdy Wooden Fort', 'Langsung mulai di Level 2 untuk menghadapi Istana Kayu Kokoh')}
                onClick={tap(() => { p.setClassicOpen(false); p.onFort(); })}
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
                  <path d="M3 3h4v3h3V3h4v3h3V3h4v8l-2 2v8H5v-8l-2-2z" fill="currentColor" />
                </svg>
                <span>{tx('Quick Test Lv.2: Wooden Fort', 'Uji Lv.2: Istana Kayu')}</span>
              </button>
            </div>
          )}
        </div>

        <div className="m-top-row">
          <div className="m-chip" aria-label={tx(`Best level ${p.best}`, `Level terbaik ${p.best}`)}>
            <span className="relative grid h-6 w-6 place-items-center">
              <svg viewBox="0 0 44 44" className="absolute inset-0 h-full w-full" aria-hidden>
                <path d="M3 2h8v6h6V2h10v6h6V2h8v15l-4 4v21H7V21l-4-4z" fill="#2f8df7" stroke="#0a1a52" strokeWidth="2.500" strokeLinejoin="round" />
              </svg>
              <span className="relative pt-1 text-[11px] tabular-nums">{p.best}</span>
            </span>
            <small>{tx('BEST LV', 'REKOR LV')}</small>
          </div>
          <div className="m-chip" aria-label={tx(`Coins ${p.coins}`, `Koin ${p.coins}`)}>
            <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
              <circle cx="12" cy="12" r="9.500" fill="#ffb61f" stroke="#0a1a52" strokeWidth="1.800" />
              <circle cx="12" cy="12" r="6" fill="#ffe27a" />
              <path d="M12 8.200v7.600" stroke="#e98a00" strokeWidth="2.200" strokeLinecap="round" />
            </svg>
            <span className="text-[#ffd53e] tabular-nums">{p.coins}</span>
          </div>
        </div>
      </div>

      {/* ---------- logo + buttons ---------- */}
      <div className="m-stack">
        <div className={p.launching ? 'g-title-exit-up' : 'g-logo-enter'}>
          <h1 aria-label="Ragdoll Archer" className="m-logo g-float">
            <Logo />
          </h1>
        </div>

        <div className={`pointer-events-auto ${p.launching ? 'g-dock-exit-down' : 'g-cta-enter'}`} style={{ marginTop: 'calc(var(--u) * 2)' }}>
          <div className="g-pulse">
            <MBtn tone="play" className="g-sheen" label={tx('Start playing', 'Mulai bermain')} onClick={p.onPlay}>
              <PlayIcon />
              <span>{tx('PLAY', 'MAIN')}</span>
            </MBtn>
          </div>
        </div>

        <div className={`m-row m-row3 pointer-events-auto ${down}`}>
          <MBtn tone="green" label={tx(`Select Bow (${p.bowName})`, `Pilih Busur (${p.bowName})`)} onClick={p.onBow}>
            <BowIcon />
            <span>{tx('BOW', 'BUSUR')}</span>
          </MBtn>
          <MBtn tone="blue" label={tx(`Change Head Skin (Active: ${p.skinName})`, `Ganti Skin Kepala (Aktif: ${p.skinName})`)} onClick={p.onSkin}>
            <SkinIcon />
            <span>SKIN</span>
          </MBtn>
          <MBtn tone="red" label={tx('Codex of Enemies, Wooden Fort & 5 Bosses', 'Kamus Musuh, Istana Kayu & 5 Bos')} onClick={p.onCodex}>
            <BookIcon />
            <span>{tx('CODEX', 'KAMUS')}</span>
          </MBtn>
        </div>

        <div className={`m-row m-row2 pointer-events-auto ${down}`}>
          <MBtn tone="navy" className="m-gold" label={tx('Skill tree, progress, unlocks & stats', 'Skill tree, progres, unlock & statistik')} onClick={p.onSkillTree}>
            <TreeIcon />
            <span>SKILL TREE</span>
          </MBtn>
          <MBtn tone="navy" label={tx('Daily challenge', 'Tantangan harian')} onClick={p.onDaily}>
            <CalendarIcon />
            <span>{tx('DAILY', 'HARIAN')}</span>
          </MBtn>
        </div>
      </div>
    </div>
  );
}
