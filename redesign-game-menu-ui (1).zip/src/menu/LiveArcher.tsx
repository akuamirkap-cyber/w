import { useEffect, useRef } from 'react';
import { v } from '../game/util';
import { BowId, drawArrow, makeStick } from '../game/ragdoll/stick';
import { HeadStyle, makeHair } from '../game/ragdoll/head';
import { newSkinRuntime } from '../game/ragdoll/skinPerks';
import { drawSkinShot } from '../game/ragdoll/skinFx';
import { drawSkinFigure, stepSkinStage } from '../SkinModal';

/* The real in-game archer on a transparent canvas: same ragdoll body, same
   renderer, same skin and bow as gameplay. He stands, draws, looses an arrow
   and reloads on a loop, so menus show exactly who you play as. */

const STEP = 1 / 120;
type Sim = Parameters<typeof stepSkinStage>[0] & { acc: number };

interface Props {
  skin: HeadStyle;
  bow: BowId;
  /** freeze the simulation (covered by a modal, off screen…) */
  paused?: boolean;
  /** world units that fit in the canvas height: smaller = bigger archer */
  units?: number;
  /** where his feet stand, as fractions of the canvas */
  ox?: number;
  oy?: number;
  /** seconds an arrow stays visible after release */
  arrowLife?: number;
  onShot?: () => void;
  className?: string;
}

export default function LiveArcher({ skin, bow, paused = false, units = 140, ox = 0.5, oy = 0.9, arrowLife = 0.7, onShot, className }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const simRef = useRef<Sim | null>(null);
  const live = useRef({ skin, bow, units, ox, oy, arrowLife, onShot });
  live.current = { skin, bow, units, ox, oy, arrowLife, onShot };

  // a new skin grows its own hair and perks on the same body
  useEffect(() => {
    const s = simRef.current;
    if (!s) return;
    s.hair = makeHair(skin, s.k);
    s.skin = skin;
    s.perks = newSkinRuntime();
    s.arrows = [];
  }, [skin]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    if (!simRef.current) {
      const k = makeStick(v(0, 0), 1, 1, false, true);
      simRef.current = { k, hair: makeHair(live.current.skin, k), cyc: 0.9, arrows: [], acc: 0, skin: live.current.skin, perks: newSkinRuntime() };
      // let him settle into his stance before the first frame
      for (let i = 0; i < 90; i++) stepSkinStage(simRef.current);
      simRef.current.arrows = [];
    }
    const sim = simRef.current;
    let raf = 0;
    let prev = 0;
    let rt = 0;

    const paint = () => {
      const o = live.current;
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(8, r.width);
      const h = Math.max(8, r.height);
      const cw = Math.round(w * dpr);
      const ch = Math.round(h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const Z = h / o.units;
      ctx.translate(w * o.ox, h * o.oy);
      ctx.scale(Z, Z);
      drawSkinFigure(ctx, sim.k, o.skin, sim.hair, rt, o.bow);
      for (const a of sim.arrows) {
        if (a.life > o.arrowLife) continue;
        ctx.save();
        ctx.globalAlpha = Math.max(0, Math.min(1, (o.arrowLife - a.life) / (o.arrowLife * 0.4)));
        if (a.skin) drawSkinShot(ctx, a.p, a.vel, a.skin, rt);
        drawArrow(ctx, a.p, Math.atan2(a.vel.y, a.vel.x), 1, false, o.bow, rt);
        ctx.restore();
      }
    };

    const loop = (now: number) => {
      const dt = Math.min(0.05, prev ? (now - prev) / 1000 : 0.016);
      prev = now;
      rt += dt;
      sim.acc += dt;
      let guard = 0;
      while (sim.acc >= STEP && guard++ < 10) {
        const before = sim.arrows.length;
        stepSkinStage(sim);
        if (sim.arrows.length > before) live.current.onShot?.();
        sim.acc -= STEP;
      }
      if (guard >= 10) sim.acc = 0;
      paint();
      raf = requestAnimationFrame(loop);
    };

    if (paused) paint();
    else raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [paused]);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />;
}
